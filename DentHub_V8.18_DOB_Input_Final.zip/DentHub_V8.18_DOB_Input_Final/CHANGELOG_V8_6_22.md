# DentHub V8.6.22 — client workflow + navigation update

## Client-requested fixes

- Treatment history deletion now persists through the clinic API and deleted encounters are hidden from normal history.
- Patient login now shows appointment/visit history only: booked, visited, cancelled, no-show. Detailed performed-treatment data is not exposed in the patient-side history/card.
- Doctors/employees can belong to multiple clinics. Staff can request another clinic, clinics can invite an existing staff member, either side can accept/reject, and accepted staff can switch active clinic.
- Treatment catalog is grouped into 7 clinical heads: Үзлэг, Эмчилгээ, Гажиг засал, Тулгуур эдийн эмчилгээ, Мэс засал, Согог засал, Бусад.
- Clinic owners can customize the registration/health questionnaire without changing code.
- Added Гэрээ module with categorized contract uploads, validity dates, notes, edit and soft-delete.
- Sidebar is grouped into Өдөр тутмын үйл ажиллагаа, Дотоод үйл ажиллагаа, Хамтран үйл ажиллагаа.
- All V8.6.21 compliance/HR/inventory/finance features and the 20 procedure templates are preserved.
- Retired external-site branding references remain removed.
