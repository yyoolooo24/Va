# DentHub V8.12 — Stability & UX Fix

- Clinic logo upload now goes through a server-validated owner endpoint so Storage RLS cannot randomly block legitimate clinic owners.
- Added a safe fallback Storage RLS migration for `clinic-logos`.
- Calendar appointment cards now use an exact pixel height based on appointment duration; a 30-minute visit stays inside one 30-minute row.
- Short appointment cards hide secondary text that cannot fit inside one row.
- Added visible `Түр хүлээнэ үү` busy notices while schedule/form/branding/report data is loading or saving.
- Generic ERP forms now use DentHub's own date picker instead of browser-native date popovers.
- Service/patient/general forms are wider and responsive at 100% browser zoom.
- Report period controls and report metric grids were tightened for normal desktop widths.
- Calendar toolbar/date navigation received a compact layout pass.
