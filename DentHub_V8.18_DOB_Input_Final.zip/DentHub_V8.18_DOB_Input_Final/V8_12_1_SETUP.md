# DentHub V8.12.1 setup

## If V8.12 migration failed with `ERROR: 40P01 deadlock detected`
Do **not** keep rerunning the old `v8_12_stability_ux_fix.sql` file.

Run only:

`supabase/v8_12_1_deadlock_module_picker_fix.sql`

The hotfix is idempotent and intentionally does not recreate policies on `storage.objects`.

Then run:

1. `npm install`
2. `npm run validate:v8.12.1`
3. `npm run build`
4. `npx vercel --prod` only after the build passes.

No data deletion is performed by this migration.
