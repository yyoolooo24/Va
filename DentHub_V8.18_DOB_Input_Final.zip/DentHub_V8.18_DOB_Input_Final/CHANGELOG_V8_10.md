# DentHub V8.10 — Platform Plans & UX

## Platform subscription control
- Added a dedicated **Багцын тохиргоо / Subscription Plans** page to Platform Admin navigation.
- Platform Admin can create, edit, duplicate, activate/deactivate and delete unused plans.
- Each plan stores its default price, billing cycle, duration, employee limit and enabled modules.
- START / GROWTH / NETWORK are seeded into the new persistent plan catalog.
- START remains protected as the registration-default plan: it can be edited but not deactivated or deleted.
- New clinics and clinic approval screens load the plan catalog instead of relying only on hard-coded plan names.

## Faster module permissions
- Replaced the old wall of checkbox cards with a grouped module-access picker.
- Added quick presets, Select all, Clear, group-level selection and module search.
- The same cleaner picker is used for clinic subscriptions, new-clinic setup and staff permissions.
- New clinic creation applies the selected plan automatically; custom module access is one optional click.

## Clinic removal behavior
- Archived clinics are hidden from the normal active list.
- Added Current / Pending / Archive / All views.
- “Remove from active list” now archives the clinic while preserving medical, financial and audit history.
- Permanent delete remains limited to truly empty test clinics and is available from the Archive view.

## UI polish
- Fixed subscription/permission modals so their body actually scrolls while header/footer stay visible.
- Improved the notification popover size, density and scrolling.
- Added visible toast feedback for Platform Admin actions.
- Fixed the login page so a previously saved dark theme cannot produce white text on a light login card.
- Rewrote mixed Mongolian/English platform and auth messages into clearer professional Mongolian.
