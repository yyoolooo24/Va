'use client';

import { useEffect, useState } from 'react';
import { Check, Loader2, X } from 'lucide-react';
import type { PatientXray, XrayMetadataInput } from '@/lib/patient-xrays';
import { updatePatientXray, uploadPatientXrays, validateImage } from '@/lib/patient-xrays';
import XrayUploadForm from './XrayUploadForm';

const EMPTY: XrayMetadataInput = { xray_type:'X-ray', body_part:'', taken_at:new Date().toISOString().slice(0,10), description:'', doctor_notes:'' };

type Props = {
  open: boolean;
  patientId: string;
  patientName: string;
  userId: string;
  editing?: PatientXray | null;
  onClose: () => void;
  onSaved: (message: string) => void;
};

export default function XrayUploadDialog({ open, patientId, patientName, userId, editing, onClose, onSaved }: Props) {
  const [files,setFiles]=useState<File[]>([]);
  const [form,setForm]=useState<XrayMetadataInput>(EMPTY);
  const [saving,setSaving]=useState(false);
  const [error,setError]=useState('');

  useEffect(()=>{
    if (!open) return;
    setFiles([]); setError('');
    if (editing) setForm({xray_type:editing.xray_type||'X-ray',body_part:editing.body_part||'',taken_at:editing.taken_at?editing.taken_at.slice(0,10):null,description:editing.description||'',doctor_notes:editing.doctor_notes||''});
    else setForm({...EMPTY,taken_at:new Date().toISOString().slice(0,10)});
  },[open,editing?.id]);

  if(!open)return null;
  async function save(){
    if(saving)return;
    setError('');
    if(!editing){
      if(!files.length){setError('Зураг сонгоно уу.');return;}
      for (const file of files) {
        const validation=validateImage(file);if(validation){setError(validation);return;}
      }
    }
    setSaving(true);
    try{
      if(editing){await updatePatientXray(editing.id,form);onSaved('Мэдээлэл амжилттай шинэчлэгдлээ.');}
      else{const created=await uploadPatientXrays({patientId,files,metadata:form,uploadedBy:userId});onSaved(created.length>1 ? `${created.length} зураг амжилттай хадгалагдлаа.` : 'Зураг амжилттай хадгалагдлаа.');}
      onClose();
    }catch(actual){const msg=actual instanceof Error?actual.message:String(actual||'');console.error('DentHub image save error',actual);const lower=msg.toLowerCase();if(lower.includes('mime')||lower.includes('bucket')||lower.includes('row-level')||lower.includes('policy')||lower.includes('permission'))setError('Зураг хадгалах эрх эсвэл Storage тохиргоонд алдаа байна. Supabase дээр v8_5_3_polish_permissions_media.sql migration-ийг ажиллуулаад дахин оролдоно уу.');else setError('Зураг хадгалах үед алдаа гарлаа. Дахин оролдоно уу.');}
    finally{setSaving(false)}
  }
  return <div className="xray-layer" onMouseDown={e=>e.currentTarget===e.target&&!saving&&onClose()}>
    <div className="xray-dialog">
      <header><div><small>{patientName}</small><h2>{editing?'Зургийн мэдээлэл засах':'Зураг нэмэх'}</h2></div><button onClick={onClose} disabled={saving}><X/></button></header>
      <div className="xray-dialog-scroll"><XrayUploadForm files={files} setFiles={setFiles} value={form} onChange={setForm} disabled={saving} metadataOnly={Boolean(editing)}/>{error&&<div className="xray-dialog-error">{error}</div>}</div>
      <footer><button className="btn-secondary" onClick={onClose} disabled={saving}>Болих</button><button className="btn-primary" onClick={save} disabled={saving}>{saving?<><Loader2 className="spin" size={18}/>Хадгалж байна...</>:<><Check size={18}/>{editing?'Шинэчлэх':'Хадгалах'}</>}</button></footer>
    </div>
  </div>;
}
