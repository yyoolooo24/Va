'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { ImagePlus, RefreshCw, Trash2, UploadCloud } from 'lucide-react';
import { formatFileSize, validateImage, type XrayMetadataInput } from '@/lib/patient-xrays';
import DentSelect from '../ui/DentSelect';

export const XRAY_TYPES = ['X-ray','CT','MRI','Ultrasound','Other'];
export const BODY_PARTS = ['Толгой','Шүд','Цээж','Уушги','Нуруу','Мөр','Гар','Бугуй','Аарцаг','Өвдөг','Хөл','Шагай','Бусад'];

type Props = {
  files: File[];
  setFiles: (files: File[]) => void;
  value: XrayMetadataInput;
  onChange: (next: XrayMetadataInput) => void;
  disabled?: boolean;
  metadataOnly?: boolean;
};

export default function XrayUploadForm({ files, setFiles, value, onChange, disabled, metadataOnly }: Props) {
  const inputRef = useRef<HTMLInputElement|null>(null);
  const [fileError, setFileError] = useState('');
  const [dragging, setDragging] = useState(false);
  const previews = useMemo(() => files.map(file => ({ file, url: URL.createObjectURL(file) })), [files]);

  useEffect(() => () => { previews.forEach(item => URL.revokeObjectURL(item.url)); }, [previews]);

  function accept(list: FileList | File[] | null) {
    const incoming = Array.from(list || []);
    if (!incoming.length) return;
    const valid: File[] = [];
    for (const file of incoming) {
      const error = validateImage(file);
      if (error) { setFileError(error); continue; }
      valid.push(file);
    }
    if (valid.length) {
      setFileError('');
      const unique = [...files, ...valid].filter((file, index, arr) => arr.findIndex(x => x.name === file.name && x.size === file.size) === index);
      setFiles(unique);
    }
  }

  function removeAt(index:number){
    setFiles(files.filter((_,i)=>i!==index));
    setFileError('');
  }

  return <div className="xray-form">
    {!metadataOnly && <div className="xray-upload-block">
      {!files.length ? <button type="button" className={`xray-dropzone ${dragging?'dragging':''}`} disabled={disabled}
        onDragOver={e=>{e.preventDefault();setDragging(true)}} onDragLeave={()=>setDragging(false)} onDrop={e=>{e.preventDefault();setDragging(false);accept(e.dataTransfer.files)}} onClick={()=>inputRef.current?.click()}>
        <UploadCloud size={32}/><b>Зураг оруулах</b><span>PNG, JPG, JPEG эсвэл WEBP зургаа энд чирж тавих эсвэл төхөөрөмжөөсөө сонгоно уу</span><em>Зураг сонгох</em>
      </button> : <div className="xray-preview-list">{previews.map((item,index)=><div className="xray-preview-card" key={`${item.file.name}-${index}`}>
        <div className="xray-preview-image">{<img src={item.url} alt="Upload preview"/>}</div>
        <div className="xray-preview-info"><span className="icon-cube"><ImagePlus/></span><div><b>{item.file.name}</b><small>{formatFileSize(item.file.size)} · {(item.file.type || 'image').replace('image/','').toUpperCase()}</small></div></div>
        <div className="xray-preview-actions"><button type="button" onClick={()=>inputRef.current?.click()}><RefreshCw size={16}/>Нэмэх</button><button type="button" className="danger" onClick={()=>removeAt(index)}><Trash2 size={16}/>Арилгах</button></div>
      </div>)}</div>}
      <input ref={inputRef} hidden type="file" multiple accept="image/png,image/jpeg,image/jpg,image/webp,.png,.jpg,.jpeg,.webp" onChange={e=>accept(e.target.files)}/>
      {fileError&&<p className="xray-field-error">{fileError}</p>}
      {!fileError&&<p className="xray-inline-hint">Нэг дор олон зураг оруулах боломжтой.</p>}
    </div>}
    <div className="xray-fields">
      <label>Зургийн төрөл<DentSelect value={value.xray_type} disabled={disabled} onChange={xray_type=>onChange({...value,xray_type})} options={XRAY_TYPES.map(x=>({value:x,label:x}))}/></label>
      <label>Биеийн хэсэг<DentSelect value={value.body_part} disabled={disabled} placeholder="Сонгох" onChange={body_part=>onChange({...value,body_part})} options={BODY_PARTS.map(x=>({value:x,label:x}))}/></label>
      <label>Зураг авсан огноо<input type="date" value={value.taken_at || ''} disabled={disabled} max={new Date().toISOString().slice(0,10)} onChange={e=>onChange({...value,taken_at:e.target.value||null})}/></label>
      <label className="wide">Тайлбар<textarea rows={3} value={value.description} disabled={disabled} onChange={e=>onChange({...value,description:e.target.value})} placeholder="Зургийн талаар нэмэлт тайлбар…"/></label>
      <label className="wide">Эмчийн тэмдэглэл<textarea rows={4} value={value.doctor_notes} disabled={disabled} onChange={e=>onChange({...value,doctor_notes:e.target.value})} placeholder="Эмчийн дүгнэлт, тэмдэглэл…"/></label>
    </div>
  </div>;
}
