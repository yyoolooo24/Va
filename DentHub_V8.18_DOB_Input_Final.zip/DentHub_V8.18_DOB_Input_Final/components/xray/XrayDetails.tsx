'use client';

import type { PatientXray } from '@/lib/patient-xrays';
import { formatFileSize } from '@/lib/patient-xrays';

type Props = { xray: PatientXray; patientName: string; patientId: string };

export default function XrayDetails({ xray, patientName, patientId }: Props) {
  const date = xray.taken_at ? new Date(xray.taken_at).toLocaleDateString('mn-MN') : '—';
  return <div className="xray-details">
    <div><span>Өвчтөн</span><b>{patientName}</b></div>
    <div><span>Patient ID</span><b className="mono-value">{patientId}</b></div>
    <div><span>Зургийн төрөл</span><b>{xray.xray_type || 'X-ray'}</b></div>
    <div><span>Биеийн хэсэг</span><b>{xray.body_part || '—'}</b></div>
    <div><span>Зураг авсан огноо</span><b>{date}</b></div>
    <div><span>Файл</span><b>{xray.original_filename || 'image.png'} · {formatFileSize(xray.file_size)}</b></div>
    <div><span>Upload хийсэн</span><b>{xray.uploader_name || 'Эмнэлгийн ажилтан'}</b></div>
    <div><span>Upload огноо</span><b>{new Date(xray.created_at).toLocaleString('mn-MN')}</b></div>
    <div className="wide"><span>Тайлбар</span><p>{xray.description || 'Тайлбар оруулаагүй.'}</p></div>
    <div className="wide"><span>Эмчийн тэмдэглэл</span><p>{xray.doctor_notes || 'Тэмдэглэл оруулаагүй.'}</p></div>
  </div>;
}
