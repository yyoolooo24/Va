'use client';

import { useRef, useState } from 'react';
import { Download, Maximize2, Minus, Plus, RotateCcw, X } from 'lucide-react';
import type { PatientXray } from '@/lib/patient-xrays';
import { createXraySignedUrl } from '@/lib/patient-xrays';
import XrayDetails from './XrayDetails';

type Props={xray:PatientXray|null;patientName:string;patientId:string;canDownload:boolean;onClose:()=>void};
export default function XrayViewer({xray,patientName,patientId,canDownload,onClose}:Props){
  const [zoom,setZoom]=useState(1);const [downloading,setDownloading]=useState(false);const ref=useRef<HTMLDivElement|null>(null);
  if(!xray)return null;
  async function download(){
    if(!canDownload||downloading)return;setDownloading(true);
    try{const url=await createXraySignedUrl(xray!.storage_path,120,true);const a=document.createElement('a');a.href=url;a.download=xray!.original_filename||'xray.png';a.click();}
    catch(error){console.error('DentHub X-ray download error',error)}finally{setDownloading(false)}
  }
  async function fullscreen(){try{if(ref.current&&!document.fullscreenElement)await ref.current.requestFullscreen();else if(document.fullscreenElement)await document.exitFullscreen()}catch(e){console.error(e)}}
  return <div className="xray-layer viewer-layer" onMouseDown={e=>e.currentTarget===e.target&&onClose()}><div className="xray-viewer" ref={ref}>
    <header><div><small>{patientName}</small><h2>{xray.xray_type||'X-ray'} · {xray.body_part||'Medical image'}</h2></div><button onClick={onClose}><X/></button></header>
    <div className="xray-viewer-layout"><div className="xray-stage"><div className="xray-stage-toolbar"><button onClick={()=>setZoom(v=>Math.max(.5,v-.25))}><Minus/></button><b>{Math.round(zoom*100)}%</b><button onClick={()=>setZoom(v=>Math.min(4,v+.25))}><Plus/></button><button onClick={()=>setZoom(1)}><RotateCcw/></button><button onClick={fullscreen}><Maximize2/></button>{canDownload&&<button onClick={download} disabled={downloading}><Download/></button>}</div><div className="xray-stage-image">{xray.signed_url?<img src={xray.signed_url} alt="Patient X-ray" style={{transform:`scale(${zoom})`}}/>:<span>Зураг ачаалж чадсангүй.</span>}</div></div><aside><XrayDetails xray={xray} patientName={patientName} patientId={patientId}/></aside></div>
  </div></div>;
}
