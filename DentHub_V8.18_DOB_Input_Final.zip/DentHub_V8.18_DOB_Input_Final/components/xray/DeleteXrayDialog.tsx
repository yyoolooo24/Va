'use client';

import { AlertTriangle, Loader2, Trash2, X } from 'lucide-react';
import type { PatientXray } from '@/lib/patient-xrays';

type Props={xray:PatientXray|null;busy:boolean;onCancel:()=>void;onConfirm:()=>void};
export default function DeleteXrayDialog({xray,busy,onCancel,onConfirm}:Props){
  if(!xray)return null;
  return <div className="xray-layer confirm-layer" onMouseDown={e=>e.currentTarget===e.target&&!busy&&onCancel()}><div className="xray-confirm"><header><span><AlertTriangle/></span><button onClick={onCancel} disabled={busy}><X/></button></header><h3>Энэ X-ray зургийг устгахдаа итгэлтэй байна уу?</h3><p>Storage дахь файл болон тухайн зургийн metadata системээс устна. Энэ үйлдлийг буцаах боломжгүй.</p><footer><button className="btn-secondary" onClick={onCancel} disabled={busy}>Болих</button><button className="btn-danger" onClick={onConfirm} disabled={busy}>{busy?<Loader2 className="spin" size={18}/>:<Trash2 size={18}/>}Устгах</button></footer></div></div>;
}
