'use client';

import { Eye, Pencil, Trash2, Image as ImageIcon } from 'lucide-react';
import type { PatientXray } from '@/lib/patient-xrays';

type Props = {
  xray: PatientXray;
  canEdit: boolean;
  canDelete: boolean;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
};

export default function XrayCard({ xray, canEdit, canDelete, onView, onEdit, onDelete }: Props) {
  return <article className="xray-card">
    <button className="xray-thumb" onClick={onView} aria-label="X-ray зураг харах">
      {xray.signed_url ? <img src={xray.signed_url} alt={`${xray.xray_type || 'X-ray'} ${xray.body_part || ''}`} /> : <span><ImageIcon /></span>}
      <i>{xray.xray_type || 'X-ray'}</i>
    </button>
    <div className="xray-card-body">
      <div className="xray-card-title"><div><b>{xray.body_part || 'Биеийн хэсэггүй'}</b><small>{xray.taken_at ? new Date(xray.taken_at).toLocaleDateString('mn-MN') : 'Огноо оруулаагүй'}</small></div></div>
      <p>{xray.description || 'Тайлбар оруулаагүй.'}</p>
      <small className="xray-uploader">{xray.uploader_name || 'Эмнэлгийн ажилтан'}</small>
      <div className="xray-card-actions">
        <button onClick={onView}><Eye size={16}/>Харах</button>
        {canEdit && <button onClick={onEdit}><Pencil size={16}/>Засах</button>}
        {canDelete && <button className="danger" onClick={onDelete}><Trash2 size={16}/>Устгах</button>}
      </div>
    </div>
  </article>;
}
