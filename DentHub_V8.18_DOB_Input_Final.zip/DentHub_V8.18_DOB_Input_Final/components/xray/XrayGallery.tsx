'use client';

import { Image as ImageIcon, Plus } from 'lucide-react';
import type { PatientXray } from '@/lib/patient-xrays';
import XrayCard from './XrayCard';

type Props = {
  xrays: PatientXray[];
  loading: boolean;
  currentUserId: string;
  role: string;
  onAdd: () => void;
  onView: (xray: PatientXray) => void;
  onEdit: (xray: PatientXray) => void;
  onDelete: (xray: PatientXray) => void;
};

export default function XrayGallery({ xrays, loading, currentUserId, role, onAdd, onView, onEdit, onDelete }: Props) {
  if (loading) return <div className="xray-grid">{Array.from({length:3}).map((_,i)=><div className="xray-skeleton" key={i}><span/><div><i/><i/><i/></div></div>)}</div>;
  if (!xrays.length) return <div className="xray-empty"><span className="icon-cube xl"><ImageIcon/></span><b>Одоогоор зураг бүртгэгдээгүй байна.</b><p>Өвчтөний рентген болон medical image түүх энд хадгалагдана.</p><button className="btn-primary" onClick={onAdd}><Plus size={18}/>Зураг нэмэх</button></div>;
  return <div className="xray-grid">{xrays.map(xray => {
    const elevated = role === 'owner' || role === 'platform_admin';
    const own = xray.uploaded_by === currentUserId;
    return <XrayCard key={xray.id} xray={xray} canEdit={elevated || own} canDelete={elevated || own} onView={()=>onView(xray)} onEdit={()=>onEdit(xray)} onDelete={()=>onDelete(xray)}/>;
  })}</div>;
}
