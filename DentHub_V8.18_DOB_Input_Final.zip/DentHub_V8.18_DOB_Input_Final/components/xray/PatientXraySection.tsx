'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Image as ImageIcon, Plus, Search, X } from 'lucide-react';
import type { AppProfile } from '@/components/DashboardApp';
import { deletePatientXray, getPatientXrays, type PatientXray } from '@/lib/patient-xrays';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import XrayGallery from './XrayGallery';
import XrayUploadDialog from './XrayUploadDialog';
import DeleteXrayDialog from './DeleteXrayDialog';
import XrayViewer from './XrayViewer';
import DentSelect from '../ui/DentSelect';

const TYPE_FILTERS=['All','X-ray','CT','MRI','Ultrasound'];
const BODY_FILTERS=['','Толгой','Шүд','Цээж','Уушги','Нуруу','Мөр','Гар','Бугуй','Аарцаг','Өвдөг','Хөл','Шагай','Бусад'];

type Props={patientId:string;patientName:string;profile:AppProfile};
export default function PatientXraySection({patientId,patientName,profile}:Props){
  const [xrays,setXrays]=useState<PatientXray[]>([]);const [loading,setLoading]=useState(true);const [error,setError]=useState('');
  const [uploadOpen,setUploadOpen]=useState(false);const [editing,setEditing]=useState<PatientXray|null>(null);const [viewer,setViewer]=useState<PatientXray|null>(null);const [deleting,setDeleting]=useState<PatientXray|null>(null);const [deleteBusy,setDeleteBusy]=useState(false);
  const [typeFilter,setTypeFilter]=useState('All');const [bodyFilter,setBodyFilter]=useState('');const [dateFilter,setDateFilter]=useState('');const [query,setQuery]=useState('');const [toast,setToast]=useState('');

  const load=useCallback(async()=>{
    if(!patientId||!isSupabaseConfigured()){setXrays([]);setLoading(false);return;}
    setLoading(true);setError('');
    try{const rows=await getPatientXrays(patientId);setXrays(rows.map(x=>x.uploaded_by===profile.id?{...x,uploader_name:profile.full_name}:x));}
    catch(actual){console.error('DentHub image list error',actual);setError('Зургийн түүхийг ачаалж чадсангүй.');}
    finally{setLoading(false)}
  },[patientId,profile.id,profile.full_name]);

  useEffect(()=>{setXrays([]);setViewer(null);setEditing(null);setDeleting(null);setTypeFilter('All');setBodyFilter('');setDateFilter('');setQuery('');load()},[patientId,load]);
  useEffect(()=>{if(!toast)return;const t=setTimeout(()=>setToast(''),3200);return()=>clearTimeout(t)},[toast]);
  useEffect(()=>{
    if(!patientId||!isSupabaseConfigured())return;
    const supabase=getSupabaseBrowser();if(!supabase)return;
    const channel=supabase.channel(`patient-xrays-${patientId}`).on('postgres_changes',{event:'*',schema:'public',table:'patient_xrays',filter:`patient_id=eq.${patientId}`},()=>{load()}).subscribe();
    return()=>{supabase.removeChannel(channel)};
  },[patientId,load]);

  const filtered=useMemo(()=>xrays.filter(x=>{
    if(typeFilter!=='All'&&x.xray_type!==typeFilter)return false;
    if(bodyFilter&&x.body_part!==bodyFilter)return false;
    if(dateFilter&&(!x.taken_at||x.taken_at.slice(0,10)!==dateFilter))return false;
    if(query&&!`${x.xray_type||''} ${x.body_part||''} ${x.description||''} ${x.doctor_notes||''}`.toLowerCase().includes(query.toLowerCase()))return false;
    return true;
  }),[xrays,typeFilter,bodyFilter,dateFilter,query]);

  async function confirmDelete(){if(!deleting||deleteBusy)return;setDeleteBusy(true);try{await deletePatientXray(deleting);setDeleting(null);setToast('Зураг устгагдлаа.');await load()}catch(actual){console.error('DentHub X-ray delete error',actual);setError('Зураг устгах үед алдаа гарлаа. Дахин оролдоно уу.')}finally{setDeleteBusy(false)}}
  const canUpload=profile.role==='owner'||profile.role==='employee'||profile.role==='platform_admin';
  const canDownload=canUpload;

  return <section className="patient-xray-section">
    <div className="xray-section-head"><div><span className="icon-cube"><ImageIcon/></span><div><h3>Рентген зураг</h3><p>Өвчтөний medical image түүх</p></div></div>{canUpload&&<button className="btn-primary compact" onClick={()=>{setEditing(null);setUploadOpen(true)}}><Plus size={17}/>Зураг нэмэх</button>}</div>
    <div className="xray-filterbar"><div className="xray-search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Зураг, тайлбар хайх…"/></div><DentSelect value={typeFilter} onChange={setTypeFilter} options={TYPE_FILTERS.map(x=>({value:x,label:x==='All'?'Бүгд':x}))}/><DentSelect value={bodyFilter} onChange={setBodyFilter} placeholder="Бүх биеийн хэсэг" options={BODY_FILTERS.filter(Boolean).map(x=>({value:x,label:x}))}/><input type="date" value={dateFilter} onChange={e=>setDateFilter(e.target.value)}/>{(typeFilter!=='All'||bodyFilter||dateFilter||query)&&<button className="xray-clear" onClick={()=>{setTypeFilter('All');setBodyFilter('');setDateFilter('');setQuery('')}}><X size={16}/>Цэвэрлэх</button>}</div>
    {error&&<div className="xray-inline-error">{error}<button onClick={()=>{setError('');load()}}>Дахин оролдох</button></div>}
    <XrayGallery xrays={filtered} loading={loading} currentUserId={profile.id || ''} role={profile.role} onAdd={()=>setUploadOpen(true)} onView={setViewer} onEdit={x=>{setEditing(x);setUploadOpen(true)}} onDelete={setDeleting}/>
    {toast&&<div className="xray-toast">{toast}</div>}
    <XrayUploadDialog open={uploadOpen} patientId={patientId} patientName={patientName} userId={profile.id || ''} editing={editing} onClose={()=>{setUploadOpen(false);setEditing(null)}} onSaved={message=>{setToast(message);load()}}/>
    <XrayViewer xray={viewer} patientName={patientName} patientId={patientId} canDownload={canDownload} onClose={()=>setViewer(null)}/>
    <DeleteXrayDialog xray={deleting} busy={deleteBusy} onCancel={()=>setDeleting(null)} onConfirm={confirmDelete}/>
  </section>;
}
