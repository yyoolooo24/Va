'use client';

import { useMemo, useState } from 'react';
import { Check, CheckCheck, ChevronDown, ChevronRight, Layers3, Search, X } from 'lucide-react';
import { CLINIC_MODULES, MODULE_GROUPS, MODULE_LABELS, PLAN_MODULES, type ClinicModule } from '@/lib/subscription';
import type { AppLang } from './DashboardApp';

export type ModulePickerPreset = {
  key:string;
  mn:string;
  en:string;
  modules:readonly string[];
};

type Props = {
  value:string[];
  onChange:(modules:string[])=>void;
  lang:AppLang;
  availableModules?:readonly string[];
  presets?:readonly ModulePickerPreset[];
  showPlanPresets?:boolean;
  title?:string;
  description?:string;
  search?:string;
  onSearchChange?:(value:string)=>void;
};

const defaultPresets:ModulePickerPreset[]=[
  {key:'start',mn:'Үндсэн',en:'Core',modules:PLAN_MODULES.START},
  {key:'growth',mn:'Өсөлт',en:'Growth',modules:PLAN_MODULES.GROWTH},
  {key:'network',mn:'Бүх эрх',en:'Full access',modules:PLAN_MODULES.NETWORK},
];

export default function ModuleAccessPicker({
  value,onChange,lang,availableModules=CLINIC_MODULES,presets=[],showPlanPresets=true,title,description,search,onSearchChange,
}:Props){
  const en=lang==='EN';
  const allowed=useMemo(()=>new Set(availableModules),[availableModules]);
  const selected=useMemo(()=>new Set(value.filter(x=>allowed.has(x))),[value,allowed]);
  const activePresets=[...(showPlanPresets?defaultPresets:[]),...presets];
  const [localSearch,setLocalSearch]=useState('');
  const [openGroups,setOpenGroups]=useState<Set<string>>(()=>new Set(['clinical']));
  const searchValue=search ?? localSearch;
  const setSearchValue=onSearchChange ?? setLocalSearch;
  const query=searchValue.trim().toLowerCase();

  const setModules=(next:Iterable<string>)=>onChange(Array.from(new Set(Array.from(next).filter(x=>allowed.has(x)))));
  const toggle=(module:string)=>{
    const next=new Set(selected);
    if(next.has(module))next.delete(module);else next.add(module);
    setModules(next);
  };
  const setPreset=(modules:readonly string[])=>setModules(modules);
  const toggleGroup=(modules:readonly ClinicModule[])=>{
    const visible=modules.filter(m=>allowed.has(m));
    const allSelected=visible.length>0&&visible.every(m=>selected.has(m));
    const next=new Set(selected);
    visible.forEach(m=>allSelected?next.delete(m):next.add(m));
    setModules(next);
  };
  const toggleOpen=(id:string)=>setOpenGroups(current=>{
    const next=new Set(current);
    if(next.has(id))next.delete(id);else next.add(id);
    return next;
  });

  const visibleGroups=MODULE_GROUPS.map(group=>{
    const modules=group.modules.filter(m=>allowed.has(m)).filter(m=>!query||`${MODULE_LABELS[m].mn} ${MODULE_LABELS[m].en}`.toLowerCase().includes(query));
    return {...group,modules};
  }).filter(group=>group.modules.length);

  return <section className="module-access-picker-pro module-access-picker-v121">
    <div className="module-picker-heading">
      <div>
        <b>{title||(en?'Module access':'Модулийн эрх')}</b>
        <p>{description||(en?'Choose a ready-made access set, then adjust only the areas that differ.':'Бэлэн эрхийн тохиргооноос эхлээд, зөвхөн шаардлагатай хэсгээ нэмж эсвэл хасна.')}</p>
      </div>
      <span><strong>{selected.size}</strong>/{availableModules.length}</span>
    </div>

    <div className="module-picker-quickbar">
      <div className="module-picker-quickcopy">
        <Layers3 size={16}/>
        <span><b>{en?'Quick setup':'Хурдан тохируулах'}</b><small>{en?'One click applies a common module set.':'Нэг товшилтоор түгээмэл эрхийн багцыг сонгоно.'}</small></span>
      </div>
      <div className="module-picker-presets">
        {activePresets.map(p=><button type="button" key={p.key} onClick={()=>setPreset(p.modules)}>{en?p.en:p.mn}</button>)}
        <button type="button" onClick={()=>onChange([])} className="quiet"><X size={14}/>{en?'Clear':'Арилгах'}</button>
      </div>
    </div>

    <div className="module-picker-tools">
      <label className="module-picker-search"><Search size={15}/><input value={searchValue} onChange={e=>setSearchValue(e.target.value)} placeholder={en?'Search modules…':'Модуль хайх…'}/>{searchValue&&<button type="button" onClick={()=>setSearchValue('')} aria-label={en?'Clear search':'Хайлтыг арилгах'}><X size={13}/></button>}</label>
      <button type="button" className="module-picker-all" onClick={()=>setModules(availableModules)}><CheckCheck size={15}/>{en?'Select all':'Бүгдийг сонгох'}</button>
    </div>

    <div className="module-group-list module-group-accordion">
      {visibleGroups.map(group=>{
        const selectedCount=group.modules.filter(m=>selected.has(m)).length;
        const allSelected=selectedCount===group.modules.length;
        const expanded=query?true:openGroups.has(group.id);
        return <section className={`module-group-section ${expanded?'open':''}`} key={group.id}>
          <div className="module-group-summary">
            <button type="button" className="module-group-expand" onClick={()=>toggleOpen(group.id)} aria-expanded={expanded}>
              {expanded?<ChevronDown size={17}/>:<ChevronRight size={17}/>}<span><b>{en?group.en:group.mn}</b><small>{en?group.descriptionEn:group.descriptionMn}</small></span>
            </button>
            <div className="module-group-count"><strong>{selectedCount}</strong><span>/{group.modules.length}</span></div>
            <button type="button" className={`module-group-toggle ${allSelected?'active':''}`} onClick={()=>toggleGroup(group.modules)}>
              {allSelected?<Check size={14}/>:null}{allSelected?(en?'All enabled':'Бүгд идэвхтэй'):(en?'Enable group':'Бүлгийг сонгох')}
            </button>
          </div>
          {expanded&&<div className="module-group-options">
            {group.modules.map(m=><button type="button" key={m} className={selected.has(m)?'selected':''} onClick={()=>toggle(m)} aria-pressed={selected.has(m)}>
              <span className="module-check-mark">{selected.has(m)&&<Check size={13}/>}</span>
              <span>{MODULE_LABELS[m][en?'en':'mn']}</span>
            </button>)}
          </div>}
        </section>;
      })}
      {!visibleGroups.length&&<div className="module-picker-empty">{en?'No matching modules.':'Тохирох модуль олдсонгүй.'}</div>}
    </div>
  </section>;
}
