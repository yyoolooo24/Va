'use client';

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  Building2, CalendarDays, Check, ChevronDown, ChevronLeft, ChevronRight,
  Clock3, Loader2, Plus, Trash2, X
} from 'lucide-react';
import { getSupabaseBrowser } from '@/lib/supabase-browser';
import type { AppLang, AppProfile } from './DashboardApp';
import DentSelect from './ui/DentSelect';
import NumericInput from './ui/NumericInput';

type Clinic={id:string;name:string};
type Doctor={id:string;clinic_id:string;full_name:string};
type Availability={clinic_id:string;doctor_id:string;weekday:number;start_time:string;end_time:string;slot_minutes:number;max_parallel?:number|null;active:boolean};
type Busy={doctor_id:string;starts_at:string;ends_at?:string|null;status:string};
type BusinessHour={clinic_id:string;weekday:number;start_time:string;end_time:string;active:boolean};
type Holiday={clinic_id:string;holiday_date:string;name?:string|null};
type Appointment={id:string;clinic_id:string;clinic_name:string;doctor_id?:string|null;starts_at:string;ends_at?:string|null;service_name?:string|null;service_request?:string|null;status:string;doctor_name?:string|null;room?:string|null};
type Gender='male'|'female'|'other'|'unspecified'|'';

const CANCELLABLE=new Set(['pending','confirmed','scheduled','waiting']);
const statusText=(status:string,en:boolean)=>{
  const mn:Record<string,string>={pending:'Хүлээгдэж байна',confirmed:'Баталгаажсан',scheduled:'Баталгаажсан',waiting:'Хүлээж байна',checked_in:'Ирсэн',in_progress:'Үзэж байна',completed:'Дууссан',done:'Дууссан',cancelled:'Цуцлагдсан',no_show:'Ирээгүй'};
  const eng:Record<string,string>={pending:'Pending',confirmed:'Confirmed',scheduled:'Confirmed',waiting:'Waiting',checked_in:'Checked in',in_progress:'In progress',completed:'Completed',done:'Completed',cancelled:'Cancelled',no_show:'No show'};
  return (en?eng:mn)[status]||status;
};
const toISODate=(d:Date)=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;

async function authFetch(url:string,init?:RequestInit){
  const supabase=getSupabaseBrowser();
  const {data}=await supabase!.auth.getSession();
  const token=data.session?.access_token;
  if(!token)throw new Error('Нэвтрэх эрх дууссан байна. Дахин нэвтэрнэ үү.');
  const res=await fetch(url,{...init,headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`,...(init?.headers||{})}});
  const json=await res.json().catch(()=>({}));
  if(!res.ok)throw new Error(json.error||'Алдаа гарлаа.');
  return json;
}

export default function ClientAppointments({profile,lang}:{profile:AppProfile;lang:AppLang}){
  const en=lang==='EN';
  const [clinics,setClinics]=useState<Clinic[]>([]);
  const [doctors,setDoctors]=useState<Doctor[]>([]);
  const [availability,setAvailability]=useState<Availability[]>([]);
  const [busy,setBusy]=useState<Busy[]>([]);
  const [businessHours,setBusinessHours]=useState<BusinessHour[]>([]);
  const [holidays,setHolidays]=useState<Holiday[]>([]);
  const [appointments,setAppointments]=useState<Appointment[]>([]);
  const [loading,setLoading]=useState(true);
  const [modal,setModal]=useState(false);
  const [saving,setSaving]=useState(false);
  const [notice,setNotice]=useState('');
  const [error,setError]=useState('');
  const [picker,setPicker]=useState<'clinic'|'doctor'|null>(null);
  const [datePage,setDatePage]=useState(0);
  const [form,setForm]=useState({clinicId:'',doctorId:'',serviceText:'',age:'',gender:'' as Gender,date:'',time:''});
  const [cancelItem,setCancelItem]=useState<Appointment|null>(null);

  async function load(silent=false){
    if(!silent)setLoading(true);
    setError('');
    try{
      const data=await authFetch('/api/booking');
      setClinics(data.clinics||[]);setDoctors(data.doctors||[]);
      setAvailability(data.availability||[]);setBusy(data.busy||[]);setBusinessHours(data.business_hours||[]);setHolidays(data.holidays||[]);setAppointments(data.appointments||[]);
    }catch(e:unknown){setError(e instanceof Error?e.message:'Мэдээлэл ачаалж чадсангүй.')}finally{if(!silent)setLoading(false)}
  }
  useEffect(()=>{
    load();
    const s=getSupabaseBrowser();if(!s)return;
    const channel=s.channel(`client-appts-${profile.id||'me'}`).on('postgres_changes',{event:'*',schema:'public',table:'appointments'},()=>load(true)).subscribe();
    return()=>{s.removeChannel(channel)};
  },[profile.id]);

  const clinicDoctors=useMemo(()=>doctors.filter(d=>d.clinic_id===form.clinicId),[doctors,form.clinicId]);
  const selectedClinic=clinics.find(c=>c.id===form.clinicId);
  const selectedDoctor=clinicDoctors.find(d=>d.id===form.doctorId);
  const upcoming=appointments.filter(a=>new Date(a.starts_at).getTime()>=Date.now()&&!['cancelled','no_show'].includes(a.status)).sort((a,b)=>+new Date(a.starts_at)-+new Date(b.starts_at));
  const past=appointments.filter(a=>!upcoming.some(u=>u.id===a.id)).sort((a,b)=>+new Date(b.starts_at)-+new Date(a.starts_at));
  const dateChoices=useMemo(()=>{const start=new Date();start.setHours(12,0,0,0);start.setDate(start.getDate()+datePage*7);return Array.from({length:7},(_,i)=>{const d=new Date(start);d.setDate(start.getDate()+i);return d})},[datePage]);
  const slots=useMemo(()=>{
    if(!form.doctorId||!form.date)return[] as string[];
    const d=new Date(`${form.date}T12:00:00`);const weekday=d.getDay();const rule=availability.find(a=>a.doctor_id===form.doctorId&&a.weekday===weekday);const clinicHour=businessHours.find(h=>h.clinic_id===form.clinicId&&h.weekday===weekday);
    if(holidays.some(h=>h.clinic_id===form.clinicId&&h.holiday_date===form.date)||clinicHour?.active===false||rule?.active===false)return[] as string[];
    const clinicStart=(clinicHour?.start_time||'09:00').slice(0,5),clinicEnd=(clinicHour?.end_time||'18:00').slice(0,5);const doctorStart=(rule?.start_time||clinicStart).slice(0,5),doctorEnd=(rule?.end_time||clinicEnd).slice(0,5);
    const toMin=(v:string)=>{const [h,m]=v.split(':').map(Number);return h*60+m};const stMin=Math.max(toMin(clinicStart),toMin(doctorStart)),etMin=Math.min(toMin(clinicEnd),toMin(doctorEnd));const step=rule?.slot_minutes||30;
    const duration=30;
    const out:string[]=[];
    for(let m=stMin;m+duration<=etMin;m+=step){
      const t=`${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;
      const a0=new Date(`${form.date}T${t}:00+08:00`).getTime(),a1=a0+duration*60000;
      if(a0<Date.now()+5*60000)continue;
      const parallelLimit=Math.max(1,Number(rule?.max_parallel||3));
      const overlapping=busy.filter(b=>b.doctor_id===form.doctorId&&!['cancelled','no_show'].includes(b.status)&&a0<(b.ends_at?+new Date(b.ends_at):+new Date(b.starts_at)+30*60000)&&a1>+new Date(b.starts_at)).length;
      if(overlapping<parallelLimit)out.push(t);
    }
    return out;
  },[form.doctorId,form.date,form.clinicId,availability,busy,businessHours,holidays]);
  useEffect(()=>{if(slots.length&&!slots.includes(form.time))setForm(v=>({...v,time:slots.at(0)??''}));if(!slots.length)setForm(v=>({...v,time:''}))},[slots]);

  function open(){
    const tomorrow=new Date();tomorrow.setDate(tomorrow.getDate()+1);
    const clinicId=clinics[0]?.id||'';const doctorId=doctors.find(d=>d.clinic_id===clinicId)?.id||'';
    setForm({clinicId,doctorId,serviceText:'',age:'',gender:'',date:toISODate(tomorrow),time:''});
    setDatePage(0);setPicker(null);setNotice('');setError('');setModal(true);
  }
  function chooseFutureDate(iso:string){
    if(!iso)return;
    const chosen=new Date(`${iso}T12:00:00`);
    if(Number.isNaN(chosen.getTime()))return;
    const today=new Date();today.setHours(12,0,0,0);
    const days=Math.max(0,Math.floor((chosen.getTime()-today.getTime())/86400000));
    setDatePage(Math.floor(days/7));
    setForm(v=>({...v,date:iso,time:''}));
  }
  function quickFuture(months:number){
    const d=new Date();d.setHours(12,0,0,0);d.setMonth(d.getMonth()+months);
    chooseFutureDate(toISODate(d));
  }
  async function book(){
    if(!form.clinicId||!form.doctorId||!form.age||!form.gender||!form.date||!form.time){
      setError(en?'Fill age, gender, doctor, date and time. Description is optional.':'Нас, хүйс, эмч, өдөр, цагаа бүрэн оруулна уу. Тайлбар заавал биш.');return;
    }
    setSaving(true);setError('');
    try{
      await authFetch('/api/booking',{method:'POST',body:JSON.stringify({...form,serviceId:'',serviceText:form.serviceText.trim()})});
      setModal(false);setNotice(en?'Appointment booked successfully.':'Цаг амжилттай захиаллаа.');await load(true);
    }catch(e:unknown){setError(e instanceof Error?e.message:'Цаг захиалж чадсангүй.')}finally{setSaving(false)}
  }
  async function cancel(){
    if(!cancelItem)return;setSaving(true);setError('');
    try{await authFetch('/api/booking',{method:'PATCH',body:JSON.stringify({id:cancelItem.id,action:'cancel'})});setNotice(en?'Appointment cancelled.':'Цаг амжилттай цуцлагдлаа.');setCancelItem(null);await load(true)}
    catch(e:unknown){setError(e instanceof Error?e.message:'Цаг цуцалж чадсангүй.')}finally{setSaving(false)}
  }

  return <div className="page-stack client-appointments-page">
    <header className="page-head"><div><small>DentHub</small><h1>{en?'My appointments':'Миний цаг'}</h1><p>{en?'Choose the clinic and doctor, then describe your problem and pick a real free slot.':'Эмнэлэг, эмчээ сонгоод зовуурь / тайлбараа бичин бодит сул цагаас сонгоно.'}</p></div><button className="btn-primary" onClick={open} disabled={!clinics.length}><Plus size={18}/>{en?'Book appointment':'Шинэ цаг авах'}</button></header>
    {notice&&<div className="status-banner success"><Check size={17}/>{notice}<button onClick={()=>setNotice('')}><X size={16}/></button></div>}
    {error&&!modal&&!cancelItem&&<div className="form-error">{error}</div>}
    <section className="client-booking-summary"><article className="panel-card booking-summary-card"><span className="icon-cube large"><CalendarDays/></span><div><small>{en?'Upcoming':'Удахгүй'}</small><strong>{loading?'—':upcoming.length}</strong><p>{en?'active appointments':'идэвхтэй цаг'}</p></div></article><article className="panel-card booking-summary-card"><span className="icon-cube large"><Building2/></span><div><small>{en?'Clinics':'Эмнэлэг'}</small><strong>{loading?'—':clinics.length}</strong><p>{en?'available to book':'цаг авах боломжтой'}</p></div></article></section>
    <section className="panel-card client-appointment-panel"><div className="panel-head"><div><h2>{en?'Upcoming appointments':'Удахгүй болох цаг'}</h2><p>{en?'Waiting bookings can be cancelled. Checked-in/in-progress bookings cannot.':'Хүлээж байгаа цагийг цуцалж болно. Ирсэн эсвэл үзлэг эхэлсэн бол цуцлахгүй.'}</p></div></div>{loading?<div className="empty-state"><Loader2 className="spin"/><b>{en?'Loading appointments…':'Цаг ачаалж байна…'}</b></div>:upcoming.length?<div className="client-appointment-list">{upcoming.map(a=><AppointmentCard key={a.id} item={a} en={en} onCancel={CANCELLABLE.has(a.status)?()=>setCancelItem(a):undefined}/>)}</div>:<div className="empty-state"><CalendarDays/><b>{en?'No upcoming appointments':'Удахгүй цаг алга'}</b><p>{en?'Book a new appointment when you need one.':'Хэрэгтэй үедээ шинэ цаг авч болно.'}</p></div>}</section>
    {!!past.length&&<section className="panel-card client-appointment-panel"><div className="panel-head"><div><h2>{en?'Past appointments':'Өмнөх цаг'}</h2></div></div><div className="client-appointment-list muted-list">{past.slice(0,50).map(a=><AppointmentCard key={a.id} item={a} en={en}/>)}</div></section>}

    {modal&&<div className="modal-backdrop booking-backdrop" onMouseDown={e=>e.currentTarget===e.target&&setModal(false)}><div className="modal-card booking-modal"><header><div><small>{en?'Self booking':'Өөрөө цаг захиалах'}</small><h2>{en?'New appointment':'Шинэ цаг авах'}</h2></div><button onClick={()=>setModal(false)}><X/></button></header><div className="booking-modern-fields">
      <div className="booking-top-grid"><BookingPicker label={en?'Clinic':'Эмнэлэг'} value={selectedClinic?.name||''} open={picker==='clinic'} onToggle={()=>setPicker(v=>v==='clinic'?null:'clinic')}>{clinics.map(c=><button key={c.id} className={c.id===form.clinicId?'selected':''} onClick={()=>{const doctorId=doctors.find(d=>d.clinic_id===c.id)?.id||'';setForm(v=>({...v,clinicId:c.id,doctorId,time:''}));setPicker(null)}}>{c.name}{c.id===form.clinicId&&<Check/>}</button>)}</BookingPicker><BookingPicker label={en?'Doctor':'Эмч'} value={selectedDoctor?.full_name||''} open={picker==='doctor'} onToggle={()=>setPicker(v=>v==='doctor'?null:'doctor')}>{clinicDoctors.map(d=><button key={d.id} className={d.id===form.doctorId?'selected':''} onClick={()=>{setForm(v=>({...v,doctorId:d.id,time:''}));setPicker(null)}}>{d.full_name}{d.id===form.doctorId&&<Check/>}</button>)}</BookingPicker></div>
      <div className="booking-demographics"><label><span>{en?'Age':'Нас'}</span><NumericInput value={form.age} onValueChange={age=>setForm(v=>({...v,age}))} maxDigits={3} maxValue={130} placeholder="25"/></label><label><span>{en?'Gender':'Хүйс'}</span><DentSelect value={form.gender} onChange={gender=>setForm(v=>({...v,gender:gender as Gender}))} placeholder={en?'Choose':'Сонгох'} options={[{value:'female',label:en?'Female':'Эмэгтэй'},{value:'male',label:en?'Male':'Эрэгтэй'},{value:'other',label:en?'Other':'Бусад'},{value:'unspecified',label:en?'Prefer not to say':'Хэлэхгүй'}]}/></label></div>
      <label className="staff-notes"><span>{en?'Symptoms / description (optional)':'Зовуурь / тайлбар (заавал биш)'}</span><textarea rows={4} value={form.serviceText} onChange={e=>setForm(v=>({...v,serviceText:e.target.value}))} placeholder={en?'Example: tooth pain on the left side, gum swelling…':'Жишээ: Зүүн талын шүд өвдсөн, буйл хавдсан…'}/></label>
      <section className="booking-choice-section"><div className="booking-choice-head"><div><span className="booking-field-label">{en?'Date':'Өдөр'}</span><small>{en?'Pick any future date — including long-term follow-ups':'Ирээдүйн дурын өдөр сонгоно — 1–2 сарын дараах хяналтын цаг ч болно'}</small></div><div className="booking-date-nav"><button onClick={()=>setDatePage(v=>Math.max(0,v-1))} disabled={datePage===0}><ChevronLeft/></button><button onClick={()=>setDatePage(v=>v+1)}><ChevronRight/></button></div></div><div className="client-future-date-tools"><label><CalendarDays size={16}/><input type="date" min={toISODate(new Date())} value={form.date} onChange={e=>chooseFutureDate(e.target.value)}/></label><button type="button" onClick={()=>quickFuture(1)}>{en?'+1 month':'+1 сар'}</button><button type="button" onClick={()=>quickFuture(2)}>{en?'+2 months':'+2 сар'}</button><button type="button" onClick={()=>quickFuture(3)}>{en?'+3 months':'+3 сар'}</button></div><div className="booking-date-strip">{dateChoices.map(d=>{const iso=toISODate(d);return <button key={iso} className={iso===form.date?'selected':''} onClick={()=>chooseFutureDate(iso)}><small>{d.toLocaleDateString(en?'en-US':'mn-MN',{weekday:'short'})}</small><b>{d.getDate()}</b><span>{d.toLocaleDateString(en?'en-US':'mn-MN',{month:'short'})}</span></button>})}</div></section>
      <section className="booking-choice-section time-section"><div className="booking-choice-head"><div><span className="booking-field-label">{en?'Available time':'Сул цаг'}</span><small>{en?'A time closes only when its capacity is full':'Тухайн цагийн боломжит слот дүүрсэн үед л хаагдана'}</small></div><div className="booking-current-time"><Clock3/>{form.time||'—'}</div></div><div className="booking-time-grid">{slots.length?slots.map(t=><button key={t} className={form.time===t?'selected':''} onClick={()=>setForm(v=>({...v,time:t}))}>{t}</button>):<p className="booking-no-slots">{en?'No available time on this date.':'Энэ өдөр сул цаг алга.'}</p>}</div></section>
      {error&&<div className="form-error">{error}</div>}
    </div><footer><button className="btn-secondary" onClick={()=>setModal(false)}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={book} disabled={saving||!slots.includes(form.time)}>{saving?<Loader2 className="spin"/>:<CalendarDays/>}{saving?(en?'Booking…':'Захиалж байна…'):(en?'Confirm booking':'Цаг баталгаажуулах')}</button></footer></div></div>}

    {cancelItem&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&setCancelItem(null)}><div className="modal-card cancel-appt-modal"><header><div><small>{en?'Appointment':'Цаг товлол'}</small><h2>{en?'Cancel appointment?':'Цагаа цуцлах уу?'}</h2></div><button onClick={()=>setCancelItem(null)}><X/></button></header><div className="cancel-appt-copy"><Trash2/><div><b>{cancelItem.clinic_name}</b><p>{new Date(cancelItem.starts_at).toLocaleString(en?'en-US':'mn-MN')} · {cancelItem.service_name||'Үзлэг'}</p><span>{en?'This slot will become available to another patient.':'Энэ цаг бусад өвчтөнд дахин сул болно.'}</span></div></div>{error&&<div className="form-error modal-error">{error}</div>}<footer><button className="btn-secondary" onClick={()=>setCancelItem(null)}>{en?'Keep appointment':'Болих'}</button><button className="btn-danger" onClick={cancel} disabled={saving}>{saving?<Loader2 className="spin"/>:<Trash2/>}{en?'Cancel appointment':'Цаг цуцлах'}</button></footer></div></div>}
  </div>;
}

function BookingPicker({label,value,open,onToggle,children}:{label:string;value:string;open:boolean;onToggle:()=>void;children:ReactNode}){
  return <div className={`booking-picker ${open?'open':''}`}><span className="booking-field-label">{label}</span><button type="button" className="booking-picker-trigger" onClick={onToggle}><span>{value||label}</span><ChevronDown/></button>{open&&<div className="booking-picker-menu">{children}</div>}</div>;
}

function AppointmentCard({item,en,onCancel}:{item:Appointment;en:boolean;onCancel?:()=>void}){
  const date=new Date(item.starts_at);
  return <article className="client-appointment-card"><div className="appointment-date-box"><b>{date.toLocaleDateString(en?'en-US':'mn-MN',{day:'2-digit'})}</b><span>{date.toLocaleDateString(en?'en-US':'mn-MN',{month:'short'})}</span></div><div className="appointment-card-main"><strong>{item.clinic_name}</strong><p>{item.service_name||(en?'Consultation':'Үзлэг')}{item.doctor_name?` · ${item.doctor_name}`:''}</p>{item.service_request&&<small>{item.service_request}</small>}<div><span><Clock3 size={15}/>{date.toLocaleTimeString(en?'en-US':'mn-MN',{hour:'2-digit',minute:'2-digit'})}</span></div></div><div className="appointment-card-actions"><em className={`appointment-status status-${item.status}`}>{statusText(item.status,en)}</em>{onCancel&&<button className="client-cancel-btn" onClick={onCancel}><X size={14}/>{en?'Cancel':'Цуцлах'}</button>}</div></article>;
}
