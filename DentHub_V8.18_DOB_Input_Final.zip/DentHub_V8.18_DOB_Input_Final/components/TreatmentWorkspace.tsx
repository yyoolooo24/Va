'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Banknote, Check, ChevronRight, Clock3, FolderTree, Loader2, Plus, Search, Stethoscope, WalletCards, X } from 'lucide-react';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import type { AppLang, AppProfile, ViewKey } from './DashboardApp';
import DentalChart from './dental/DentalChart';
import ConfirmDialog from './ui/ConfirmDialog';
import NumericInput from './ui/NumericInput';

type QueueItem={
  id:string; patient_id:string; doctor_id?:string|null; service_id?:string|null; service_name?:string|null; service_request?:string|null;
  starts_at:string; status:string; patients?:{full_name:string;phone?:string|null;patient_code?:string|null;external_patient_id?:string|null}|null;
  doctor?:{full_name:string}|null;
};
type Service={id:string;name:string;service_code?:string|null;category?:string|null;subcategory?:string|null;price?:number|null};
type Encounter={id:string;appointment_id?:string|null;patient_id:string;doctor_id?:string|null;diagnosis?:string|null;notes?:string|null;status:string;dentition?:'adult'|'child'};
type TreatmentLine={id:string;tooth_no?:string|null;service_id?:string|null;service_name:string;unit_price?:number|null;notes?:string|null;created_at:string};
type PaymentMethod={id:string;name:string;code?:string|null;active:boolean;is_system?:boolean;sort_order?:number};
type VisitPayment={id:string;amount:number;payment_method_name:string;note?:string|null;created_at:string};

async function authFetch(url:string,init?:RequestInit){
  const s=getSupabaseBrowser();if(!s)throw new Error('Supabase холболт алга.');
  const {data}=await s.auth.getSession();const token=data.session?.access_token;if(!token)throw new Error('Нэвтрэх эрх дууссан байна.');
  const res=await fetch(url,{...init,headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`,...(init?.headers||{})}});const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Алдаа гарлаа.');return body;
}
const dateKey=(d:Date)=>d.toLocaleDateString('en-CA',{timeZone:'Asia/Ulaanbaatar'});
const splitToothNumbers=(value?:string|null)=>String(value||'').split(',').map(x=>x.trim()).filter(Boolean);

const TREATMENT_HEADS=[
  {id:'exam',mn:'Үзлэг',en:'Examination'},
  {id:'treatment',mn:'Эмчилгээ',en:'Treatment'},
  {id:'ortho',mn:'Гажиг засал',en:'Orthodontics'},
  {id:'periodontal',mn:'Тулгуур эдийн эмчилгээ',en:'Periodontal treatment'},
  {id:'surgery',mn:'Мэс засал',en:'Surgery'},
  {id:'prosthetic',mn:'Согог засал',en:'Prosthodontics'},
  {id:'other',mn:'Бусад',en:'Other'},
] as const;
type TreatmentHeadId=(typeof TREATMENT_HEADS)[number]['id'];
function treatmentHeadForCategory(category?:string|null):TreatmentHeadId{
  const value=String(category||'').trim().toUpperCase();
  if(value.includes('ҮЗЛЭГ')||value.includes('ОНОШ'))return 'exam';
  if(value.includes('ГАЖИГ'))return 'ortho';
  if(value.includes('ТУЛГУУР')||value.includes('ПАРОДОНТ'))return 'periodontal';
  if(value.includes('МЭС ЗАС')||value.includes('ИМПЛАНТ')||value.includes('АВАХ'))return 'surgery';
  if(value.includes('ХИЙМЭЛ')||value.includes('ШҮДЭЛБЭР')||value.includes('СОГОГ')||value.includes('ЦӨГЦ СЭРГЭЭХ')||value.includes('БҮРЭЭС')||value.includes('VENEER'))return 'prosthetic';
  if(value.includes('ЭМЧИЛГЭЭ')||value.includes('БАЙНГЫН ШҮД')||value.includes('СҮҮН ШҮД'))return 'treatment';
  return 'other';
}

export default function TreatmentWorkspace({profile,clinicName,lang,onNavigate}:{profile:AppProfile;clinicName:string;lang:AppLang;onNavigate?:(view:ViewKey)=>void}){
  const en=lang==='EN';const clinicId=profile.clinic_id||'';
  const [queue,setQueue]=useState<QueueItem[]>([]);const [services,setServices]=useState<Service[]>([]);const [loading,setLoading]=useState(true);const [error,setError]=useState('');const [notice,setNotice]=useState('');const [query,setQuery]=useState('');
  const [selected,setSelected]=useState<QueueItem|null>(null);const [encounter,setEncounter]=useState<Encounter|null>(null);const [lines,setLines]=useState<TreatmentLine[]>([]);const [saving,setSaving]=useState(false);
  const [diagnosis,setDiagnosis]=useState('');const [encounterNotes,setEncounterNotes]=useState('');const [dentition,setDentition]=useState<'adult'|'child'>('adult');const [teeth,setTeeth]=useState<string[]>([]);const [serviceHead,setServiceHead]=useState<TreatmentHeadId|''>('');const [serviceGroup,setServiceGroup]=useState('');const [serviceSubgroup,setServiceSubgroup]=useState('');const [serviceId,setServiceId]=useState('');const [serviceSearch,setServiceSearch]=useState('');const [lineNotes,setLineNotes]=useState('');const [deleteTreatmentTarget,setDeleteTreatmentTarget]=useState<TreatmentLine|null>(null);
  const [paymentMethods,setPaymentMethods]=useState<PaymentMethod[]>([]);const [visitPayments,setVisitPayments]=useState<VisitPayment[]>([]);const [paymentMethodId,setPaymentMethodId]=useState('');const [paymentAmount,setPaymentAmount]=useState('');const [paymentNote,setPaymentNote]=useState('');const [paymentBusy,setPaymentBusy]=useState(false);const [showAddPaymentMethod,setShowAddPaymentMethod]=useState(false);const [newPaymentMethod,setNewPaymentMethod]=useState('');

  const loadQueue=useCallback(async(silent=false)=>{
    if(!clinicId||!isSupabaseConfigured()){setLoading(false);return}
    if(!silent)setLoading(true);setError('');
    try{
      const s=getSupabaseBrowser();if(!s)return;
      const now=new Date();const today=dateKey(now);const carryStart=new Date(now.getTime()-24*60*60*1000).toISOString();const end=new Date(`${today}T24:00:00+08:00`).toISOString();
      let q=s.from('appointments').select('id,patient_id,doctor_id,service_id,service_name,service_request,starts_at,status,patients(full_name,phone,patient_code,external_patient_id),doctor:profiles!appointments_doctor_id_fkey(full_name)').eq('clinic_id',clinicId).in('status',['checked_in','in_progress']).gte('starts_at',carryStart).lt('starts_at',end).order('starts_at');
      if(profile.role==='employee'&&profile.id)q=q.eq('doctor_id',profile.id);
      const [{data:appointments,error:apptError},{data:svc,error:svcError}]=await Promise.all([q,s.from('services').select('id,name,service_code,category,subcategory,price').eq('clinic_id',clinicId).or('active.eq.true,active.is.null').or('is_category.eq.false,is_category.is.null').order('category').order('name')]);
      if(apptError)throw apptError;if(svcError)throw svcError;setQueue((appointments||[]) as unknown as QueueItem[]);setServices((svc||[]) as Service[]);
    }catch(e:unknown){setError(e instanceof Error?e.message:'Үзлэгийн урсгал ачаалж чадсангүй.')}finally{if(!silent)setLoading(false)}
  },[clinicId,profile.id,profile.role]);

  const loadPaymentMethods=useCallback(async(silent=false)=>{
    if(!clinicId||!isSupabaseConfigured())return;
    try{
      const s=getSupabaseBrowser();if(!s)return;
      const {data,error:e}=await s.from('payment_methods').select('id,name,code,active,is_system,sort_order').eq('clinic_id',clinicId).eq('active',true).order('sort_order').order('name');
      if(e)throw e;const methods=(data||[]) as PaymentMethod[];setPaymentMethods(methods);if(!paymentMethodId&&methods[0]?.id)setPaymentMethodId(methods[0].id);
    }catch(e:unknown){if(!silent)setError(e instanceof Error?e.message:'Төлбөрийн хэлбэрүүд ачаалж чадсангүй.')}
  },[clinicId,paymentMethodId]);

  useEffect(()=>{loadPaymentMethods()},[clinicId]);
  useEffect(()=>{loadQueue();const s=getSupabaseBrowser();if(!s||!clinicId)return;const c=s.channel(`denthub-treatment-queue-${clinicId}`).on('postgres_changes',{event:'*',schema:'public',table:'appointments',filter:`clinic_id=eq.${clinicId}`},()=>loadQueue(true)).on('postgres_changes',{event:'*',schema:'public',table:'encounters',filter:`clinic_id=eq.${clinicId}`},()=>selected&&openSession(selected,true)).on('postgres_changes',{event:'*',schema:'public',table:'encounter_treatments',filter:`clinic_id=eq.${clinicId}`},()=>selected&&openSession(selected,true)).on('postgres_changes',{event:'*',schema:'public',table:'encounter_payments',filter:`clinic_id=eq.${clinicId}`},()=>selected&&openSession(selected,true)).on('postgres_changes',{event:'*',schema:'public',table:'payment_methods',filter:`clinic_id=eq.${clinicId}`},()=>loadPaymentMethods(true)).subscribe();const timer=window.setInterval(()=>loadQueue(true),60_000);return()=>{window.clearInterval(timer);s.removeChannel(c)}},[clinicId,loadQueue,selected?.id]);
  useEffect(()=>{if(!notice)return;const t=window.setTimeout(()=>setNotice(''),2800);return()=>window.clearTimeout(t)},[notice]);

  async function openSession(appt:QueueItem,silent=false){
    setSelected(appt);if(!silent){setSaving(true);setError('');setTeeth([]);setServiceHead('');setServiceGroup('');setServiceSubgroup('');setServiceId('');setServiceSearch('');setLineNotes('');setPaymentNote('');setShowAddPaymentMethod(false)}
    try{
      const s=getSupabaseBrowser();if(!s)throw new Error('Supabase холболт алга.');
      let {data:enc,error:encError}=await s.from('encounters').select('id,appointment_id,patient_id,doctor_id,diagnosis,notes,status,dentition').eq('clinic_id',clinicId).eq('appointment_id',appt.id).maybeSingle();
      if(encError)throw encError;
      if(!enc){
        const inserted=await s.from('encounters').insert({clinic_id:clinicId,appointment_id:appt.id,patient_id:appt.patient_id,doctor_id:appt.doctor_id||profile.id||null,treatment_plan:appt.service_name||null,notes:appt.service_request||null,status:'open',dentition:'adult'}).select('id,appointment_id,patient_id,doctor_id,diagnosis,notes,status,dentition').single();
        if(inserted.error){const retry=await s.from('encounters').select('id,appointment_id,patient_id,doctor_id,diagnosis,notes,status,dentition').eq('clinic_id',clinicId).eq('appointment_id',appt.id).maybeSingle();if(retry.error||!retry.data)throw inserted.error;enc=retry.data}else enc=inserted.data;
      }
      setEncounter(enc as Encounter);setDiagnosis((enc as any)?.diagnosis||'');setEncounterNotes((enc as any)?.notes||'');setDentition((enc as any)?.dentition==='child'?'child':'adult');
      const lineRes=await s.from('encounter_treatments').select('id,tooth_no,service_id,service_name,unit_price,notes,created_at').eq('encounter_id',(enc as any).id).order('created_at');if(lineRes.error)throw lineRes.error;const loadedLines=(lineRes.data||[]) as TreatmentLine[];setLines(loadedLines);
      const paymentRes=await s.from('encounter_payments').select('id,amount,payment_method_name,note,created_at').eq('encounter_id',(enc as any).id).order('created_at',{ascending:false});if(paymentRes.error)throw paymentRes.error;const loadedPayments=(paymentRes.data||[]) as VisitPayment[];setVisitPayments(loadedPayments);
      const loadedTotal=loadedLines.reduce((sum,line)=>sum+Number(line.unit_price||0),0);const loadedPaid=loadedPayments.reduce((sum,row)=>sum+Number(row.amount||0),0);setPaymentAmount(String(Math.max(0,Math.round(loadedTotal-loadedPaid))));
      if(appt.status==='checked_in'&&!silent){await authFetch('/api/appointments',{method:'PATCH',body:JSON.stringify({id:appt.id,status:'in_progress'})});setQueue(v=>v.map(x=>x.id===appt.id?{...x,status:'in_progress'}:x));}
    }catch(e:unknown){setError(e instanceof Error?e.message:'Үзлэг нээж чадсангүй.')}finally{if(!silent)setSaving(false)}
  }

  async function saveEncounter(){if(!encounter)return false;setSaving(true);setError('');try{const s=getSupabaseBrowser();if(!s)return false;const {error:e}=await s.from('encounters').update({diagnosis:diagnosis.trim()||null,notes:encounterNotes.trim()||null,dentition}).eq('id',encounter.id).eq('clinic_id',clinicId);if(e)throw e;setNotice(en?'Visit notes saved.':'Үзлэгийн тэмдэглэл хадгалагдлаа.');return true}catch(e:unknown){setError(e instanceof Error?e.message:'Хадгалж чадсангүй.');return false}finally{setSaving(false)}}
  async function addTreatment(){
    if(!encounter||!serviceId)return;
    const svc=services.find(x=>x.id===serviceId);if(!svc)return;
    const noToothRequired=serviceHead==='ortho';
    if(!noToothRequired&&teeth.length===0){setError(en?'Select at least one tooth for this treatment.':'Энэ эмчилгээнд дор хаяж нэг шүд сонгоно уу.');return}
    setSaving(true);setError('');
    try{
      const s=getSupabaseBrowser();if(!s)return;
      const unitPrice=Math.max(0,Number(svc.price||0));
      const targets:(string|null)[]=noToothRequired?[null]:teeth;
      const payload=targets.map(tooth=>({clinic_id:clinicId,encounter_id:encounter.id,tooth_no:tooth,service_id:svc.id,service_name:svc.name,unit_price:unitPrice,notes:lineNotes.trim()||null,created_by:profile.id||null}));
      const {data,error:e}=await s.from('encounter_treatments').insert(payload).select('id,tooth_no,service_id,service_name,unit_price,notes,created_at');
      if(e)throw e;
      const inserted=(data||[]) as TreatmentLine[];
      const nextTeeth=Array.from(new Set([...lines.flatMap(x=>splitToothNumbers(x.tooth_no)),...teeth]));
      const nextTotal=lines.reduce((sum,line)=>sum+Number(line.unit_price||0),0)+(unitPrice*targets.length);
      const alreadyPaid=visitPayments.reduce((sum,row)=>sum+Number(row.amount||0),0);
      const nextStatus=nextTotal<=0?'no_charge':alreadyPaid>=nextTotal?'paid':alreadyPaid>0?'partial':'unpaid';
      const {error:encSyncError}=await s.from('encounters').update({selected_teeth:nextTeeth,dentition,total_amount:nextTotal,paid_amount:alreadyPaid,billing_status:nextStatus}).eq('id',encounter.id).eq('clinic_id',clinicId);
      if(encSyncError)throw encSyncError;
      setLines(v=>[...v,...inserted]);setPaymentAmount(String(Math.max(0,Math.round(nextTotal-alreadyPaid))));setTeeth([]);setServiceId('');setLineNotes('');
      setNotice(noToothRequired?(en?'Orthodontic treatment added without tooth selection.':'Гажиг заслын эмчилгээ шүд сонголгүй хадгалагдлаа.'):(en?`Treatment added to ${teeth.length} teeth.`:`${teeth.length} шүдэнд эмчилгээ нэг дор нэмэгдлээ.`))
    }catch(e:unknown){setError(e instanceof Error?e.message:'Эмчилгээ нэмэж чадсангүй.')}finally{setSaving(false)}
  }
  async function confirmRemoveTreatment(){const line=deleteTreatmentTarget;if(!encounter||!line)return;setSaving(true);setError('');try{const remaining=lines.filter(x=>x.id!==line.id);const nextTotal=remaining.reduce((sum,item)=>sum+Number(item.unit_price||0),0);const alreadyPaid=visitPayments.reduce((sum,row)=>sum+Number(row.amount||0),0);if(alreadyPaid>nextTotal)throw new Error(en?'This treatment cannot be removed because the visit already has more payment recorded than the new total.':'Энэ эмчилгээг устгавал төлсөн дүн нийт дүнгээс их болох тул эхлээд төлбөрийн бүртгэлийг шалгана уу.');const s=getSupabaseBrowser();if(!s)return;const {error:e}=await s.from('encounter_treatments').delete().eq('id',line.id).eq('clinic_id',clinicId);if(e)throw e;const nextTeeth=Array.from(new Set(remaining.flatMap(x=>splitToothNumbers(x.tooth_no))));const nextStatus=nextTotal<=0?'no_charge':alreadyPaid>=nextTotal?'paid':alreadyPaid>0?'partial':'unpaid';const {error:encSyncError}=await s.from('encounters').update({selected_teeth:nextTeeth,dentition,total_amount:nextTotal,paid_amount:alreadyPaid,billing_status:nextStatus}).eq('id',encounter.id).eq('clinic_id',clinicId);if(encSyncError)throw encSyncError;setLines(remaining);setPaymentAmount(String(Math.max(0,Math.round(nextTotal-alreadyPaid))));setDeleteTreatmentTarget(null);setNotice(en?'Treatment removed.':'Эмчилгээ устгагдлаа.')}catch(e:unknown){setError(e instanceof Error?e.message:'Устгаж чадсангүй.')}finally{setSaving(false)}}
  async function completeVisit(){if(!encounter||!selected)return;setSaving(true);setError('');try{const saved=await saveEncounter();if(!saved)throw new Error(en?'Could not save visit notes.':'Үзлэгийн тэмдэглэл хадгалагдсангүй.');const s=getSupabaseBrowser();if(!s)return;const {error:e}=await s.from('encounters').update({status:'completed'}).eq('id',encounter.id).eq('clinic_id',clinicId);if(e)throw e;await authFetch('/api/appointments',{method:'PATCH',body:JSON.stringify({id:selected.id,status:'completed'})});const shouldOpenCashier=remainingTotal>0&&Boolean(onNavigate);if(shouldOpenCashier){try{sessionStorage.setItem('denthub-payment-preset',JSON.stringify({patientId:selected.patient_id,encounterId:encounter.id,amount:String(Math.round(remainingTotal)),description:`${selected.patients?.full_name||'Өвчтөн'} · ${lines.length} эмчилгээ · ₮${Math.round(treatmentTotal).toLocaleString()}`}))}catch{}}setSelected(null);setEncounter(null);setLines([]);setTeeth([]);setServiceHead('');setServiceGroup('');setServiceSubgroup('');setServiceId('');setServiceSearch('');setLineNotes('');setNotice(shouldOpenCashier?(en?'Visit completed. Sending to cashier…':'Үзлэг дууслаа. Касс руу шилжүүлж байна…'):(en?'Visit completed.':'Үзлэг, эмчилгээ дууслаа.'));await loadQueue(true);if(shouldOpenCashier)onNavigate?.('payments')}catch(e:unknown){setError(e instanceof Error?e.message:'Дуусгаж чадсангүй.')}finally{setSaving(false)}}

  async function addPaymentMethod(){
    const name=newPaymentMethod.trim();if(!name||!clinicId)return;setPaymentBusy(true);setError('');
    try{const s=getSupabaseBrowser();if(!s)return;const {data,error:e}=await s.from('payment_methods').insert({clinic_id:clinicId,name,active:true,is_system:false,sort_order:100,created_by:profile.id||null}).select('id,name,code,active,is_system,sort_order').single();if(e)throw e;const row=data as PaymentMethod;setPaymentMethods(v=>[...v,row].sort((a,b)=>(a.sort_order||100)-(b.sort_order||100)||a.name.localeCompare(b.name,'mn')));setPaymentMethodId(row.id);setNewPaymentMethod('');setShowAddPaymentMethod(false);setNotice(en?'Payment method added.':'Төлбөрийн хэлбэр нэмэгдлээ.')}catch(e:unknown){setError(e instanceof Error?e.message:'Төлбөрийн хэлбэр нэмэж чадсангүй.')}finally{setPaymentBusy(false)}
  }
  async function registerVisitPayment(){
    if(!encounter||!paymentMethodId)return;const amountValue=Number(paymentAmount);if(!Number.isFinite(amountValue)||amountValue<=0){setError(en?'Enter a valid payment amount.':'Төлөх дүнг 0-ээс ихээр оруулна уу.');return}
    const method=paymentMethods.find(x=>x.id===paymentMethodId);if(method?.code==='qpay'){openBilling();return}
    setPaymentBusy(true);setError('');
    try{const s=getSupabaseBrowser();if(!s)return;const {data,error:e}=await s.rpc('denthub_record_encounter_payment',{p_encounter_id:encounter.id,p_amount:amountValue,p_payment_method_id:paymentMethodId,p_note:paymentNote.trim()||null});if(e)throw e;const paymentRes=await s.from('encounter_payments').select('id,amount,payment_method_name,note,created_at').eq('encounter_id',encounter.id).order('created_at',{ascending:false});if(paymentRes.error)throw paymentRes.error;const next=(paymentRes.data||[]) as VisitPayment[];setVisitPayments(next);const paid=next.reduce((sum,row)=>sum+Number(row.amount||0),0);setPaymentAmount(String(Math.max(0,Math.round(treatmentTotal-paid))));setPaymentNote('');setNotice(en?'Payment saved to cashbook.':'Төлбөр кассын журналд хадгалагдлаа.')}catch(e:unknown){const raw=e instanceof Error?e.message:'';const friendly=raw.includes('PAYMENT_EXCEEDS_REMAINING')?(en?'Payment exceeds the remaining balance.':'Төлөх дүн үлдэгдэл төлбөрөөс их байна.'):raw.includes('PAYMENT_METHOD_NOT_FOUND')?(en?'Choose an active payment method.':'Идэвхтэй төлбөрийн хэлбэр сонгоно уу.'):raw||'Төлбөр хадгалж чадсангүй.';setError(friendly)}finally{setPaymentBusy(false)}
  }

  const filtered=useMemo(()=>{const q=query.trim().toLowerCase();return q?queue.filter(x=>`${x.patients?.full_name||''} ${x.patients?.phone||''} ${x.patients?.patient_code||''} ${x.patients?.external_patient_id||''} ${x.doctor?.full_name||''}`.toLowerCase().includes(q)):queue},[queue,query]);
  const treatmentHeads=useMemo(()=>TREATMENT_HEADS.map(head=>{
    const headServices=services.filter(s=>treatmentHeadForCategory(s.category)===head.id);
    const categories=new Set(headServices.map(s=>(s.category||'Ангилалгүй').trim()).filter(Boolean));
    return {...head,count:headServices.length,groupCount:categories.size};
  }),[services]);
  const selectedHead=treatmentHeads.find(head=>head.id===serviceHead);
  const serviceGroups=useMemo(()=>serviceHead?Array.from(new Set<string>(services.filter(s=>treatmentHeadForCategory(s.category)===serviceHead).map(s=>(s.category||'Ангилалгүй').trim()).filter(Boolean))).sort((a,b)=>a.localeCompare(b,'mn')):[],[services,serviceHead]);
  const serviceSubgroups=useMemo(()=>serviceGroup?Array.from(new Set<string>(services.filter(s=>(s.category||'Ангилалгүй').trim()===serviceGroup).map(s=>(s.subcategory||'').trim()).filter(Boolean))).sort((a,b)=>a.localeCompare(b,'mn')):[],[services,serviceGroup]);
  const branchServices=useMemo(()=>services.filter(s=>{
    if(!serviceHead||!serviceGroup)return false;
    if(treatmentHeadForCategory(s.category)!==serviceHead)return false;
    if((s.category||'Ангилалгүй').trim()!==serviceGroup)return false;
    if(serviceSubgroups.length>0)return Boolean(serviceSubgroup)&&(s.subcategory||'').trim()===serviceSubgroup;
    return true;
  }),[services,serviceHead,serviceGroup,serviceSubgroup,serviceSubgroups.length]);
  const filteredServices=useMemo(()=>{const q=serviceSearch.trim().toLowerCase();return q?branchServices.filter(s=>`${s.name} ${s.service_code||''}`.toLowerCase().includes(q)):branchServices},[branchServices,serviceSearch]);
  const orthoDirectServices=useMemo(()=>{if(serviceHead!=='ortho')return [];const q=serviceSearch.trim().toLowerCase();const list=services.filter(s=>treatmentHeadForCategory(s.category)==='ortho');return (q?list.filter(s=>`${s.name} ${s.service_code||''} ${s.category||''} ${s.subcategory||''}`.toLowerCase().includes(q)):list).sort((a,b)=>a.name.localeCompare(b.name,'mn'))},[services,serviceHead,serviceSearch]);
  const noToothRequired=serviceHead==='ortho';
  const treatmentTotal=useMemo(()=>lines.reduce((sum,line)=>sum+Number(line.unit_price||0),0),[lines]);
  const paidTotal=useMemo(()=>visitPayments.reduce((sum,row)=>sum+Number(row.amount||0),0),[visitPayments]);
  const remainingTotal=Math.max(0,treatmentTotal-paidTotal);
  const selectedPaymentMethod=paymentMethods.find(x=>x.id===paymentMethodId)||null;

  function openBilling(){
    if(!selected)return;
    try{sessionStorage.setItem('denthub-payment-preset',JSON.stringify({patientId:selected.patient_id,encounterId:encounter?.id||null,amount:String(Math.round(remainingTotal||treatmentTotal)),description:`${selected.patients?.full_name||'Өвчтөн'} · Үзлэг, эмчилгээ`}));}catch{}
    setSelected(null);onNavigate?.('payments');
  }

  return <div className="page-stack treatment-workspace"><header className="page-head"><div><small>{clinicName}</small><h1>{en?'Examination & treatment':'Үзлэг, эмчилгээ'}</h1><p>{en?'Patients marked “Arrived” in Appointments appear here instantly for the assigned doctor.':'Цаг товлолоос “Ирсэн” болгосон өвчтөн тухайн эмчийн өнөөдрийн үзлэгийн урсгалд шууд орж ирнэ.'}</p></div></header>
    {notice&&<div className="app-toast success"><Check size={17}/><span>{notice}</span><button onClick={()=>setNotice('')}><X size={16}/></button></div>}
    <section className="panel-card treatment-queue-card"><div className="panel-head"><div><h2><Clock3 size={19}/>{en?' Today’s arrived patients':' Өнөөдрийн ирсэн өвчтөн'}</h2><p>{en?'This list refreshes in realtime and rolls over automatically each day.':'Realtime шинэчлэгдэнэ. Өдөр солигдоход өнөөдрийн жагсаалт автоматаар шинэчлэгдэнэ.'}</p></div><span className="queue-count">{filtered.length}</span></div><div className="module-search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={en?'Name, phone or patient ID…':'Нэр, утас эсвэл ID-аар хайх…'}/></div>{error&&<div className="form-error">{error}</div>}{loading?<div className="purchase-loading"><Loader2 className="spin"/>{en?'Loading…':'Ачаалж байна…'}</div>:filtered.length?<div className="treatment-queue-list">{filtered.map(item=><button key={item.id} className="treatment-queue-row" onClick={()=>openSession(item)}><span className="queue-time">{new Date(item.starts_at).toLocaleTimeString(en?'en-US':'mn-MN',{hour:'2-digit',minute:'2-digit'})}</span><span><b>{item.patients?.full_name||'Өвчтөн'}</b><small>{[item.patients?.patient_code,item.patients?.external_patient_id,item.patients?.phone].filter(Boolean).join(' · ')}</small></span><span><b>{item.doctor?.full_name||'—'}</b><small>{item.service_name||item.service_request||'Үзлэг'}</small></span><em className={item.status==='in_progress'?'progress':'arrived'}>{item.status==='in_progress'?(en?'In treatment':'Үзэж байна'):(en?'Arrived':'Ирсэн')}</em></button>)}</div>:<div className="empty-state"><Stethoscope/><b>{en?'No arrived patients yet':'Одоогоор ирсэн өвчтөн алга'}</b><p>{en?'Mark a booked patient as Arrived in Appointments.':'Цаг товлол дээр өвчтөнийг “Ирсэн” болгомогц энд шууд харагдана.'}</p></div>}</section>

    <ConfirmDialog open={Boolean(deleteTreatmentTarget)} busy={saving} title={en?'Delete this treatment line?':'Энэ эмчилгээний мөрийг устгах уу?'} description={deleteTreatmentTarget?(en?`${deleteTreatmentTarget.tooth_no||'Tooth'} · ${deleteTreatmentTarget.service_name} will be removed from this visit.`:`${deleteTreatmentTarget.tooth_no||'Шүд'} · ${deleteTreatmentTarget.service_name} бүртгэл энэ үзлэгээс устна.`):''} confirmLabel={en?'Delete treatment':'Эмчилгээ устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!saving&&setDeleteTreatmentTarget(null)} onConfirm={confirmRemoveTreatment}/>
    {selected&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&!saving&&setSelected(null)}><div className="modal-card treatment-session-modal"><header><div><small>{en?'Treatment session':'Үзлэг, эмчилгээ'}</small><h2>{selected.patients?.full_name||'Өвчтөн'}</h2><p>{[selected.patients?.patient_code,selected.patients?.external_patient_id,selected.patients?.phone].filter(Boolean).join(' · ')}</p></div><button onClick={()=>setSelected(null)} disabled={saving}><X/></button></header><div className="treatment-session-scroll"><section className="visit-summary-grid"><div><span>{en?'Appointment':'Цаг'}</span><b>{new Date(selected.starts_at).toLocaleString(en?'en-US':'mn-MN')}</b></div><div><span>{en?'Doctor':'Эмч'}</span><b>{selected.doctor?.full_name||'—'}</b></div><div className="wide"><span>{en?'Reception note / request':'Ресепшний тайлбар / хүсэлт'}</span><b>{selected.service_request||selected.service_name||'—'}</b></div></section>
      <section className="visit-clinical-notes"><label><span>{en?'Diagnosis / conclusion':'Онош / дүгнэлт'}</span><input value={diagnosis} onChange={e=>setDiagnosis(e.target.value)} placeholder={en?'Doctor enters diagnosis here':'Эмч онош, дүгнэлтээ энд оруулна'}/></label><label><span>{en?'Visit notes':'Үзлэгийн тэмдэглэл'}</span><textarea rows={3} value={encounterNotes} onChange={e=>setEncounterNotes(e.target.value)} placeholder={en?'Clinical notes':'Эмчийн тэмдэглэл'}/></label><button className="btn-secondary" onClick={saveEncounter} disabled={saving||!encounter}><Check size={16}/>{en?'Save visit notes':'Үзлэгийн тэмдэглэл хадгалах'}</button></section>
      <section className="tooth-treatment-section"><div className="tooth-treatment-head"><div><h3>{en?'Performed treatments':'Хийсэн эмчилгээ'}</h3><p>{en?'Choose the performed treatment. Orthodontics can be saved without a tooth; other groups require one or more teeth.':'Хийсэн эмчилгээгээ сонгоно. Гажиг заслын эмчилгээ шүд сонголгүй хадгалагдаж болно, бусад бүлэгт нэг эсвэл олон шүд сонгоно.'}</p></div><span>{lines.length}</span></div>{lines.length?<div className="saved-treatment-lines">{lines.map(line=><article key={line.id}><span className="treatment-line-teeth">{splitToothNumbers(line.tooth_no).length?splitToothNumbers(line.tooth_no).map(t=><i key={t}>{t}</i>):<i>—</i>}</span><div><b>{line.service_name}</b><small className="treatment-line-price">₮{Number(line.unit_price||0).toLocaleString()}</small>{line.notes&&<small>{line.notes}</small>}</div><button type="button" onClick={()=>setDeleteTreatmentTarget(line)} disabled={saving}><X size={15}/></button></article>)}</div>:<div className="treatment-line-empty">{en?'No performed treatment saved yet. Choose a treatment below.':'Хийсэн эмчилгээ хараахан хадгалаагүй байна. Доороос эмчилгээгээ сонгоно уу.'}</div>}
        <div className="treatment-entry-editor"><div className="treatment-entry-title"><Plus size={17}/><div><b>{en?'Add performed treatment':'Хийсэн ажилбар нэмэх'}</b><small>{en?'Choose through the tree: head → group → subgroup → treatment, then select one or more teeth.':'Мод хэлбэрээр: толгой бүлэг → бүлэг → дэд бүлэг → эмчилгээ гэж дараад, дараа нь нэг эсвэл олон шүд сонгоно.'}</small></div></div>
        <div className="treatment-tree-picker">
          <div className="treatment-tree-step"><div className="treatment-tree-step-head"><span>1</span><div><b>{en?'Clinical group':'Эмчилгээний бүлэг'}</b><small>{en?'Seven clear clinical groups — choose one to narrow the catalog.':'7 үндсэн эмнэлзүйн бүлгээс эхэлж сонгоно.'}</small></div></div><div className="treatment-head-grid">{treatmentHeads.map(head=><button type="button" key={head.id} className={serviceHead===head.id?'active':''} onClick={()=>{setServiceHead(head.id);setServiceGroup('');setServiceSubgroup('');setServiceId('');setServiceSearch('')}}><FolderTree size={17}/><span><b>{en?head.en:head.mn}</b><small>{head.groupCount} {en?'groups':'бүлэг'} · {head.count} {en?'services':'үйлчилгээ'}</small></span><ChevronRight size={16}/></button>)}</div></div>
          {serviceHead==='ortho'?<div className="treatment-tree-step service-leaf-step ortho-direct-step"><div className="treatment-tree-step-head"><span>2</span><div><b>{en?'Search orthodontic treatment':'Гажиг заслын эмчилгээ хайх'}</b><small>{en?'No tooth selection is required for orthodontic treatment.':'Гажиг заслын эмчилгээнд шүд заавал сонгохгүй.'}</small></div></div><label className="treatment-branch-search"><Search size={16}/><input value={serviceSearch} onChange={e=>setServiceSearch(e.target.value)} placeholder={en?'Search orthodontic treatment by name or code…':'Гажиг заслын эмчилгээг нэр эсвэл кодоор хайх…'}/>{serviceSearch&&<button type="button" onClick={()=>setServiceSearch('')}><X size={14}/></button>}</label><div className="treatment-service-grid">{orthoDirectServices.length?orthoDirectServices.map(s=><button type="button" key={s.id} className={serviceId===s.id?'active':''} onClick={()=>setServiceId(s.id)}><span><b>{s.name}</b><small>{[s.service_code?`#${s.service_code}`:'',s.subcategory||s.category||'',`₮${Number(s.price||0).toLocaleString()}`].filter(Boolean).join(' · ')}</small></span>{serviceId===s.id?<Check size={16}/>:<ChevronRight size={15}/>}</button>):<div className="treatment-tree-empty">{en?'No orthodontic treatment matched your search.':'Хайлтад тохирох гажиг заслын эмчилгээ олдсонгүй.'}</div>}</div></div>:<>{serviceHead&&<div className="treatment-tree-step"><div className="treatment-tree-step-head"><span>2</span><div><b>{en?'Group':'Бүлэг'}</b><small>{en?`Inside ${selectedHead?.en||''}`:`${selectedHead?.mn||''} дотроос сонгоно`}</small></div></div><div className="treatment-branch-grid">{serviceGroups.map(group=>{const count=services.filter(s=>treatmentHeadForCategory(s.category)===serviceHead&&(s.category||'Ангилалгүй').trim()===group).length;return <button type="button" key={group} className={serviceGroup===group?'active':''} onClick={()=>{setServiceGroup(group);setServiceSubgroup('');setServiceId('');setServiceSearch('')}}><span><b>{group}</b><small>{count} {en?'services':'үйлчилгээ'}</small></span><ChevronRight size={15}/></button>})}</div></div>}{serviceGroup&&serviceSubgroups.length>0&&<div className="treatment-tree-step"><div className="treatment-tree-step-head"><span>3</span><div><b>{en?'Subgroup':'Дэд бүлэг'}</b><small>{serviceGroup}</small></div></div><div className="treatment-branch-grid compact">{serviceSubgroups.map(group=>{const count=services.filter(s=>(s.category||'Ангилалгүй').trim()===serviceGroup&&(s.subcategory||'').trim()===group).length;return <button type="button" key={group} className={serviceSubgroup===group?'active':''} onClick={()=>{setServiceSubgroup(group);setServiceId('');setServiceSearch('')}}><span><b>{group}</b><small>{count} {en?'services':'үйлчилгээ'}</small></span><ChevronRight size={15}/></button>})}</div></div>}{serviceGroup&&(serviceSubgroups.length===0||Boolean(serviceSubgroup))&&<div className="treatment-tree-step service-leaf-step"><div className="treatment-tree-step-head"><span>{serviceSubgroups.length>0?'4':'3'}</span><div><b>{en?'Performed treatment':'Хийсэн ажилбар / эмчилгээ'}</b><small>{serviceSubgroup||serviceGroup}</small></div></div>{branchServices.length>8&&<label className="treatment-branch-search"><Search size={16}/><input value={serviceSearch} onChange={e=>setServiceSearch(e.target.value)} placeholder={en?'Search only inside this group…':'Зөвхөн энэ бүлгээс хайх…'}/>{serviceSearch&&<button type="button" onClick={()=>setServiceSearch('')}><X size={14}/></button>}</label>}<div className="treatment-service-grid">{filteredServices.length?filteredServices.map(s=><button type="button" key={s.id} className={serviceId===s.id?'active':''} onClick={()=>setServiceId(s.id)}><span><b>{s.name}</b><small>{[s.service_code?`#${s.service_code}`:'',`₮${Number(s.price||0).toLocaleString()}`].filter(Boolean).join(' · ')}</small></span>{serviceId===s.id?<Check size={16}/>:<ChevronRight size={15}/>}</button>):<div className="treatment-tree-empty">{en?'No matching treatment in this branch.':'Энэ салаанд тохирох эмчилгээ олдсонгүй.'}</div>}</div></div>}</>}
        </div>
        {serviceId&&<div className="selected-treatment-summary"><span>{en?'Selected treatment':'Сонгосон эмчилгээ'}</span><b>{services.find(x=>x.id===serviceId)?.name||'—'}</b><strong>₮{Number(services.find(x=>x.id===serviceId)?.price||0).toLocaleString()}</strong></div>}
        {!noToothRequired?<DentalChart lang={lang} dentition={dentition} onDentitionChange={d=>{setDentition(d);setTeeth([])}} value={teeth} onChange={setTeeth}/>:<div className="ortho-no-tooth-note"><Check size={16}/><div><b>{en?'No tooth selection required':'Шүд сонгох шаардлагагүй'}</b><small>{en?'Orthodontic treatment is recorded once for this visit.':'Гажиг заслын эмчилгээ энэ үзлэгт нэг мөрөөр хадгалагдана.'}</small></div></div>}
        <div className="treatment-entry-fields">{!noToothRequired&&<label><span>{en?'Selected teeth':'Сонгосон шүд'}</span><strong className="selected-teeth-value">{teeth.length?`${teeth.join(', ')} · ${teeth.length}`:'—'}</strong></label>}<label className="wide"><span>{en?'Treatment note':'Эмчилгээний тэмдэглэл'}</span><input value={lineNotes} onChange={e=>setLineNotes(e.target.value)} placeholder={noToothRequired?(en?'Optional orthodontic treatment note':'Гажиг заслын эмчилгээний нэмэлт тайлбар'):(en?'Optional details for these teeth':'Сонгосон шүднүүдийн эмчилгээний нэмэлт тайлбар')}/></label></div>
        <button className="btn-primary add-tooth-treatment" onClick={addTreatment} disabled={saving||!serviceId||(!noToothRequired&&teeth.length===0)}>{saving?<Loader2 className="spin" size={17}/>:<Plus size={17}/>} {noToothRequired?(en?'Save orthodontic treatment':'Гажиг заслын эмчилгээ хадгалах'):teeth.length>1?(en?`Save treatment for ${teeth.length} teeth`:`${teeth.length} шүдэнд эмчилгээ хадгалах`):(en?'Save treatment':'Эмчилгээ хадгалах')}</button></div>
      </section><section className="visit-billing-card treatment-payment-card cashier-handoff-card"><div className="payment-card-head"><div><span className="billing-icon"><Banknote size={19}/></span><div><b>{en?'Visit total':'Үзлэгийн нийт үнэ'}</b><small>{en?'The doctor only confirms treatments here. Payment method and receipt are handled at Cashier.':'Эмч энд зөвхөн хийсэн эмчилгээ, үнийг баталгаажуулна. Төлбөрийн хэлбэр болон баримтыг Касс дээр сонгоно.'}</small></div></div></div><div className="cashier-handoff-total"><span>{en?'Total amount':'Нийт дүн'}</span><strong>₮{treatmentTotal.toLocaleString()}</strong><small>{lines.length} {en?'treatment rows':'эмчилгээний мөр'}</small></div><div className="cashier-handoff-actions">{onNavigate&&<button type="button" className="btn-primary" onClick={completeVisit} disabled={saving||!encounter||lines.length===0}>{saving?<Loader2 className="spin" size={17}/>:<Banknote size={17}/>} {treatmentTotal>0?(en?'Finish & send to Cashier':'Дуусгаад Касс руу илгээх'):(en?'Complete visit':'Үзлэг дуусгах')}</button>}<p>{en?'No payment is recorded from the doctor screen.':'Эмчийн дэлгэцээс төлбөрийн бичилт хийхгүй.'}</p></div></section>{error&&<div className="form-error">{error}</div>}</div><footer><button className="btn-secondary" onClick={()=>setSelected(null)} disabled={saving}>{en?'Close':'Хаах'}</button><button className="btn-secondary" onClick={saveEncounter} disabled={saving||!encounter}><Check size={17}/>{en?'Save notes':'Тэмдэглэл хадгалах'}</button></footer></div></div>}
  </div>;
}
