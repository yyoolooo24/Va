'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Boxes, CalendarDays, ClipboardPlus, FileBarChart, MessageSquare, UsersRound, WalletCards, CircleUserRound,
  Plus, Search, X, Check, Clock3, Phone, UserRound, PackagePlus, CircleDollarSign, Send, Moon, Sun,
  ShieldCheck, Stethoscope, ArrowRight, Download, FileText, Loader2, Tags, UserCog, Truck, ShoppingCart,
  ClipboardList, ArrowLeftRight, ReceiptText, HandCoins, TestTube2, ContactRound, ShieldPlus, Wrench, Warehouse, Building2,
  ChevronDown, Pencil, Trash2, FolderPlus, ShoppingBag, RotateCcw, Banknote, BadgePercent, Hash, UploadCloud
} from 'lucide-react';
import type { AppLang, AppProfile, ViewKey } from './DashboardApp';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import ClientAppointments from './ClientAppointments';
import StaffAppointments from './StaffAppointments';
import PatientXraySection from './xray/PatientXraySection';
import SupplierWorkspace from './SupplierWorkspace';
import NumericInput from './ui/NumericInput';
import DentalChart from './dental/DentalChart';
import ServicePackagesPanel from './ServicePackagesPanel';
import ConfirmDialog from './ui/ConfirmDialog';
import StaffDocumentsPanel from './StaffDocumentsPanel';
import StaffAffiliationsPanel from './StaffAffiliationsPanel';
import DentMonthPicker from './ui/DentMonthPicker';
import DentDatePicker from './ui/DentDatePicker';
import BirthDateInput, { birthDateToIso, formatBirthDateDisplay } from './ui/BirthDateInput';

type Row = { id:string; title:string; subtitle:string; meta:string; status?:string; isCategory?:boolean; category?:string; subcategory?:string; patientCode?:string; serviceCode?:string; externalSource?:string; externalSourceId?:string; selectedTeeth?:string[]; dentition?:'adult'|'child'; payload?:Record<string,any> };
type Config = {title:string;desc:string;icon:any;action?:string;empty:string};
type RefOption = {id:string;label:string;meta?:string;code?:string};
type RefData = {patients:RefOption[];suppliers:RefOption[];inventory:RefOption[];staff:RefOption[]};

const config: Partial<Record<ViewKey,Config>> = {
  appointments:{title:'Цаг товлол',desc:'Эмч, өвчтөн, үйлчилгээ болон цагийн хуваарийг ойлгомжтой удирдана.',icon:CalendarDays,action:'Цаг товлох',empty:'Цаг товлол хараахан алга.'},
  patients:{title:'Өвчтөн',desc:'Өвчтөний бүртгэл, холбоо барих мэдээлэл болон түүхийг нэг дор.',icon:UsersRound,action:'Өвчтөн нэмэх',empty:'Өвчтөн бүртгэгдээгүй байна.'},
  treatments:{title:'Үзлэг, эмчилгээ',desc:'Онош, тэмдэглэл, эмчилгээний төлөвлөгөөг хурдан бүртгэнэ.',icon:ClipboardPlus,action:'Үзлэг бүртгэх',empty:'Үзлэгийн бүртгэл алга.'},
  services:{title:'Үйлчилгээ & үнэ',desc:'Эмнэлгийн үйлчилгээ, ангилал, үнэ тарифыг нэг дор удирдана.',icon:Tags,action:'Үйлчилгээ нэмэх',empty:'Үйлчилгээ бүртгэгдээгүй байна.'},
  sales:{title:'Борлуулалт',desc:'Өвчтөнтэй ID-аар холбогдсон борлуулалт, төлбөрийн хэлбэр, дүн болон төлөв.',icon:ShoppingBag,action:'Борлуулалт бүртгэх',empty:'Борлуулалтын бүртгэл алга.'},
  sales_returns:{title:'Буцаалт',desc:'Борлуулалтын буцаалт, өвчтөн, шалтгаан, дүн болон буцаалтын явц.',icon:RotateCcw,action:'Буцаалт бүртгэх',empty:'Буцаалтын бүртгэл алга.'},
  cashbook:{title:'Кассын журнал',desc:'Бэлэн, карт, шилжүүлэг болон QPay кассын хөдөлгөөнийг нэг жагсаалтаар хянана.',icon:Banknote,action:'Кассын бичилт нэмэх',empty:'Кассын журнал хоосон байна.'},
  price_lists:{title:'Үнийн жагсаалт',desc:'Үнийн бүлэг, хөнгөлөлтийн дүрэм, хүчинтэй хугацааг нэг дор төвлөрүүлж удирдана.',icon:BadgePercent,action:'Үнийн дүрэм нэмэх',empty:'Үнийн жагсаалт бүртгэгдээгүй байна.'},
  stock_movements:{title:'Барааны хөдөлгөөн',desc:'Барааны орлого, зарлага, шилжүүлэг болон хөдөлгөөний түүх.',icon:ArrowLeftRight,action:'Хөдөлгөөн бүртгэх',empty:'Барааны хөдөлгөөн алга.'},
  suppliers:{title:'Ханган нийлүүлэгч',desc:'Нийлүүлэгч байгууллага, холбоо барих хүн, нөхцөл болон ангилал.',icon:Truck,action:'Нийлүүлэгч нэмэх',empty:'Нийлүүлэгч бүртгэгдээгүй байна.'},
  procurement:{title:'Худалдан авалт',desc:'Худалдан авах хүсэлт, төсөв, нийлүүлэгч болон хугацааг хянана.',icon:ShoppingCart,action:'Хүсэлт үүсгэх',empty:'Худалдан авалтын хүсэлт алга.'},
  purchase_orders:{title:'Захиалга / PO',desc:'Нийлүүлэгч рүү илгээх худалдан авалтын захиалга болон төлөв.',icon:ClipboardList,action:'PO үүсгэх',empty:'Purchase order алга.'},
  lab_orders:{title:'Лабораторийн захиалга',desc:'Шүдний лабораторийн ажил, өвчтөн, хугацаа болон явцыг хянана.',icon:TestTube2,action:'Лаб захиалга нэмэх',empty:'Лабораторийн захиалга алга.'},
  rooms:{title:'Өрөө & кабинет',desc:'Кабинет, өрөө, зориулалт болон ашиглалтын төлөв.',icon:Building2,action:'Өрөө нэмэх',empty:'Өрөө бүртгэгдээгүй байна.'},
  crm:{title:'CRM',desc:'Харилцагчтай хийсэн холбоо, follow-up, сануулга болон тэмдэглэл.',icon:ContactRound,action:'Холбоо нэмэх',empty:'CRM бүртгэл алга.'},
  insurance:{title:'Даатгал',desc:'Даатгалын мэдээлэл, claim, дүн болон баталгаажуулалтын төлөв.',icon:ShieldPlus,action:'Claim нэмэх',empty:'Даатгалын бүртгэл алга.'},
  invoices:{title:'Нэхэмжлэх',desc:'Нэхэмжлэх, харилцагч, төлөх хугацаа болон төлөлтийн төлөв.',icon:ReceiptText,action:'Нэхэмжлэх үүсгэх',empty:'Нэхэмжлэх алга.'},
  receivables:{title:'Авлага',desc:'Төлөгдөөгүй авлага, харилцагч, хугацаа болон төлөлтийн явц.',icon:HandCoins,action:'Авлага нэмэх',empty:'Авлага алга.'},
  expenses:{title:'Зардал',desc:'Зардлын ангилал, дүн, төлбөрийн хэлбэр болон тайлбар.',icon:CircleDollarSign,action:'Зардал нэмэх',empty:'Зардлын бүртгэл алга.'},
  staff:{title:'Ажилтнууд',desc:'Эмнэлгийн ажилтан, үүрэг, эрх болон идэвхтэй төлөв.',icon:UserCog,empty:'Ажилтан бүртгэгдээгүй байна.'},
  shifts:{title:'Ээлж & хуваарь',desc:'Ажилтны ээлж, эхлэх/дуусах цаг болон байршлыг удирдана.',icon:Clock3,action:'Ээлж нэмэх',empty:'Ээлжийн хуваарь алга.'},
  assets:{title:'Үндсэн хөрөнгө',desc:'Тоног төхөөрөмж, серийн дугаар, байршил болон үнэлгээ.',icon:Wrench,action:'Хөрөнгө нэмэх',empty:'Үндсэн хөрөнгө бүртгэгдээгүй байна.'},
  branches:{title:'Салбарууд',desc:'Салбарын нэр, хаяг, утас, менежер болон үйл ажиллагааны төлөв.',icon:Warehouse,action:'Салбар нэмэх',empty:'Салбар бүртгэгдээгүй байна.'},
  supplier_warehouse:{title:'Ханган нийлүүлэх',desc:'Нийлүүлэх бараа, SKU, үлдэгдэл, нэгж болон дахин захиалах түвшин.',icon:Warehouse,action:'Нийлүүлэх бараа нэмэх',empty:'Агуулахын бүртгэл алга.'},
  partner_clinics:{title:'Хамтрагч эмнэлгүүд',desc:'Харилцан ажилладаг эмнэлэг, салбар, холбоо барих мэдээлэл болон хамтын ажиллагааны төлөв.',icon:Building2,action:'Хамтрагч эмнэлэг нэмэх',empty:'Хамтрагч эмнэлэг бүртгэгдээгүй байна.'},
  inventory:{title:'Бараа материал',desc:'Нөөц, доод үлдэгдэл болон барааны хөдөлгөөнийг хянана.',icon:Boxes,action:'Бараа нэмэх',empty:'Бараа материал алга.'},
  finance:{title:'Санхүү',desc:'Орлого, зарлага, авлага болон кассын хөдөлгөөнийг нэг дор.',icon:WalletCards,action:'Гүйлгээ нэмэх',empty:'Санхүүгийн гүйлгээ алга.'},
  reports:{title:'Тайлан',desc:'Өдөр тутмын ажиллагаа, орлого, өвчтөн болон нөөцийн тойм.',icon:FileBarChart,empty:'Тайлангийн мэдээлэл хараахан бүрдээгүй байна.'},
  chat:{title:'Чат',desc:'Өвчтөн болон эмнэлгийн ажилтантай шууд харилцана.',icon:MessageSquare,empty:'Чат сонгоно уу.'},
  profile:{title:'Миний мэдээлэл',desc:'Профайл, нууцлал, хэл болон харагдах байдлын тохиргоо.',icon:CircleUserRound,empty:''},
};

const configEn: Partial<Record<ViewKey,Config>> = {
  appointments:{title:'Appointments',desc:'Manage doctors, patients, services and schedules clearly.',icon:CalendarDays,action:'Book appointment',empty:'No appointments yet.'},
  patients:{title:'Patients',desc:'Patient records, contact details and history in one place.',icon:UsersRound,action:'Add patient',empty:'No patients registered yet.'},
  treatments:{title:'Treatments',desc:'Record diagnoses, notes and treatment plans quickly.',icon:ClipboardPlus,action:'Add treatment',empty:'No treatment records yet.'},
  services:{title:'Services & Pricing',desc:'Manage clinic services, categories and pricing.',icon:Tags,action:'Add service',empty:'No services yet.'},
  sales:{title:'Sales',desc:'Patient-ID-linked sales, payment method, amount and status.',icon:ShoppingBag,action:'Record sale',empty:'No sales records yet.'},
  sales_returns:{title:'Returns',desc:'Sales returns, patient, reason, amount and refund progress.',icon:RotateCcw,action:'Record return',empty:'No returns yet.'},
  cashbook:{title:'Cashbook',desc:'Cash, card, transfer and QPay movements in one operational ledger.',icon:Banknote,action:'Add cashbook entry',empty:'No cashbook records yet.'},
  price_lists:{title:'Price Lists',desc:'Pricing groups, discount rules and effective dates in one place.',icon:BadgePercent,action:'Add price rule',empty:'No price lists yet.'},
  stock_movements:{title:'Stock Movement',desc:'Track stock in, stock out, transfers and movement history.',icon:ArrowLeftRight,action:'Add movement',empty:'No stock movement yet.'},
  suppliers:{title:'Suppliers',desc:'Supplier companies, contacts, terms and categories.',icon:Truck,action:'Add supplier',empty:'No suppliers yet.'},
  procurement:{title:'Procurement',desc:'Purchase requests, budgets, suppliers and due dates.',icon:ShoppingCart,action:'New request',empty:'No procurement requests yet.'},
  purchase_orders:{title:'Purchase Orders',desc:'Purchase orders sent to suppliers and their status.',icon:ClipboardList,action:'Create PO',empty:'No purchase orders yet.'},
  lab_orders:{title:'Lab Orders',desc:'Dental lab work, patient, due date and progress.',icon:TestTube2,action:'Add lab order',empty:'No lab orders yet.'},
  rooms:{title:'Rooms & Operatories',desc:'Rooms, operatories, purpose and availability.',icon:Building2,action:'Add room',empty:'No rooms yet.'},
  crm:{title:'CRM',desc:'Customer contacts, follow-ups, reminders and notes.',icon:ContactRound,action:'Add contact',empty:'No CRM records yet.'},
  insurance:{title:'Insurance',desc:'Insurance details, claims, amounts and approvals.',icon:ShieldPlus,action:'Add claim',empty:'No insurance records yet.'},
  invoices:{title:'Invoices',desc:'Invoices, customers, due dates and payment status.',icon:ReceiptText,action:'Create invoice',empty:'No invoices yet.'},
  receivables:{title:'Receivables',desc:'Outstanding balances, customers and due dates.',icon:HandCoins,action:'Add receivable',empty:'No receivables yet.'},
  expenses:{title:'Expenses',desc:'Expense categories, amounts, payment methods and notes.',icon:CircleDollarSign,action:'Add expense',empty:'No expenses yet.'},
  staff:{title:'Staff',desc:'Clinic employees, roles, access and active status.',icon:UserCog,empty:'No staff yet.'},
  shifts:{title:'Shifts & Roster',desc:'Staff shifts, start/end times and locations.',icon:Clock3,action:'Add shift',empty:'No shifts yet.'},
  assets:{title:'Assets',desc:'Equipment, serial numbers, locations and values.',icon:Wrench,action:'Add asset',empty:'No assets yet.'},
  branches:{title:'Branches',desc:'Branch names, addresses, phones and managers.',icon:Warehouse,action:'Add branch',empty:'No branches yet.'},
  supplier_warehouse:{title:'Supply',desc:'Warehouse stock, SKU, units and reorder levels.',icon:Warehouse,action:'Add supply item',empty:'No warehouse records yet.'},
  partner_clinics:{title:'Partner Clinics',desc:'Clinics you work with, contacts and relationship status.',icon:Building2,action:'Add partner clinic',empty:'No partner clinics yet.'},
  inventory:{title:'Inventory',desc:'Track stock, minimum levels and item movement.',icon:Boxes,action:'Add item',empty:'No inventory items yet.'},
  finance:{title:'Finance',desc:'Income, expenses, receivables and cash movement in one place.',icon:WalletCards,action:'Add transaction',empty:'No finance transactions yet.'},
  reports:{title:'Reports',desc:'Daily operations, revenue, patients and inventory overview.',icon:FileBarChart,empty:'Report data is not available yet.'},
  chat:{title:'Chat',desc:'Message patients and clinic staff directly.',icon:MessageSquare,empty:'Select a chat.'},
  profile:{title:'My Profile',desc:'Manage your profile, privacy, language and appearance.',icon:CircleUserRound,empty:''},
};

const seeds: Partial<Record<ViewKey,Row[]>> = {};
const genericErpViews:ViewKey[]=['sales','sales_returns','price_lists','stock_movements','suppliers','procurement','purchase_orders','lab_orders','crm','insurance','invoices','receivables','expenses','shifts','assets','branches','supplier_warehouse','partner_clinics'];

type RefSource=keyof RefData;
function refSourceFor(view:ViewKey,key:string):RefSource|null{
  if(key==='patient'&&['treatments','lab_orders','insurance','sales','sales_returns','invoices','receivables'].includes(view))return 'patients';
  if(key==='supplier'&&['procurement','purchase_orders','supplier_warehouse'].includes(view))return 'suppliers';
  if(key==='item'&&view==='stock_movements')return 'inventory';
  if(key==='staff'&&['shifts','stock_movements'].includes(view))return 'staff';
  if(key==='manager'&&view==='branches')return 'staff';
  return null;
}

function detailLabels(view:ViewKey,en:boolean){
  const mn:Partial<Record<ViewKey,[string,string,string]>>={
    patients:['Утас / регистр','Бүртгэсэн','Төлөв'],sales:['Өвчтөн / төлбөр','Дүн / огноо','Төлөв'],sales_returns:['Өвчтөн / шалтгаан','Буцаалтын дүн / огноо','Төлөв'],cashbook:['Төлбөрийн хэлбэр / утга','Дүн / огноо','Төлөв'],price_lists:['Үнийн бүлэг / хөнгөлөлт','Хүчинтэй хугацаа','Төлөв'],treatments:['Онош / тэмдэглэл','Огноо / эмч','Төлөв'],services:['Ангилал','Үнэ / хугацаа','Төлөв'],inventory:['SKU / үлдэгдэл','Дахин захиалах босго','Нөөцийн төлөв'],stock_movements:['Хөдөлгөөн / бараа','Тоо хэмжээ / үлдэгдэл','Төлөв'],suppliers:['Холбоо барих','Ангилал / регистр','Төлөв'],procurement:['Нийлүүлэгч / тоо','Төсөв / огноо','Төлөв'],purchase_orders:['Нийлүүлэгч','Нийт дүн / огноо','Төлөв'],lab_orders:['Лаборатори / ажил','Хугацаа','Төлөв'],insurance:['Даатгал / claim','Дүн','Төлөв'],invoices:['Харилцагч','Дүн / хугацаа','Төлөв'],receivables:['Харилцагч','Дүн / хугацаа','Төлөв'],expenses:['Тайлбар','Дүн / төлбөр','Төлөв'],finance:['Төлбөрийн хэлбэр','Дүн','Төлөв'],staff:['Албан тушаал','Эрх / төлөв','Төлөв'],shifts:['Ажилтан / байршил','Огноо / цаг','Төлөв'],assets:['Серийн дугаар / байршил','Үнэ / үнэлгээ','Төлөв'],branches:['Хаяг / утас','Менежер','Төлөв']
  };
  const enMap:Partial<Record<ViewKey,[string,string,string]>>={inventory:['SKU / stock','Reorder threshold','Stock status'],patients:['Phone / registration','Registered','Status'],treatments:['Diagnosis / notes','Date / doctor','Status'],services:['Category','Price / duration','Status'],stock_movements:['Movement / item','Quantity / balance','Status'],suppliers:['Contact','Category / registration','Status']};
  return (en?enMap[view]:mn[view]) || (en?['Information','Details','Status']:['Мэдээлэл','Дэлгэрэнгүй','Төлөв']);
}

export default function ModulePage({view,profile,clinicName,theme,onThemeChange,lang,onNavigate}:{view:ViewKey;profile:AppProfile;clinicName:string;theme:'light'|'dark';onThemeChange:()=>void;lang:AppLang;onNavigate?:(view:ViewKey)=>void}){
  const en=lang==='EN';
  const isDoctor=profile.role==='employee'&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(profile.specialty||'');
  const item:Config=(en?configEn:config)[view]||{title:'DentHub',desc:'',icon:Stethoscope,empty:''};
  const Icon=item.icon;
  const [detailInfoLabel,detailMetaLabel,detailStatusLabel]=detailLabels(view,en);
  const storageKey=`clinicos-${view}-rows`;
  const [rows,setRows]=useState<Row[]>(()=>[]);
  const [modal,setModal]=useState(false);
  const [query,setQuery]=useState('');
  const [notice,setNotice]=useState('');
  const [selected,setSelected]=useState<Row|null>(null);
  const [saving,setSaving]=useState(false);
  const [recordsLoading,setRecordsLoading]=useState(false);
  const [form,setForm]=useState<Record<string,string>>({});
  const [refs,setRefs]=useState<RefData>({patients:[],suppliers:[],inventory:[],staff:[]});
  const [refsLoading,setRefsLoading]=useState(false);
  const [categoryModal,setCategoryModal]=useState(false);
  const [categoryName,setCategoryName]=useState('');
  const [categoryTarget,setCategoryTarget]=useState<Row|null>(null);
  const [categorySaving,setCategorySaving]=useState(false);
  const [deleteCategoryTarget,setDeleteCategoryTarget]=useState<Row|null>(null);
  const [deleteServiceTarget,setDeleteServiceTarget]=useState<Row|null>(null);
  const [deletePatientTarget,setDeletePatientTarget]=useState<Row|null>(null);
  const [deleteCashbookTarget,setDeleteCashbookTarget]=useState<Row|null>(null);
  const [pendingExcelImport,setPendingExcelImport]=useState<File|null>(null);
  const [pendingExcelDeleteCount,setPendingExcelDeleteCount]=useState(0);
  const [editingId,setEditingId]=useState<string|null>(null);

  useEffect(()=>{
    let active=true;setRecordsLoading(true);
    async function load(){
      if(view==='appointments' && profile.role==='client') return;
      const production=isSupabaseConfigured()&&process.env.NEXT_PUBLIC_DEMO_MODE!=='true'&&Boolean(profile.clinic_id);
      if(!production){
        if(process.env.NEXT_PUBLIC_DEMO_MODE==='true'){
          try{const saved=localStorage.getItem(storageKey);if(saved)setRows(JSON.parse(saved));else setRows(seeds[view]||[])}catch{setRows(seeds[view]||[])}
        }else{setRows([]);setNotice(en?'Database connection unavailable. Changes are disabled.':'Supabase холболт алга. Өгөгдөл өөрчлөх боломжгүй.');}
        return;
      }
      const supabase=getSupabaseBrowser(); if(!supabase)return;
      let mapped:Row[]=[];
      if(view==='patients'){
        let patientQuery=supabase.from('patients').select('id,patient_code,external_patient_id,full_name,phone,register_no,date_of_birth,gender,address,emergency_phone,notes,created_at').eq('clinic_id',profile.clinic_id).is('deleted_at',null);
        if(isDoctor&&profile.id){
          const [a,e]=await Promise.all([
            supabase.from('appointments').select('patient_id').eq('clinic_id',profile.clinic_id).eq('doctor_id',profile.id),
            supabase.from('encounters').select('patient_id').eq('clinic_id',profile.clinic_id).eq('doctor_id',profile.id),
          ]);
          const patientIds=Array.from(new Set([...(a.data||[]),...(e.data||[])].map((x:any)=>String(x.patient_id||'')).filter(Boolean)));
          if(patientIds.length)patientQuery=patientQuery.in('id',patientIds);
          else patientQuery=patientQuery.eq('id','00000000-0000-0000-0000-000000000000');
        }
        const {data}=await patientQuery.order('created_at',{ascending:false});
        mapped=(data||[]).map((r:any)=>({id:r.id,title:r.full_name,patientCode:r.patient_code||undefined,subtitle:[r.external_patient_id,r.phone,r.register_no].filter(Boolean).join(' · ')||'Холбоо барих мэдээлэлгүй',meta:`Бүртгэсэн: ${new Date(r.created_at).toLocaleDateString('mn-MN')}`,payload:{name:r.full_name,phone:String(r.phone||'').replace(/^\+976/,''),externalId:r.external_patient_id||'',reg:r.register_no||'',dob:r.date_of_birth||'',gender:r.gender||'',address:r.address||'',emergencyPhone:String(r.emergency_phone||'').replace(/^\+976/,''),note:r.notes||''}}));
      }
      if(view==='appointments'){
        let aq=supabase.from('appointments').select('id,doctor_id,starts_at,service_name,status,patients(full_name),doctor:profiles!appointments_doctor_id_fkey(full_name)').eq('clinic_id',profile.clinic_id);
        if(isDoctor&&profile.id)aq=aq.eq('doctor_id',profile.id);
        const {data}=await aq.order('starts_at',{ascending:true}).limit(100);
        mapped=(data||[]).map((r:any)=>({id:r.id,title:r.patients?.full_name||'Өвчтөн',subtitle:`${r.service_name||'Үзлэг'}${r.doctor?.full_name?` · ${r.doctor.full_name}`:''}`,meta:new Date(r.starts_at).toLocaleString('mn-MN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}),status:statusLabel(r.status)}));
      }
      if(view==='treatments'){
        let tq=supabase.from('encounters').select('id,doctor_id,diagnosis,status,selected_teeth,dentition,created_at,patients(full_name),doctor:profiles!encounters_doctor_id_fkey(full_name)').eq('clinic_id',profile.clinic_id).is('deleted_at',null);
        if(isDoctor&&profile.id)tq=tq.eq('doctor_id',profile.id);
        const {data}=await tq.order('created_at',{ascending:false}).limit(100);
        mapped=(data||[]).map((r:any)=>({id:r.id,title:r.patients?.full_name||'Өвчтөн',subtitle:r.diagnosis||'Үзлэгийн тэмдэглэл',meta:`${new Date(r.created_at).toLocaleDateString('mn-MN')}${r.doctor?.full_name?` · ${r.doctor.full_name}`:''}`,status:r.status==='completed'?'Дууссан':'Нээлттэй',selectedTeeth:Array.isArray(r.selected_teeth)?r.selected_teeth:[],dentition:r.dentition==='child'?'child':'adult'}));
      }
      if(view==='inventory'){
        const {data}=await supabase.from('inventory_items').select('id,name,sku,quantity,min_quantity,batch_no,expiry_date,created_at').eq('clinic_id',profile.clinic_id).order('created_at',{ascending:false});
        mapped=(data||[]).map((r:any)=>{const exp=r.expiry_date?String(r.expiry_date):'';const days=exp?Math.ceil((new Date(exp+'T23:59:59').getTime()-Date.now())/86400000):null;const stockLow=Number(r.min_quantity)>0&&Number(r.quantity)<=Number(r.min_quantity);const expiring=days!==null&&days<=30;return {id:r.id,title:r.name,subtitle:`SKU: ${r.sku||'-'} · Үлдэгдэл ${r.quantity}${r.batch_no?` · Batch ${r.batch_no}`:''}`,meta:[`Дахин захиалах босго: ${r.min_quantity}`,exp?`Хугацаа: ${exp}`:''].filter(Boolean).join(' · '),status:days!==null&&days<0?'Хугацаа дууссан':expiring?'Хугацаа ойртсон':stockLow?'Нөөц бага':undefined,payload:{name:r.name,sku:r.sku||'',qty:String(r.quantity??0),min:String(r.min_quantity??0),batchNo:r.batch_no||'',expiry:exp}}});
      }
      if(view==='finance'){
        const {data}=await supabase.from('finance_transactions').select('id,kind,description,amount,payment_method,created_at').eq('clinic_id',profile.clinic_id).order('created_at',{ascending:false}).limit(100);
        mapped=(data||[]).map((r:any)=>({id:r.id,title:r.description,subtitle:r.payment_method||'Төлбөрийн хэлбэргүй',meta:`${r.kind==='expense'?'-':'+'} ₮${Number(r.amount).toLocaleString()}`,status:r.kind==='expense'?'Зарлага':'Орлого',payload:{kind:r.kind==='expense'?(en?'Expense':'Зарлага'):(en?'Income':'Орлого'),description:r.description||'',amount:String(r.amount??0),method:r.payment_method||''}}));
      }
      if(view==='cashbook'){
        const {data}=await supabase.from('finance_transactions').select('id,kind,description,amount,payment_method,created_at,patient_id,encounter_id').eq('clinic_id',profile.clinic_id).order('created_at',{ascending:false}).limit(250);
        mapped=(data||[]).map((r:any)=>({id:r.id,title:r.description,subtitle:r.payment_method||'Төлбөрийн хэлбэргүй',meta:`${r.kind==='expense'?'-':'+'} ₮${Number(r.amount).toLocaleString()} · ${new Date(r.created_at).toLocaleString(en?'en-US':'mn-MN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'})}`,status:r.kind==='expense'?(en?'Expense':'Зарлага'):(en?'Income':'Орлого'),payload:{kind:r.kind==='expense'?(en?'Expense':'Зарлага'):(en?'Income':'Орлого'),description:r.description||'',amount:String(r.amount??0),method:r.payment_method||'',patientId:r.patient_id||'',encounterId:r.encounter_id||''}}));
      }
      if(view==='services'){
        const {data}=await supabase.from('services').select('id,name,category,subcategory,price,duration_minutes,active,is_category,service_code,external_source,external_source_id,created_at').eq('clinic_id',profile.clinic_id).order('created_at',{ascending:false});
        mapped=(data||[]).map((r:any)=>({id:r.id,title:r.name,subtitle:[r.category,r.subcategory].filter(Boolean).join(' › ')||'Ангилалгүй',meta:r.is_category?'Ангилал':`${r.service_code?`${r.service_code} · `:''}₮${Number(r.price||0).toLocaleString()} · ${Number(r.duration_minutes||30)} мин`,status:r.active===false?'Идэвхгүй':r.is_category?'Ангилал':'Идэвхтэй',isCategory:Boolean(r.is_category),category:r.category||undefined,subcategory:r.subcategory||undefined,serviceCode:r.service_code||undefined,externalSource:r.external_source||undefined,externalSourceId:r.external_source_id||undefined,payload:{name:r.name,code:r.service_code||'',category:r.category||'',subcategory:r.subcategory||'',price:String(r.price??0),duration:String(r.duration_minutes??30)}}));
      }
      if(view==='staff'){
        const {data}=await supabase.from('profiles').select('id,full_name,role,phone,active,specialty').eq('clinic_id',profile.clinic_id).in('role',['owner','employee']).order('full_name',{ascending:true});
        mapped=(data||[]).map((r:any)=>{const isDoctor=r.role!=='owner'&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(r.specialty||'');return {id:r.id,title:r.full_name,subtitle:[r.phone,r.specialty|| (r.role==='owner'?'Эзэмшигч':'Ажилтан')].filter(Boolean).join(' · '),meta:r.active===false?'Эрх цуцлагдсан':'Системд нэвтрэх эрхтэй',status:r.active===false?'Идэвхгүй':'Идэвхтэй',category:r.role==='owner'?'owner':isDoctor?'doctor':'staff'};});
      }
      if(genericErpViews.includes(view)){
        const {data}=await supabase.from('erp_records').select('id,title,subtitle,meta,status,payload,created_at').eq('clinic_id',profile.clinic_id).eq('module_key',view).order('created_at',{ascending:false}).limit(200);
        mapped=(data||[]).map((r:any)=>({id:r.id,title:r.title,subtitle:r.subtitle||'',meta:r.meta||'',status:r.status||undefined,patientCode:r.payload?.patientCode||undefined,payload:r.payload||{}}));
      }
      if(active)setRows(mapped);
    }
    load().catch((e:any)=>{if(active)setNotice(e?.message||'Өгөгдөл уншиж чадсангүй.')}).finally(()=>{if(active)setRecordsLoading(false)}); return()=>{active=false};
  },[storageKey,view,profile.clinic_id,profile.id,profile.role,profile.specialty,isDoctor]);

  useEffect(()=>{
    if(!notice)return;
    const timer=window.setTimeout(()=>setNotice(''),3200);
    return()=>window.clearTimeout(timer);
  },[notice]);

  useEffect(()=>{
    if(!modal||!profile.clinic_id||!isSupabaseConfigured())return;
    let alive=true;setRefsLoading(true);
    (async()=>{
      const s=getSupabaseBrowser();if(!s)return;
      try{
        let patientRefQuery=s.from('patients').select('id,patient_code,full_name,phone,register_no').eq('clinic_id',profile.clinic_id).is('deleted_at',null);
        if(isDoctor&&profile.id){
          const [a,e]=await Promise.all([
            s.from('appointments').select('patient_id').eq('clinic_id',profile.clinic_id).eq('doctor_id',profile.id),
            s.from('encounters').select('patient_id').eq('clinic_id',profile.clinic_id).eq('doctor_id',profile.id),
          ]);
          const patientIds=Array.from(new Set([...(a.data||[]),...(e.data||[])].map((x:any)=>String(x.patient_id||'')).filter(Boolean)));
          if(patientIds.length)patientRefQuery=patientRefQuery.in('id',patientIds);
          else patientRefQuery=patientRefQuery.eq('id','00000000-0000-0000-0000-000000000000');
        }
        const [p,inv,staff,sup]=await Promise.all([
          patientRefQuery.order('full_name'),
          s.from('inventory_items').select('id,name,sku,quantity').eq('clinic_id',profile.clinic_id).order('name'),
          s.from('profiles').select('id,full_name,specialty').eq('clinic_id',profile.clinic_id).in('role',['owner','employee']).eq('active',true).order('full_name'),
          s.from('erp_records').select('id,title,subtitle').eq('clinic_id',profile.clinic_id).eq('module_key','suppliers').order('title'),
        ]);
        if(!alive)return;
        setRefs({
          patients:(p.data||[]).map((x:any)=>({id:x.id,label:x.full_name,code:x.patient_code||undefined,meta:[x.patient_code,x.phone,x.register_no].filter(Boolean).join(' · ')})),
          inventory:(inv.data||[]).map((x:any)=>({id:x.id,label:x.name,meta:[x.sku?`SKU ${x.sku}`:'',`${Number(x.quantity||0)} үлдэгдэл`].filter(Boolean).join(' · ')})),
          staff:(staff.data||[]).map((x:any)=>({id:x.id,label:x.full_name,meta:x.specialty||'Эмч / Ажилтан'})),
          suppliers:(sup.data||[]).map((x:any)=>({id:x.id,label:x.title,meta:x.subtitle||''})),
        });
      } finally {if(alive)setRefsLoading(false)}
    })();
    return()=>{alive=false};
  },[modal,profile.clinic_id,profile.id,profile.role,profile.specialty,isDoctor]);

  function persist(next:Row[]){setRows(next);if(process.env.NEXT_PUBLIC_DEMO_MODE==='true'){try{localStorage.setItem(storageKey,JSON.stringify(next))}catch{}}}
  function statusLabel(status?:string){return status==='done'?'Дууссан':status==='cancelled'?'Цуцлагдсан':status==='in_progress'?'Үзэж байна':status==='checked_in'?'Ирсэн':'Баталгаажсан'}


  const filtered=useMemo(()=>rows.filter(r=>`${r.title} ${r.subtitle} ${r.meta} ${r.patientCode||''}`.toLowerCase().includes(query.toLowerCase())),[rows,query]);
  const moduleStats=useMemo(()=>{
    const statusRows=rows.filter(r=>Boolean(r.status));
    const statusTypes=new Set(statusRows.map(r=>r.status)).size;
    const numericTotal=rows.reduce((sum,row)=>{const firstMatch=(row.meta.match(/[\d,]+/g)||[]).at(0)??'';const n=firstMatch?Number(firstMatch.replace(/,/g,'')):0;return sum+(Number.isFinite(n)?n:0)},0);
    return {total:rows.length,matched:filtered.length,statusRows:statusRows.length,statusTypes,numericTotal,coded:rows.filter(r=>Boolean(r.patientCode)).length};
  },[rows,filtered]);
  const staffGroups=useMemo(()=>{
    if(view!=='staff')return {doctors:[] as Row[],staff:[] as Row[],owners:[] as Row[]};
    return {doctors:filtered.filter(r=>r.category==='doctor'),staff:filtered.filter(r=>r.category==='staff'),owners:filtered.filter(r=>r.category==='owner')};
  },[view,filtered]);
  const serviceCategoryNames=useMemo(()=>{
    if(view!=='services')return [] as string[];
    const names=new Set<string>();
    rows.forEach(row=>{
      if(row.isCategory&&row.title.trim())names.add(row.title.trim());
      else if(row.category?.trim())names.add(row.category.trim());
      else {const first=row.subtitle.split('›')[0]?.trim();if(first&&first!=='Ангилалгүй')names.add(first)}
    });
    return Array.from(names).sort((a,b)=>a.localeCompare(b,'mn'));
  },[rows,view]);
  const serviceSubcategoryNames=useMemo(()=>{
    if(view!=='services'||!form.category)return [] as string[];
    const names=new Set<string>();
    rows.filter(row=>!row.isCategory&&(row.category||row.subtitle.split('›')[0]?.trim())===form.category).forEach(row=>{if(row.subcategory?.trim())names.add(row.subcategory.trim())});
    return Array.from(names).sort((a,b)=>a.localeCompare(b,'mn'));
  },[rows,view,form.category]);
  const serviceGroups=useMemo(()=>{
    if(view!=='services')return [] as Array<{category:string;heading?:Row;subgroups:Array<{name:string;rows:Row[]}>}>;
    const map=new Map<string,Map<string,Row[]>>();
    for(const category of serviceCategoryNames)map.set(category,new Map());
    for(const row of filtered){
      if(row.isCategory)continue;
      const parts=row.subtitle.split('›').map(x=>x.trim()).filter(Boolean);
      const category=row.category?.trim()||parts[0]||'Бусад'; const sub=row.subcategory?.trim()||parts[1]||'Ерөнхий';
      if(!map.has(category))map.set(category,new Map());
      const submap=map.get(category)!; if(!submap.has(sub))submap.set(sub,[]); submap.get(sub)!.push(row);
    }
    return Array.from(map.entries()).map(([category,sub])=>({category,heading:rows.find(r=>r.isCategory&&r.title.trim().toLowerCase()===category.trim().toLowerCase()),subgroups:Array.from(sub.entries()).map(([name,items])=>({name,rows:items}))}));
  },[filtered,rows,serviceCategoryNames,view]);
  const inventoryGroups=useMemo(()=>{
    if(view!=='inventory')return [] as Array<{name:string,total:number,batches:Row[]}>;
    const map=new Map<string,{name:string,total:number,batches:Row[]}>();
    for(const row of filtered){const key=row.title.trim().toLocaleLowerCase('mn-MN');const current=map.get(key)||{name:row.title,total:0,batches:[]};current.total+=Number(row.payload?.qty||0);current.batches.push(row);map.set(key,current)}
    return Array.from(map.values()).sort((a,b)=>a.name.localeCompare(b.name,'mn'));
  },[view,filtered]);
  const importInputRef = useRef<HTMLInputElement|null>(null);
  const patientImportRef = useRef<HTMLInputElement|null>(null);
  const inventoryImportRef = useRef<HTMLInputElement|null>(null);

  async function refreshPatients(){
    if(view!=='patients'||!profile.clinic_id||!isSupabaseConfigured())return;
    const supabase=getSupabaseBrowser();if(!supabase)return;
    const {data,error}=await supabase.from('patients').select('id,patient_code,external_patient_id,full_name,phone,register_no,date_of_birth,gender,address,emergency_phone,notes,created_at').eq('clinic_id',profile.clinic_id).is('deleted_at',null).order('created_at',{ascending:false});if(error)throw error;
    setRows((data||[]).map((r:any)=>({id:r.id,title:r.full_name,patientCode:r.patient_code||undefined,subtitle:[r.external_patient_id,r.phone,r.register_no].filter(Boolean).join(' · ')||'Холбоо барих мэдээлэлгүй',meta:`Бүртгэсэн: ${new Date(r.created_at).toLocaleDateString('mn-MN')}`,payload:{name:r.full_name,phone:String(r.phone||'').replace(/^\+976/,''),externalId:r.external_patient_id||'',reg:r.register_no||'',dob:r.date_of_birth||'',gender:r.gender||'',address:r.address||'',emergencyPhone:String(r.emergency_phone||'').replace(/^\+976/,''),note:r.notes||''}})));
  }

  async function exportPatientsExcel(){
    try{
      const body=await apiJson('/api/admin/excel-sync?entity=patients');const rows=Array.isArray(body.rows)?body.rows:[];const XLSX=await import('xlsx');const wb=XLSX.utils.book_new();
      const headers=['patient_id','patient_code','external_patient_id','full_name','phone','register_no','date_of_birth','gender','address','emergency_phone','notes'];
      const sheet=rows.length?XLSX.utils.json_to_sheet(rows.map((r:any)=>Object.fromEntries(headers.map(h=>[h,r[h]??'']))),{header:headers}):XLSX.utils.aoa_to_sheet([headers]);
      sheet['!cols']=headers.map(h=>({wch:h==='full_name'||h==='address'||h==='notes'?30:18}));XLSX.utils.book_append_sheet(wb,sheet,'Patients');
      const guide=XLSX.utils.aoa_to_sheet([[en?'DentHub patient Excel import':'DentHub өвчтөн Excel импорт'],[en?'Keep patient_id for existing patients. Leave patient_id blank to create a new patient.':'Одоо байгаа өвчтөнийг засах бол patient_id-г хэвээр үлдээнэ. Шинэ өвчтөн нэмэх бол patient_id-г хоосон үлдээнэ.'],[en?'Phone and emergency_phone must be 8-digit Mongolian numbers.':'phone болон emergency_phone нь 8 оронтой Монгол дугаар байна.']]);guide['!cols']=[{wch:100}];XLSX.utils.book_append_sheet(wb,guide,'README');
      XLSX.writeFile(wb,`denthub-patients-${new Date().toISOString().slice(0,10)}.xlsx`);setNotice(en?'Patient Excel downloaded.':'Өвчтөний Excel файл татагдлаа.');
    }catch(e:any){setNotice(e?.message||'Өвчтөний Excel татаж чадсангүй.');}
  }

  async function importPatientsExcel(file:File){
    setSaving(true);setNotice('');
    try{const XLSX=await import('xlsx');const buf=await file.arrayBuffer();const wb=XLSX.read(buf,{type:'array'});const sheet=wb.Sheets[wb.SheetNames[0]];if(!sheet)throw new Error('Excel sheet олдсонгүй.');const rows=XLSX.utils.sheet_to_json(sheet,{defval:''});if(!rows.length)throw new Error('Өгөгдлийн мөр олдсонгүй.');const body=await apiJson('/api/admin/excel-sync',{method:'POST',body:JSON.stringify({entity:'patients',rows})});await refreshPatients();const errors=Array.isArray(body.errors)?body.errors:[];setNotice(en?`Patient Excel applied: ${body.updated||0} updated, ${body.created||0} created${errors.length?`, ${errors.length} errors`:''}.`:`Өвчтөний Excel орлоо: ${body.updated||0} шинэчилсэн, ${body.created||0} шинээр нэмсэн${errors.length?`, ${errors.length} мөр алдаатай`:''}. ${errors.slice(0,2).join(' | ')}`);}catch(e:any){setNotice(e?.message||'Өвчтөний Excel импорт хийж чадсангүй.');}finally{setSaving(false);if(patientImportRef.current)patientImportRef.current.value='';}
  }

  async function refreshInventory(){
    if(view!=='inventory'||!profile.clinic_id||!isSupabaseConfigured())return;const supabase=getSupabaseBrowser();if(!supabase)return;
    const {data,error}=await supabase.from('inventory_items').select('id,name,sku,quantity,min_quantity,batch_no,expiry_date,created_at').eq('clinic_id',profile.clinic_id).order('name').order('expiry_date',{ascending:true,nullsFirst:false});if(error)throw error;
    setRows((data||[]).map((r:any)=>{const exp=r.expiry_date?String(r.expiry_date):'';const days=exp?Math.ceil((new Date(exp+'T23:59:59').getTime()-Date.now())/86400000):null;const stockLow=Number(r.min_quantity)>0&&Number(r.quantity)<=Number(r.min_quantity);const expiring=days!==null&&days<=30;return {id:r.id,title:r.name,subtitle:`SKU: ${r.sku||'-'} · Үлдэгдэл ${r.quantity}${r.batch_no?` · Batch ${r.batch_no}`:''}`,meta:[`Дахин захиалах босго: ${r.min_quantity}`,exp?`Хугацаа: ${exp}`:''].filter(Boolean).join(' · '),status:days!==null&&days<0?'Хугацаа дууссан':expiring?'Хугацаа ойртсон':stockLow?'Нөөц бага':undefined,payload:{name:r.name,sku:r.sku||'',qty:String(r.quantity??0),min:String(r.min_quantity??0),batchNo:r.batch_no||'',expiry:exp}}}));
  }

  async function exportInventoryExcel(){
    try{const XLSX=await import('xlsx');const supabase=getSupabaseBrowser();let data:any[]=[];if(supabase&&profile.clinic_id){const res=await supabase.from('inventory_items').select('id,name,sku,quantity,min_quantity,batch_no,expiry_date').eq('clinic_id',profile.clinic_id).order('name').order('expiry_date',{ascending:true,nullsFirst:false});if(res.error)throw res.error;data=(res.data||[]).map((r:any)=>({inventory_id:r.id,name:r.name,sku:r.sku||'',batch_no:r.batch_no||'',expiry_date:r.expiry_date||'',quantity:Number(r.quantity||0),min_quantity:Number(r.min_quantity||0)}))}else data=rows.map(r=>({inventory_id:r.id,name:r.title,sku:r.payload?.sku||'',batch_no:r.payload?.batchNo||'',expiry_date:r.payload?.expiry||'',quantity:Number(r.payload?.qty||0),min_quantity:Number(r.payload?.min||0)}));
      const detail=XLSX.utils.json_to_sheet(data,{header:['inventory_id','name','sku','batch_no','expiry_date','quantity','min_quantity']});detail['!cols']=[{wch:38},{wch:30},{wch:18},{wch:20},{wch:16},{wch:14},{wch:16}];const sums=new Map<string,number>();for(const r of data)sums.set(r.name,(sums.get(r.name)||0)+Number(r.quantity||0));const summary=XLSX.utils.json_to_sheet(Array.from(sums.entries()).map(([name,quantity])=>({'Барааны нэр':name,'Нийт үлдэгдэл':quantity})));summary['!cols']=[{wch:34},{wch:18}];const guide=XLSX.utils.aoa_to_sheet([['DentHub бараа материал Excel импорт'],['Нэг бараа өөр batch / дуусах хугацаатай бол тусдаа мөрөөр оруулна.'],['Ижил name + sku + batch_no + expiry_date мөр импортлоход тухайн batch-ийн quantity шинэчлэгдэнэ.'],['Шинэ batch нэмэх бол inventory_id-г хоосон үлдээнэ.']]);guide['!cols']=[{wch:100}];const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,detail,'Бараа материал');XLSX.utils.book_append_sheet(wb,summary,'Нэрээр нийлбэр');XLSX.utils.book_append_sheet(wb,guide,'README');XLSX.writeFile(wb,`denthub-inventory-${new Date().toISOString().slice(0,10)}.xlsx`);setNotice(en?'Inventory Excel downloaded.':'Бараа материалын Excel татагдлаа.');
    }catch(e:any){setNotice(e?.message||'Бараа материалын Excel татаж чадсангүй.')}
  }

  async function importInventoryExcel(file:File){
    if(profile.role!=='owner'||!profile.clinic_id)return;setSaving(true);setNotice('');
    try{const XLSX=await import('xlsx');const buf=await file.arrayBuffer();const wb=XLSX.read(buf,{type:'array'});const sheet=wb.Sheets[wb.SheetNames[0]];if(!sheet)throw new Error('Excel sheet олдсонгүй.');const raw=XLSX.utils.sheet_to_json(sheet,{defval:''}) as any[];if(!raw.length)throw new Error('Импортлох мөр алга.');const value=(r:any,...keys:string[])=>{for(const k of keys){if(r[k]!==undefined&&String(r[k]).trim()!=='')return r[k]}return ''};const normalized=raw.map((r:any)=>({id:String(value(r,'inventory_id','id')||'').trim(),name:String(value(r,'name','Барааны нэр','Нэр')||'').trim(),sku:String(value(r,'sku','SKU')||'').trim(),batch:String(value(r,'batch_no','batch','Batch','Цуврал')||'').trim(),expiry:String(value(r,'expiry_date','expiry','Хүчинтэй хугацаа','Дуусах хугацаа')||'').trim().slice(0,10),qty:Math.max(0,Number(value(r,'quantity','qty','Тоо хэмжээ','Үлдэгдэл')||0)),min:Math.max(0,Number(value(r,'min_quantity','min','Доод үлдэгдэл','Дахин захиалах босго')||0))})).filter((r:any)=>r.name);if(!normalized.length)throw new Error('Барааны нэртэй мөр олдсонгүй.');const s=getSupabaseBrowser();if(!s)throw new Error('Supabase холболт алга.');const {data:existing,error:loadError}=await s.from('inventory_items').select('id,name,sku,batch_no,expiry_date').eq('clinic_id',profile.clinic_id);if(loadError)throw loadError;type InventoryImportKnownRow={id:string;name:string;sku:string|null;batch_no:string|null;expiry_date:string|null};const rowsNow:InventoryImportKnownRow[]=[...((existing||[]) as InventoryImportKnownRow[])];let created=0,updated=0;for(const r of normalized){let match:any=null;if(r.id)match=rowsNow.find((x:any)=>x.id===r.id);if(!match)match=rowsNow.find((x:any)=>String(x.name||'').trim().toLowerCase()===r.name.toLowerCase()&&String(x.sku||'').trim().toLowerCase()===r.sku.toLowerCase()&&String(x.batch_no||'').trim().toLowerCase()===r.batch.toLowerCase()&&String(x.expiry_date||'').slice(0,10)===r.expiry);const data={name:r.name,sku:r.sku||null,batch_no:r.batch||null,expiry_date:r.expiry||null,quantity:r.qty,min_quantity:r.min};if(match){const res=await s.from('inventory_items').update(data).eq('id',match.id).eq('clinic_id',profile.clinic_id);if(res.error)throw res.error;updated++}else{const res=await s.from('inventory_items').insert({clinic_id:profile.clinic_id,...data}).select('id,name,sku,batch_no,expiry_date').single();if(res.error)throw res.error;rowsNow.push(res.data as InventoryImportKnownRow);created++}}await refreshInventory();setNotice(en?`Inventory Excel applied: ${updated} updated, ${created} created.`:`Бараа материал Excel орлоо: ${updated} batch шинэчилсэн, ${created} batch шинээр нэмсэн.`);
    }catch(e:any){setNotice(e?.message||'Бараа материалын Excel импорт хийж чадсангүй.')}finally{setSaving(false);if(inventoryImportRef.current)inventoryImportRef.current.value=''}
  }

  async function exportServicesExcel(){
    try{
      const XLSX=await import('xlsx');
      const supabase=getSupabaseBrowser();
      let exported:any[]=[];
      if(supabase&&profile.clinic_id){
        const {data,error}=await supabase.from('services').select('id,name,service_code,category,subcategory,price,duration_minutes,active,is_category').eq('clinic_id',profile.clinic_id).order('created_at',{ascending:true});
        if(error)throw error;
        exported=(data||[]).map((row:any)=>({service_id:row.id,record_type:row.is_category?'category':'service',name:row.name,service_code:row.is_category?'':(row.service_code||''),category:row.is_category?row.name:(row.category||''),subcategory:row.is_category?'':(row.subcategory||''),price:row.is_category?0:Number(row.price||0),duration_minutes:row.is_category?30:Number(row.duration_minutes||30),active:row.active!==false,action:''}));
      }else{
        exported=rows.map(row=>({service_id:row.id,record_type:row.isCategory?'category':'service',name:row.title,service_code:row.isCategory?'':(row.serviceCode||''),category:row.isCategory?row.title:(row.category||''),subcategory:row.isCategory?'':(row.subcategory||''),price:row.isCategory?0:Number((row.meta.match(/₮([\d,]+)/)?.[1]||'0').replace(/,/g,'')),duration_minutes:row.isCategory?30:Number(row.meta.match(/(\d+) мин/)?.[1]||30),active:row.status==='Идэвхгүй'?false:true,action:''}));
      }
      const sheet=XLSX.utils.json_to_sheet(exported,{header:['service_id','record_type','name','service_code','category','subcategory','price','duration_minutes','active','action']});
      sheet['!cols']=[{wch:38},{wch:14},{wch:34},{wch:16},{wch:34},{wch:28},{wch:14},{wch:18},{wch:12},{wch:14}];
      sheet['!autofilter']={ref:`A1:J${Math.max(1,exported.length+1)}`};
      const help=XLSX.utils.aoa_to_sheet([
        ['DentHub үйлчилгээ & үнэ — Excel round-trip'],
        ['1. service_id баганыг өөрчлөхгүй. Энэ ID-аар яг тухайн Supabase мөр шинэчлэгдэнэ.'],
        ['2. name / service_code / category / subcategory / price / duration_minutes / active утгыг засаж болно.'],
        ['3. Мөрийг устгах бол action баганад DELETE гэж бичнэ.'],
        ['4. Шинэ үйлчилгээ нэмэхдээ service_id-г хоосон, record_type-г service гэж үлдээнэ.'],
        ['5. Шинэ ангилал нэмэхдээ service_id-г хоосон, record_type-г category гэж бичнэ.'],
      ]);
      help['!cols']=[{wch:105}];
      const wb=XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb,sheet,'Үйлчилгээ');
      XLSX.utils.book_append_sheet(wb,help,'Заавар');
      XLSX.writeFile(wb,`denthub-services-${new Date().toISOString().slice(0,10)}.xlsx`);
      setNotice(en?'Excel file downloaded. Edit it and import the same file to update DentHub.':'Excel файл татагдлаа. Засварлаад буцааж импортлоход DentHub шинэчлэгдэнэ.');
    }catch(e:any){setNotice(e?.message||'Excel экспорт хийж чадсангүй.');}
  }

  async function readServiceSpreadsheet(file:File){
    const XLSX=await import('xlsx');
    const workbook=XLSX.read(await file.arrayBuffer(),{type:'array'});
    const sheet=workbook.Sheets[workbook.SheetNames.includes('Үйлчилгээ')?'Үйлчилгээ':workbook.SheetNames[0]];
    if(!sheet)throw new Error(en?'No worksheet found.':'Excel sheet олдсонгүй.');
    return XLSX.utils.sheet_to_json(sheet,{defval:'',raw:false}) as Record<string,unknown>[];
  }

  async function prepareServiceImport(file:File){
    try{
      const rows=await readServiceSpreadsheet(file);
      const deleteCount=rows.filter(record=>String(record.action??'').trim().toLowerCase()==='delete').length;
      if(deleteCount>0){setPendingExcelImport(file);setPendingExcelDeleteCount(deleteCount);return}
      await importServices(file);
    }catch(e:any){setNotice(e?.message||'Excel файл уншиж чадсангүй.');if(importInputRef.current)importInputRef.current.value='';}
  }

  async function importServices(file:File){
    try{
      const input=await readServiceSpreadsheet(file);
      if(!input.length)throw new Error(en?'The spreadsheet is empty.':'Excel файл хоосон байна.');
      const normalize=(value:unknown)=>String(value??'').trim();
      const truthy=(value:unknown)=>!['false','0','no','inactive','идэвхгүй','үгүй'].includes(normalize(value).toLowerCase());
      const payload=input.map(record=>({
        id:normalize(record.service_id||record.id),
        recordType:(normalize(record.record_type)||'service').toLowerCase(),
        name:normalize(record.name),
        serviceCode:normalize(record.service_code||record.code),
        category:normalize(record.category),
        subcategory:normalize(record.subcategory),
        price:Math.max(0,Number(normalize(record.price).replace(/[^0-9.-]/g,''))||0),
        duration_minutes:Math.max(5,Number(normalize(record.duration_minutes).replace(/[^0-9.-]/g,''))||30),
        active:truthy(record.active),
        action:normalize(record.action).toLowerCase(),
      })).filter(row=>row.name||row.id);
      if(!payload.length)throw new Error(en?'No valid rows found.':'Зөв мөр олдсонгүй.');
      const supabase=getSupabaseBrowser();if(!supabase||!profile.clinic_id)throw new Error('Supabase холболт дутуу байна.');
      const {data:existing,error:existingError}=await supabase.from('services').select('id,name,category,subcategory,is_category,service_code').eq('clinic_id',profile.clinic_id);
      if(existingError)throw existingError;
      type ServiceImportKnownRow={id:string;name:string;category:string|null;subcategory:string|null;is_category:boolean;service_code:string|null};
      const known:ServiceImportKnownRow[]=[...((existing||[]) as ServiceImportKnownRow[])];
      let updated=0,created=0,deleted=0;
      const categoryRows=payload.filter(row=>row.recordType==='category');
      const serviceRows=payload.filter(row=>row.recordType!=='category');
      for(const row of categoryRows){
        const match=known.find((item:any)=>item.id===row.id)||known.find((item:any)=>item.is_category&&item.name?.trim().toLowerCase()===row.name.toLowerCase());
        if(row.action==='delete'){
          if(match){
            const {error:moveError}=await supabase.from('services').update({category:null,subcategory:null}).eq('clinic_id',profile.clinic_id).eq('category',match.name).eq('is_category',false);if(moveError)throw moveError;
            const {error}=await supabase.from('services').delete().eq('id',match.id).eq('clinic_id',profile.clinic_id);if(error)throw error;deleted++;
          }
          continue;
        }
        if(!row.name)continue;
        if(match){
          const oldName=match.name;
          if(oldName!==row.name){const {error}=await supabase.from('services').update({category:row.name}).eq('clinic_id',profile.clinic_id).eq('category',oldName).eq('is_category',false);if(error)throw error;}
          const {error}=await supabase.from('services').update({name:row.name,category:row.name,active:row.active}).eq('id',match.id).eq('clinic_id',profile.clinic_id);if(error)throw error;updated++;
          match.name=row.name;match.category=row.name;
        }else{
          const {data,error}=await supabase.from('services').insert({clinic_id:profile.clinic_id,name:row.name,category:row.name,subcategory:null,price:0,duration_minutes:30,active:row.active,is_category:true}).select('id,name,category,subcategory,is_category,service_code').single();if(error)throw error;known.push(data as ServiceImportKnownRow);created++;
        }
      }
      const categoryNames=new Set<string>(serviceRows.filter(r=>r.action!=='delete'&&r.category).map(r=>String(r.category)));
      for(const category of categoryNames){
        if(known.some((item:any)=>item.is_category&&item.name?.trim().toLowerCase()===category.toLowerCase()))continue;
        const {data,error}=await supabase.from('services').insert({clinic_id:profile.clinic_id,name:category,category,subcategory:null,price:0,duration_minutes:30,active:true,is_category:true}).select('id,name,category,subcategory,is_category,service_code').single();if(error)throw error;known.push(data as ServiceImportKnownRow);created++;
      }
      for(const row of serviceRows){
        const match=known.find((item:any)=>item.id===row.id)
          ||known.find((item:any)=>!item.is_category&&[item.name,item.service_code||'',item.category||'',item.subcategory||''].map((x:string)=>String(x).trim().toLowerCase()).join('|')===[row.name,row.serviceCode,row.category,row.subcategory].map(x=>x.trim().toLowerCase()).join('|'));
        if(row.action==='delete'){
          if(match){const {error}=await supabase.from('services').delete().eq('id',match.id).eq('clinic_id',profile.clinic_id);if(error)throw error;deleted++;}
          continue;
        }
        if(!row.name)continue;
        const data={clinic_id:profile.clinic_id,name:row.name,service_code:row.serviceCode||null,category:row.category||null,subcategory:row.subcategory||null,price:row.price,duration_minutes:row.duration_minutes,active:row.active,is_category:false};
        if(match){const {error}=await supabase.from('services').update(data).eq('id',match.id).eq('clinic_id',profile.clinic_id);if(error)throw error;updated++;}
        else{const {data:createdRow,error}=await supabase.from('services').insert(data).select('id,name,service_code,category,subcategory,is_category').single();if(error)throw error;known.push(createdRow as ServiceImportKnownRow);created++;}
      }
      await refreshServices();
      setNotice(en?`Excel applied: ${updated} updated, ${created} created, ${deleted} deleted.`:`Excel өөрчлөлт орлоо: ${updated} шинэчилсэн, ${created} нэмсэн, ${deleted} устгасан.`);
    }catch(e:any){setNotice(e?.message||'Excel импорт хийж чадсангүй.');}
    finally{if(importInputRef.current)importInputRef.current.value='';}
  }


  async function confirmDeletePatient(){
    const target=deletePatientTarget;if(!target||profile.role!=='owner')return;setSaving(true);setNotice('');
    try{await apiJson('/api/patients',{method:'DELETE',body:JSON.stringify({id:target.id})});setRows(list=>list.filter(x=>x.id!==target.id));if(selected?.id===target.id)setSelected(null);setDeletePatientTarget(null);setNotice(en?'Patient removed. Historical accounting records remain protected.':'Өвчтөний бүртгэл устгагдлаа. Өмнөх эмчилгээ, санхүүгийн түүх audit зорилгоор хамгаалагдана.')}catch(e:any){setNotice(e?.message||'Өвчтөн устгаж чадсангүй.')}finally{setSaving(false)}
  }

  async function confirmDeleteCashbook(){
    const target=deleteCashbookTarget;if(!target||profile.role!=='owner')return;setSaving(true);setNotice('');
    try{
      const production=isSupabaseConfigured()&&process.env.NEXT_PUBLIC_DEMO_MODE!=='true'&&Boolean(profile.clinic_id);
      if(production){const supabase=getSupabaseBrowser();if(!supabase)throw new Error('Supabase холболт дутуу байна.');const {error}=await supabase.rpc('denthub_delete_cashbook_entry',{p_finance_transaction_id:target.id});if(error)throw error;}
      setRows(list=>list.filter(x=>x.id!==target.id));if(selected?.id===target.id)setSelected(null);setDeleteCashbookTarget(null);setNotice(en?'Cashbook entry deleted and linked visit totals recalculated.':'Кассын бичилт устгагдаж, холбоотой эмчилгээний төлбөрийн дүн дахин тооцогдлоо.');
    }catch(e:any){setNotice(e?.message||'Кассын бичилт устгаж чадсангүй.')}finally{setSaving(false)}
  }


  async function refreshServices(){
    if(view!=='services')return;
    if(!isSupabaseConfigured()||process.env.NEXT_PUBLIC_DEMO_MODE==='true'||!profile.clinic_id)return;
    const supabase=getSupabaseBrowser();if(!supabase)return;
    const {data,error}=await supabase.from('services').select('id,name,category,subcategory,price,duration_minutes,active,is_category,service_code,external_source,external_source_id,created_at').eq('clinic_id',profile.clinic_id).order('created_at',{ascending:false});
    if(error)throw error;
    setRows((data||[]).map((r:any)=>({id:r.id,title:r.name,subtitle:[r.category,r.subcategory].filter(Boolean).join(' › ')||'Ангилалгүй',meta:r.is_category?'Ангилал':`${r.service_code?`${r.service_code} · `:''}₮${Number(r.price||0).toLocaleString()} · ${Number(r.duration_minutes||30)} мин`,status:r.active===false?'Идэвхгүй':r.is_category?'Ангилал':'Идэвхтэй',isCategory:Boolean(r.is_category),category:r.category||undefined,subcategory:r.subcategory||undefined,serviceCode:r.service_code||undefined,externalSource:r.external_source||undefined,externalSourceId:r.external_source_id||undefined,payload:r.is_category?undefined:{name:r.name,code:r.service_code||'',category:r.category||'',subcategory:r.subcategory||'',price:String(r.price??0),duration:String(r.duration_minutes??30)}})));
  }

  function openCategoryEditor(target:Row|null=null){
    setCategoryTarget(target);setCategoryName(target?.title||'');setCategoryModal(true);setNotice('');
  }
  async function saveCategory(){
    const name=categoryName.trim();if(!name)return setNotice(en?'Category name is required.':'Ангиллын нэр оруулна уу.');
    if(serviceCategoryNames.some(x=>x.toLowerCase()===name.toLowerCase()&&x.toLowerCase()!==categoryTarget?.title.toLowerCase()))return setNotice(en?'This category already exists.':'Ийм ангилал аль хэдийн байна.');
    setCategorySaving(true);
    try{
      const production=isSupabaseConfigured()&&process.env.NEXT_PUBLIC_DEMO_MODE!=='true'&&Boolean(profile.clinic_id);
      if(production){
        const supabase=getSupabaseBrowser();if(!supabase||!profile.clinic_id)throw new Error('Supabase холболт дутуу байна.');
        if(categoryTarget){
          const old=categoryTarget.title;
          const {error:childrenError}=await supabase.from('services').update({category:name}).eq('clinic_id',profile.clinic_id).eq('category',old).eq('is_category',false);if(childrenError)throw childrenError;
          const {error:headingError}=await supabase.from('services').update({name,category:name}).eq('id',categoryTarget.id).eq('clinic_id',profile.clinic_id);if(headingError)throw headingError;
        }else{
          const {error}=await supabase.from('services').insert({clinic_id:profile.clinic_id,name,category:name,subcategory:null,price:0,duration_minutes:30,active:true,is_category:true});if(error)throw error;
        }
        await refreshServices();
      }else{
        if(categoryTarget){setRows(list=>list.map(r=>r.id===categoryTarget.id?{...r,title:name,category:name,subtitle:name}:(!r.isCategory&&r.category===categoryTarget.title?{...r,category:name,subtitle:[name,r.subcategory].filter(Boolean).join(' › ')}:r)))}
        else setRows(list=>[{id:`cat-${Date.now()}`,title:name,subtitle:name,meta:'Ангилал',status:'Ангилал',isCategory:true,category:name},...list]);
      }
      setCategoryModal(false);setCategoryTarget(null);setCategoryName('');setNotice(en?'Category saved.':'Ангилал амжилттай хадгалагдлаа.');
    }catch(e:any){setNotice(e?.message||'Ангилал хадгалж чадсангүй.')}finally{setCategorySaving(false)}
  }
  async function confirmDeleteCategory(){
    const target=deleteCategoryTarget;if(!target)return;
    setCategorySaving(true);
    try{
      const production=isSupabaseConfigured()&&process.env.NEXT_PUBLIC_DEMO_MODE!=='true'&&Boolean(profile.clinic_id);
      if(production){
        const supabase=getSupabaseBrowser();if(!supabase||!profile.clinic_id)throw new Error('Supabase холболт дутуу байна.');
        const {error:moveError}=await supabase.from('services').update({category:null,subcategory:null}).eq('clinic_id',profile.clinic_id).eq('category',target.title).eq('is_category',false);if(moveError)throw moveError;
        const {error}=await supabase.from('services').delete().eq('id',target.id).eq('clinic_id',profile.clinic_id);if(error)throw error;
        await refreshServices();
      }else setRows(list=>list.filter(r=>r.id!==target.id).map(r=>!r.isCategory&&r.category===target.title?{...r,category:undefined,subcategory:undefined,subtitle:'Ангилалгүй'}:r));
      setNotice(en?'Category removed.':'Ангилал устгагдлаа.');
      setDeleteCategoryTarget(null);
    }catch(e:any){setNotice(e?.message||'Ангилал устгаж чадсангүй.')}finally{setCategorySaving(false)}
  }

  async function confirmDeleteService(){
    const target=deleteServiceTarget;if(!target||target.isCategory)return;
    setSaving(true);
    try{
      const production=isSupabaseConfigured()&&process.env.NEXT_PUBLIC_DEMO_MODE!=='true'&&Boolean(profile.clinic_id);
      if(production){
        const supabase=getSupabaseBrowser();if(!supabase||!profile.clinic_id)throw new Error('Supabase холболт дутуу байна.');
        const {error}=await supabase.from('services').delete().eq('id',target.id).eq('clinic_id',profile.clinic_id);if(error)throw error;
        await refreshServices();
      }else setRows(list=>list.filter(r=>r.id!==target.id));
      setSelected(null);setDeleteServiceTarget(null);setNotice(en?'Service deleted.':'Үйлчилгээ устгагдлаа.');
    }catch(e:any){setNotice(e?.message||'Үйлчилгээ устгаж чадсангүй.')}finally{setSaving(false)}
  }

  const employeeWriteViews:ViewKey[]=['patients','appointments','treatments','lab_orders','crm','shifts'];
  const specialty=(profile.specialty||'').toLowerCase();
  const legacyWriteViews:ViewKey[]=[...employeeWriteViews,
    ...((specialty.includes('ресеп')||specialty.includes('reception'))?(['sales'] as ViewKey[]):[]),
    ...((specialty.includes('нягт')||specialty.includes('finance')||specialty.includes('санхүү'))?(['sales','sales_returns','cashbook','invoices','receivables','expenses'] as ViewKey[]):[]),
  ];
  const employeeCanWrite=profile.role==='employee'&&((profile.allowed_modules?.length||0)>0?Boolean(profile.allowed_modules?.includes(view)):legacyWriteViews.includes(view));
  const canCreate=Boolean(item.action)&&(profile.role==='owner'||employeeCanWrite);

  function openNew(preset:Record<string,string>={}){
    const now=new Date();const stamp=`${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}-${String(now.getHours()).padStart(2,'0')}${String(now.getMinutes()).padStart(2,'0')}`;
    const defaults:Record<string,string>={};
    if(view==='inventory')Object.assign(defaults,{qty:'0',min:''});
    if(view==='stock_movements')Object.assign(defaults,{type:en?'Stock in':'Орлого',qty:'1',location:en?'Main warehouse':'Төв агуулах'});
    if(view==='purchase_orders')Object.assign(defaults,{number:`PO-${stamp}`,status:en?'Draft':'Ноорог'});
    if(view==='invoices')Object.assign(defaults,{number:`INV-${stamp}`,status:en?'Unpaid':'Төлөөгүй'});
    if(view==='services')Object.assign(defaults,{duration:'30'});
    if(view==='treatments')Object.assign(defaults,{dentition:'adult',selectedTeeth:''});
    if(view==='sales')Object.assign(defaults,{reference:`SALE-${stamp}`,date:now.toISOString().slice(0,10),status:en?'Completed':'Дууссан',method:'QPay'});
    if(view==='sales_returns')Object.assign(defaults,{reference:`RET-${stamp}`,date:now.toISOString().slice(0,10),status:en?'Pending':'Хүлээгдэж байна'});
    if(view==='cashbook')Object.assign(defaults,{reference:`CASH-${stamp}`,kind:en?'Income':'Орлого',method:en?'Cash':'Бэлэн'});
    if(view==='price_lists')Object.assign(defaults,{status:en?'Active':'Идэвхтэй'});
    Object.assign(defaults,preset);
    setEditingId(null);setForm(defaults);setModal(true);setNotice('');
  }

  function openEdit(row:Row){
    if(row.isCategory&&view==='services'){openCategoryEditor(row);return}
    if(!row.payload)return;
    setEditingId(row.id);
    setForm(Object.fromEntries(Object.entries(row.payload).map(([k,v])=>[k,String(v??'')])));
    setSelected(null);setModal(true);setNotice('');
  }
  async function apiJson(url:string,init?:RequestInit){
    const s=getSupabaseBrowser();if(!s)throw new Error('Supabase холболт дутуу байна.');
    const {data}=await s.auth.getSession();const token=data.session?.access_token;if(!token)throw new Error('Нэвтрэх эрх дууссан байна.');
    const res=await fetch(url,{...init,headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`,...(init?.headers||{})}});
    const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Алдаа гарлаа.');return body;
  }

  async function save(){
    setSaving(true); setNotice('');
    try{
      const production=isSupabaseConfigured()&&process.env.NEXT_PUBLIC_DEMO_MODE!=='true'&&Boolean(profile.clinic_id);
      if(production){
        const supabase=getSupabaseBrowser(); if(!supabase||!profile.clinic_id)throw new Error('Supabase холболт дутуу байна.');
        if(editingId&&view==='patients'){
          if(!form.name?.trim())throw new Error('Өвчтөний нэр оруулна уу.');
          if(form.phone && form.phone.replace(/\D/g,'').length!==8)throw new Error('Утасны дугаар 8 оронтой байна.');
          if(form.emergencyPhone && form.emergencyPhone.replace(/\D/g,'').length!==8)throw new Error('Яаралтай үед холбоо барих утас 8 оронтой байна.');
          const dobIso=birthDateToIso(form.dob||'');if(form.dob&&!dobIso)throw new Error(en?'Enter birth date as YYYY/MM/DD. Example: 2000/08/23':'Төрсөн огноог YYYY/MM/DD хэлбэрээр зөв оруулна уу. Жишээ: 2000/08/23');
          const updated=await apiJson('/api/patients',{method:'PATCH',body:JSON.stringify({id:editingId,fullName:form.name.trim(),phone:form.phone||'',registerNo:form.reg||'',externalPatientId:form.externalId||'',dateOfBirth:dobIso||'',address:form.address||'',emergencyPhone:form.emergencyPhone||'',notes:form.note||''})});
          const data=updated.patient;
          setRows(v=>v.map(r=>r.id===editingId?{...r,title:data.full_name,patientCode:data.patient_code||undefined,subtitle:[data.external_patient_id,data.phone,data.register_no].filter(Boolean).join(' · ')||'Холбоо барих мэдээлэлгүй',payload:{name:data.full_name,phone:String(data.phone||'').replace(/^\+976/,''),externalId:data.external_patient_id||'',reg:data.register_no||'',dob:data.date_of_birth||'',gender:data.gender||'',address:data.address||'',emergencyPhone:String(data.emergency_phone||'').replace(/^\+976/,''),note:data.notes||''}}:r));
        } else if(editingId&&view==='inventory'){
          if(!form.name?.trim())throw new Error('Барааны нэр оруулна уу.');
          const qty=Math.max(0,Number(form.qty||0));const requestedMin=form.min===''||form.min==null?Math.floor(qty*.2):Math.max(0,Number(form.min||0));const min=Math.min(qty,requestedMin);
          const {data,error}=await supabase.from('inventory_items').update({name:form.name.trim(),sku:form.sku||null,quantity:qty,min_quantity:min,batch_no:form.batchNo?.trim()||null,expiry_date:form.expiry||null}).eq('id',editingId).eq('clinic_id',profile.clinic_id).select('id,name,sku,quantity,min_quantity,batch_no,expiry_date').single();if(error)throw error;
          setRows(v=>v.map(r=>r.id===editingId?{...r,title:data.name,subtitle:`SKU: ${data.sku||'-'} · Үлдэгдэл ${data.quantity}${data.batch_no?` · Batch ${data.batch_no}`:''}`,meta:[`Дахин захиалах босго: ${data.min_quantity}`,data.expiry_date?`Хугацаа: ${data.expiry_date}`:''].filter(Boolean).join(' · '),payload:{name:data.name,sku:data.sku||'',qty:String(data.quantity??0),min:String(data.min_quantity??0),batchNo:data.batch_no||'',expiry:data.expiry_date||''}}:r));
        } else if(editingId&&view==='stock_movements'){
          const original=rows.find(r=>r.id===editingId);if(!original?.payload)throw new Error(en?'Original stock movement could not be loaded.':'Анхны барааны хөдөлгөөн олдсонгүй.');
          const oldItemId=String(original.payload.itemId||original.payload.item_id||'');const itemId=String(form.itemId||oldItemId);if(!itemId)throw new Error(en?'Choose an inventory item.':'Бараа материалаас сонгоно уу.');if(oldItemId&&itemId!==oldItemId)throw new Error(en?'To change the item, create a new movement instead.':'Барааг өөрчлөх бол шинэ хөдөлгөөн үүсгэнэ үү. Тоо/төрөл/тайлбарыг энд засаж болно.');
          const item=refs.inventory.find(x=>x.id===itemId);if(!item)throw new Error(en?'Inventory item not found.':'Бараа материал олдсонгүй.');const qty=Math.max(0,Number(form.qty||0));if(qty<=0)throw new Error(en?'Quantity must be greater than zero.':'Тоо хэмжээ 0-ээс их байна.');
          const signed=(type:string,value:number)=>type==='Орлого'||type==='Stock in'?value:type==='Зарлага'||type==='Stock out'?-value:0;const oldQty=Math.max(0,Number(original.payload.qty||0));const oldSigned=signed(String(original.payload.type||''),oldQty);const newSigned=signed(String(form.type||''),qty);
          const {data:dbItem,error:itemError}=await supabase.from('inventory_items').select('id,quantity,min_quantity').eq('id',itemId).eq('clinic_id',profile.clinic_id).single();if(itemError)throw itemError;const nextQty=Number(dbItem.quantity||0)-oldSigned+newSigned;if(nextQty<0)throw new Error(en?'This edit would make stock negative.':'Энэ засварын дараа үлдэгдэл сөрөг болох тул хадгалах боломжгүй.');
          const {error:updateStockError}=await supabase.from('inventory_items').update({quantity:nextQty}).eq('id',itemId).eq('clinic_id',profile.clinic_id);if(updateStockError)throw updateStockError;const staffRef=form.staffId?refs.staff.find(x=>x.id===form.staffId):null;const normalized={...form,item:item.label,itemId,item_id:itemId,staff:staffRef?.label||form.staff||profile.full_name,staffId:form.staffId||profile.id||'',quantity_after:nextQty};const row=genericPresentation(view,{...normalized,quantity_after:String(nextQty)},en);const {error:updateRecordError}=await supabase.from('erp_records').update({title:row.title,subtitle:row.subtitle||null,meta:row.meta||null,status:row.status||null,payload:normalized}).eq('id',editingId).eq('clinic_id',profile.clinic_id).eq('module_key',view);if(updateRecordError)throw updateRecordError;setRows(v=>v.map(r=>r.id===editingId?{...row,id:editingId,meta:`${row.meta} · ${en?'Balance':'Үлдэгдэл'} ${nextQty}`,payload:normalized}:r));
        } else if(editingId&&(view==='finance'||view==='cashbook')){
          if(!form.description?.trim())throw new Error('Гүйлгээний тайлбар оруулна уу.');const amount=Number(String(form.amount||'').replace(/\D/g,''));if(!Number.isFinite(amount)||amount<=0)throw new Error(en?'Enter a valid amount greater than 0.':'Дүнг 0-ээс их тоогоор оруулна уу.');const kind=(form.kind==='Зарлага'||form.kind==='Expense')?'expense':'income';
          const currentRow=rows.find(r=>r.id===editingId);const linkedEncounterId=String(currentRow?.payload?.encounterId||'');
          if(view==='cashbook'&&linkedEncounterId){const {error}=await supabase.rpc('denthub_update_cashbook_entry',{p_finance_transaction_id:editingId,p_kind:kind,p_description:form.description.trim(),p_amount:Math.round(amount),p_payment_method:form.method||'Бэлэн'});if(error)throw error;}
          else {const {error}=await supabase.from('finance_transactions').update({kind,description:form.description.trim(),amount:Math.round(amount),payment_method:form.method||'Бэлэн'}).eq('id',editingId).eq('clinic_id',profile.clinic_id);if(error)throw error;}
          setRows(v=>v.map(r=>r.id===editingId?{...r,title:form.description.trim(),subtitle:form.method||'Бэлэн',meta:`${kind==='expense'?'-':'+'} ₮${Math.round(amount).toLocaleString()}`,status:kind==='expense'?'Зарлага':'Орлого',payload:{...(r.payload||{}),kind:form.kind,description:form.description.trim(),amount:String(Math.round(amount)),method:form.method||'Бэлэн'}}:r));
        } else if(editingId&&view==='services'){
          if(!form.name?.trim())throw new Error(en?'Service name is required.':'Үйлчилгээний нэр оруулна уу.');if(!form.category?.trim())throw new Error(en?'Choose a category first.':'Эхлээд ангиллаа сонгоно уу.');
          const patch={name:form.name.trim(),service_code:form.code?.trim()||null,category:form.category.trim(),subcategory:form.subcategory?.trim()||null,price:Math.max(0,Number(form.price||0)),duration_minutes:Math.max(5,Number(form.duration||30))};
          const {error}=await supabase.from('services').update(patch).eq('id',editingId).eq('clinic_id',profile.clinic_id).eq('is_category',false);if(error)throw error;await refreshServices();window.dispatchEvent(new CustomEvent('denthub:services-changed'));
        } else if(editingId&&genericErpViews.includes(view)){
          const patientRef=form.patientId?refs.patients.find(x=>x.id===form.patientId):null;const normalizedForm:Record<string,string>={...form,...(patientRef?{patient:patientRef.label,patientCode:patientRef.code||''}:{})};
          if(['sales','sales_returns','invoices','receivables','insurance','lab_orders'].includes(view)&&!patientRef&&!form.patient)throw new Error(en?'Choose a registered patient.':'Бүртгэлтэй өвчтөнөөс сонгоно уу.');
          const amountKeys=['sales','sales_returns','cashbook','invoices','receivables','expenses','insurance'];if(amountKeys.includes(view)){const amount=Number(normalizedForm.amount||0);if(!Number.isFinite(amount)||amount<=0)throw new Error(en?'Enter an amount greater than 0.':'Дүнг 0-ээс их тоогоор оруулна уу.');}
          const row=genericPresentation(view,normalizedForm,en);if(!row.title.trim())throw new Error(en?'Required information is missing.':'Шаардлагатай мэдээллээ оруулна уу.');
          const {error}=await supabase.from('erp_records').update({title:row.title,subtitle:row.subtitle||null,meta:row.meta||null,status:row.status||null,payload:normalizedForm}).eq('id',editingId).eq('clinic_id',profile.clinic_id).eq('module_key',view);if(error)throw error;
          setRows(v=>v.map(r=>r.id===editingId?{...row,id:editingId,patientCode:patientRef?.code||r.patientCode,payload:normalizedForm}:r));
        } else if(view==='patients'){
          if(!form.name?.trim())throw new Error('Өвчтөний нэр оруулна уу.');
          if(form.phone && form.phone.replace(/\D/g,'').length!==8)throw new Error('Утасны дугаар 8 оронтой байна.');
          if(form.emergencyPhone && form.emergencyPhone.replace(/\D/g,'').length!==8)throw new Error('Яаралтай үед холбоо барих утас 8 оронтой байна.');
          const dobIso=birthDateToIso(form.dob||'');if(form.dob&&!dobIso)throw new Error(en?'Enter birth date as YYYY/MM/DD. Example: 2000/08/23':'Төрсөн огноог YYYY/MM/DD хэлбэрээр зөв оруулна уу. Жишээ: 2000/08/23');
          const created=await apiJson('/api/patients',{method:'POST',body:JSON.stringify({fullName:form.name.trim(),phone:form.phone||'',registerNo:form.reg||'',externalPatientId:form.externalId||'',dateOfBirth:dobIso||'',address:form.address||'',emergencyPhone:form.emergencyPhone||'',notes:form.note||''})});
          const data=created.patient;
          setRows(v=>[{id:data.id,title:data.full_name,patientCode:data.patient_code||undefined,subtitle:[data.external_patient_id,data.phone,data.register_no].filter(Boolean).join(' · ')||'Холбоо барих мэдээлэлгүй',meta:'Дөнгөж сая',payload:{name:data.full_name,phone:String(data.phone||'').replace(/^\+976/,''),externalId:data.external_patient_id||'',reg:data.register_no||'',dob:data.date_of_birth||'',gender:data.gender||'',address:data.address||'',emergencyPhone:String(data.emergency_phone||'').replace(/^\+976/,''),note:data.notes||''}},...v]);
        } else if(view==='appointments'||view==='treatments'){
          const patientId=form.patientId||'';
          const patient=refs.patients.find(x=>x.id===patientId);
          if(!patientId||!patient)throw new Error(en?'Choose a registered patient.':'Бүртгэлтэй өвчтөнөөс сонгоно уу.');
          if(view==='appointments'){
            const date=form.date||new Date().toISOString().slice(0,10);const time=form.time||'09:00';const starts=new Date(`${date}T${time}:00`);
            const {data,error}=await supabase.from('appointments').insert({clinic_id:profile.clinic_id,patient_id:patient.id,doctor_id:profile.role==='employee'?profile.id:null,starts_at:starts.toISOString(),service_name:form.service||'Ерөнхий үзлэг',status:'scheduled'}).select('id,starts_at,service_name,status').single();if(error)throw error;
            setRows(v=>[{id:data.id,title:patient.label,subtitle:`${data.service_name}${profile.role==='employee'?` · ${profile.full_name}`:''}`,meta:new Date(data.starts_at).toLocaleString('mn-MN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}),status:'Баталгаажсан'},...v]);
          }else{
            const selectedTeeth=(form.selectedTeeth||'').split(',').map(x=>x.trim()).filter(Boolean);
            const {data,error}=await supabase.from('encounters').insert({clinic_id:profile.clinic_id,patient_id:patient.id,doctor_id:profile.id||null,diagnosis:form.diagnosis||null,treatment_plan:form.plan||null,notes:form.note||null,selected_teeth:selectedTeeth,dentition:form.dentition==='child'?'child':'adult',status:'open'}).select('id,created_at').single();if(error)throw error;
            setRows(v=>[{id:data.id,title:patient.label,subtitle:form.diagnosis||'Үзлэгийн тэмдэглэл',meta:`Өнөөдөр · ${profile.full_name}`,status:'Нээлттэй',selectedTeeth,dentition:form.dentition==='child'?'child':'adult'},...v]);
          }
        } else if(view==='inventory'){
          if(!form.name?.trim())throw new Error('Барааны нэр оруулна уу.');
          const qty=Math.max(0,Number(form.qty||0));
          const requestedMin=form.min===''||form.min==null?Math.floor(qty*.2):Math.max(0,Number(form.min||0));
          const min=Math.min(qty,requestedMin);
          const {data,error}=await supabase.from('inventory_items').insert({clinic_id:profile.clinic_id,name:form.name.trim(),sku:form.sku||null,quantity:qty,min_quantity:min,batch_no:form.batchNo?.trim()||null,expiry_date:form.expiry||null}).select('id,name,sku,quantity,min_quantity,batch_no,expiry_date').single();if(error)throw error;
          setRows(v=>[{id:data.id,title:data.name,subtitle:`SKU: ${data.sku||'-'} · Үлдэгдэл ${data.quantity}${data.batch_no?` · Batch ${data.batch_no}`:''}`,meta:[`Дахин захиалах босго: ${data.min_quantity}`,data.expiry_date?`Хугацаа: ${data.expiry_date}`:''].filter(Boolean).join(' · '),status:Number(data.quantity)<=Number(data.min_quantity)&&Number(data.min_quantity)>0?'Нөөц бага':undefined,payload:{name:data.name,sku:data.sku||'',qty:String(data.quantity??0),min:String(data.min_quantity??0),batchNo:data.batch_no||'',expiry:data.expiry_date||''}},...v]);
        } else if(view==='stock_movements'){
          const itemId=form.itemId||'';const item=refs.inventory.find(x=>x.id===itemId);if(!itemId||!item)throw new Error(en?'Choose an inventory item.':'Бараа материалаас сонгоно уу.');
          const qty=Math.max(0,Number(form.qty||0));if(qty<=0)throw new Error(en?'Quantity must be greater than zero.':'Тоо хэмжээ 0-ээс их байна.');
          const {data:dbItem,error:itemError}=await supabase.from('inventory_items').select('id,name,sku,quantity,min_quantity').eq('id',itemId).eq('clinic_id',profile.clinic_id).single();if(itemError)throw itemError;
          const kind=form.type||'Орлого';let nextQty=Number(dbItem.quantity||0);
          if(kind==='Орлого'||kind==='Stock in')nextQty+=qty;else if(kind==='Зарлага'||kind==='Stock out'){if(qty>nextQty)throw new Error(en?'Not enough stock.':'Үлдэгдэл хүрэлцэхгүй байна.');nextQty-=qty;}
          const {error:updateError}=await supabase.from('inventory_items').update({quantity:nextQty}).eq('id',itemId);if(updateError)throw updateError;
          const staffRef=form.staffId?refs.staff.find(x=>x.id===form.staffId):null;const normalized={...form,item:item.label,item_id:itemId,itemId,staff:staffRef?.label||profile.full_name,staffId:form.staffId||profile.id||'',quantity_after:nextQty};const row=genericPresentation(view,{...normalized,quantity_after:String(nextQty)},en);
          const {data,error}=await supabase.from('erp_records').insert({clinic_id:profile.clinic_id,module_key:view,title:row.title,subtitle:row.subtitle||null,meta:row.meta||null,status:row.status||null,payload:normalized,created_by:profile.id||null}).select('id').single();if(error)throw error;
          setRows(v=>[{...row,id:data.id,meta:`${row.meta} · Үлдэгдэл ${nextQty}`,payload:normalized},...v]);
        } else if(view==='finance'||view==='cashbook'){
          if(!form.description?.trim())throw new Error('Гүйлгээний тайлбар оруулна уу.');
          const amount=Number(String(form.amount||'').replace(/\D/g,''));
          if(!Number.isFinite(amount)||amount<=0)throw new Error(en?'Enter a valid amount greater than 0.':'Дүнг 0-ээс их тоогоор оруулна уу.');
          const kind=(form.kind==='Зарлага'||form.kind==='Expense')?'expense':'income';
          const {data,error}=await supabase.from('finance_transactions').insert({clinic_id:profile.clinic_id,created_by:profile.id||null,kind,description:form.description.trim(),amount:Math.round(amount),payment_method:form.method||'Бэлэн'}).select('id').single();if(error)throw error;
          setRows(v=>[{id:data.id,title:form.description,subtitle:form.method||'Бэлэн',meta:`${kind==='expense'?'-':'+'} ₮${Math.round(amount).toLocaleString()}`,status:kind==='expense'?'Зарлага':'Орлого',payload:{kind:form.kind,description:form.description,amount:String(Math.round(amount)),method:form.method||'Бэлэн'}},...v]);
        } else if(view==='services'){
          if(!form.name?.trim())throw new Error(en?'Service name is required.':'Үйлчилгээний нэр оруулна уу.');
          if(!form.category?.trim())throw new Error(en?'Choose a category first.':'Эхлээд ангиллаа сонгоно уу.');
          const {data,error}=await supabase.from('services').insert({clinic_id:profile.clinic_id,name:form.name.trim(),service_code:form.code?.trim()||null,category:form.category.trim(),subcategory:form.subcategory?.trim()||null,price:Math.max(0,Number(form.price||0)),duration_minutes:Math.max(5,Number(form.duration||30)),active:true,is_category:false}).select('id,name,service_code,category,subcategory,price,duration_minutes,active,is_category,external_source,external_source_id').single();if(error)throw error;
          setRows(v=>[{id:data.id,title:data.name,subtitle:[data.category,data.subcategory].filter(Boolean).join(' › ')||'Ангилалгүй',meta:`${data.service_code?`${data.service_code} · `:''}₮${Number(data.price||0).toLocaleString()} · ${Number(data.duration_minutes||30)} мин`,status:'Идэвхтэй',isCategory:false,category:data.category||undefined,subcategory:data.subcategory||undefined,serviceCode:data.service_code||undefined,payload:{name:data.name,code:data.service_code||'',category:data.category||'',subcategory:data.subcategory||'',price:String(data.price??0),duration:String(data.duration_minutes??30)}},...v]);window.dispatchEvent(new CustomEvent('denthub:services-changed'));
        } else if(genericErpViews.includes(view)){
          const patientRef=form.patientId?refs.patients.find(x=>x.id===form.patientId):null;
          const normalizedForm:Record<string,string>={...form,...(patientRef?{patient:patientRef.label,patientCode:patientRef.code||''}:{})};
          if(['sales','sales_returns','invoices','receivables','insurance','lab_orders'].includes(view)&&!patientRef)throw new Error(en?'Choose a registered patient.':'Бүртгэлтэй өвчтөнөөс сонгоно уу.');
          const amountKeys=['sales','sales_returns','cashbook','invoices','receivables','expenses','insurance'];
          if(amountKeys.includes(view)){const amount=Number(normalizedForm.amount||0);if(!Number.isFinite(amount)||amount<=0)throw new Error(en?'Enter an amount greater than 0.':'Дүнг 0-ээс их тоогоор оруулна уу.');}
          const row=genericPresentation(view,normalizedForm,en);
          if(!row.title.trim())throw new Error(en?'Required information is missing.':'Шаардлагатай мэдээллээ оруулна уу.');
          const {data,error}=await supabase.from('erp_records').insert({clinic_id:profile.clinic_id,module_key:view,title:row.title,subtitle:row.subtitle||null,meta:row.meta||null,status:row.status||null,payload:normalizedForm,created_by:profile.id||null}).select('id').single();if(error)throw error;
          setRows(v=>[{...row,id:data.id,patientCode:patientRef?.code||undefined,payload:normalizedForm},...v]);
        }
      } else {
        if(process.env.NEXT_PUBLIC_DEMO_MODE!=='true')throw new Error(en?'Database connection unavailable. Nothing was saved.':'Supabase холболт алга. Өгөгдөл хадгалагдсангүй.');
        let row:Row|undefined;
        if(view==='patients') {const localId=`p-${Date.now()}`;row={id:localId,title:form.name||'Шинэ өвчтөн',patientCode:`PT-${String(Date.now()).slice(-8)}`,subtitle:`${form.phone||'Утасгүй'}${form.reg?` · ${form.reg}`:''}`,meta:'Дөнгөж сая',payload:{name:form.name||'Шинэ өвчтөн',phone:form.phone||'',externalId:form.externalId||'',reg:form.reg||'',dob:form.dob||'',address:form.address||'',emergencyPhone:form.emergencyPhone||'',note:form.note||''}};}
        if(view==='appointments') row={id:`a-${Date.now()}`,title:form.patient||'Өвчтөн',subtitle:`${form.service||'Үзлэг'} · ${form.doctor||profile.full_name}`,meta:`${form.date||'Өнөөдөр'} · ${form.time||'09:00'}`,status:'Баталгаажсан'};
        if(view==='treatments') row={id:`t-${Date.now()}`,title:form.patient||'Өвчтөн',subtitle:form.diagnosis||'Үзлэгийн тэмдэглэл',meta:`Өнөөдөр · ${profile.full_name}`,status:'Нээлттэй',selectedTeeth:(form.selectedTeeth||'').split(',').map(x=>x.trim()).filter(Boolean),dentition:form.dentition==='child'?'child':'adult'};
        if(view==='inventory') row={id:`i-${Date.now()}`,title:form.name||'Шинэ бараа',subtitle:`SKU: ${form.sku||'-'} · Үлдэгдэл ${form.qty||'0'}${form.batchNo?` · Batch ${form.batchNo}`:''}`,meta:[`Дахин захиалах босго: ${form.min||'авто'}`,form.expiry?`Хугацаа: ${form.expiry}`:''].filter(Boolean).join(' · '),payload:{...form}};
        if(view==='finance'||view==='cashbook') row={id:`f-${Date.now()}`,title:form.description||'Шинэ гүйлгээ',subtitle:form.method||'Бэлэн',meta:`${(form.kind==='Зарлага'||form.kind==='Expense')?'-':'+'} ₮${Number(form.amount||0).toLocaleString()}`,status:form.kind||(en?'Income':'Орлого')};
        if(view==='services') row={id:`s-${Date.now()}`,title:form.name||'Шинэ үйлчилгээ',subtitle:form.category||'Ангилалгүй',meta:`${form.code?`${form.code} · `:''}₮${Number(form.price||0).toLocaleString()}`,status:en?'Active':'Идэвхтэй',serviceCode:form.code||undefined};
        if(genericErpViews.includes(view)) {const patientRef=form.patientId?refs.patients.find(x=>x.id===form.patientId):null;const localForm:Record<string,string>={...form,...(patientRef?{patient:patientRef.label,patientCode:patientRef.code||''}:{})};row={...genericPresentation(view,localForm,en),id:`e-${Date.now()}`,patientCode:patientRef?.code};}
        if(row)persist([row,...rows]);
      }
      setNotice(editingId?(en?'Changes saved.':'Өөрчлөлт хадгалагдлаа.'):`${item.action} амжилттай.`);setModal(false);setForm({});setEditingId(null);
    }catch(e:any){setNotice(e?.message||'Хадгалахад алдаа гарлаа.')}finally{setSaving(false)}
  }


  if(profile.role==='supplier' && (view==='supplier_warehouse'||view==='partner_clinics')) return <SupplierWorkspace view={view} profile={profile} lang={lang}/>;
  if(view==='appointments' && profile.role==='client') return <ClientAppointments profile={profile} lang={lang}/>;
  if(view==='appointments' && (profile.role==='owner'||profile.role==='employee')) return <StaffAppointments profile={profile} clinicName={clinicName} lang={lang} onNavigate={onNavigate?()=>onNavigate('treatments'):undefined}/>;
  if(view==='chat') return <ChatPage profile={profile} lang={lang}/>;
  if(view==='profile') return <ProfilePage profile={profile} clinicName={clinicName} theme={theme} onThemeChange={onThemeChange} lang={lang}/>;
  if(view==='reports') return <ReportsPage profile={profile} clinicName={clinicName} lang={lang}/>;

  return <div className="page-stack module-page">
    <header className="page-head"><div><small>{clinicName}</small><h1>{item.title}</h1><p>{item.desc}</p></div>{canCreate&&<button className="btn-primary" onClick={()=>openNew()}><Plus size={18}/>{item.action}</button>}</header>
    {notice&&<div className={`app-toast success ${(recordsLoading||saving||refsLoading)?'with-busy':''}`}><Check size={17}/><span>{notice}</span><button onClick={()=>setNotice('')}><X size={16}/></button></div>}
    {(recordsLoading||saving||refsLoading)&&<div className="workspace-busy-notice" role="status" aria-live="polite"><Loader2 className="spin" size={17}/><span>{recordsLoading?(en?'Loading records… Please wait.':'Бүртгэлийн мэдээллийг уншиж байна… Түр хүлээнэ үү.'):saving?(en?'Saving changes… Please wait.':'Өөрчлөлтийг хадгалж байна… Түр хүлээнэ үү.'):(en?'Loading form data… Please wait.':'Маягтын мэдээллийг уншиж байна… Түр хүлээнэ үү.')}</span></div>}
    {view==='staff'&&<StaffAffiliationsPanel profile={profile} lang={lang}/>}
    <section className="module-toolbar panel-card"><div className="module-search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={en?`Search ${item.title.toLowerCase()}…`:`${item.title} хайх…`}/></div>{view==='patients'&&profile.role==='owner'&&<div className="services-import-tools patient-excel-tools"><button className="btn-light" onClick={exportPatientsExcel}><Download size={17}/>{en?'Export Excel':'Excel татах'}</button><button className="btn-secondary" onClick={()=>patientImportRef.current?.click()}><FileText size={17}/>{en?'Import patients':'Өвчтөн Excel импорт'}</button><input ref={patientImportRef} type="file" accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" onChange={e=>{const file=e.target.files?.[0];if(file)void importPatientsExcel(file)}}/></div>}{view==='inventory'&&profile.role==='owner'&&<div className="services-import-tools inventory-excel-tools"><button className="btn-light" onClick={exportInventoryExcel}><Download size={17}/>{en?'Export Excel':'Excel татах'}</button><button className="btn-secondary" onClick={()=>inventoryImportRef.current?.click()}><UploadCloud size={17}/>{en?'Import inventory':'Бараа материал Excel импорт'}</button><input ref={inventoryImportRef} type="file" accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" onChange={e=>{const file=e.target.files?.[0];if(file)void importInventoryExcel(file)}}/></div>}{view==='services'&&<div className="services-import-tools"><button className="btn-secondary" onClick={()=>document.getElementById('service-packages')?.scrollIntoView({behavior:'smooth',block:'start'})}><PackagePlus size={17}/>{en?'Service packages':'Багц үйлчилгээ'}</button><button className="btn-secondary category-manage-btn" onClick={()=>openCategoryEditor()}><FolderPlus size={17}/>{en?'Add category':'Ангилал нэмэх'}</button><button className="btn-light" onClick={exportServicesExcel}><Download size={17}/>{en?'Export Excel':'Excel татах'}</button><button className="btn-secondary" onClick={()=>importInputRef.current?.click()}><FileText size={17}/>{en?'Import Excel':'Excel импорт'}</button><input ref={importInputRef} type="file" accept=".xlsx,.xls,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv" onChange={e=>{const file=e.target.files?.[0]; if(file) prepareServiceImport(file);}}/></div>}</section>{view==='inventory'&&<div className="import-note">{en?'Excel supports multiple batches for the same item. The list is grouped by item name and shows the summed stock while preserving each batch and expiry date.':'Excel-д нэг барааг өөр өөр batch, өөр дуусах хугацаатай тусдаа мөрөөр оруулж болно. Дэлгэц дээр нэрээр нь нэгтгэн нийт үлдэгдлийг харуулах боловч batch бүрийн хугацаа тусдаа хадгалагдана.'}</div>}{view==='services'&&<div className="import-note">{en?'Excel import merges new rows into the existing service list. Existing rows update by service_id; rows are deleted only when action=DELETE.':'Excel импорт нь одоо байгаа үйлчилгээг устгахгүйгээр шинэ мөрүүдийг нэмнэ. service_id-аар тухайн мөр шинэчлэгдэнэ; action=DELETE үед л устгана.'}</div>}
    {view!=='services'&&<section className="module-kpi-strip" aria-label={en?'Module summary':'Модулийн тойм'}>
      <article className="module-kpi"><span><Icon size={17}/></span><div><strong>{moduleStats.total.toLocaleString()}</strong><small>{en?'Total records':'Нийт бүртгэл'}</small></div></article>
      <article className="module-kpi"><span><Search size={17}/></span><div><strong>{moduleStats.matched.toLocaleString()}</strong><small>{query?(en?'Matching search':'Хайлтад тохирсон'):(en?'Visible now':'Одоо харагдаж буй')}</small></div></article>
      <article className="module-kpi"><span><Check size={17}/></span><div><strong>{view==='patients'?moduleStats.coded.toLocaleString():moduleStats.statusRows.toLocaleString()}</strong><small>{view==='patients'?(en?'With patient ID':'Patient ID-тай'):(en?'With tracked status':'Төлөвтэй бүртгэл')}</small></div></article>
      <article className="module-kpi"><span><CircleDollarSign size={17}/></span><div><strong>{['sales','sales_returns','cashbook','invoices','receivables','expenses','finance'].includes(view)?`₮${moduleStats.numericTotal.toLocaleString()}`:moduleStats.statusTypes.toLocaleString()}</strong><small>{['sales','sales_returns','cashbook','invoices','receivables','expenses','finance'].includes(view)?(en?'Recorded value':'Бүртгэсэн дүн'):(en?'Status groups':'Төлөвийн төрөл')}</small></div></article>
    </section>}
    <section className="module-board panel-card">
      <div className="module-board-head"><div className="icon-cube large"><Icon/></div><div><h2>{item.title}</h2><p>{filtered.length} {en?'records':'бүртгэл'}</p></div></div>
      {(filtered.length||view==='services'&&serviceCategoryNames.length)?(view==='services'?<div className="service-admin-tree">{serviceGroups.map(group=><section key={group.category} className="service-admin-category"><div className="service-admin-category-head"><div><h3>{group.category}</h3><small>{group.subgroups.reduce((n,x)=>n+x.rows.length,0)} {en?'services':'үйлчилгээ'}</small></div><div className="service-category-actions"><button type="button" title={en?'Add service in this category':'Энэ ангилалд үйлчилгээ нэмэх'} onClick={()=>openNew({category:group.category})}><Plus size={16}/></button>{group.heading&&profile.role==='owner'&&<><button type="button" title={en?'Edit category':'Ангилал засах'} onClick={()=>openCategoryEditor(group.heading!)}><Pencil size={15}/></button><button type="button" className="danger" title={en?'Delete category':'Ангилал устгах'} onClick={()=>setDeleteCategoryTarget(group.heading!)}><Trash2 size={15}/></button></>}</div></div>{group.subgroups.length?group.subgroups.map(sub=><div key={sub.name} className="service-admin-subgroup"><div className="service-admin-subtitle">{sub.name}<span>{sub.rows.length}</span></div><div>{sub.rows.map(row=><button key={row.id} className="service-admin-row" onClick={()=>setSelected(row)}><span><b>{row.title}</b><small>{row.meta}</small></span>{row.status&&<em>{row.status}</em>}<ArrowRight size={17}/></button>)}</div></div>):<div className="service-category-empty"><span>{en?'No services in this category yet.':'Энэ ангилалд үйлчилгээ хараахан алга.'}</span><button type="button" onClick={()=>openNew({category:group.category})}><Plus size={15}/>{en?'Add service':'Үйлчилгээ нэмэх'}</button></div>}</section>)}</div>:view==='inventory'?<div className="inventory-group-list">{inventoryGroups.map(group=><section className="inventory-group-card" key={group.name}><div className="inventory-group-head"><div><b>{group.name}</b><small>{group.batches.length} {en?'batches / expiry rows':'batch / хугацааны мөр'}</small></div><strong>{group.total.toLocaleString()} <small>{en?'total':'нийт'}</small></strong></div><div className="inventory-batch-list">{group.batches.map(row=><button key={row.id} onClick={()=>setSelected(row)}><span><b>{row.payload?.batchNo||'Batch —'}</b><small>{[row.payload?.sku?`SKU ${row.payload.sku}`:'',row.payload?.expiry?`${en?'Expires':'Хугацаа'} ${row.payload.expiry}`:(en?'No expiry':'Хугацаагүй')].filter(Boolean).join(' · ')}</small></span><strong>{Number(row.payload?.qty||0).toLocaleString()}</strong>{row.status&&<em>{row.status}</em>}<ArrowRight size={16}/></button>)}</div></section>)}</div>:view==='staff'?<div className="staff-grouped-list">{([{key:'doctors',label:en?'Doctors':'Эмч нар',rows:staffGroups.doctors},{key:'staff',label:en?'Employees':'Ажилтнууд',rows:staffGroups.staff},{key:'owners',label:en?'Clinic owner':'Эмнэлгийн эзэмшигч',rows:staffGroups.owners}] as const).map(group=>group.rows.length?<section className="staff-group" key={group.key}><div className="staff-group-head"><h3>{group.label}</h3><span>{group.rows.length}</span></div><div className="module-list">{group.rows.map(row=><button key={row.id} className="module-row" onClick={()=>setSelected(row)}><div><b>{row.title}</b></div><span className="module-secondary-cell">{row.subtitle||'—'}</span><span className="module-meta-cell">{row.meta||'—'}</span><div className="module-row-meta"><small>{row.meta}</small>{row.status&&<em>{row.status}</em>}<ArrowRight size={17}/></div></button>)}</div></section>:null)}</div>:<><div className="module-table-head"><span>{view==='patients'?(en?'Patient / ID':'Өвчтөн / ID'):(en?'Name / record':'Нэр / бүртгэл')}</span><span>{detailInfoLabel}</span><span>{detailMetaLabel}</span><span>{detailStatusLabel}</span></div><div className="module-list">{filtered.map(row=><button key={row.id} className="module-row" onClick={()=>setSelected(row)}><div><div className="patient-row-title"><b>{row.title}</b>{row.patientCode&&<span className="patient-code-chip"><Hash size={10}/>{row.patientCode}</span>}</div></div><span className="module-secondary-cell">{row.subtitle||'—'}</span><span className="module-meta-cell">{row.meta||'—'}</span><div className="module-row-meta"><small>{row.meta}</small>{row.status&&<em>{row.status}</em>}<ArrowRight size={17}/></div></button>)}</div></>):<div className="empty-state"><span className="icon-cube xl"><Icon/></span><b>{item.empty}</b><p>{canCreate?(en?`Use “${item.action}” to add the first record.`:`“${item.action}” товчоор эхний бүртгэлээ нэмнэ үү.`):(en?'Information will appear here when available.':'Мэдээлэл бүрдэх үед энд харагдана.')}</p>{canCreate&&<button className="btn-primary" onClick={()=>openNew()}><Plus size={18}/>{item.action}</button>}</div>}
    </section>

    {view==='services'&&<ServicePackagesPanel profile={profile} lang={lang}/>}

    {selected&&<div className="modal-backdrop patient-profile-backdrop" onMouseDown={e=>e.currentTarget===e.target&&setSelected(null)}><div className={`modal-card detail-modal ${view==='patients'?'patient-profile-modal':''}`}><header><div><small>{item.title}</small><h2>{selected.title}</h2></div><button onClick={()=>setSelected(null)}><X size={20}/></button></header><div className="patient-profile-scroll"><div className="detail-lines"><div><span>{detailInfoLabel}</span><b>{selected.subtitle||'—'}</b></div><div><span>{detailMetaLabel}</span><b>{selected.meta||'—'}</b></div>{selected.status&&<div><span>{detailStatusLabel}</span><b>{selected.status}</b></div>}</div>{view==='treatments'&&<section className="treatment-teeth-detail"><div className="treatment-teeth-heading"><div><b>{en?'Selected teeth':'Сонгосон шүд'}</b><small>{selected.dentition==='child'?(en?'Primary dentition':'Сүүн шүд'):(en?'Permanent dentition':'Байнгын шүд')}</small></div>{selected.selectedTeeth?.length?<span>{selected.selectedTeeth.length}</span>:null}</div>{selected.selectedTeeth?.length?<><div className="history-teeth treatment-detail-chips">{selected.selectedTeeth.map(tooth=><span key={tooth}>{tooth}</span>)}</div><DentalChart compact readOnly lang={lang} dentition={selected.dentition||'adult'} onDentitionChange={()=>{}} value={selected.selectedTeeth} onChange={()=>{}}/></>:<div className="treatment-no-teeth">{en?'No teeth were selected for this encounter.':'Энэ үзлэгт шүд сонгоогүй байна.'}</div>}</section>}{view==='patients'&&selected.patientCode&&<div className="patient-identity-card"><Hash size={18}/><div><b>{en?'Patient ID':'Өвчтөний ID'} · {selected.patientCode}</b><small>{en?'Use this ID for payments, sales and patient selection.':'Төлбөр, борлуулалт болон өвчтөн сонгох бүх хэсэгт энэ ID ашиглагдана.'}</small></div></div>}{view==='patients'&&selected.payload&&<section className="patient-contact-detail"><div><span>{en?'Phone':'Утас'}</span><b>{selected.payload.phone?`+976 ${selected.payload.phone}`:'—'}</b></div><div><span>{en?'Date of birth':'Төрсөн он сар өдөр'}</span><b>{selected.payload.dob?formatBirthDateDisplay(selected.payload.dob):'—'}</b></div><div className="wide"><span>{en?'Residential address':'Оршин суугаа хаяг'}</span><b>{selected.payload.address||'—'}</b></div><div><span>{en?'Emergency contact':'Яаралтай үед холбоо барих'}</span><b>{selected.payload.emergencyPhone?`+976 ${selected.payload.emergencyPhone}`:'—'}</b></div><div><span>{en?'Registration':'Регистр'}</span><b>{selected.payload.reg||'—'}</b></div></section>}{view==='staff'&&<StaffDocumentsPanel employeeId={selected.id} employeeName={selected.title} profile={profile} lang={lang}/>}{view==='patients'&&<PatientXraySection key={selected.id} patientId={selected.id} patientName={selected.title} profile={profile}/>}</div><footer>{view==='services'&&!selected.isCategory&&profile.role==='owner'&&<button className="btn-danger detail-delete-btn" onClick={()=>setDeleteServiceTarget(selected)}><Trash2 size={17}/>{en?'Delete service':'Үйлчилгээ устгах'}</button>}{selected.payload&&(profile.role==='owner'||employeeCanWrite)&&!['appointments','treatments','staff'].includes(view)&&<button className="btn-secondary" onClick={()=>openEdit(selected)}><Pencil size={17}/>{en?'Edit':'Засах'}</button>}{view==='patients'&&profile.role==='owner'&&<button className="btn-danger detail-delete-btn" onClick={()=>setDeletePatientTarget(selected)}><Trash2 size={17}/>{en?'Delete patient':'Өвчтөн устгах'}</button>}{view==='cashbook'&&profile.role==='owner'&&<button className="btn-danger detail-delete-btn" onClick={()=>setDeleteCashbookTarget(selected)}><Trash2 size={17}/>{en?'Delete entry':'Бичилт устгах'}</button>}{view==='patients'&&onNavigate&&<button className="btn-secondary" onClick={()=>{try{sessionStorage.setItem('clinicos-book-patient',JSON.stringify({id:selected.id,name:selected.title}))}catch{};setSelected(null);onNavigate('appointments')}}><CalendarDays size={17}/>{en?'Book appointment':'Цаг товлох'}</button>}<button className="btn-primary" onClick={()=>setSelected(null)}>{en?'Close':'Хаах'}</button></footer></div></div>}

    {modal&&<div className="modal-backdrop" onMouseDown={e=>{if(e.currentTarget===e.target){setModal(false);setEditingId(null)}}}><div className={`modal-card module-form-modal ${view==='branches'?'branch-form-modal':''}` }><header><div><small>{clinicName}</small><h2>{editingId?(en?'Edit record':'Бүртгэл засах'):item.action}</h2></div><button onClick={()=>{setModal(false);setEditingId(null)}}><X size={20}/></button></header><div className="modal-fields">{fieldsFor(view,lang).map(f=>{
      const source=refSourceFor(view,f.key);const options=source?refs[source]:[];const idKey=`${f.key}Id`;const numeric=f.inputMode==='numeric';
      const labelClass=[view==='services'&&f.key==='category'?'category-picker-label':'',view==='branches'&&f.key==='manager'?'branch-manager-field':''].filter(Boolean).join(' ');
      return <label key={f.key} className={labelClass}>{f.label}{
        source?<SmartSelect options={options} value={form[idKey]||''} loading={refsLoading} placeholder={f.placeholder||f.label} onChange={option=>setForm(v=>({...v,[idKey]:option?.id||'',[f.key]:option?.label||''}))}/>:
        view==='services'&&f.key==='category'?<div className="category-picker-row"><ChoiceSelect options={serviceCategoryNames} value={form.category||''} placeholder={en?'Choose category':'Ангилал сонгох'} onChange={value=>setForm(v=>({...v,category:value,subcategory:''}))}/><button type="button" className="category-inline-add" onClick={()=>openCategoryEditor()} title={en?'Create category':'Шинэ ангилал'}><Plus size={17}/><span>{en?'New category':'Шинэ ангилал'}</span></button></div>:
        f.type==='select'?<ChoiceSelect options={f.options||[]} value={form[f.key]||f.options?.[0]||''} placeholder={f.placeholder||f.label} onChange={value=>setForm(v=>({...v,[f.key]:value}))}/>:
        f.type==='textarea'?<textarea rows={4} value={form[f.key]||''} onChange={e=>setForm(v=>({...v,[f.key]:e.target.value}))} placeholder={f.placeholder}/>:
        f.type==='birthdate'?<BirthDateInput value={form[f.key]||''} onValueChange={value=>setForm(v=>({...v,[f.key]:value}))} placeholder={f.placeholder||'XXXX/XX/XX'} ariaLabel={f.label}/>:
        f.type==='date'?<DentDatePicker value={form[f.key]||''} onChange={value=>setForm(v=>({...v,[f.key]:value}))} lang={lang} placeholder={f.placeholder||f.label}/>:
        (numeric||f.key==='phone'||f.key==='emergencyPhone')?<NumericInput value={form[f.key]||''} onValueChange={value=>setForm(v=>({...v,[f.key]:value}))} maxDigits={(f.key==='phone'||f.key==='emergencyPhone')?8:16} placeholder={f.placeholder}/>:
        <input type={f.type==='time'?'time':'text'} value={form[f.key]||''} onChange={e=>setForm(v=>({...v,[f.key]:e.target.value}))} placeholder={f.placeholder}/>
      }</label>
    })}{view==='treatments'&&<DentalChart lang={lang} dentition={(form.dentition==='child'?'child':'adult')} onDentitionChange={dentition=>setForm(v=>({...v,dentition,selectedTeeth:''}))} value={(form.selectedTeeth||'').split(',').map(x=>x.trim()).filter(Boolean)} onChange={teeth=>setForm(v=>({...v,selectedTeeth:teeth.join(',')}))}/>}
    {view==='services'&&<div className="form-auto-note"><Tags size={15}/><span>{en?'Pick a category first. Categories are managed once and reused for every service.':'Ангиллыг нэг удаа үүсгээд дараа нь бүх үйлчилгээнд dropdown-оос сонгоно.'}</span></div>}{view==='inventory'&&<div className="form-auto-note"><Check size={15}/><span>{en?'Leave reorder threshold empty to calculate 20% automatically.':'Дахин захиалах босгыг хоосон үлдээвэл эхний үлдэгдлийн 20%-иар автоматаар тооцно.'}</span></div>}{view==='patients'&&<div className="form-auto-note"><Check size={15}/><span>{en?'If this phone already belongs to a DentHub patient account, chat access is linked automatically.':'Энэ утас DentHub өвчтөний account-тай таарвал чатны холбоос автоматаар үүснэ.'}</span></div>}</div><footer><button className="btn-secondary" onClick={()=>{setModal(false);setEditingId(null)}}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={save} disabled={saving}>{saving?<Loader2 className="spin" size={18}/>:<Check size={18}/>} {saving?(en?'Saving…':'Хадгалж байна…'):(editingId?(en?'Save changes':'Өөрчлөлт хадгалах'):(en?'Save':'Хадгалах'))}</button></footer></div></div>}

    {categoryModal&&<div className="modal-backdrop category-modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&!categorySaving&&setCategoryModal(false)}><div className="modal-card category-editor-modal"><header><div><small>{en?'Services':'Үйлчилгээ & үнэ'}</small><h2>{categoryTarget?(en?'Edit category':'Ангилал засах'):(en?'New category':'Шинэ ангилал')}</h2></div><button onClick={()=>!categorySaving&&setCategoryModal(false)}><X size={20}/></button></header><div className="category-editor-body"><label>{en?'Category name':'Ангиллын нэр'}<input autoFocus value={categoryName} onChange={e=>setCategoryName(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')saveCategory()}} placeholder={en?'Example: Permanent teeth':'Жишээ: Байнгын шүд'}/></label><p>{en?'Create the category once, then add services inside it from the service form.':'Ангиллыг нэг удаа үүсгээд дараа нь үйлчилгээ нэмэхдээ dropdown-оос сонгоно.'}</p></div><footer><button className="btn-secondary" onClick={()=>setCategoryModal(false)} disabled={categorySaving}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={saveCategory} disabled={categorySaving||!categoryName.trim()}>{categorySaving?<Loader2 className="spin" size={18}/>:<Check size={18}/>} {en?'Save category':'Ангилал хадгалах'}</button></footer></div></div>}
    <ConfirmDialog open={Boolean(pendingExcelImport)} busy={false} title={en?'This Excel import contains deletions':'Excel импортод устгах мөр байна'} description={en?`${pendingExcelDeleteCount} row(s) are marked DELETE. Importing will permanently remove those records.`:`${pendingExcelDeleteCount} мөр action=DELETE гэж тэмдэглэгдсэн байна. Импорт үргэлжилбэл эдгээр бүртгэл системээс устна.`} confirmLabel={en?'Import & delete':'Импортлох, устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>{setPendingExcelImport(null);setPendingExcelDeleteCount(0);if(importInputRef.current)importInputRef.current.value='';}} onConfirm={()=>{const file=pendingExcelImport;if(!file)return;setPendingExcelImport(null);setPendingExcelDeleteCount(0);void importServices(file)}}/>
    <ConfirmDialog open={Boolean(deleteCategoryTarget)} busy={categorySaving} title={en?'Delete this category?':'Энэ ангиллыг устгах уу?'} description={en?'Services inside it will not be deleted. They will move to Uncategorized.':'Доторх үйлчилгээнүүд устахгүй. “Ангилалгүй” хэсэгт шилжинэ. Энэ үйлдлийг үргэлжлүүлэх үү?'} confirmLabel={en?'Delete category':'Ангилал устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!categorySaving&&setDeleteCategoryTarget(null)} onConfirm={confirmDeleteCategory}/>
    <ConfirmDialog open={Boolean(deletePatientTarget)} busy={saving} title={en?'Delete this patient?':'Энэ өвчтөнийг устгах уу?'} description={deletePatientTarget?(en?`“${deletePatientTarget.title}” will be removed from active patient lists. Treatment/payment audit history is preserved.`:`“${deletePatientTarget.title}” идэвхтэй өвчтөний жагсаалтаас алга болно. Эмчилгээ, төлбөрийн audit түүх хамгаалагдана.`):''} confirmLabel={en?'Delete patient':'Өвчтөн устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!saving&&setDeletePatientTarget(null)} onConfirm={confirmDeletePatient}/>
    <ConfirmDialog open={Boolean(deleteCashbookTarget)} busy={saving} title={en?'Delete this cashbook entry?':'Энэ кассын бичилтийг устгах уу?'} description={deleteCashbookTarget?(deleteCashbookTarget.payload?.encounterId?(en?'This payment is linked to a treatment visit. The payment row will be removed and the visit balance will be recalculated automatically.':'Энэ бичилт эмчилгээний төлбөртэй холбоотой. Устгасны дараа тухайн үзлэгийн төлсөн/үлдэгдэл дүн автоматаар дахин тооцогдоно.'):(en?'This manual cashbook entry will be deleted.':'Энэ кассын гар бичилт системээс устна.')):''} confirmLabel={en?'Delete entry':'Бичилт устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!saving&&setDeleteCashbookTarget(null)} onConfirm={confirmDeleteCashbook}/>
    <ConfirmDialog open={Boolean(deleteServiceTarget)} busy={saving} title={en?'Delete this service?':'Энэ үйлчилгээг устгах уу?'} description={deleteServiceTarget?(en?`“${deleteServiceTarget.title}” will be removed from the clinic service list.`:`“${deleteServiceTarget.title}” үйлчилгээ системээс устна. Энэ үйлдлийг буцаах боломжгүй.`):''} confirmLabel={en?'Delete service':'Үйлчилгээ устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!saving&&setDeleteServiceTarget(null)} onConfirm={confirmDeleteService}/>
  </div>
}


function SmartSelect({options,value,onChange,placeholder,loading}:{options:RefOption[];value:string;onChange:(option:RefOption|null)=>void;placeholder:string;loading?:boolean}){
  const [open,setOpen]=useState(false);const [search,setSearch]=useState('');const root=useRef<HTMLDivElement|null>(null);
  const selected=options.find(x=>x.id===value)||null;
  const visible=options.filter(x=>`${x.label} ${x.meta||''}`.toLowerCase().includes(search.toLowerCase())).slice(0,80);
  useEffect(()=>{if(!open)return;const close=(e:PointerEvent)=>{if(root.current&&!root.current.contains(e.target as Node))setOpen(false)};window.addEventListener('pointerdown',close);return()=>window.removeEventListener('pointerdown',close)},[open]);
  return <div className={`smart-select ${open?'open':''}`} ref={root}><button type="button" className="smart-select-trigger" onClick={()=>setOpen(v=>!v)}><span>{selected?<><b>{selected.label}</b>{selected.meta&&<small>{selected.meta}</small>}</>:<em>{loading?'Ачаалж байна…':placeholder}</em>}</span><ChevronDown size={17}/></button>{open&&<div className="smart-select-popover"><div className="smart-select-search"><Search size={16}/><input autoFocus value={search} onChange={e=>setSearch(e.target.value)} placeholder="Хайх…"/></div><button type="button" className="smart-select-clear" onClick={()=>{onChange(null);setOpen(false)}}>— Сонголтгүй —</button>{visible.length?visible.map(x=><button type="button" key={x.id} className={x.id===value?'selected':''} onClick={()=>{onChange(x);setOpen(false);setSearch('')}}><span><b>{x.label}</b>{x.meta&&<small>{x.meta}</small>}</span>{x.id===value&&<Check size={16}/>}</button>):<p className="smart-select-empty">Тохирох бүртгэл олдсонгүй.</p>}</div>}</div>;
}

function ChoiceSelect({options,value,onChange,placeholder}:{options:string[];value:string;onChange:(value:string)=>void;placeholder:string}){
  const [open,setOpen]=useState(false);const [search,setSearch]=useState('');const root=useRef<HTMLDivElement|null>(null);
  const unique=useMemo(()=>Array.from(new Set(options.filter(Boolean))),[options]);
  const visible=useMemo(()=>{const q=search.trim().toLowerCase();const list=q?unique.filter(x=>x.toLowerCase().includes(q)):unique;return list.slice(0,100)},[unique,search]);
  useEffect(()=>{if(!open)return;const close=(e:PointerEvent)=>{if(root.current&&!root.current.contains(e.target as Node))setOpen(false)};window.addEventListener('pointerdown',close);return()=>window.removeEventListener('pointerdown',close)},[open]);
  return <div className={`choice-select ${open?'open':''}`} ref={root}><button type="button" className="choice-select-trigger" onClick={()=>setOpen(v=>!v)}><span className={value?'':'placeholder'}>{value||placeholder}</span><ChevronDown size={17}/></button>{open&&<div className="choice-select-menu">{unique.length>8&&<div className="choice-select-search"><Search size={15}/><input autoFocus value={search} onChange={e=>setSearch(e.target.value)} placeholder="Сонголт хайх…"/></div>}{visible.length?visible.map(option=><button type="button" key={option} className={option===value?'selected':''} onClick={()=>{onChange(option);setOpen(false);setSearch('')}}><span>{option}</span>{option===value&&<Check size={16}/>}</button>):<p>{search?'Тохирох сонголт олдсонгүй.':'Сонголт алга'}</p>}</div>}</div>;
}

function fieldsFor(view:ViewKey,lang:AppLang):Array<{key:string;label:string;placeholder?:string;type?:string;inputMode?:string;options?:string[]}>{
  const en=lang==='EN';
  if(view==='patients') return [{key:'name',label:en?'Full name':'Овог нэр',placeholder:en?'Example: B. Bat':'Жишээ: Б. Бат'},{key:'phone',label:en?'Phone':'Утас',placeholder:'9911 2233',inputMode:'numeric'},{key:'externalId',label:en?'Client ID (optional)':'Үйлчлүүлэгчийн ID (заавал биш)',placeholder:en?'Clinic/customer reference ID':'Эмнэлгийн өөрийн ID дугаар'},{key:'reg',label:en?'Registration':'Регистр',placeholder:'УБ90010112'},{key:'dob',label:en?'Date of birth':'Төрсөн он сар өдөр',type:'birthdate',placeholder:'XXXX/XX/XX'},{key:'address',label:en?'Residential address':'Оршин суугаа хаяг',placeholder:en?'District, khoroo, address':'Дүүрэг, хороо, байр / гудамж'},{key:'emergencyPhone',label:en?'Emergency contact phone':'Яаралтай үед холбоо барих утас',placeholder:'9911 2233',inputMode:'numeric'},{key:'note',label:en?'Notes':'Тэмдэглэл',placeholder:en?'Additional information':'Нэмэлт мэдээлэл',type:'textarea'}];
  if(view==='appointments') return [{key:'patient',label:en?'Patient':'Өвчтөн',placeholder:en?'Choose a registered patient':'Бүртгэлтэй өвчтөн сонгох'},{key:'doctor',label:en?'Doctor':'Эмч',placeholder:en?'Doctor name':'Эмчийн нэр'},{key:'service',label:en?'Service':'Үйлчилгээ',placeholder:en?'Example: General consultation':'Жишээ: Ерөнхий үзлэг'},{key:'date',label:en?'Date':'Огноо',type:'date'},{key:'time',label:en?'Time':'Цаг',type:'time'}];
  if(view==='treatments') return [{key:'patient',label:en?'Patient':'Өвчтөн',placeholder:en?'Choose a registered patient':'Бүртгэлтэй өвчтөн сонгох'},{key:'diagnosis',label:en?'Diagnosis / complaint':'Онош / зовиур',placeholder:en?'Diagnosis or complaint':'Онош эсвэл зовиур'},{key:'plan',label:en?'Treatment plan':'Эмчилгээний төлөвлөгөө',placeholder:en?'Plan':'Төлөвлөгөө',type:'textarea'},{key:'note',label:en?'Notes':'Тэмдэглэл',placeholder:en?'SOAP / additional notes':'SOAP / нэмэлт тэмдэглэл',type:'textarea'}];
  if(view==='inventory') return [{key:'name',label:en?'Item name':'Барааны нэр',placeholder:en?'Item name':'Барааны нэр'},{key:'sku',label:'SKU',placeholder:'SKU-001'},{key:'batchNo',label:en?'Batch / lot':'Цуврал / Batch',placeholder:'LOT-2026-01'},{key:'expiry',label:en?'Expiry date':'Хүчинтэй хугацаа',type:'date'},{key:'qty',label:en?'Quantity':'Тоо хэмжээ',placeholder:'0',inputMode:'numeric'},{key:'min',label:en?'Reorder threshold':'Дахин захиалах босго',placeholder:en?'Auto: 20%':'Авто: 20%',inputMode:'numeric'}];
  if(view==='services') return [{key:'name',label:en?'Service name':'Үйлчилгээний нэр',placeholder:en?'Example: Consultation':'Жишээ: Шүдний цоорлын эмчилгээ'},{key:'code',label:en?'Service code':'Код / Баркод',placeholder:en?'Example: 00503':'Жишээ: 00503'},{key:'category',label:en?'Main category':'Үндсэн ангилал',placeholder:en?'Dental treatment':'Шүдний эмчилгээ'},{key:'subcategory',label:en?'Subcategory':'Дэд ангилал',placeholder:en?'Milk teeth / Surgery / Checkup':'Сүүн шүд / Мэс засал / Үзлэг'},{key:'price',label:en?'Price':'Үнэ',placeholder:'0',inputMode:'numeric'},{key:'duration',label:en?'Duration (minutes)':'Үргэлжлэх хугацаа (минут)',placeholder:'30',inputMode:'numeric'}];
  if(view==='sales') return [{key:'patient',label:en?'Patient':'Өвчтөн',placeholder:en?'Choose patient by name, phone or ID':'Нэр, утас эсвэл ID-аар өвчтөн сонгох'},{key:'reference',label:en?'Sale reference':'Борлуулалтын №',placeholder:'SALE-...'},{key:'amount',label:en?'Sale amount':'Борлуулалтын дүн',placeholder:'0',inputMode:'numeric'},{key:'method',label:en?'Payment method':'Төлбөрийн хэлбэр',type:'select',options:en?['Cash','Card','QPay','Transfer']:['Бэлэн','Карт','QPay','Шилжүүлэг']},{key:'date',label:en?'Date':'Огноо',type:'date'},{key:'status',label:en?'Status':'Төлөв',type:'select',options:en?['Completed','Pending','Cancelled']:['Дууссан','Хүлээгдэж байна','Цуцлагдсан']},{key:'note',label:en?'Note':'Тэмдэглэл',placeholder:en?'Treatment / product / reference':'Эмчилгээ / бараа / тайлбар',type:'textarea'}];
  if(view==='sales_returns') return [{key:'patient',label:en?'Patient':'Өвчтөн',placeholder:en?'Choose registered patient':'Бүртгэлтэй өвчтөн сонгох'},{key:'reference',label:en?'Return reference':'Буцаалтын №',placeholder:'RET-...'},{key:'originalRef',label:en?'Original sale / invoice':'Анхны борлуулалт / invoice',placeholder:'SALE / INV / QPay ref'},{key:'amount',label:en?'Refund amount':'Буцаалтын дүн',placeholder:'0',inputMode:'numeric'},{key:'reason',label:en?'Reason':'Шалтгаан',placeholder:en?'Return / correction reason':'Буцаалтын шалтгаан',type:'textarea'},{key:'status',label:en?'Status':'Төлөв',type:'select',options:en?['Pending','Approved','Refunded','Rejected']:['Хүлээгдэж байна','Зөвшөөрсөн','Буцаасан','Татгалзсан']}];
  if(view==='cashbook') return [{key:'reference',label:en?'Reference':'Баримтын №',placeholder:'CASH-...'},{key:'kind',label:en?'Movement':'Хөдөлгөөн',type:'select',options:en?['Income','Expense']:['Орлого','Зарлага']},{key:'description',label:en?'Description':'Гүйлгээний утга',placeholder:en?'Cashbook description':'Кассын гүйлгээний утга'},{key:'amount',label:en?'Amount':'Дүн',placeholder:'0',inputMode:'numeric'},{key:'method',label:en?'Method':'Хэлбэр',placeholder:en?'Cash / Card / custom method':'Бэлэн / Карт / өөрийн хэлбэр'},{key:'note',label:en?'Note':'Тэмдэглэл',placeholder:en?'Optional note':'Нэмэлт тэмдэглэл'}];
  if(view==='price_lists') return [{key:'name',label:en?'Price list name':'Үнийн жагсаалтын нэр',placeholder:en?'VIP / Insurance / Standard':'VIP / Даатгал / Стандарт'},{key:'scope',label:en?'Applies to':'Хамаарах хүрээ',placeholder:en?'Service category / patient group':'Үйлчилгээний ангилал / өвчтөний бүлэг'},{key:'adjustment',label:en?'Discount %':'Хөнгөлөлт %',placeholder:'0',inputMode:'numeric'},{key:'from',label:en?'Valid from':'Эхлэх огноо',type:'date'},{key:'to',label:en?'Valid until':'Дуусах огноо',type:'date'},{key:'status',label:en?'Status':'Төлөв',type:'select',options:en?['Active','Paused','Expired']:['Идэвхтэй','Түр зогссон','Дууссан']}];
  if(view==='suppliers') return [{key:'company',label:en?'Company':'Байгууллагын нэр',placeholder:'ABC Supply LLC'},{key:'reg',label:en?'Registration no.':'Регистр / РД',placeholder:'1234567'},{key:'contact',label:en?'Contact person':'Холбоо барих хүн',placeholder:en?'Name':'Нэр'},{key:'phone',label:en?'Phone':'Утас',placeholder:'99112233'},{key:'category',label:en?'Category':'Ангилал',placeholder:en?'Dental materials':'Шүдний материал'}];
  if(view==='procurement') return [{key:'item',label:en?'Requested item':'Худалдан авах зүйл',placeholder:en?'Item / service':'Бараа / үйлчилгээ'},{key:'supplier',label:en?'Preferred supplier':'Нийлүүлэгч',placeholder:en?'Supplier':'Нийлүүлэгч'},{key:'qty',label:en?'Quantity':'Тоо хэмжээ',placeholder:'1',inputMode:'numeric'},{key:'budget',label:en?'Budget':'Төсөв',placeholder:'0',inputMode:'numeric'},{key:'due',label:en?'Needed by':'Хэрэгтэй огноо',type:'date'}];
  if(view==='purchase_orders') return [{key:'number',label:en?'PO number':'PO дугаар',placeholder:'PO-0001'},{key:'supplier',label:en?'Supplier':'Нийлүүлэгч',placeholder:en?'Supplier company':'Нийлүүлэгч байгууллага'},{key:'amount',label:en?'Total amount':'Нийт дүн',placeholder:'0',inputMode:'numeric'},{key:'due',label:en?'Expected date':'Хүлээн авах огноо',type:'date'},{key:'status',label:en?'Status':'Төлөв',type:'select',options:en?['Draft','Sent','Approved','Received']:['Ноорог','Илгээсэн','Баталсан','Хүлээн авсан']}];
  if(view==='stock_movements') return [{key:'item',label:en?'Item':'Бараа',placeholder:en?'Item name':'Барааны нэр'},{key:'staff',label:en?'Responsible employee':'Хөдөлгөөн хийсэн ажилтан',placeholder:en?'Choose employee':'Ажилтан сонгох'},{key:'type',label:en?'Movement':'Хөдөлгөөн',type:'select',options:en?['Stock in','Stock out','Transfer']:['Орлого','Зарлага','Шилжүүлэг']},{key:'qty',label:en?'Quantity':'Тоо хэмжээ',placeholder:'1',inputMode:'numeric'},{key:'location',label:en?'Location':'Байршил',placeholder:en?'Main warehouse':'Төв агуулах'},{key:'note',label:en?'Note':'Тэмдэглэл',placeholder:en?'Reason / reference':'Шалтгаан / баримт'}];
  if(view==='lab_orders') return [{key:'patient',label:en?'Patient':'Өвчтөн',placeholder:en?'Choose a registered patient':'Бүртгэлтэй өвчтөн сонгох'},{key:'lab',label:en?'Laboratory':'Лаборатори',placeholder:en?'Lab name':'Лаб нэр'},{key:'work',label:en?'Work':'Ажил',placeholder:en?'Crown / denture / aligner':'Бүрээс / протез / aligner'},{key:'due',label:en?'Due date':'Дуусах огноо',type:'date'},{key:'status',label:en?'Status':'Төлөв',type:'select',options:en?['New','In progress','Ready','Delivered']:['Шинэ','Хийгдэж байна','Бэлэн','Хүлээлгэн өгсөн']}];
  if(view==='crm') return [{key:'contact',label:en?'Contact':'Харилцагч',placeholder:en?'Name / company':'Нэр / байгууллага'},{key:'channel',label:en?'Channel':'Суваг',type:'select',options:['Phone','Facebook','Instagram','Walk-in','Email']},{key:'note',label:en?'Note':'Тэмдэглэл',placeholder:en?'Conversation / request':'Яриа / хүсэлт',type:'textarea'},{key:'next',label:en?'Next follow-up':'Дараагийн follow-up',type:'date'}];
  if(view==='insurance') return [{key:'patient',label:en?'Patient':'Өвчтөн',placeholder:en?'Choose a registered patient':'Бүртгэлтэй өвчтөн сонгох'},{key:'provider',label:en?'Insurance provider':'Даатгалын байгууллага',placeholder:en?'Provider':'Байгууллага'},{key:'policy',label:en?'Policy / claim no.':'Policy / claim дугаар',placeholder:'CLM-001'},{key:'amount',label:en?'Claim amount':'Claim дүн',placeholder:'0',inputMode:'numeric'},{key:'status',label:en?'Status':'Төлөв',type:'select',options:en?['Draft','Submitted','Approved','Rejected','Paid']:['Ноорог','Илгээсэн','Зөвшөөрсөн','Татгалзсан','Төлсөн']}];
  if(view==='invoices') return [{key:'number',label:en?'Invoice no.':'Нэхэмжлэх №',placeholder:'INV-0001'},{key:'patient',label:en?'Patient':'Өвчтөн',placeholder:en?'Choose registered patient':'Бүртгэлтэй өвчтөн сонгох'},{key:'amount',label:en?'Amount':'Дүн',placeholder:'0',inputMode:'numeric'},{key:'due',label:en?'Due date':'Төлөх хугацаа',type:'date'},{key:'status',label:en?'Status':'Төлөв',type:'select',options:en?['Unpaid','Partially paid','Paid','Overdue']:['Төлөөгүй','Хэсэгчлэн','Төлсөн','Хугацаа хэтэрсэн']}];
  if(view==='receivables') return [{key:'patient',label:en?'Patient':'Өвчтөн',placeholder:en?'Choose registered patient':'Бүртгэлтэй өвчтөн сонгох'},{key:'amount',label:en?'Outstanding amount':'Авлагын дүн',placeholder:'0',inputMode:'numeric'},{key:'due',label:en?'Due date':'Төлөх хугацаа',type:'date'},{key:'status',label:en?'Status':'Төлөв',type:'select',options:en?['Open','Partial','Paid','Overdue']:['Нээлттэй','Хэсэгчлэн','Төлсөн','Хугацаа хэтэрсэн']}];
  if(view==='expenses') return [{key:'category',label:en?'Category':'Ангилал',placeholder:en?'Rent / salary / supplies':'Түрээс / цалин / хангамж'},{key:'description',label:en?'Description':'Тайлбар',placeholder:en?'Expense description':'Зардлын тайлбар'},{key:'amount',label:en?'Amount':'Дүн',placeholder:'0',inputMode:'numeric'},{key:'method',label:en?'Payment method':'Төлбөрийн хэлбэр',type:'select',options:en?['Cash','Card','Transfer','QPay']:['Бэлэн','Карт','Шилжүүлэг','QPay']}];
  if(view==='shifts') return [{key:'staff',label:en?'Staff':'Ажилтан',placeholder:en?'Employee name':'Ажилтны нэр'},{key:'date',label:en?'Date':'Огноо',type:'date'},{key:'start',label:en?'Start':'Эхлэх',type:'time'},{key:'end',label:en?'End':'Дуусах',type:'time'},{key:'location',label:en?'Room / branch':'Өрөө / салбар',placeholder:en?'Main branch':'Төв салбар'}];
  if(view==='assets') return [{key:'name',label:en?'Asset':'Хөрөнгийн нэр',placeholder:en?'Dental chair':'Шүдний сандал'},{key:'serial',label:en?'Serial no.':'Серийн дугаар',placeholder:'SN-001'},{key:'location',label:en?'Location':'Байршил',placeholder:en?'Room / branch':'Өрөө / салбар'},{key:'value',label:en?'Value':'Үнэ / үнэлгээ',placeholder:'0',inputMode:'numeric'},{key:'status',label:en?'Status':'Төлөв',type:'select',options:en?['Active','Maintenance','Retired']:['Ашиглаж байна','Засвартай','Акталсан']}];
  if(view==='branches') return [{key:'name',label:en?'Branch name':'Салбарын нэр',placeholder:en?'Branch 2':'Салбар 2'},{key:'address',label:en?'Address':'Хаяг',placeholder:en?'Address':'Хаяг'},{key:'phone',label:en?'Phone':'Утас',placeholder:'99112233'},{key:'manager',label:en?'Manager':'Менежер',placeholder:en?'Manager name':'Менежерийн нэр'}];
  if(view==='supplier_warehouse') return [{key:'item',label:en?'Item':'Барааны нэр',placeholder:en?'Dental material':'Шүдний материал'},{key:'supplier',label:en?'Supplier':'Нийлүүлэгч',placeholder:en?'Supplier company':'Нийлүүлэгч байгууллага'},{key:'sku',label:'SKU',placeholder:'SUP-001'},{key:'qty',label:en?'Stock quantity':'Үлдэгдэл',placeholder:'0',inputMode:'numeric'},{key:'unit',label:en?'Unit':'Нэгж',placeholder:en?'pcs / box':'ш / хайрцаг'},{key:'min',label:en?'Reorder threshold':'Дахин захиалах босго',placeholder:en?'Auto':'Авто',inputMode:'numeric'}];
  if(view==='partner_clinics') return [{key:'name',label:en?'Clinic name':'Эмнэлгийн нэр',placeholder:en?'Partner clinic':'Хамтрагч эмнэлэг'},{key:'city',label:en?'City / area':'Хот / дүүрэг',placeholder:en?'Ulaanbaatar':'Улаанбаатар'},{key:'contact',label:en?'Contact person':'Холбоо барих хүн',placeholder:en?'Name':'Нэр'},{key:'phone',label:en?'Phone':'Утас',placeholder:'99112233'},{key:'status',label:en?'Relationship':'Харилцааны төлөв',type:'select',options:en?['Active','Trial','Paused']:['Идэвхтэй','Туршилт','Түр зогссон']},{key:'note',label:en?'Note':'Тэмдэглэл',placeholder:en?'Cooperation details':'Хамтын ажиллагааны тайлбар',type:'textarea'}];
  return [{key:'kind',label:en?'Type':'Төрөл',type:'select',options:en?['Income','Expense']:['Орлого','Зарлага']},{key:'description',label:en?'Description':'Тайлбар',placeholder:en?'Transaction description':'Гүйлгээний тайлбар'},{key:'amount',label:en?'Amount':'Дүн',placeholder:'0',inputMode:'numeric'},{key:'method',label:en?'Payment method':'Төлбөрийн хэлбэр',type:'select',options:en?['QPay','Card','Cash','Transfer']:['QPay','Карт','Бэлэн','Шилжүүлэг']}];
}

function genericPresentation(view:ViewKey,form:Record<string,string>,en:boolean):Row{
  const money=(v?:string)=>`₮${Number(v||0).toLocaleString()}`;
  const id='';
  switch(view){
    case 'sales': return {id,title:form.reference||form.patient||'',subtitle:[form.patient,form.patientCode,form.method].filter(Boolean).join(' · '),meta:[money(form.amount),form.date].filter(Boolean).join(' · '),status:form.status||(en?'Completed':'Дууссан'),patientCode:form.patientCode||undefined};
    case 'sales_returns': return {id,title:form.reference||form.patient||'',subtitle:[form.patient,form.patientCode,form.originalRef].filter(Boolean).join(' · '),meta:[money(form.amount),form.reason].filter(Boolean).join(' · '),status:form.status||(en?'Pending':'Хүлээгдэж байна'),patientCode:form.patientCode||undefined};
    case 'cashbook': return {id,title:form.description||form.reference||'',subtitle:[form.reference,form.method].filter(Boolean).join(' · '),meta:`${(form.kind==='Expense'||form.kind==='Зарлага')?'-':'+'} ${money(form.amount)}`,status:form.kind||''};
    case 'price_lists': return {id,title:form.name||'',subtitle:[form.scope,form.adjustment?`${form.adjustment}%`:null].filter(Boolean).join(' · '),meta:[form.from,form.to].filter(Boolean).join(' → '),status:form.status||''};
    case 'suppliers': return {id,title:form.company||'',subtitle:[form.contact,form.phone].filter(Boolean).join(' · '),meta:form.category||form.reg||'',status:en?'Active':'Идэвхтэй'};
    case 'procurement': return {id,title:form.item||'',subtitle:[form.supplier,form.qty?`x${form.qty}`:''].filter(Boolean).join(' · '),meta:[form.budget?money(form.budget):'',form.due].filter(Boolean).join(' · '),status:en?'Requested':'Хүсэлт'};
    case 'purchase_orders': return {id,title:form.number||'',subtitle:form.supplier||'',meta:[money(form.amount),form.due].filter(Boolean).join(' · '),status:form.status||''};
    case 'stock_movements': return {id,title:form.item||'',subtitle:[form.type,form.location,form.staff].filter(Boolean).join(' · '),meta:`${form.qty||0} ${en?'units':'ш'}${form.staff?` · ${form.staff}`:''}`,status:form.type||''};
    case 'lab_orders': return {id,title:form.patient||'',subtitle:[form.work,form.lab].filter(Boolean).join(' · '),meta:form.due||'',status:form.status||''};
    case 'crm': return {id,title:form.contact||'',subtitle:[form.channel,form.note].filter(Boolean).join(' · '),meta:form.next?`${en?'Follow-up':'Follow-up'}: ${form.next}`:'',status:en?'Open':'Нээлттэй'};
    case 'insurance': return {id,title:form.patient||'',subtitle:[form.provider,form.policy].filter(Boolean).join(' · '),meta:money(form.amount),status:form.status||''};
    case 'invoices': return {id,title:form.number||'',subtitle:[form.patient,form.patientCode].filter(Boolean).join(' · '),meta:[money(form.amount),form.due].filter(Boolean).join(' · '),status:form.status||'',patientCode:form.patientCode||undefined};
    case 'receivables': return {id,title:form.patient||'',subtitle:[form.patientCode,en?'Outstanding balance':'Авлагын үлдэгдэл'].filter(Boolean).join(' · '),meta:[money(form.amount),form.due].filter(Boolean).join(' · '),status:form.status||'',patientCode:form.patientCode||undefined};
    case 'expenses': return {id,title:form.description||form.category||'',subtitle:[form.category,form.method].filter(Boolean).join(' · '),meta:`- ${money(form.amount)}`,status:en?'Expense':'Зардал'};
    case 'shifts': return {id,title:form.staff||'',subtitle:[form.date,`${form.start||'--:--'}–${form.end||'--:--'}`].filter(Boolean).join(' · '),meta:form.location||'',status:en?'Scheduled':'Хуваарьтай'};
    case 'assets': return {id,title:form.name||'',subtitle:[form.serial,form.location].filter(Boolean).join(' · '),meta:money(form.value),status:form.status||''};
    case 'branches': return {id,title:form.name||'',subtitle:[form.address,form.phone].filter(Boolean).join(' · '),meta:form.manager||'',status:en?'Active':'Идэвхтэй'};
    case 'supplier_warehouse': return {id,title:form.item||'',subtitle:[form.supplier,form.sku].filter(Boolean).join(' · '),meta:`${form.qty||0} ${form.unit||''} · ${en?'Reorder':'Доод'} ${form.min||0}`,status:Number(form.qty||0)<=Number(form.min||0)?(en?'Low stock':'Нөөц бага'):(en?'In stock':'Нөөцтэй')};
    case 'partner_clinics': return {id,title:form.name||'',subtitle:[form.city,form.contact,form.phone].filter(Boolean).join(' · '),meta:form.note||'',status:form.status||(en?'Active':'Идэвхтэй')};
    default:return {id,title:form.description||form.name||'',subtitle:'',meta:'',status:''};
  }
}


type ChatPerson={id:string;name:string;meta:string;kind?:string};
type ChatMessage={id:string;sender_id:string;recipient_id:string;body:string;created_at:string;read_at?:string|null};

function ChatPage({profile,lang}:{profile:AppProfile;lang:AppLang}){
  const en=lang==='EN';
  const production=isSupabaseConfigured()&&process.env.NEXT_PUBLIC_DEMO_MODE!=='true'&&Boolean(profile.id);
  const [people,setPeople]=useState<ChatPerson[]>([]);
  const [chatId,setChatId]=useState<string|null>(null);
  const [messages,setMessages]=useState<ChatMessage[]>([]);
  const [message,setMessage]=useState('');
  const [query,setQuery]=useState('');
  const [loading,setLoading]=useState(production);
  const [sending,setSending]=useState(false);
  const [error,setError]=useState('');

  async function api(url:string,init?:RequestInit){
    const s=getSupabaseBrowser();if(!s)throw new Error('Supabase холболт алга.');
    const {data}=await s.auth.getSession();const token=data.session?.access_token;if(!token)throw new Error('Нэвтрэх эрх дууссан байна.');
    const res=await fetch(url,{...init,headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`,...(init?.headers||{})}});const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Алдаа гарлаа.');return body;
  }

  useEffect(()=>{
    if(!production){setLoading(false);return}
    let alive=true;(async()=>{try{const data=await api('/api/chat/contacts');if(!alive)return;const mapped=(data.contacts||[]) as ChatPerson[];setPeople(mapped);setChatId(current=>current&&mapped.some(p=>p.id===current)?current:(mapped[0]?.id||null));setError('')}catch(e:unknown){if(alive)setError(e instanceof Error?e.message:'Чатын холбоо ачаалж чадсангүй.')}finally{if(alive)setLoading(false)}})();return()=>{alive=false};
  },[production,profile.id,profile.role]);

  useEffect(()=>{
    const userId=profile.id;const selectedChatId=chatId;if(!production||!userId||!selectedChatId){setMessages([]);return}
    const targetChatId:string=selectedChatId;let alive=true;const s=getSupabaseBrowser();if(!s)return;
    async function load(){try{const data=await api(`/api/chat/messages?with=${encodeURIComponent(targetChatId)}`);if(alive){setMessages(data.messages||[]);setError('')}}catch(e:unknown){if(alive)setError(e instanceof Error?e.message:'Чат ачаалж чадсангүй.')}}
    load();
    const channel=s.channel(`denthub-chat-${userId}-${selectedChatId}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'direct_messages'},(payload:any)=>{const m=payload.new as ChatMessage;const belongs=(m.sender_id===userId&&m.recipient_id===selectedChatId)||(m.sender_id===selectedChatId&&m.recipient_id===userId);if(belongs)setMessages(list=>list.some(x=>x.id===m.id)?list:[...list,m])}).subscribe();
    return()=>{alive=false;s.removeChannel(channel)};
  },[production,profile.id,chatId]);

  async function send(){
    const body=message.trim();if(!body||!chatId||sending)return;setSending(true);setError('');
    try{const data=await api('/api/chat/messages',{method:'POST',body:JSON.stringify({recipientId:chatId,body})});if(data.message)setMessages(list=>list.some(x=>x.id===data.message.id)?list:[...list,data.message]);setMessage('')}catch(e:unknown){setError(e instanceof Error?e.message:'Мессеж илгээж чадсангүй.')}finally{setSending(false)}
  }

  const filtered=people.filter(p=>`${p.name} ${p.meta}`.toLowerCase().includes(query.toLowerCase()));
  const current=people.find(p=>p.id===chatId)||null;
  const placeholder=profile.role==='client'?(en?'Search clinic staff…':'Эмнэлгийн ажилтан хайх…'):(en?'Search patients or staff…':'Өвчтөн эсвэл ажилтан хайх…');
  return <div className="page-stack"><header className="page-head"><div><small>DentHub</small><h1>{en?'Chat':'Чат'}</h1><p>{profile.role==='client'?(en?'Message staff at clinics where you are registered.':'Бүртгэлтэй эмнэлгийн эмч, ажилтантай шууд чатлана.'):(en?'Message patients and clinic staff without a separate social network.':'Өвчтөн болон эмнэлгийн ажилтантай тусдаа нийгмийн сүлжээгүйгээр шууд чатлана.')}</p></div></header>
    {error&&<div className="form-error">{error}</div>}
    <section className="chat-shell panel-card"><aside className="chat-people"><div className="module-search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={placeholder}/></div>
      {loading?<div className="chat-empty-side">{en?'Loading…':'Ачаалж байна…'}</div>:filtered.length?filtered.map(p=><button className={chatId===p.id?'active':''} key={p.id} onClick={()=>setChatId(p.id)}><span className="avatar-3d">{p.name.trim().charAt(0)||'Х'}</span><div><b>{p.name}</b><small>{p.meta}</small></div></button>):<div className="chat-empty-side"><MessageSquare size={23}/><b>{en?'No available contacts':'Чатлах хүн одоогоор алга'}</b><p>{profile.role==='client'?(en?'Staff will appear after your patient record is linked to a clinic.':'Таны өвчтөний бүртгэл эмнэлэгтэй холбогдсоны дараа ажилтнууд энд харагдана.'):(en?'Patients with DentHub accounts and clinic staff will appear here.':'DentHub бүртгэлтэй өвчтөн болон эмнэлгийн ажилтнууд энд харагдана.')}</p></div>}
    </aside><div className="chat-main">{current?<><header><span className="avatar-3d">{current.name.trim().charAt(0)||'Х'}</span><div><b>{current.name}</b><small>{current.meta}</small></div></header><div className="chat-messages">{messages.length?messages.map(m=><div className={`chat-bubble ${m.sender_id===profile.id?'mine':'theirs'}`} key={m.id}>{m.body}<small>{new Date(m.created_at).toLocaleTimeString(en?'en-US':'mn-MN',{hour:'2-digit',minute:'2-digit'})}</small></div>):<div className="chat-conversation-empty"><MessageSquare size={28}/><b>{en?'Start the conversation':'Яриагаа эхлүүлнэ үү'}</b><p>{en?'No messages have been sent yet.':'Одоогоор мессеж илгээгээгүй байна.'}</p></div>}</div><div className="chat-composer"><input value={message} onChange={e=>setMessage(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder={en?'Write a message…':'Мессеж бичих…'}/><button onClick={send} disabled={!message.trim()||sending}><Send size={18}/></button></div></>:<div className="chat-conversation-empty"><MessageSquare size={32}/><b>{en?'No chat selected':'Чат сонгогдоогүй'}</b><p>{en?'Choose a contact from the left.':'Зүүн талаас чатлах хүнээ сонгоно уу.'}</p></div>}</div></section>
  </div>;
}

function ProfilePage({profile,clinicName,theme,onThemeChange,lang}:{profile:AppProfile;clinicName:string;theme:'light'|'dark';onThemeChange:()=>void;lang:AppLang}){
  const en=lang==='EN';
  const [name,setName]=useState(profile.full_name);
  const [phone,setPhone]=useState(profile.phone||'');
  const [saved,setSaved]=useState(false);
  const [profileError,setProfileError]=useState('');
  const [newPassword,setNewPassword]=useState('');
  const [confirmPassword,setConfirmPassword]=useState('');
  const [passwordBusy,setPasswordBusy]=useState(false);
  const [passwordMessage,setPasswordMessage]=useState('');

  async function saveProfile(){
    setSaved(false);setProfileError('');
    if(profile.id&&isSupabaseConfigured()){
      const s=getSupabaseBrowser();if(!s)return;
      const normalizedPhone=phone.replace(/\D/g,'').replace(/^976/,'').slice(0,8);
      const {error}=await s.from('profiles').update({full_name:name,phone:normalizedPhone?`+976${normalizedPhone}`:null}).eq('id',profile.id);
      if(error){setProfileError(error.message);return}
    }else localStorage.setItem('clinicos-profile-name',name);
    setSaved(true);
  }

  async function changePassword(){
    setPasswordMessage('');
    if(newPassword.length<8){setPasswordMessage(en?'Password must be at least 8 characters.':'Нууц үг хамгийн багадаа 8 тэмдэгт байна.');return}
    if(newPassword!==confirmPassword){setPasswordMessage(en?'Passwords do not match.':'Нууц үг хоорондоо таарахгүй байна.');return}
    const s=getSupabaseBrowser();if(!s){setPasswordMessage('Supabase холболт алга.');return}
    setPasswordBusy(true);
    const {error}=await s.auth.updateUser({password:newPassword});
    setPasswordBusy(false);
    if(error){setPasswordMessage(error.message);return}
    setNewPassword('');setConfirmPassword('');
    setPasswordMessage(en?'Password changed successfully.':'Нууц үг амжилттай солигдлоо.');
  }

  return <div className="page-stack"><header className="page-head"><div><small>{clinicName}</small><h1>{en?'My Profile':'Миний мэдээлэл'}</h1><p>{en?'Manage your profile, password and appearance here.':'Профайл, нууц үг болон харагдах байдлаа эндээс удирдана.'}</p></div></header><div className="settings-grid">
    <section className="panel-card form-card"><div className="panel-head"><div><h2>{en?'Profile':'Профайл'}</h2><p>{en?'Personal information':'Хувийн мэдээлэл'}</p></div><span className="icon-cube"><UserRound/></span></div><label>{en?'Name':'Нэр'}<input value={name} onChange={e=>setName(e.target.value)}/></label><label>{en?'Phone':'Утас'}<NumericInput value={phone.replace(/\D/g,'').replace(/^976/,'').slice(0,8)} onValueChange={setPhone} maxDigits={8}/></label><label>{en?'Role':'Эрх'}<input value={profile.role} disabled/></label>{profileError&&<div className="form-error">{profileError}</div>}<button className="btn-primary" onClick={saveProfile}><Check size={17}/> {en?'Save':'Хадгалах'}</button>{saved&&<p className="saved-note">{en?'Changes saved.':'Өөрчлөлт хадгалагдлаа.'}</p>}</section>
    <section className="panel-card form-card"><div className="panel-head"><div><h2>{en?'Password':'Нууц үг'}</h2><p>{en?'Change your password while signed in.':'Нэвтэрсэн үедээ нууц үгээ эндээс солино.'}</p></div><span className="icon-cube"><ShieldCheck/></span></div><label>{en?'New password':'Шинэ нууц үг'}<input type="password" value={newPassword} onChange={e=>setNewPassword(e.target.value)} placeholder={en?'At least 8 characters':'8-аас дээш тэмдэгт'}/></label><label>{en?'Confirm password':'Нууц үг давтах'}<input type="password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} onKeyDown={e=>e.key==='Enter'&&void changePassword()}/></label>{passwordMessage&&<div className={passwordMessage.includes('амжилттай')||passwordMessage.includes('successfully')?'form-success':'form-error'}>{passwordMessage}</div>}<button className="btn-primary" onClick={changePassword} disabled={passwordBusy}>{passwordBusy?<Loader2 className="spin" size={17}/>:<ShieldCheck size={17}/>} {passwordBusy?(en?'Changing…':'Сольж байна…'):(en?'Change password':'Нууц үг солих')}</button><small className="password-hint">{en?'If you forgot the password and cannot sign in, a clinic owner/admin can issue a temporary password from Management.':'Хэрэв нэвтэрч чадахгүй бол эмнэлгийн эзэмшигч/админ Удирдлага хэсгээс түр нууц үг өгч сэргээнэ.'}</small></section>
    <section className="panel-card"><div className="panel-head"><div><h2>{en?'Appearance':'Харагдах байдал'}</h2><p>{en?'Choose a comfortable theme.':'Танд эвтэйхэн theme сонгоно.'}</p></div></div><button className="theme-choice" onClick={onThemeChange}>{theme==='light'?<Moon/>:<Sun/>}<div><b>{theme==='light'?(en?'Switch to dark theme':'Dark theme рүү'):(en?'Switch to light theme':'Light theme рүү')}</b><span>{en?'Switch with one click.':'Нэг даралтаар солино.'}</span></div><ArrowRight/></button><div className="permission-list"><div><ShieldCheck/><span><b>{en?'Privacy':'Нууцлал'}</b><p>{en?'Private medical data is protected and only shown to authorized users.':'Эмнэлгийн хувийн өгөгдөл зөвхөн эрхтэй хэрэглэгчдэд харагдана.'}</p></span></div></div></section>
  </div></div>
}

function ReportsPage({profile,clinicName,lang}:{profile:AppProfile;clinicName:string;lang:AppLang}){
  const en=lang==='EN';
  const [exportError,setExportError]=useState('');
  const production=isSupabaseConfigured()&&process.env.NEXT_PUBLIC_DEMO_MODE!=='true';
  const now=new Date();
  const [mode,setMode]=useState<'month'|'year'>('month');
  const [month,setMonth]=useState(`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`);
  const [year,setYear]=useState(String(now.getFullYear()));
  const [loading,setLoading]=useState(production);
  const [report,setReport]=useState({patients:0,newPatients:0,appointments:0,inventoryLow:0,revenue:0,expenses:0});
  const range=useMemo(()=>{
    if(mode==='month'){
      const [y,m]=month.split('-').map(Number);const start=new Date(y,m-1,1);const end=new Date(y,m,1);return {start:start.toISOString(),end:end.toISOString(),label:month};
    }
    const y=Number(year)||now.getFullYear();return {start:new Date(y,0,1).toISOString(),end:new Date(y+1,0,1).toISOString(),label:String(y)};
  },[mode,month,year]);
  useEffect(()=>{
    if(!production){setLoading(false);return}
    if(profile.role==='platform_admin'||!profile.clinic_id){setLoading(false);return}
    let alive=true;setLoading(true);
    (async()=>{
      const s=getSupabaseBrowser();if(!s)return;
      const [{count:patients},{count:newPatients},{count:appointments},{data:inventory},{data:finance}]=await Promise.all([
        s.from('patients').select('id',{count:'exact',head:true}).eq('clinic_id',profile.clinic_id).is('deleted_at',null).lt('created_at',range.end),
        s.from('patients').select('id',{count:'exact',head:true}).eq('clinic_id',profile.clinic_id).is('deleted_at',null).gte('created_at',range.start).lt('created_at',range.end),
        s.from('appointments').select('id',{count:'exact',head:true}).eq('clinic_id',profile.clinic_id).gte('starts_at',range.start).lt('starts_at',range.end),
        s.from('inventory_items').select('quantity,min_quantity,expiry_date').eq('clinic_id',profile.clinic_id),
        profile.role==='owner'?s.from('finance_transactions').select('amount,kind').eq('clinic_id',profile.clinic_id).gte('created_at',range.start).lt('created_at',range.end):Promise.resolve({data:[] as any[]}),
      ]);
      const low=(inventory||[]).filter((x:any)=>Number(x.quantity)<=Number(x.min_quantity)&&Number(x.min_quantity)>0).length;
      const revenue=(finance||[]).filter((x:any)=>x.kind==='income').reduce((sum:number,x:any)=>sum+Number(x.amount||0),0);
      const expenses=(finance||[]).filter((x:any)=>x.kind==='expense').reduce((sum:number,x:any)=>sum+Number(x.amount||0),0);
      if(alive)setReport({patients:patients||0,newPatients:newPatients||0,appointments:appointments||0,inventoryLow:low,revenue,expenses});
    })().finally(()=>alive&&setLoading(false));return()=>{alive=false};
  },[production,profile.role,profile.clinic_id,range.start,range.end]);
  const periodLabel=mode==='month'?(()=>{const [y,m]=month.split('-').map(Number);return new Date(y,m-1,1).toLocaleDateString(en?'en-US':'mn-MN',{year:'numeric',month:'long'})})():year;
  const cards=[
    {title:en?'Revenue':'Орлого',value:profile.role==='owner'?(loading?'—':`₮${report.revenue.toLocaleString()}`):'—',meta:periodLabel,icon:CircleDollarSign},
    {title:en?'Expenses':'Зарлага',value:profile.role==='owner'?(loading?'—':`₮${report.expenses.toLocaleString()}`):'—',meta:periodLabel,icon:WalletCards},
    {title:en?'Appointments':'Цаг товлол',value:loading?'—':String(report.appointments),meta:periodLabel,icon:CalendarDays},
    {title:en?'New patients':'Шинэ өвчтөн',value:loading?'—':String(report.newPatients),meta:periodLabel,icon:UsersRound},
    {title:en?'Registered patients':'Нийт өвчтөн',value:loading?'—':String(report.patients),meta:en?'Through period end':'Тайлант үеийн эцэс',icon:UsersRound},
    {title:en?'Low stock':'Нөөцийн анхааруулга',value:loading?'—':String(report.inventoryLow),meta:en?'Current stock':'Одоогийн нөөц',icon:Boxes},
  ];
  async function exportExcel(){setExportError('');try{const XLSX=await import('xlsx');const data=cards.map(c=>({[en?'Report':'Тайлан']:c.title,[en?'Value':'Утга']:c.value,[en?'Period':'Хугацаа']:c.meta}));const sheet=XLSX.utils.json_to_sheet(data);sheet['!cols']=[{wch:30},{wch:22},{wch:22}];const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,sheet,mode==='month'?'Сарын тайлан':'Жилийн эцсийн тайлан');XLSX.writeFile(wb,`denthub-${mode==='month'?'monthly':'year-end'}-report-${range.label}.xlsx`)}catch(e:any){setExportError(e?.message||'Excel экспорт хийж чадсангүй.')}}
  if(profile.role==='platform_admin')return <div className="page-stack"><header className="page-head"><div><small>DentHub Platform</small><h1>{en?'Reports':'Тайлан'}</h1><p>{en?'Clinic reports are available inside each clinic workspace.':'Тайланг эмнэлэг тус бүрийн бодит мэдээлэл дээр үндэслэн тухайн эмнэлгийн орчноос гаргана.'}</p></div></header></div>;
  return <div className="page-stack reports-page">{loading&&<div className="workspace-busy-notice" role="status" aria-live="polite"><Loader2 className="spin" size={17}/><span>{en?'Calculating report… Please wait.':'Тайлангийн мэдээллийг уншиж, тооцоолж байна… Түр хүлээнэ үү.'}</span></div>}{exportError&&<div className="form-error">{exportError}</div>}<header className="page-head"><div><small>{clinicName}</small><h1>{en?'Reports':'Тайлан'}</h1><p>{en?'Monthly and year-end reports are separated so the clinic can export the exact reporting period.':'Сарын тайлан болон жилийн эцсийн тайлан тусдаа. Тайлант хугацаагаа сонгоод Excel-р татна.'}</p></div><button className="btn-secondary" onClick={exportExcel}><Download size={18}/>{en?'Export Excel':'Excel экспорт'}</button></header>
    <section className="panel-card report-period-card"><div className="report-mode-tabs"><button className={mode==='month'?'active':''} onClick={()=>setMode('month')}>{en?'Monthly report':'Сарын тайлан'}</button><button className={mode==='year'?'active':''} onClick={()=>setMode('year')}>{en?'Year-end report':'Жилийн эцсийн тайлан'}</button></div>{mode==='month'?<label><span>{en?'Month':'Сар'}</span><DentMonthPicker value={month} onChange={setMonth} lang={lang}/></label>:<label><span>{en?'Year':'Жил'}</span><input type="number" min="2020" max="2100" value={year} onChange={e=>setYear(e.target.value.replace(/\D/g,'').slice(0,4))}/></label>}<div className="report-period-note"><FileText size={17}/><span>{mode==='month'?(en?'Shows activity only for the selected month.':'Зөвхөн сонгосон сарын үйл ажиллагааг харуулна.'):(en?'Shows January 1 through December 31 for the selected year.':'Сонгосон жилийн 1-р сарын 1-ээс 12-р сарын 31 хүртэлх дүн.')}</span></div></section>
    <section className="metric-grid report-metric-grid">{cards.map(c=><article className="metric-card" key={c.title}><div className="metric-top"><span className="icon-cube"><c.icon/></span><span className="delta">{c.meta}</span></div><strong>{c.value}</strong><p>{c.title}</p></article>)}</section>
  </div>;
}
