'use client';

import { Check, ChevronDown, Search } from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type CSSProperties, type KeyboardEvent as ReactKeyboardEvent } from 'react';
import { createPortal } from 'react-dom';

export type DentSelectOption = {
  value: string;
  label: string;
  description?: string;
  disabled?: boolean;
};

export default function DentSelect({
  value,
  options,
  onChange,
  placeholder='Сонгох',
  searchable=false,
  searchPlaceholder='Хайх…',
  disabled=false,
  className='',
  emptyText='Сонголт олдсонгүй.',
}: {
  value: string;
  options: DentSelectOption[];
  onChange: (value:string)=>void;
  placeholder?: string;
  searchable?: boolean;
  searchPlaceholder?: string;
  disabled?: boolean;
  className?: string;
  emptyText?: string;
}) {
  const [open,setOpen]=useState(false);
  const [query,setQuery]=useState('');
  const [activeIndex,setActiveIndex]=useState(0);
  const root=useRef<HTMLDivElement|null>(null);
  const menuRef=useRef<HTMLDivElement|null>(null);
  const [menuStyle,setMenuStyle]=useState<CSSProperties>({});
  const selected=options.find(o=>o.value===value)||null;
  const visible=useMemo(()=>{
    const q=query.trim().toLocaleLowerCase('mn');
    return q?options.filter(o=>`${o.label} ${o.description||''}`.toLocaleLowerCase('mn').includes(q)):options;
  },[options,query]);

  useEffect(()=>{
    if(!open)return;
    const outside=(e:PointerEvent)=>{const target=e.target as Node;if(root.current&&!root.current.contains(target)&&!menuRef.current?.contains(target))setOpen(false)};
    const escape=(e:globalThis.KeyboardEvent)=>{if(e.key==='Escape')setOpen(false)};
    window.addEventListener('pointerdown',outside);
    window.addEventListener('keydown',escape);
    return()=>{window.removeEventListener('pointerdown',outside);window.removeEventListener('keydown',escape)};
  },[open]);

  useEffect(()=>{if(!open){setQuery('');setActiveIndex(0)}},[open]);

  useEffect(()=>{
    if(!open)return;
    const position=()=>{
      const trigger=root.current?.getBoundingClientRect();
      if(!trigger)return;
      const viewportH=window.innerHeight;
      const gap=7;
      const below=viewportH-trigger.bottom-gap;
      const above=trigger.top-gap;
      const desired=Math.min(330,Math.max(180,Math.max(below,above)-12));
      const openUp=below<210&&above>below;
      setMenuStyle({
        position:'fixed',
        left:Math.min(Math.max(8,trigger.left),Math.max(8,window.innerWidth-Math.min(trigger.width,window.innerWidth-16)-8)),
        width:Math.min(trigger.width,window.innerWidth-16),
        top:openUp?undefined:trigger.bottom+gap,
        bottom:openUp?viewportH-trigger.top+gap:undefined,
        maxHeight:desired,
        zIndex:1700,
      });
    };
    position();
    window.addEventListener('resize',position);
    window.addEventListener('scroll',position,true);
    return()=>{window.removeEventListener('resize',position);window.removeEventListener('scroll',position,true)};
  },[open]);

  function pick(option:DentSelectOption){
    if(option.disabled)return;
    onChange(option.value);setOpen(false);setQuery('');
  }

  function keyDown(e:ReactKeyboardEvent<HTMLButtonElement>){
    if(e.key==='ArrowDown'||e.key==='ArrowUp'){
      if(visible.length===0)return;
      e.preventDefault();
      if(!open){setOpen(true);return}
      const direction=e.key==='ArrowDown'?1:-1;
      let next=activeIndex;
      for(let i=0;i<Math.max(visible.length,1);i++){
        next=(next+direction+visible.length)%visible.length;
        if(!visible[next]?.disabled)break;
      }
      setActiveIndex(next);
    }else if(e.key==='Enter'||e.key===' '){
      e.preventDefault();
      if(!open){setOpen(true);return}
      const option=visible[activeIndex];if(option)pick(option);
    }else if(e.key==='Escape'){setOpen(false)}
  }

  return <div ref={root} className={`dent-select ${open?'open':''} ${className}`.trim()}>
    <button type="button" className="dent-select-trigger" disabled={disabled} aria-haspopup="listbox" aria-expanded={open} onKeyDown={keyDown} onClick={()=>!disabled&&setOpen(v=>!v)}>
      <span className="dent-select-value">
        {selected?<><b>{selected.label}</b>{selected.description&&<small>{selected.description}</small>}</>:<em>{placeholder}</em>}
      </span>
      <ChevronDown size={17}/>
    </button>
    {open&&typeof document!=='undefined'&&createPortal(<div ref={menuRef} className="dent-select-menu dent-select-portal" role="listbox" style={menuStyle}>
      {searchable&&<div className="dent-select-search"><Search size={15}/><input autoFocus value={query} onChange={e=>{setQuery(e.target.value);setActiveIndex(0)}} placeholder={searchPlaceholder}/></div>}
      <div className="dent-select-options">
        {visible.length?visible.map((option,index)=><button type="button" role="option" aria-selected={option.value===value} key={`${option.value}-${index}`} disabled={option.disabled} className={`${option.value===value?'selected':''} ${index===activeIndex?'active':''}`.trim()} onMouseEnter={()=>setActiveIndex(index)} onClick={()=>pick(option)}>
          <span><b>{option.label}</b>{option.description&&<small>{option.description}</small>}</span>{option.value===value&&<Check size={16}/>} 
        </button>):<p className="dent-select-empty">{emptyText}</p>}
      </div>
    </div>,document.body)}
  </div>;
}
