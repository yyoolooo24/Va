'use client';

import { CalendarDays, Check, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import { createPortal } from 'react-dom';

export default function DentMonthPicker({value,onChange,lang='MN',minYear=2020,maxYear=2100}:{value:string;onChange:(value:string)=>void;lang?:'MN'|'EN';minYear?:number;maxYear?:number}){
  const now=new Date();
  const parsed=/^(\d{4})-(\d{2})$/.exec(value||'');
  const selectedYear=Number(parsed?.[1]||now.getFullYear());
  const selectedMonth=Number(parsed?.[2]||now.getMonth()+1);
  const [open,setOpen]=useState(false);
  const [yearMode,setYearMode]=useState(false);
  const [viewYear,setViewYear]=useState(selectedYear);
  const root=useRef<HTMLDivElement|null>(null);
  const popover=useRef<HTMLDivElement|null>(null);
  const selectedYearRef=useRef<HTMLButtonElement|null>(null);
  const [style,setStyle]=useState<CSSProperties>({});
  const monthNames=lang==='EN'?['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']:['1-р сар','2-р сар','3-р сар','4-р сар','5-р сар','6-р сар','7-р сар','8-р сар','9-р сар','10-р сар','11-р сар','12-р сар'];
  const years=useMemo(()=>Array.from({length:maxYear-minYear+1},(_,i)=>minYear+i),[minYear,maxYear]);
  const label=lang==='EN'?`${new Date(selectedYear,selectedMonth-1,1).toLocaleString('en-US',{month:'long'})} ${selectedYear}`:`${selectedYear} оны ${selectedMonth}-р сар`;

  useEffect(()=>{setViewYear(selectedYear)},[selectedYear]);
  useEffect(()=>{
    if(!open)return;
    const outside=(e:PointerEvent)=>{const target=e.target as Node;if(!root.current?.contains(target)&&!popover.current?.contains(target))setOpen(false)};
    const esc=(e:KeyboardEvent)=>{if(e.key==='Escape')setOpen(false)};
    window.addEventListener('pointerdown',outside);window.addEventListener('keydown',esc);
    return()=>{window.removeEventListener('pointerdown',outside);window.removeEventListener('keydown',esc)};
  },[open]);
  useEffect(()=>{
    if(!open)return;
    const position=()=>{
      const r=root.current?.getBoundingClientRect();if(!r)return;
      const width=Math.min(360,window.innerWidth-20);const gap=8;
      const below=window.innerHeight-r.bottom-gap;const above=r.top-gap;const openUp=below<350&&above>below;
      setStyle({position:'fixed',width,left:Math.min(Math.max(10,r.left),window.innerWidth-width-10),top:openUp?undefined:r.bottom+gap,bottom:openUp?window.innerHeight-r.top+gap:undefined,zIndex:1800});
    };
    position();window.addEventListener('resize',position);window.addEventListener('scroll',position,true);
    return()=>{window.removeEventListener('resize',position);window.removeEventListener('scroll',position,true)};
  },[open]);
  useEffect(()=>{if(open&&yearMode)requestAnimationFrame(()=>selectedYearRef.current?.scrollIntoView({block:'center'}))},[open,yearMode,viewYear]);

  function chooseMonth(month:number){onChange(`${viewYear}-${String(month).padStart(2,'0')}`);setOpen(false);setYearMode(false)}
  function shiftYear(delta:number){setViewYear(y=>Math.min(maxYear,Math.max(minYear,y+delta)))}

  return <div className="dent-month-picker dent-month-picker-v16" ref={root}>
    <button type="button" className="dent-month-trigger" onClick={()=>{setOpen(v=>!v);setYearMode(false)}} aria-expanded={open} aria-haspopup="dialog">
      <CalendarDays size={17}/><span>{label}</span><ChevronDown size={16}/>
    </button>
    {open&&typeof document!=='undefined'&&createPortal(<div ref={popover} className="dent-month-popover-v16" style={style} role="dialog" aria-label={lang==='EN'?'Choose month':'Сар сонгох'}>
      <div className="dent-month-head-v16">
        <button type="button" onClick={()=>shiftYear(-1)} disabled={viewYear<=minYear} aria-label={lang==='EN'?'Previous year':'Өмнөх жил'}><ChevronLeft size={17}/></button>
        <button type="button" className="dent-month-year-button" onClick={()=>setYearMode(v=>!v)}>{viewYear}<ChevronDown size={14}/></button>
        <button type="button" onClick={()=>shiftYear(1)} disabled={viewYear>=maxYear} aria-label={lang==='EN'?'Next year':'Дараагийн жил'}><ChevronRight size={17}/></button>
      </div>
      {yearMode?<div className="dent-month-year-list" role="listbox">{years.map(y=><button ref={y===viewYear?selectedYearRef:undefined} type="button" role="option" aria-selected={y===viewYear} className={y===viewYear?'selected':''} key={y} onClick={()=>{setViewYear(y);setYearMode(false)}}><span>{y}</span>{y===viewYear&&<Check size={15}/>}</button>)}</div>:<div className="dent-month-grid-v16">{monthNames.map((name,i)=>{const month=i+1;const selected=viewYear===selectedYear&&month===selectedMonth;const current=viewYear===now.getFullYear()&&month===now.getMonth()+1;return <button type="button" key={month} className={`${selected?'selected':''} ${current?'current':''}`.trim()} onClick={()=>chooseMonth(month)}><span>{name}</span>{current&&<small>{lang==='EN'?'Now':'Одоо'}</small>}</button>})}</div>}
      <div className="dent-month-footer-v16"><button type="button" onClick={()=>{setViewYear(now.getFullYear());onChange(`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`);setOpen(false)}}>{lang==='EN'?'This month':'Энэ сар'}</button></div>
    </div>,document.body)}
  </div>;
}
