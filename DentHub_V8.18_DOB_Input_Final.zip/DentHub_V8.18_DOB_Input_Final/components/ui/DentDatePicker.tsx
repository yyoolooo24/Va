'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { CalendarDays, ChevronLeft, ChevronRight } from 'lucide-react';

const pad=(n:number)=>String(n).padStart(2,'0');
const key=(d:Date)=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
function parse(value:string){
  const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(value||'');
  if(!m)return new Date();
  const d=new Date(Number(m[1]),Number(m[2])-1,Number(m[3]),12,0,0,0);
  return Number.isNaN(d.getTime())?new Date():d;
}
function mondayIndex(day:number){return (day+6)%7}

export default function DentDatePicker({value,onChange,min,max,lang='MN',placeholder,className=''}:{value:string;onChange:(value:string)=>void;min?:string;max?:string;lang?:'MN'|'EN';placeholder?:string;className?:string}){
  const [open,setOpen]=useState(false);
  const selected=useMemo(()=>parse(value),[value]);
  const [cursor,setCursor]=useState(()=>new Date(selected.getFullYear(),selected.getMonth(),1,12));
  const ref=useRef<HTMLDivElement|null>(null);
  useEffect(()=>{if(open)setCursor(new Date(selected.getFullYear(),selected.getMonth(),1,12))},[open,selected]);
  useEffect(()=>{const fn=(e:MouseEvent)=>{if(ref.current&&!ref.current.contains(e.target as Node))setOpen(false)};document.addEventListener('mousedown',fn);return()=>document.removeEventListener('mousedown',fn)},[]);
  const first=new Date(cursor.getFullYear(),cursor.getMonth(),1,12);
  const start=new Date(first);start.setDate(1-mondayIndex(first.getDay()));
  const days=Array.from({length:42},(_,i)=>{const d=new Date(start);d.setDate(start.getDate()+i);return d});
  const minKey=min||'';const maxKey=max||'';
  const weekdays=lang==='EN'?['Mon','Tue','Wed','Thu','Fri','Sat','Sun']:['Да','Мя','Лх','Пү','Ба','Бя','Ня'];
  const locale=lang==='EN'?'en-US':'mn-MN';
  const label=value?selected.toLocaleDateString(locale,{year:'numeric',month:'short',day:'numeric'}):(placeholder||(lang==='EN'?'Choose date':'Өдөр сонгох'));
  return <div ref={ref} className={`dent-date-picker ${className} ${open?'open':''}`}>
    <button type="button" className="dent-date-trigger" onClick={()=>setOpen(v=>!v)}><CalendarDays size={17}/><span>{label}</span></button>
    {open&&<div className="dent-date-popover" role="dialog" aria-label={lang==='EN'?'Choose date':'Өдөр сонгох'}>
      <div className="dent-date-head"><button type="button" onClick={()=>setCursor(d=>new Date(d.getFullYear(),d.getMonth()-1,1,12))}><ChevronLeft/></button><strong>{cursor.toLocaleDateString(locale,{month:'long',year:'numeric'})}</strong><button type="button" onClick={()=>setCursor(d=>new Date(d.getFullYear(),d.getMonth()+1,1,12))}><ChevronRight/></button></div>
      <div className="dent-date-weekdays">{weekdays.map(x=><span key={x}>{x}</span>)}</div>
      <div className="dent-date-grid">{days.map(d=>{const k=key(d);const outside=d.getMonth()!==cursor.getMonth();const disabled=(minKey&&k<minKey)||(maxKey&&k>maxKey);return <button type="button" disabled={Boolean(disabled)} key={k} className={`${outside?'outside':''} ${k===value?'selected':''} ${k===key(new Date())?'today':''}`} onClick={()=>{onChange(k);setOpen(false)}}>{d.getDate()}</button>})}</div>
      <div className="dent-date-footer"><button type="button" onClick={()=>{const today=key(new Date());if((!minKey||today>=minKey)&&(!maxKey||today<=maxKey)){onChange(today);setOpen(false)}}}>{lang==='EN'?'Today':'Өнөөдөр'}</button>{value&&<button type="button" onClick={()=>{onChange('');setOpen(false)}}>{lang==='EN'?'Clear':'Цэвэрлэх'}</button>}</div>
    </div>}
  </div>
}
