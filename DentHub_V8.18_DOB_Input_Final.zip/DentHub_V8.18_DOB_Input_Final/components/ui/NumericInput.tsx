'use client';

import type { InputHTMLAttributes } from 'react';

type Props=Omit<InputHTMLAttributes<HTMLInputElement>,'value'|'onChange'|'type'|'inputMode'> & {
  value:string;
  onValueChange:(value:string)=>void;
  maxDigits?:number;
  maxValue?:number;
  allowDecimal?:boolean;
};

export default function NumericInput({value,onValueChange,maxDigits=16,maxValue,allowDecimal=false,...rest}:Props){
  const sanitize=(raw:string)=>{
    let out=allowDecimal?raw.replace(/[^0-9.]/g,''):raw.replace(/\D/g,'');
    if(allowDecimal){
      const [whole,...fraction]=out.split('.');
      out=whole+(fraction.length?`.`+fraction.join(''): '');
    }
    if(maxDigits>0){
      if(allowDecimal){const [whole,fraction]=out.split('.');out=whole.slice(0,maxDigits)+(fraction!==undefined?`.`+fraction.slice(0,2):'')}
      else out=out.slice(0,maxDigits);
    }
    if(maxValue!==undefined&&out!==''&&Number(out)>maxValue)out=String(maxValue);
    return out;
  };
  return <input {...rest} type="text" inputMode={allowDecimal?'decimal':'numeric'} pattern={allowDecimal?'[0-9]*[.]?[0-9]*':'[0-9]*'} value={value} onKeyDown={e=>{
    rest.onKeyDown?.(e);
    if(e.defaultPrevented)return;
    if(e.ctrlKey||e.metaKey||e.altKey)return;
    const allowed=['Backspace','Delete','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Tab','Home','End','Enter'];
    if(allowed.includes(e.key))return;
    if(e.key.length===1&&!/\d/.test(e.key)&&!(allowDecimal&&e.key==='.'&&!value.includes('.')))e.preventDefault();
  }} onChange={e=>onValueChange(sanitize(e.target.value))}/>
}
