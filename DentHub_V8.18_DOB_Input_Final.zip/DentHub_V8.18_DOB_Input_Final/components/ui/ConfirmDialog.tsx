'use client';

import { AlertTriangle, Loader2, Trash2, X } from 'lucide-react';

type Props = {
  open: boolean;
  title: string;
  description?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  busy?: boolean;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
};

export default function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel='Устгах',
  cancelLabel='Болих',
  busy=false,
  danger=true,
  onConfirm,
  onCancel,
}: Props){
  if(!open)return null;
  return <div className="confirm-dialog-layer" role="presentation" onMouseDown={e=>{if(e.currentTarget===e.target&&!busy)onCancel()}}>
    <section className="confirm-dialog" role="alertdialog" aria-modal="true" aria-labelledby="confirm-dialog-title" aria-describedby={description?'confirm-dialog-description':undefined}>
      <header>
        <span className={`confirm-dialog-icon ${danger?'danger':''}`}><AlertTriangle size={22}/></span>
        <button type="button" className="confirm-dialog-close" onClick={onCancel} disabled={busy} aria-label="Close"><X size={19}/></button>
      </header>
      <div className="confirm-dialog-copy">
        <h3 id="confirm-dialog-title">{title}</h3>
        {description&&<p id="confirm-dialog-description">{description}</p>}
      </div>
      <footer>
        <button type="button" className="btn-secondary" onClick={onCancel} disabled={busy}>{cancelLabel}</button>
        <button type="button" className={danger?'btn-danger':'btn-primary'} onClick={onConfirm} disabled={busy}>{busy?<Loader2 className="spin" size={17}/>:danger?<Trash2 size={17}/>:null}{confirmLabel}</button>
      </footer>
    </section>
  </div>;
}
