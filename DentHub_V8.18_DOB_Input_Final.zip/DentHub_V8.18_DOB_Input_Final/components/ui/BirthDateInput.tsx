'use client';

import { useMemo } from 'react';

export function maskBirthDate(value:unknown){
  const digits=String(value??'').replace(/\D/g,'').slice(0,8);
  if(digits.length<=4)return digits;
  if(digits.length<=6)return `${digits.slice(0,4)}/${digits.slice(4)}`;
  return `${digits.slice(0,4)}/${digits.slice(4,6)}/${digits.slice(6,8)}`;
}

export function birthDateToIso(value:unknown){
  const digits=String(value??'').replace(/\D/g,'').slice(0,8);
  if(!digits)return '';
  if(digits.length!==8)return null;
  const year=Number(digits.slice(0,4));
  const month=Number(digits.slice(4,6));
  const day=Number(digits.slice(6,8));
  if(year<1900||month<1||month>12||day<1||day>31)return null;
  const date=new Date(Date.UTC(year,month-1,day));
  if(date.getUTCFullYear()!==year||date.getUTCMonth()!==month-1||date.getUTCDate()!==day)return null;
  const today=new Date();
  const todayUtc=new Date(Date.UTC(today.getFullYear(),today.getMonth(),today.getDate()));
  if(date>todayUtc)return null;
  return `${String(year).padStart(4,'0')}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
}

export function formatBirthDateDisplay(value:unknown){
  const iso=birthDateToIso(value);
  if(!iso)return value?maskBirthDate(value):'';
  return iso.replace(/-/g,'/');
}

export default function BirthDateInput({
  value,
  onValueChange,
  placeholder='XXXX/XX/XX',
  disabled=false,
  className='',
  ariaLabel,
}:{
  value:string;
  onValueChange:(value:string)=>void;
  placeholder?:string;
  disabled?:boolean;
  className?:string;
  ariaLabel?:string;
}){
  const display=useMemo(()=>maskBirthDate(value),[value]);
  return <input
    type="text"
    className={`birth-date-input ${className}`.trim()}
    value={display}
    onChange={e=>onValueChange(maskBirthDate(e.target.value))}
    onKeyDown={e=>{
      if(e.ctrlKey||e.metaKey||e.altKey)return;
      if(['Backspace','Delete','ArrowLeft','ArrowRight','Tab','Home','End','Enter'].includes(e.key))return;
      if(!/^\d$/.test(e.key))e.preventDefault();
    }}
    inputMode="numeric"
    pattern="[0-9/]*"
    maxLength={10}
    autoComplete="bday"
    enterKeyHint="next"
    placeholder={placeholder}
    disabled={disabled}
    aria-label={ariaLabel||placeholder}
  />;
}
