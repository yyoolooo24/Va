'use client';

import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, CreditCard, Loader2, Plus, QrCode, ReceiptText, Trash2, UsersRound, WalletCards, Stethoscope, Clock3, ArrowRight, HandCoins } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { getSupabaseBrowser } from '@/lib/supabase-browser';
import type { AppLang } from './DashboardApp';
import DentSelect from './ui/DentSelect';
import NumericInput from './ui/NumericInput';
import ConfirmDialog from './ui/ConfirmDialog';

type Profile={id?:string;full_name:string;role:string;clinic_id?:string|null};
type Patient={id:string;patient_code?:string|null;full_name:string;phone?:string|null;register_no?:string|null};
type InvoiceResult={invoice_id?:string;sender_invoice_no?:string;patient_code?:string|null;qr_text?:string;qr_image?:string|null;qPay_shortUrl?:string|null;qpay_urls?:Array<{name?:string;description?:string;logo?:string;link:string}>;demo?:boolean;error?:string};
type PaymentMethod={id:string;name:string;code?:string|null;active:boolean;is_system?:boolean;sort_order?:number};
type PendingCheckout={id:string;patient_id:string;total_amount:number;paid_amount:number;billing_status?:string|null;credit_transferred_at?:string|null;status?:string|null;created_at:string;patients?:{full_name?:string|null;patient_code?:string|null;phone?:string|null}|null;doctor?:{full_name?:string|null}|null};

export default function PaymentPanel({profile,clinicName,lang}:{profile:Profile;clinicName:string;lang:AppLang}) {
  const en=lang==='EN';
  const [patients,setPatients]=useState<Patient[]>([]);const [patientId,setPatientId]=useState('');
  const [paymentMethods,setPaymentMethods]=useState<PaymentMethod[]>([]);const [paymentMethodId,setPaymentMethodId]=useState('');const [newPaymentMethod,setNewPaymentMethod]=useState('');const [methodBusy,setMethodBusy]=useState(false);const [deleteMethodTarget,setDeleteMethodTarget]=useState<PaymentMethod|null>(null);const [encounterId,setEncounterId]=useState('');
  const [amount,setAmount]=useState('');const [creditDue,setCreditDue]=useState(()=>{const d=new Date();d.setDate(d.getDate()+30);return d.toISOString().slice(0,10)});
  const [description,setDescription]=useState(en?'Medical service':'Эмнэлгийн үйлчилгээ');
  const [requestEbarimt,setRequestEbarimt]=useState(true);
  const [receiverType,setReceiverType]=useState<'CITIZEN'|'COMPANY'>('CITIZEN');
  const [receiver,setReceiver]=useState('');
  const [result,setResult]=useState<InvoiceResult|null>(null);
  const [busy,setBusy]=useState(false);const [error,setError]=useState('');const [notice,setNotice]=useState('');
  const [pendingCheckouts,setPendingCheckouts]=useState<PendingCheckout[]>([]);const [queueLoading,setQueueLoading]=useState(false);

  async function loadPendingCheckouts(){
    if(!profile.clinic_id||!['owner','employee'].includes(profile.role))return;
    const s=getSupabaseBrowser();if(!s)return;setQueueLoading(true);
    try{
      const {data,error:e}=await s.from('encounters')
        .select('id,patient_id,total_amount,paid_amount,billing_status,credit_transferred_at,status,created_at,patients(full_name,patient_code,phone),doctor:profiles!encounters_doctor_id_fkey(full_name)')
        .eq('clinic_id',profile.clinic_id).is('deleted_at',null).gt('total_amount',0).order('created_at',{ascending:false}).limit(120);
      if(e)throw e;
      const rows=((data||[]) as unknown as PendingCheckout[]).filter(r=>!r.credit_transferred_at&&['completed','done'].includes(String(r.status||''))&&Number(r.total_amount||0)-Number(r.paid_amount||0)>0.009);
      setPendingCheckouts(rows);
    }catch{}finally{setQueueLoading(false)}
  }
  useEffect(()=>{(async()=>{if(!profile.clinic_id||!['owner','employee'].includes(profile.role))return;const s=getSupabaseBrowser();if(!s)return;const [{data:patientRows},{data:methodRows}]=await Promise.all([s.from('patients').select('id,patient_code,full_name,phone,register_no').eq('clinic_id',profile.clinic_id).is('deleted_at',null).order('full_name'),s.from('payment_methods').select('id,name,code,active,is_system,sort_order').eq('clinic_id',profile.clinic_id).eq('active',true).order('sort_order').order('name')]);setPatients((patientRows||[]) as Patient[]);const methods=(methodRows||[]) as PaymentMethod[];setPaymentMethods(methods);if(methods[0]?.id)setPaymentMethodId(current=>current||methods[0].id);await loadPendingCheckouts()})()},[profile.clinic_id,profile.role]);
  useEffect(()=>{if(!profile.clinic_id||!['owner','employee'].includes(profile.role))return;const s=getSupabaseBrowser();if(!s)return;const channel=s.channel(`denthub-cashier-${profile.clinic_id}`).on('postgres_changes',{event:'*',schema:'public',table:'encounters',filter:`clinic_id=eq.${profile.clinic_id}`},()=>loadPendingCheckouts()).on('postgres_changes',{event:'*',schema:'public',table:'encounter_payments',filter:`clinic_id=eq.${profile.clinic_id}`},()=>loadPendingCheckouts()).subscribe();return()=>{s.removeChannel(channel)}},[profile.clinic_id,profile.role]);
  useEffect(()=>{
    if(typeof window==='undefined'||!['owner','employee'].includes(profile.role))return;
    try{
      const raw=sessionStorage.getItem('denthub-payment-preset');if(!raw)return;
      sessionStorage.removeItem('denthub-payment-preset');
      const preset=JSON.parse(raw);
      if(preset?.patientId)setPatientId(String(preset.patientId));
      if(preset?.encounterId)setEncounterId(String(preset.encounterId));
      if(preset?.amount)setAmount(String(preset.amount));
      if(preset?.description)setDescription(String(preset.description));
    }catch{}
  },[profile.role]);
  const selectedPatient=useMemo(()=>patients.find(p=>p.id===patientId)||null,[patients,patientId]);

  async function addPaymentMethod(){
    const name=newPaymentMethod.trim();if(!name||!profile.clinic_id)return;setMethodBusy(true);setError('');
    try{const s=getSupabaseBrowser();if(!s)return;const {data,error:e}=await s.from('payment_methods').insert({clinic_id:profile.clinic_id,name,active:true,is_system:false,sort_order:100,created_by:profile.id||null}).select('id,name,code,active,is_system,sort_order').single();if(e)throw e;const row=data as PaymentMethod;setPaymentMethods(v=>[...v,row].sort((a,b)=>(a.sort_order||100)-(b.sort_order||100)||a.name.localeCompare(b.name,'mn')));setPaymentMethodId(row.id);setNewPaymentMethod('')}catch(e:unknown){setError(e instanceof Error?e.message:'Төлбөрийн хэлбэр нэмэж чадсангүй.')}finally{setMethodBusy(false)}
  }
  async function removePaymentMethod(method:PaymentMethod){
    if(method.is_system){setError(en?'Default methods can be disabled later from settings; keep them for cashbook consistency.':'Үндсэн төлбөрийн хэлбэрүүдийг кассын түүхийн нийцтэй байдлаас шалтгаалж эндээс устгахгүй.');return}
    setMethodBusy(true);setError('');
    try{const s=getSupabaseBrowser();if(!s)return;const {error:e}=await s.from('payment_methods').delete().eq('id',method.id).eq('clinic_id',profile.clinic_id||'');if(e)throw e;setPaymentMethods(v=>v.filter(x=>x.id!==method.id));if(paymentMethodId===method.id)setPaymentMethodId(paymentMethods.find(x=>x.id!==method.id)?.id||'');setDeleteMethodTarget(null)}catch(e:unknown){setError(e instanceof Error?e.message:'Төлбөрийн хэлбэр устгаж чадсангүй.')}finally{setMethodBusy(false)}
  }


  async function saveDirectPayment(){
    if(!patientId){setError(en?'Choose a patient first.':'Эхлээд өвчтөн сонгоно уу.');return}
    const numericAmount=Number(amount);if(!Number.isFinite(numericAmount)||numericAmount<=0){setError(en?'Enter a valid payment amount.':'Төлбөрийн дүнг зөв оруулна уу.');return}
    const method=paymentMethods.find(x=>x.id===paymentMethodId);if(!method){setError(en?'Choose a payment method.':'Төлбөрийн хэлбэр сонгоно уу.');return}
    if(method.code==='qpay'){await createInvoice();return}
    if(method.code==='clinic_credit'){
      setBusy(true);setError('');setNotice('');
      try{
        const s=getSupabaseBrowser();if(!s)throw new Error('Supabase холболт алга.');const patient=patients.find(p=>p.id===patientId);if(!patient)throw new Error(en?'Patient not found.':'Өвчтөн олдсонгүй.');
        if(!encounterId)throw new Error(en?'Clinic credit must be linked to a completed treatment.':'Эмнэлгийн зээлийг дууссан үзлэг, эмчилгээтэй холбоно уу.');
        const due=creditDue||(()=>{const d=new Date();d.setDate(d.getDate()+30);return d.toISOString().slice(0,10)})();
        const {error:e}=await s.rpc('denthub_transfer_encounter_to_receivable',{p_encounter_id:encounterId,p_amount:numericAmount,p_due_date:due,p_note:description.trim()||null});if(e)throw e;
        setNotice(en?'Clinic credit moved to Receivables.':'Эмнэлгийн зээл Авлага модуль руу шилжлээ.');setAmount('');setEncounterId('');await loadPendingCheckouts();
      }catch(e:unknown){setError(e instanceof Error?e.message:'Авлага үүсгэж чадсангүй.')}finally{setBusy(false)}
      return;
    }
    setBusy(true);setError('');setNotice('');
    try{
      const s=getSupabaseBrowser();if(!s)throw new Error('Supabase холболт алга.');
      if(encounterId){
        const {error:e}=await s.rpc('denthub_record_encounter_payment_v2',{p_encounter_id:encounterId,p_amount:numericAmount,p_payment_method_id:paymentMethodId,p_note:description.trim()||null,p_request_ebarimt:requestEbarimt,p_ebarimt_receiver_type:requestEbarimt?receiverType:null,p_ebarimt_receiver:requestEbarimt?(receiver||null):null});if(e)throw e;
      }else{
        const {error:e}=await s.from('finance_transactions').insert({clinic_id:profile.clinic_id,created_by:profile.id||null,kind:'income',description:description.trim()||'Төлбөр',amount:Math.round(numericAmount),payment_method:method.name,patient_id:patientId,request_ebarimt:requestEbarimt,ebarimt_receiver_type:requestEbarimt?receiverType:null,ebarimt_receiver:requestEbarimt?(receiver||null):null});if(e)throw e;
      }
      setNotice(requestEbarimt?(en?'Payment saved to cashbook and marked for receipt reporting.':'Төлбөр кассын журналд хадгалагдаж, баримттай төлөлтөөр НЭМГ-ийн тайланд орно.'):(en?'Payment saved to treatment history and cashbook.':'Төлбөр эмчилгээний түүхтэй холбогдож, кассын журналд хадгалагдлаа.'));setAmount('');setEncounterId('');await loadPendingCheckouts();
    }catch(e:unknown){setError(e instanceof Error?e.message:'Төлбөр хадгалж чадсангүй.')}finally{setBusy(false)}
  }

  async function createInvoice(){
    if(['owner','employee'].includes(profile.role)&&!patientId){setError(en?'Choose a patient first.':'Эхлээд өвчтөн сонгоно уу.');return}
    const numericAmount=Number(amount);
    if(!Number.isFinite(numericAmount)||numericAmount<=0){setError(en?'Enter a valid payment amount.':'Төлбөрийн дүнг 0-ээс их тоогоор оруулна уу.');return}
    if(!description.trim()){setError(en?'Enter a payment description.':'Гүйлгээний утга оруулна уу.');return}
    setBusy(true);setError('');setResult(null);
    try{
      const supabase=getSupabaseBrowser();const {data}=supabase?await supabase.auth.getSession():({data:{session:null}} as any);
      const res=await fetch('/api/qpay/invoice',{method:'POST',headers:{'Content-Type':'application/json',...(data.session?.access_token?{Authorization:`Bearer ${data.session.access_token}`}:{})},body:JSON.stringify({patientId,encounterId:encounterId||undefined,amount:numericAmount,description:description.trim(),requestEbarimt,ebarimtReceiverType:receiverType,ebarimtReceiver:receiver||undefined})});
      const body=await res.json(); if(!res.ok) throw new Error(body.error||(en?'Could not create QPay invoice.':'QPay invoice үүсгэж чадсангүй.'));setResult(body);
    }catch(e:unknown){setError(e instanceof Error?e.message:(en?'Something went wrong.':'Алдаа гарлаа.'));}finally{setBusy(false)}
  }

  function choosePending(row:PendingCheckout){
    const remaining=Math.max(0,Number(row.total_amount||0)-Number(row.paid_amount||0));
    setPatientId(row.patient_id);setEncounterId(row.id);setAmount(String(Math.round(remaining)));setDescription(`${row.patients?.full_name||'Өвчтөн'} · Үзлэг, эмчилгээ`);setResult(null);setError('');setNotice('');
    window.setTimeout(()=>document.querySelector('.payment-form-card')?.scrollIntoView({behavior:'smooth',block:'start'}),0);
  }

  return <div className="page-stack payment-page">
    <ConfirmDialog open={Boolean(deleteMethodTarget)} busy={methodBusy} title={en?'Delete this payment method?':'Энэ төлбөрийн хэлбэрийг устгах уу?'} description={deleteMethodTarget?(en?`${deleteMethodTarget.name} will no longer appear for new payments. Existing cashbook history keeps its saved method name.`:`${deleteMethodTarget.name} шинэ төлбөрийн сонголтоос алга болно. Өмнөх кассын түүхэнд хадгалагдсан нэр хэвээр үлдэнэ.`):''} confirmLabel={en?'Delete method':'Хэлбэр устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!methodBusy&&setDeleteMethodTarget(null)} onConfirm={()=>deleteMethodTarget&&removePaymentMethod(deleteMethodTarget)}/>
    <header className="page-head"><div><small>{clinicName} · {en?'POS':'Касс'}</small><h1>{en?'Cashier & payments':'Касс & төлбөр'}</h1><p>{en?'Every payment is linked to one unique patient ID, preventing name collisions and preserving purchase history.':'Төлбөр бүр өвчтөний давтагдашгүй ID-тай холбогдож, ижил нэртэй хүмүүсийн гүйлгээ холилдохоос хамгаална.'}</p></div></header>
    {['owner','employee'].includes(profile.role)&&<section className="panel-card cashier-queue-card"><div className="panel-head"><div><h2>{en?'Waiting for payment':'Касс хүлээж буй эмчилгээ'}</h2><p>{en?'Treatments saved by doctors appear here automatically with their remaining amount.':'Эмчийн хадгалсан эмчилгээ нийт дүнтэйгээ энд автоматаар жагсаж орно.'}</p></div><span className="queue-count">{queueLoading?'…':pendingCheckouts.length}</span></div>{pendingCheckouts.length?<div className="cashier-queue-list">{pendingCheckouts.map(row=>{const remaining=Math.max(0,Number(row.total_amount||0)-Number(row.paid_amount||0));return <button type="button" className={encounterId===row.id?'active':''} key={row.id} onClick={()=>choosePending(row)}><span className="queue-icon"><Stethoscope size={17}/></span><span className="queue-copy"><b>{row.patients?.full_name||'Өвчтөн'} {row.patients?.patient_code&&<small>{row.patients.patient_code}</small>}</b><em><Clock3 size={13}/>{new Date(row.created_at).toLocaleString(en?'en-US':'mn-MN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'})}{row.doctor?.full_name?` · ${row.doctor.full_name}`:''}</em></span><span className="queue-money"><small>{en?'Remaining':'Үлдэгдэл'}</small><strong>₮{Math.round(remaining).toLocaleString()}</strong></span><ArrowRight size={17}/></button>})}</div>:<div className="cashier-queue-empty"><CheckCircle2 size={20}/><span>{en?'No unpaid treatment visits are waiting.':'Төлбөр хүлээж буй эмчилгээ одоогоор алга.'}</span></div>}</section>}
    <div className="payment-layout"><article className="panel-card form-card payment-form-card"><div className="panel-head"><div><h2>{en?'Create invoice':'Нэхэмжлэх үүсгэх'}</h2><p>{en?'Patient-linked cashier entry · receipt · cashbook':'Өвчтөнтэй холбогдсон кассын бичилт · баримт · кассын журнал'}</p></div><span className="icon-cube"><CreditCard/></span></div>
      {['owner','employee'].includes(profile.role)&&<label>{en?'Patient':'Өвчтөн'}<DentSelect searchable value={patientId} onChange={setPatientId} placeholder={en?'Choose patient by name, phone or ID':'Нэр, утас эсвэл ID-аар өвчтөн сонгох'} searchPlaceholder={en?'Search patient…':'Өвчтөн хайх…'} options={patients.map(p=>({value:p.id,label:`${p.full_name}${p.patient_code?` · ${p.patient_code}`:''}`,description:[p.phone,p.register_no].filter(Boolean).join(' · ')}))}/></label>}
      {selectedPatient&&<div className="patient-identity-card payment-patient-meta"><UsersRound size={18}/><div><b>{selectedPatient.full_name} <span className="patient-code-chip">{selectedPatient.patient_code||selectedPatient.id.slice(0,8)}</span></b><small>{[selectedPatient.phone,selectedPatient.register_no].filter(Boolean).join(' · ')|| (en?'No additional contact information':'Нэмэлт холбоо барих мэдээлэлгүй')}</small></div></div>}<div className="payment-method-manager"><div className="payment-method-manager-head"><span><WalletCards size={17}/><b>{en?'Clinic payment methods':'Эмнэлгийн төлбөрийн хэлбэрүүд'}</b></span><small>{en?'Cash, card, clinic credit, loan apps — add your own methods anytime.':'Бэлэн, карт, эмнэлгийн зээл, зээлийн апп болон өөрсдийн хэрэглэдэг хэлбэрээ нэмж болно.'}</small></div><div className="payment-method-chips">{paymentMethods.map(method=><span className="payment-method-chip" key={method.id}><WalletCards size={14}/>{method.name}{!method.is_system&&<button type="button" onClick={()=>setDeleteMethodTarget(method)} title={en?'Remove':'Устгах'}><Trash2 size={12}/></button>}</span>)}</div><div className="payment-method-add-row"><input value={newPaymentMethod} onChange={e=>setNewPaymentMethod(e.target.value)} placeholder={en?'Add custom method, e.g. SocialPay':'Шинэ хэлбэр, ж: SocialPay'}/><button type="button" className="btn-secondary" onClick={addPaymentMethod} disabled={methodBusy||!newPaymentMethod.trim()}>{methodBusy?<Loader2 className="spin" size={14}/>:<Plus size={14}/>} {en?'Add':'Нэмэх'}</button></div></div>
      <label>{en?'Amount':'Төлбөрийн дүн'}<div className="money-input"><span>₮</span><NumericInput value={amount} onValueChange={setAmount} maxDigits={12} placeholder="0" aria-label={en?'Payment amount':'Төлбөрийн дүн'}/></div></label>
      <label>{en?'Description':'Утга'}<input value={description} onChange={e=>setDescription(e.target.value)} placeholder={en?'Treatment / product / invoice note':'Эмчилгээ / бараа / гүйлгээний утга'}/></label>
      <label>{en?'Payment method':'Төлбөрийн хэлбэр'}<DentSelect value={paymentMethodId} onChange={setPaymentMethodId} options={paymentMethods.map(m=>({value:m.id,label:m.name,description:m.code==='qpay'?'QPay':''}))}/></label>
      {paymentMethods.find(x=>x.id===paymentMethodId)?.code==='clinic_credit'&&<label>{en?'Receivable due date':'Авлагын төлөх хугацаа'}<input type="date" value={creditDue} onChange={e=>setCreditDue(e.target.value)}/><small className="payment-field-hint">{en?'No cashbook income is created yet; the balance moves to Receivables.':'Энэ үед кассын орлого бичихгүй, үлдэгдэл Авлага модуль руу шилжинэ.'}</small></label>}
      <label className="check-row receipt-report-toggle"><input type="checkbox" checked={requestEbarimt} onChange={e=>setRequestEbarimt(e.target.checked)}/><span><b>{en?'Receipt / eBarimt':'Баримт / eBarimt авах'}</b><small>{en?'For QPay, eBarimt is generated after payment. For cash/card/other methods, this payment is marked as receipt-issued and the selected patient is included in the Health Department receipt report.':'QPay бол төлөгдсөний дараа eBarimt үүснэ. Бэлэн, карт болон бусад төлбөр дээр энэ сонголтыг хийвэл тухайн өвчтөний мэдээлэл НЭМГ-ийн баримттай төлөлтийн тайланд орно.'}</small></span></label>
      {requestEbarimt&&<div className="ebarimt-fields"><label>{en?'Receiver':'Хүлээн авагч'}<DentSelect value={receiverType} onChange={v=>setReceiverType(v as 'CITIZEN'|'COMPANY')} options={[{value:'CITIZEN',label:en?'Citizen':'Иргэн'},{value:'COMPANY',label:en?'Company':'Байгууллага'}]}/></label>{receiverType==='COMPANY'&&<label>{en?'Company TIN / registration':'Байгууллагын TIN / регистр'}<NumericInput value={receiver} onValueChange={setReceiver} maxDigits={14} placeholder={en?'Registration / TIN':'Регистр / TIN'}/></label>}<div className="receipt-report-preview"><ReceiptText size={16}/><span><b>{en?'Health Department report':'НЭМГ-ийн тайлан'}</b><small>{selectedPatient?(en?`${selectedPatient.full_name} will be included when this payment is saved.`:`${selectedPatient.full_name} төлбөр хадгалагдахад баримттай төлөлтийн жагсаалтад орно.`):(en?'Choose a patient to link this receipt.':'Баримтыг холбох өвчтөнөө сонгоно уу.')}</small></span></div></div>}
      {error&&<div className="form-error">{error}</div>}{notice&&<div className="success-hint"><CheckCircle2 size={18}/><span>{notice}</span></div>}
      <button className="btn-primary full" onClick={saveDirectPayment} disabled={busy||!paymentMethodId}>{busy?<><Loader2 className="spin" size={17}/> {en?'Saving…':'Хадгалж байна…'}</>:paymentMethods.find(x=>x.id===paymentMethodId)?.code==='qpay'?<><QrCode size={17}/>{en?'Create QPay invoice':'QPay invoice үүсгэх'}</>:paymentMethods.find(x=>x.id===paymentMethodId)?.code==='clinic_credit'?<><HandCoins size={17}/>{en?'Move to receivables':'Авлага руу шилжүүлэх'}</>:<><CheckCircle2 size={17}/>{en?'Save payment & cashbook':'Төлбөр + кассын журнал хадгалах'}</>}</button>
      <div className="payment-note"><ReceiptText size={18}/><p>{en?'DentHub stores the patient UUID as the real relationship and shows a shorter patient code to staff. Transactions never rely on the patient name alone.':'DentHub database-д өвчтөний UUID-г үндсэн холбоосоор хадгалж, ажилтанд богино Patient ID харуулна. Гүйлгээг зөвхөн нэрээр нь хэзээ ч холбохгүй.'}</p></div>
    </article>
    <article className="panel-card invoice-preview-card"><div className="panel-head"><div><h2>{en?'Payment QR':'Төлбөрийн QR'}</h2><p>{result?result.demo?(en?'Test invoice':'Туршилтын invoice'):'QPay invoice':(en?'Appears here after invoice creation':'Invoice үүсгэсний дараа энд гарна')}</p></div>{result&&<span className="status-pill active">READY</span>}</div>
      {!result?<div className="qr-empty"><span className="icon-cube xl"><QrCode/></span><b>{en?'No QR yet':'QR хараахан үүсээгүй'}</b><p>{en?'Choose a patient, enter the amount and create the invoice.':'Өвчтөнөө сонгоод дүнгээ оруулж invoice үүсгэнэ үү.'}</p></div>:<div className="qr-result"><div className="qr-box">{result.qr_image?<img src={result.qr_image.startsWith('data:')?result.qr_image:`data:image/png;base64,${result.qr_image}`} alt="QPay QR"/>:<QRCodeSVG value={result.qr_text||result.invoice_id||'QPAY'} size={230} level="M"/>}</div><div className="invoice-id"><small>Invoice ID</small><b>{result.invoice_id}</b></div>{result.patient_code&&<div className="transaction-reference"><small>{en?'Patient ID':'Өвчтөний ID'}</small><b>{result.patient_code}</b></div>}{result.sender_invoice_no&&<div className="transaction-reference"><small>{en?'Transaction ref':'Гүйлгээний дугаар'}</small><b>{result.sender_invoice_no}</b></div>}{result.demo&&<div className="demo-warning">{en?'This is a test invoice.':'Туршилтын invoice байна.'}</div>}{result.qPay_shortUrl&&<a className="btn-primary full link-btn" href={result.qPay_shortUrl} target="_blank" rel="noreferrer">{en?'Open QPay link':'QPay link нээх'}</a>}{result.qpay_urls&&result.qpay_urls.length>0&&<div className="bank-links">{result.qpay_urls.slice(0,8).map((u,i)=><a key={i} href={u.link}>{u.name||u.description||(en?'Bank':'Банк')}</a>)}</div>}<div className="success-hint"><CheckCircle2 size={18}/><span>{en?'This invoice is linked to the selected patient ID.':'Энэ нэхэмжлэх сонгосон өвчтөний ID-тай холбогдлоо.'}</span></div></div>}
    </article></div>
  </div>
}
