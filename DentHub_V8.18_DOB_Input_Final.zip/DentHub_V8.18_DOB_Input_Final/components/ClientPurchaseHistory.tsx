'use client';

import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Clock3, CreditCard, Loader2, ReceiptText, Search } from 'lucide-react';
import { getSupabaseBrowser } from '@/lib/supabase-browser';
import type { AppLang, AppProfile } from './DashboardApp';

type Purchase={id:string;clinic_name:string;sender_invoice_no:string;amount:number;description?:string|null;status:string;payment_id?:string|null;paid_at?:string|null;created_at:string};
async function authFetch(url:string){const s=getSupabaseBrowser();if(!s)throw new Error('Supabase холболт алга.');const {data}=await s.auth.getSession();const token=data.session?.access_token;if(!token)throw new Error('Нэвтрэх эрх дууссан байна.');const res=await fetch(url,{headers:{Authorization:`Bearer ${token}`}});const json=await res.json().catch(()=>({}));if(!res.ok)throw new Error(json.error||'Алдаа гарлаа.');return json}

export default function ClientPurchaseHistory({profile,lang}:{profile:AppProfile;lang:AppLang}){
  const en=lang==='EN';const [items,setItems]=useState<Purchase[]>([]);const [loading,setLoading]=useState(true);const [error,setError]=useState('');const [setupRequired,setSetupRequired]=useState(false);const [q,setQ]=useState('');
  async function load(silent=false){if(!silent)setLoading(true);try{const data=await authFetch('/api/client/purchases');setItems(data.items||[]);setSetupRequired(Boolean(data.setup_required));setError('')}catch(e:unknown){setError(e instanceof Error?e.message:'Төлбөрийн түүх ачаалж чадсангүй.')}finally{if(!silent)setLoading(false)}}
  useEffect(()=>{load();const s=getSupabaseBrowser();if(!s)return;const channel=s.channel(`client-purchases-${profile.id||'me'}`).on('postgres_changes',{event:'*',schema:'public',table:'qpay_invoices'},()=>load(true)).subscribe();return()=>{s.removeChannel(channel)}},[profile.id]);
  const filtered=useMemo(()=>{const x=q.toLowerCase().trim();return x?items.filter(i=>`${i.clinic_name} ${i.description||''} ${i.sender_invoice_no}`.toLowerCase().includes(x)):items},[items,q]);
  const paid=items.filter(i=>['PAID','SUCCESS','paid'].includes(i.status)).reduce((n,i)=>n+Number(i.amount||0),0);
  return <div className="page-stack client-purchases-page"><header className="page-head"><div><small>DentHub</small><h1>{en?'Purchase history':'Худалдан авалтын түүх'}</h1><p>{en?'Your clinic invoices and QPay payment history.':'Таны эмнэлгийн нэхэмжлэх болон QPay төлбөрийн түүх.'}</p></div></header>
    <section className="client-purchase-summary"><article className="panel-card purchase-stat"><span><ReceiptText/></span><div><b>{loading?'—':items.length}</b><small>{en?'invoices':'нэхэмжлэх'}</small></div></article><article className="panel-card purchase-stat"><span><CheckCircle2/></span><div><b>{loading?'—':`₮${paid.toLocaleString()}`}</b><small>{en?'paid total':'төлсөн дүн'}</small></div></article></section>
    <section className="panel-card purchase-history-card"><div className="panel-head"><div><h2>{en?'Transactions':'Гүйлгээний түүх'}</h2><p>{en?'Newest transactions appear first.':'Сүүлийн гүйлгээ хамгийн дээр харагдана.'}</p></div></div><div className="module-search purchase-search"><Search size={17}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder={en?'Search clinic or description…':'Эмнэлэг эсвэл утгаар хайх…'}/></div>
      {error&&<div className="form-error">{error}</div>}{setupRequired&&<div className="status-banner">{en?'Purchase history is being enabled by the clinic administrator.':'Худалдан авалтын түүхийн холболтыг эмнэлгийн админ тохируулж байна.'}</div>}{loading?<div className="purchase-loading"><Loader2 className="spin"/>{en?'Loading…':'Ачаалж байна…'}</div>:filtered.length?<div className="purchase-list">{filtered.map(i=><article key={i.id} className="purchase-row"><span className="purchase-icon"><CreditCard/></span><div className="purchase-main"><b>{i.description|| (en?'Medical service':'Эмнэлгийн үйлчилгээ')}</b><span>{i.clinic_name}</span><small><Clock3 size={13}/>{new Date(i.paid_at||i.created_at).toLocaleString(en?'en-US':'mn-MN')} · {i.sender_invoice_no}</small></div><div className="purchase-side"><strong>₮{Number(i.amount||0).toLocaleString()}</strong><em className={`purchase-status ${String(i.status).toLowerCase()}`}>{i.status}</em></div></article>)}</div>:<div className="empty-state"><ReceiptText/><b>{en?'No purchase history yet':'Одоогоор худалдан авалтын түүх алга'}</b><p>{en?'Payments linked to your patient account will appear here.':'Таны өвчтөний бүртгэлтэй холбогдсон төлбөрүүд энд харагдана.'}</p></div>}
    </section>
  </div>
}
