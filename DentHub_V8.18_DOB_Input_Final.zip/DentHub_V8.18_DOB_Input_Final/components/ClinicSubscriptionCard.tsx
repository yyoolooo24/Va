'use client';

import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Clock3, LockKeyhole, Send, ShieldCheck, X } from 'lucide-react';
import { getSupabaseBrowser } from '@/lib/supabase-browser';
import { CLINIC_MODULES, MODULE_LABELS } from '@/lib/subscription';
import type { AppLang, AppProfile } from './DashboardApp';
import ModuleAccessPicker from './ModuleAccessPicker';

export default function ClinicSubscriptionCard({profile,lang}:{profile:AppProfile;lang:AppLang}){
  const en=lang==='EN';
  const active=profile.clinic_modules||[];
  const [selected,setSelected]=useState<string[]>([]);
  const [pending,setPending]=useState<any[]>([]);
  const [busy,setBusy]=useState(false);
  const [notice,setNotice]=useState<{kind:'success'|'error';text:string}|null>(null);
  const [requestOpen,setRequestOpen]=useState(false);
  const locked=useMemo(()=>CLINIC_MODULES.filter(m=>!active.includes(m)),[active]);
  async function token(){const s=getSupabaseBrowser();const {data}=s?await s.auth.getSession():({data:{session:null}} as any);return data.session?.access_token||''}
  async function load(){try{const t=await token();if(!t)return;const res=await fetch('/api/clinic/module-requests',{headers:{Authorization:`Bearer ${t}`}});const body=await res.json();if(res.ok)setPending(body.rows||[])}catch{}}
  useEffect(()=>{void load()},[]);
  useEffect(()=>{if(!notice)return;const id=window.setTimeout(()=>setNotice(null),5000);return()=>window.clearTimeout(id)},[notice]);
  async function send(){
    if(!selected.length)return;setBusy(true);setNotice(null);
    try{const t=await token();const res=await fetch('/api/clinic/module-requests',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${t}`},body:JSON.stringify({modules:selected})});const body=await res.json();if(!res.ok)throw new Error(body.error||(en?'Could not send request.':'Хүсэлт илгээж чадсангүй.'));setSelected([]);setRequestOpen(false);setNotice({kind:'success',text:en?'Module request sent for Platform Admin review.':'Нэмэлт модулийн хүсэлтийг DentHub системийн админд илгээлээ.'});await load()}catch(e:any){setNotice({kind:'error',text:e?.message||(en?'Could not send request.':'Хүсэлт илгээж чадсангүй.')})}finally{setBusy(false)}
  }
  const hasPending=pending.some(r=>r.status==='pending');
  return <section className="panel-card clinic-subscription-card">
    {notice&&<div className={`platform-action-toast ${notice.kind}`} role="status"><div>{notice.kind==='success'?<CheckCircle2 size={17}/>:<X size={17}/>}<span>{notice.text}</span></div><button onClick={()=>setNotice(null)}><X size={15}/></button></div>}
    <div className="panel-head"><div><h2>{en?'DentHub subscription':'DentHub багц'}</h2><p>{en?'Your clinic can use only the modules licensed to it.':'Танай эмнэлэг зөвхөн өөрт нь зөвшөөрсөн модулиудыг ашиглана.'}</p></div><span className="icon-cube"><ShieldCheck/></span></div>
    <div className="subscription-summary"><div><small>{en?'Plan':'Багц'}</small><b>{profile.clinic_plan||'—'}</b></div><div><small>{en?'Status':'Төлөв'}</small><b>{String(profile.clinic_status||'active').toUpperCase()}</b></div><div><small>{en?'Active modules':'Идэвхтэй модуль'}</small><b>{active.length}</b></div></div>
    <div className="licensed-module-chips">{active.map(m=><span key={m}><CheckCircle2 size={13}/>{(MODULE_LABELS as any)[m]?.[en?'en':'mn']||m}</span>)}</div>
    {locked.length>0&&<div className="module-request-box"><div><b><LockKeyhole size={16}/>{en?'Need another module?':'Нэмэлт модуль хэрэгтэй юу?'}</b><small>{hasPending?(en?'Your previous request is waiting for review.':'Таны өмнөх хүсэлт шийдвэр хүлээж байна.'):(en?'Open the module picker, select what you need, and send one request.':'Хэрэгтэй модулиудаа нэг дор сонгоод нэг хүсэлтээр илгээнэ.')}</small></div><button className="btn-primary" onClick={()=>setRequestOpen(true)} disabled={busy||hasPending}>{hasPending?<Clock3 size={16}/>:<Send size={16}/>} {hasPending?(en?'Pending review':'Шийдвэр хүлээж байна'):(en?'Choose modules':'Модуль сонгох')}</button></div>}
    {requestOpen&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&!busy&&setRequestOpen(false)}><div className="modal-card clinic-module-setup-modal"><header><div><small>{profile.clinic_plan||'DentHub'}</small><h2>{en?'Request additional modules':'Нэмэлт модуль хүсэх'}</h2></div><button onClick={()=>!busy&&setRequestOpen(false)}><X/></button></header><div className="clinic-module-setup-scroll"><ModuleAccessPicker value={selected} onChange={setSelected} lang={lang} availableModules={locked} showPlanPresets={false} title={en?'Modules to request':'Хүсэх модулиуд'} description={en?'Select all the modules you need and send them together.':'Хэрэгтэй бүх модулиа сонгоод нэг хүсэлтээр илгээнэ.'}/></div><footer><button className="btn-secondary" onClick={()=>setRequestOpen(false)} disabled={busy}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={send} disabled={busy||!selected.length}>{busy?<Clock3 className="spin"/>:<Send size={16}/>} {en?'Send request':'Хүсэлт илгээх'}</button></footer></div></div>}
  </section>;
}
