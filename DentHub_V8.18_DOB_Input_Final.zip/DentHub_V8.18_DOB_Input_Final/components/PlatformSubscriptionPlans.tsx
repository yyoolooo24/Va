'use client';

import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Copy, Edit3, Loader2, Plus, Power, Search, Trash2, X } from 'lucide-react';
import { getSupabaseBrowser } from '@/lib/supabase-browser';
import { BUILTIN_SUBSCRIPTION_PLANS, sanitizeClinicModules, type ClinicModule, type SubscriptionPlanDefinition } from '@/lib/subscription';
import type { AppLang } from './DashboardApp';
import DentSelect from './ui/DentSelect';
import ConfirmDialog from './ui/ConfirmDialog';
import ModuleAccessPicker from './ModuleAccessPicker';

type PlanRow=SubscriptionPlanDefinition & {created_at?:string;updated_at?:string};
type EditorMode='create'|'edit';

type FormState={
  code:string;nameMn:string;nameEn:string;descriptionMn:string;descriptionEn:string;employeeLimit:string;price:string;billingCycle:'monthly'|'yearly'|'custom';durationMonths:string;modules:string[];active:boolean;
};

const emptyForm:FormState={code:'',nameMn:'',nameEn:'',descriptionMn:'',descriptionEn:'',employeeLimit:'10',price:'',billingCycle:'monthly',durationMonths:'1',modules:[],active:true};

export default function PlatformSubscriptionPlans({lang}:{lang:AppLang}){
  const en=lang==='EN';
  const [plans,setPlans]=useState<PlanRow[]>([]);
  const [loading,setLoading]=useState(true);
  const [message,setMessage]=useState('');
  const [error,setError]=useState('');
  const [busy,setBusy]=useState('');
  const [query,setQuery]=useState('');
  const [editor,setEditor]=useState<{mode:EditorMode;originalCode?:string}|null>(null);
  const [form,setForm]=useState<FormState>(emptyForm);
  const [moduleSearch,setModuleSearch]=useState('');
  const [deletePlan,setDeletePlan]=useState<PlanRow|null>(null);

  async function token(){const s=getSupabaseBrowser();const {data}=s?await s.auth.getSession():({data:{session:null}} as any);return data.session?.access_token||''}
  async function load(){
    const s=getSupabaseBrowser();if(!s)return;
    setLoading(true);setError('');
    const {data,error}=await s.from('platform_subscription_plans').select('code,name_mn,name_en,description_mn,description_en,enabled_modules,employee_limit,price,billing_cycle,duration_months,active,sort_order,created_at,updated_at').order('sort_order').order('created_at');
    if(error){setPlans(BUILTIN_SUBSCRIPTION_PLANS as PlanRow[]);setError(en?'Run the V8.10 Supabase migration to make plan editing persistent.':'Багцын тохиргоог хадгалдаг болгохын тулд V8.10 Supabase migration-ийг ажиллуулна уу.');}
    else setPlans((data||[]).map((p:any)=>({...p,enabled_modules:sanitizeClinicModules(p.enabled_modules),price:Number(p.price||0),employee_limit:Number(p.employee_limit||1),duration_months:Number(p.duration_months||1),active:p.active!==false,sort_order:Number(p.sort_order||0)})) as PlanRow[]);
    setLoading(false);
  }
  useEffect(()=>{void load()},[]);

  function openCreate(seed?:PlanRow){
    const suffix=seed?`${seed.code}_COPY`:'';
    setForm(seed?{code:suffix,nameMn:`${seed.name_mn} хуулбар`,nameEn:`${seed.name_en} copy`,descriptionMn:seed.description_mn||'',descriptionEn:seed.description_en||'',employeeLimit:String(seed.employee_limit),price:String(seed.price||''),billingCycle:seed.billing_cycle,durationMonths:String(seed.duration_months||1),modules:[...seed.enabled_modules],active:true}:emptyForm);
    setEditor({mode:'create'});setMessage('');setError('');setModuleSearch('');
  }
  function openEdit(p:PlanRow){
    setForm({code:p.code,nameMn:p.name_mn,nameEn:p.name_en,descriptionMn:p.description_mn||'',descriptionEn:p.description_en||'',employeeLimit:String(p.employee_limit),price:String(p.price||''),billingCycle:p.billing_cycle,durationMonths:String(p.duration_months||1),modules:[...p.enabled_modules],active:p.active});
    setEditor({mode:'edit',originalCode:p.code});setMessage('');setError('');setModuleSearch('');
  }

  async function action(action:string,payload:Record<string,unknown>){
    setBusy(action);setError('');setMessage('');
    try{
      const t=await token();const res=await fetch('/api/admin/subscription-plans',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${t}`},body:JSON.stringify({action,...payload})});
      const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Action failed');
      setMessage(en?'Saved successfully.':'Өөрчлөлт хадгалагдлаа.');setEditor(null);setDeletePlan(null);await load();
    }catch(e:any){setError(e?.message||(en?'Could not save the plan.':'Багцын тохиргоог хадгалж чадсангүй.'))}finally{setBusy('')}
  }
  async function save(){
    if(!form.code.trim()||!form.nameMn.trim())return setError(en?'Plan code and Mongolian name are required.':'Багцын код болон Монгол нэрийг оруулна уу.');
    await action(editor?.mode==='edit'?'update':'create',{originalCode:editor?.originalCode,code:form.code,nameMn:form.nameMn,nameEn:form.nameEn||form.nameMn,descriptionMn:form.descriptionMn,descriptionEn:form.descriptionEn,employeeLimit:Number(form.employeeLimit||1),price:form.price,billingCycle:form.billingCycle,durationMonths:Number(form.durationMonths||1),enabledModules:form.modules,active:form.active});
  }

  const visible=useMemo(()=>plans.filter(p=>!query||`${p.code} ${p.name_mn} ${p.name_en}`.toLowerCase().includes(query.toLowerCase())),[plans,query]);

  return <div className="page-stack subscription-plans-page">
    <header className="page-head platform-plan-page-head"><div><small>{en?'DentHub Platform':'DentHub системийн удирдлага'}</small><h1>{en?'Subscription plans':'Багцын тохиргоо'}</h1><p>{en?'Create reusable plans, set default staff limits, pricing and module access.':'Эмнэлгүүдэд оноох багцын нэр, үнэ, хугацаа, ажилтны хязгаар болон модулийн эрхийг эндээс нэг удаа тохируулна.'}</p></div><button className="btn-primary" onClick={()=>openCreate()}><Plus size={17}/>{en?'New plan':'Шинэ багц'}</button></header>

    {(message||error)&&<div className={`platform-action-toast ${error?'error':'success'}`} role="status"><div>{error?<X size={17}/>:<CheckCircle2 size={17}/>}<span>{error||message}</span></div><button onClick={()=>{setMessage('');setError('')}} aria-label={en?'Close':'Хаах'}><X size={15}/></button></div>}

    <section className="panel-card plan-directory-card">
      <div className="plan-directory-toolbar"><div><h2>{en?'Available plans':'Боломжит багцууд'}</h2><p>{en?'Choose one when creating or approving a clinic.':'Шинэ эмнэлэг үүсгэх эсвэл зөвшөөрөх үед эдгээр багцаас шууд сонгоно.'}</p></div><label><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={en?'Search plans…':'Багц хайх…'}/></label></div>
      {loading?<div className="purchase-loading"><Loader2 className="spin"/> {en?'Loading…':'Ачаалж байна…'}</div>:<div className="plan-table">
        <div className="plan-table-head"><span>{en?'Plan':'Багц'}</span><span>{en?'Defaults':'Үндсэн тохиргоо'}</span><span>{en?'Modules':'Модуль'}</span><span>{en?'Actions':'Үйлдэл'}</span></div>
        {visible.map(p=><article key={p.code} className={!p.active?'inactive':''}>
          <div className="plan-name-cell"><strong>{en?p.name_en:p.name_mn}</strong><span>{p.code}</span><small>{en?p.description_en:p.description_mn}</small></div>
          <div className="plan-default-cell"><b>{p.employee_limit} {en?'staff':'ажилтан'}</b><small>{p.price?`${Number(p.price).toLocaleString()} ₮ / ${p.billing_cycle==='yearly'?(en?'year':'жил'):(en?'month':'сар')}`:(en?'Price not set':'Үнэ тохируулаагүй')}</small><small>{p.duration_months} {en?'month default duration':'сарын үндсэн хугацаа'}</small></div>
          <div className="plan-module-cell"><strong>{p.enabled_modules.length}</strong><span>{en?'modules':'модуль'}</span><small>{p.active?(en?'Available':'Идэвхтэй'):(en?'Hidden':'Идэвхгүй')}</small></div>
          <div className="plan-row-actions"><button onClick={()=>openEdit(p)}><Edit3 size={15}/>{en?'Edit':'Засах'}</button><button onClick={()=>openCreate(p)} title={en?'Duplicate':'Хуулбарлах'}><Copy size={15}/></button><button disabled={p.code==='START'} onClick={()=>p.code!=='START'&&action('toggle',{code:p.code,active:!p.active})} title={p.code==='START'?(en?'START is the registration default':'START нь шинэ бүртгэлийн үндсэн багц'):p.active?(en?'Deactivate':'Идэвхгүй болгох'):(en?'Activate':'Идэвхжүүлэх')}><Power size={15}/></button><button disabled={p.code==='START'} className="danger" onClick={()=>p.code!=='START'&&setDeletePlan(p)} title={p.code==='START'?(en?'START cannot be deleted':'START багцыг устгах боломжгүй'):(en?'Delete unused plan':'Ашиглагдаагүй багц устгах')}><Trash2 size={15}/></button></div>
        </article>)}
        {!visible.length&&<div className="plan-empty">{en?'No matching plans.':'Тохирох багц олдсонгүй.'}</div>}
      </div>}
    </section>

    {editor&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&!busy&&setEditor(null)}><div className="modal-card plan-editor-modal">
      <header><div><small>{editor.mode==='edit'?form.code:(en?'New reusable plan':'Шинэ багц')}</small><h2>{editor.mode==='edit'?(en?'Edit subscription plan':'Багц засах'):(en?'Create subscription plan':'Шинэ багц үүсгэх')}</h2></div><button onClick={()=>!busy&&setEditor(null)}><X/></button></header>
      <div className="plan-editor-scroll">
        <section className="plan-editor-basics">
          <label>{en?'Plan code':'Багцын код'}<input value={form.code} disabled={editor.mode==='edit'} onChange={e=>setForm(v=>({...v,code:e.target.value.toUpperCase().replace(/[^A-Z0-9_]/g,'').slice(0,24)}))} placeholder="PRO"/></label>
          <label>{en?'Mongolian name':'Монгол нэр'}<input value={form.nameMn} onChange={e=>setForm(v=>({...v,nameMn:e.target.value}))} placeholder="Мэргэжлийн"/></label>
          <label>{en?'English name':'Англи нэр'}<input value={form.nameEn} onChange={e=>setForm(v=>({...v,nameEn:e.target.value}))} placeholder="Professional"/></label>
          <label>{en?'Staff limit':'Ажилтны хязгаар'}<input inputMode="numeric" value={form.employeeLimit} onChange={e=>setForm(v=>({...v,employeeLimit:e.target.value.replace(/\D/g,'').slice(0,4)}))}/></label>
          <label>{en?'Default price':'Үндсэн үнэ'}<input inputMode="numeric" value={form.price} onChange={e=>setForm(v=>({...v,price:e.target.value.replace(/[^0-9.]/g,'')}))} placeholder="0"/></label>
          <label>{en?'Billing cycle':'Төлбөрийн мөчлөг'}<DentSelect value={form.billingCycle} onChange={billingCycle=>setForm(v=>({...v,billingCycle:billingCycle as FormState['billingCycle']}))} options={[{value:'monthly',label:en?'Monthly':'Сар бүр'},{value:'yearly',label:en?'Yearly':'Жил бүр'},{value:'custom',label:en?'Custom':'Тусгай нөхцөл'}]}/></label>
          <label>{en?'Default duration':'Үндсэн хугацаа (сар)'}<input inputMode="numeric" value={form.durationMonths} onChange={e=>setForm(v=>({...v,durationMonths:e.target.value.replace(/\D/g,'').slice(0,3)}))}/></label>
          <label className="wide">{en?'Description':'Тайлбар'}<textarea rows={2} value={en?form.descriptionEn:form.descriptionMn} onChange={e=>setForm(v=>en?({...v,descriptionEn:e.target.value}):({...v,descriptionMn:e.target.value}))}/></label>
        </section>
        <ModuleAccessPicker value={form.modules} onChange={modules=>setForm(v=>({...v,modules}))} lang={lang} search={moduleSearch} onSearchChange={setModuleSearch}/>
      </div>
      <footer><button className="btn-secondary" onClick={()=>setEditor(null)} disabled={!!busy}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={save} disabled={!!busy}>{busy?<Loader2 className="spin"/>:<CheckCircle2/>}{en?'Save plan':'Багц хадгалах'}</button></footer>
    </div></div>}

    <ConfirmDialog open={Boolean(deletePlan)} danger busy={busy==='delete'} title={en?'Delete this unused plan?':'Энэ ашиглагдаагүй багцыг устгах уу?'} description={en?'DentHub will refuse deletion while any clinic is assigned to this plan. You can deactivate it instead.':'Энэ багцыг ашиглаж байгаа эмнэлэг байвал DentHub устгахгүй. Тийм үед багцыг идэвхгүй болгоно.'} confirmLabel={en?'Delete plan':'Багц устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!busy&&setDeletePlan(null)} onConfirm={()=>deletePlan&&action('delete',{code:deletePlan.code})}/>
  </div>;
}
