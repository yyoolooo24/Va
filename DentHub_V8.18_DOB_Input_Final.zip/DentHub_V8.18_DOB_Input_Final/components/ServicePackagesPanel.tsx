'use client';

import { useEffect, useMemo, useState } from 'react';
import { Check, Layers3, Loader2, PackagePlus, Pencil, Plus, Search, Trash2, X } from 'lucide-react';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import type { AppLang, AppProfile } from './DashboardApp';
import NumericInput from './ui/NumericInput';
import ConfirmDialog from './ui/ConfirmDialog';

type Service={id:string;name:string;category?:string|null;subcategory?:string|null;price?:number|null;duration_minutes?:number|null};
type PackageRow={id:string;name:string;description?:string|null;price:number;duration_minutes:number;active:boolean;items?:Array<{service_id:string;quantity:number;services?:Service|null}>};
type Draft={name:string;description:string;price:string;duration:string;active:boolean;serviceIds:string[]};
const emptyDraft:Draft={name:'',description:'',price:'',duration:'60',active:true,serviceIds:[]};

export default function ServicePackagesPanel({profile,lang}:{profile:AppProfile;lang:AppLang}){
  const en=lang==='EN';
  const [packages,setPackages]=useState<PackageRow[]>([]);const [services,setServices]=useState<Service[]>([]);const [loading,setLoading]=useState(true);const [modal,setModal]=useState(false);const [editing,setEditing]=useState<PackageRow|null>(null);const [draft,setDraft]=useState<Draft>(emptyDraft);const [saving,setSaving]=useState(false);const [notice,setNotice]=useState('');const [search,setSearch]=useState('');const [deleteTarget,setDeleteTarget]=useState<PackageRow|null>(null);
  const canEdit=profile.role==='owner'||(profile.role==='employee'&&Boolean(profile.allowed_modules?.includes('services')));
  async function loadServices(){
    if(!isSupabaseConfigured()||!profile.clinic_id)return [] as Service[];
    const s=getSupabaseBrowser();if(!s)return [] as Service[];
    const {data,error}=await s.from('services').select('id,name,category,subcategory,price,duration_minutes').eq('clinic_id',profile.clinic_id).eq('active',true).or('is_category.is.null,is_category.eq.false').order('category').order('name');
    if(error){setNotice(error.message||'Үйлчилгээний жагсаалтыг уншиж чадсангүй.');return [] as Service[]}
    const next=(data||[]) as Service[];setServices(next);return next;
  }
  async function load(){
    if(!isSupabaseConfigured()||!profile.clinic_id){setLoading(false);return}
    const s=getSupabaseBrowser();if(!s)return;
    setLoading(true);
    const [p,sv]=await Promise.all([
      s.from('service_packages').select('id,name,description,price,duration_minutes,active,service_package_items(service_id,quantity,services(id,name,category,subcategory,price,duration_minutes))').eq('clinic_id',profile.clinic_id).order('created_at',{ascending:false}),
      s.from('services').select('id,name,category,subcategory,price,duration_minutes').eq('clinic_id',profile.clinic_id).eq('active',true).or('is_category.is.null,is_category.eq.false').order('category').order('name'),
    ]);
    if(p.error){setNotice(en?'Run the V8.6.1 Supabase migration to enable packages.':'Багц үйлчилгээ идэвхжүүлэхийн тулд V8.6.1 SQL migration ажиллуулна уу.');setPackages([])}else setPackages((p.data||[]).map((row:any)=>({...row,items:row.service_package_items||[]})) as PackageRow[]);
    setServices((sv.data||[]) as Service[]);setLoading(false);
  }
  useEffect(()=>{load()},[profile.clinic_id]);
  useEffect(()=>{const refresh=()=>{void loadServices()};window.addEventListener('denthub:services-changed',refresh);return()=>window.removeEventListener('denthub:services-changed',refresh)},[profile.clinic_id]);
  useEffect(()=>{if(!notice)return;const t=setTimeout(()=>setNotice(''),3500);return()=>clearTimeout(t)},[notice]);
  const filtered=useMemo(()=>{const q=search.trim().toLowerCase();return q?packages.filter(p=>`${p.name} ${p.description||''} ${(p.items||[]).map(i=>i.services?.name||'').join(' ')}`.toLowerCase().includes(q)):packages},[packages,search]);
  const grouped=useMemo(()=>{const map=new Map<string,Service[]>();services.forEach(s=>{const key=s.category||(en?'Other':'Бусад');const arr=map.get(key)||[];arr.push(s);map.set(key,arr)});return Array.from(map.entries())},[services,en]);
  async function openNew(){setEditing(null);setDraft(emptyDraft);setModal(true);await loadServices()}
  async function openEdit(p:PackageRow){setEditing(p);setDraft({name:p.name,description:p.description||'',price:String(p.price||''),duration:String(p.duration_minutes||60),active:p.active!==false,serviceIds:(p.items||[]).map(i=>i.service_id)});setModal(true);await loadServices()}
  function toggleService(id:string){setDraft(v=>({...v,serviceIds:v.serviceIds.includes(id)?v.serviceIds.filter(x=>x!==id):[...v.serviceIds,id]}))}
  async function save(){
    if(!profile.clinic_id)return;if(!draft.name.trim()){setNotice(en?'Enter a package name.':'Багцын нэр оруулна уу.');return}if(!draft.serviceIds.length){setNotice(en?'Choose at least one service.':'Дор хаяж 1 үйлчилгээ сонгоно уу.');return}
    const price=Number(draft.price||0);if(price<0){setNotice(en?'Price cannot be negative.':'Үнэ сөрөг байж болохгүй.');return}
    const s=getSupabaseBrowser();if(!s)return;setSaving(true);
    try{
      let id=editing?.id;
      if(id){const {error}=await s.from('service_packages').update({name:draft.name.trim(),description:draft.description.trim()||null,price:Math.round(price),duration_minutes:Math.max(1,Number(draft.duration||60)),active:draft.active}).eq('id',id).eq('clinic_id',profile.clinic_id);if(error)throw error;const {error:delErr}=await s.from('service_package_items').delete().eq('package_id',id);if(delErr)throw delErr}
      else {const {data,error}=await s.from('service_packages').insert({clinic_id:profile.clinic_id,name:draft.name.trim(),description:draft.description.trim()||null,price:Math.round(price),duration_minutes:Math.max(1,Number(draft.duration||60)),active:draft.active,created_by:profile.id||null}).select('id').single();if(error)throw error;id=data.id}
      const {error:itemError}=await s.from('service_package_items').insert(draft.serviceIds.map(service_id=>({package_id:id,service_id,quantity:1})));if(itemError)throw itemError;
      setModal(false);setNotice(en?'Package saved.':'Багц үйлчилгээ хадгалагдлаа.');await load();
    }catch(e:any){setNotice(e?.message||'Багц хадгалж чадсангүй.')}finally{setSaving(false)}
  }
  async function confirmRemove(){const p=deleteTarget;if(!canEdit||!p)return;const s=getSupabaseBrowser();if(!s)return;setSaving(true);const {error}=await s.from('service_packages').delete().eq('id',p.id).eq('clinic_id',profile.clinic_id);setSaving(false);setNotice(error?(error.message||'Устгаж чадсангүй.'):(en?'Package deleted.':'Багц устгагдлаа.'));if(!error){setDeleteTarget(null);load()}}
  return <section id="service-packages" className="service-packages-panel panel-card">
    <div className="service-packages-head"><div><span className="section-kicker"><Layers3 size={16}/>{en?'SERVICE PACKAGES':'БАГЦ ҮЙЛЧИЛГЭЭ'}</span><h2>{en?'Packages & bundles':'Багц үйлчилгээ'}</h2><p>{en?'Combine several treatments into one reusable package with its own price.':'Олон үйлчилгээг нэг багц болгон нэг үнэ, хугацаатайгаар дахин ашиглана.'}</p></div>{canEdit&&<button className="btn-primary" type="button" onClick={()=>void openNew()}><PackagePlus size={17}/>{en?'New package':'Багц нэмэх'}</button>}</div>
    {notice&&<div className="module-toast inline">{notice}</div>}
    <div className="package-search"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={en?'Search packages…':'Багц хайх…'}/></div>
    {loading?<div className="package-loading"><Loader2 className="spin"/>{en?'Loading packages…':'Багц үйлчилгээ ачаалж байна…'}</div>:filtered.length?<div className="package-grid">{filtered.map(p=>{const included=(p.items||[]).map(i=>i.services?.name).filter(Boolean) as string[];return <article className="package-card" key={p.id}><div className="package-card-top"><span className="package-icon"><Layers3/></span><div><h3>{p.name}</h3><small>{included.length} {en?'services':'үйлчилгээ'} · {Number(p.duration_minutes||0)} {en?'min':'мин'}</small></div><em className={p.active?'active':'inactive'}>{p.active?(en?'Active':'Идэвхтэй'):(en?'Inactive':'Идэвхгүй')}</em></div>{p.description&&<p>{p.description}</p>}<div className="package-service-chips">{included.slice(0,5).map(name=><span key={name}>{name}</span>)}{included.length>5&&<span>+{included.length-5}</span>}</div><footer><strong>₮{Number(p.price||0).toLocaleString()}</strong>{canEdit&&<div><button type="button" onClick={()=>void openEdit(p)} title={en?'Edit':'Засах'}><Pencil size={15}/></button><button className="danger" type="button" onClick={()=>setDeleteTarget(p)} title={en?'Delete':'Устгах'}><Trash2 size={15}/></button></div>}</footer></article>})}</div>:<div className="package-empty"><Layers3/><b>{en?'No service packages yet':'Багц үйлчилгээ хараахан алга'}</b><p>{en?'Create a reusable bundle from your existing services.':'Одоо байгаа үйлчилгээнүүдээс багц үүсгээрэй.'}</p>{canEdit&&<button className="btn-secondary" onClick={()=>void openNew()}><Plus size={16}/>{en?'Create first package':'Эхний багц үүсгэх'}</button>}</div>}
    <ConfirmDialog open={Boolean(deleteTarget)} busy={saving} title={en?'Delete this service package?':'Энэ багц үйлчилгээг устгах уу?'} description={deleteTarget?(en?`“${deleteTarget.name}” will be permanently removed.`:`“${deleteTarget.name}” багц системээс бүрэн устна. Энэ үйлдлийг буцаах боломжгүй.`):''} confirmLabel={en?'Delete package':'Багц устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!saving&&setDeleteTarget(null)} onConfirm={confirmRemove}/>
    {modal&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&!saving&&setModal(false)}><div className="modal-card package-modal"><header><div><small>{en?'Services & Pricing':'Үйлчилгээ & үнэ'}</small><h2>{editing?(en?'Edit package':'Багц засах'):(en?'New service package':'Шинэ багц үйлчилгээ')}</h2></div><button onClick={()=>!saving&&setModal(false)}><X size={20}/></button></header><div className="package-modal-body"><div className="package-basic-fields"><label>{en?'Package name':'Багцын нэр'}<input autoFocus value={draft.name} onChange={e=>setDraft(v=>({...v,name:e.target.value}))} placeholder={en?'Example: Full hygiene package':'Жишээ: Бүрэн цэвэрлэгээний багц'}/></label><label>{en?'Package price':'Багцын үнэ'}<NumericInput value={draft.price} onValueChange={price=>setDraft(v=>({...v,price}))} maxDigits={12} placeholder="0"/></label><label>{en?'Duration (minutes)':'Нийт хугацаа (минут)'}<NumericInput value={draft.duration} onValueChange={duration=>setDraft(v=>({...v,duration}))} maxDigits={4} placeholder="60"/></label><label className="package-description">{en?'Description':'Тайлбар'}<textarea rows={3} value={draft.description} onChange={e=>setDraft(v=>({...v,description:e.target.value}))} placeholder={en?'What is included / package notes':'Багцын тайлбар'}/></label><label className="package-active-toggle"><input type="checkbox" checked={draft.active} onChange={e=>setDraft(v=>({...v,active:e.target.checked}))}/><span><b>{en?'Active package':'Идэвхтэй багц'}</b><small>{en?'Can be used in clinic workflows':'Эмнэлгийн ажиллагаанд ашиглах боломжтой'}</small></span></label></div><div className="package-service-picker"><div className="package-picker-title"><div><b>{en?'Included services':'Багцад орох үйлчилгээ'}</b><small>{draft.serviceIds.length} {en?'selected':'сонгосон'}</small></div></div>{grouped.map(([category,items])=><section key={category}><h4>{category}</h4><div>{items.map(service=>{const checked=draft.serviceIds.includes(service.id);return <button type="button" key={service.id} className={checked?'selected':''} onClick={()=>toggleService(service.id)}><span className="package-check">{checked&&<Check size={14}/>}</span><span><b>{service.name}</b><small>{service.subcategory||''}{service.price!=null?` · ₮${Number(service.price).toLocaleString()}`:''}</small></span></button>})}</div></section>)}</div></div><footer><button className="btn-secondary" onClick={()=>setModal(false)} disabled={saving}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={save} disabled={saving}>{saving?<Loader2 className="spin" size={17}/>:<Check size={17}/>} {en?'Save package':'Багц хадгалах'}</button></footer></div></div>}
  </section>;
}
