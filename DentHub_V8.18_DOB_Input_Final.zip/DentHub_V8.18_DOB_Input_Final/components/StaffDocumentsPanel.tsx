'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { CalendarDays, Download, FileText, Loader2, Paperclip, Plus, Trash2, UploadCloud } from 'lucide-react';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import type { AppLang, AppProfile } from './DashboardApp';
import DentSelect from './ui/DentSelect';
import ConfirmDialog from './ui/ConfirmDialog';

type DocRow={id:string;document_type:string;title:string;storage_path:string;file_name:string;issued_at?:string|null;expires_at?:string|null;notes?:string|null;created_at:string;created_by?:string|null;signedUrl?:string|null};

const DOC_TYPES=[
  'Ажилд орсон тушаал',
  'Хөдөлмөрийн гэрээ',
  'Албан тушаалын тодорхойлолт',
  'Мэргэжлийн диплом',
  'Мэргэжлийн үйл ажиллагаа эрхлэх зөвшөөрөл',
  'Мэргэшлийн гэрчилгээ',
  'Эрүүл мэндийн үзлэгийн баримт',
  'Хөдөлмөрийн аюулгүй ажиллагааны сургалт',
  'Халдвар хамгааллын сургалт',
  'Тоног төхөөрөмжийн сургалт',
  'Ажлын байрны зааварчилгаа',
  'Нууцлалын гэрээ / үүрэг',
  'Ёс зүйн шаардлагатай баримт',
] as const;

function safeName(name:string){return name.normalize('NFKD').replace(/[^a-zA-Z0-9._-]+/g,'-').replace(/-+/g,'-').slice(0,120)||'document';}

export default function StaffDocumentsPanel({employeeId,employeeName,profile,lang}:{employeeId:string;employeeName:string;profile:AppProfile;lang:AppLang}){
  const en=lang==='EN';
  const [rows,setRows]=useState<DocRow[]>([]);const [loading,setLoading]=useState(true);const [saving,setSaving]=useState(false);const [error,setError]=useState('');const [notice,setNotice]=useState('');
  const [docType,setDocType]=useState<string>(DOC_TYPES[0]);const [issuedAt,setIssuedAt]=useState('');const [expiresAt,setExpiresAt]=useState('');const [notes,setNotes]=useState('');const [file,setFile]=useState<File|null>(null);const [deleteTarget,setDeleteTarget]=useState<DocRow|null>(null);const fileRef=useRef<HTMLInputElement|null>(null);
  const canManage=profile.role==='owner'||profile.id===employeeId;

  async function load(){
    if(!isSupabaseConfigured()||!profile.clinic_id){setLoading(false);return}
    const s=getSupabaseBrowser();if(!s)return;setLoading(true);setError('');
    try{
      const {data,error:e}=await s.from('employee_documents').select('id,document_type,title,storage_path,file_name,issued_at,expires_at,notes,created_at,created_by').eq('clinic_id',profile.clinic_id).eq('employee_id',employeeId).is('deleted_at',null).order('created_at',{ascending:false});if(e)throw e;
      const list=(data||[]) as DocRow[];
      const signed=await Promise.all(list.map(async row=>{const {data:link}=await s.storage.from('clinic-documents').createSignedUrl(row.storage_path,3600);return {...row,signedUrl:link?.signedUrl||null}}));
      setRows(signed);
    }catch(e:unknown){setError(e instanceof Error?e.message:'Ажилтны баримт ачаалж чадсангүй.')}finally{setLoading(false)}
  }
  useEffect(()=>{load()},[employeeId,profile.clinic_id]);
  useEffect(()=>{if(!notice)return;const t=window.setTimeout(()=>setNotice(''),2800);return()=>window.clearTimeout(t)},[notice]);

  async function upload(){
    if(!canManage||!file||!profile.clinic_id)return;const s=getSupabaseBrowser();if(!s)return;setSaving(true);setError('');
    try{
      const path=`${profile.clinic_id}/employees/${employeeId}/${Date.now()}-${safeName(file.name)}`;
      const {error:ue}=await s.storage.from('clinic-documents').upload(path,file,{upsert:false,contentType:file.type||undefined});if(ue)throw ue;
      const {error:ie}=await s.from('employee_documents').insert({clinic_id:profile.clinic_id,employee_id:employeeId,document_type:docType,title:docType,storage_path:path,file_name:file.name,issued_at:issuedAt||null,expires_at:expiresAt||null,notes:notes.trim()||null,created_by:profile.id||null});if(ie){await s.storage.from('clinic-documents').remove([path]);throw ie}
      setFile(null);setIssuedAt('');setExpiresAt('');setNotes('');if(fileRef.current)fileRef.current.value='';setNotice(en?'Document uploaded.':'Баримт амжилттай нэмэгдлээ.');await load();
    }catch(e:unknown){setError(e instanceof Error?e.message:'Баримт upload хийж чадсангүй.')}finally{setSaving(false)}
  }
  async function remove(){
    const row=deleteTarget;if(!row||profile.role!=='owner'||!profile.clinic_id)return;const s=getSupabaseBrowser();if(!s)return;setSaving(true);setError('');
    try{const {error:e}=await s.from('employee_documents').update({deleted_at:new Date().toISOString(),deleted_by:profile.id||null}).eq('id',row.id).eq('clinic_id',profile.clinic_id);if(e)throw e;setDeleteTarget(null);setNotice(en?'Document removed.':'Баримт устгагдлаа.');await load()}catch(e:unknown){setError(e instanceof Error?e.message:'Баримт устгаж чадсангүй.')}finally{setSaving(false)}
  }
  const missing=useMemo(()=>DOC_TYPES.filter(type=>!rows.some(r=>r.document_type===type)),[rows]);
  const now=new Date().toISOString().slice(0,10);

  return <section className="staff-documents-panel">
    <ConfirmDialog open={Boolean(deleteTarget)} busy={saving} title={en?'Delete this employee document?':'Энэ ажилтны баримтыг устгах уу?'} description={deleteTarget?.title||''} confirmLabel={en?'Delete':'Устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!saving&&setDeleteTarget(null)} onConfirm={remove}/>
    <div className="staff-docs-head"><div><b><Paperclip size={17}/>{en?' Employee documents':' Ажилтны баримт бичиг'}</b><small>{employeeName} · {rows.length}/{DOC_TYPES.length} {en?'document types uploaded':'төрлийн баримт бүрдсэн'}</small></div>{missing.length>0&&<span className="staff-docs-missing">{missing.length} {en?'missing':'дутуу'}</span>}</div>
    {error&&<div className="form-error">{error}</div>}{notice&&<div className="success-hint">{notice}</div>}
    {canManage&&<div className="staff-doc-upload-grid">
      <label><span>{en?'Document type':'Баримтын төрөл'}</span><DentSelect value={docType} onChange={setDocType} options={DOC_TYPES.map(x=>({value:x,label:x}))}/></label>
      <label><span>{en?'Issued / completed date':'Олгосон / хийсэн огноо'}</span><input type="date" value={issuedAt} onChange={e=>setIssuedAt(e.target.value)}/></label>
      <label><span>{en?'Expiry date':'Хүчинтэй хугацаа'}</span><input type="date" value={expiresAt} onChange={e=>setExpiresAt(e.target.value)}/></label>
      <label className="wide"><span>{en?'Note':'Тэмдэглэл'}</span><input value={notes} onChange={e=>setNotes(e.target.value)} placeholder={en?'Optional note':'Нэмэлт тайлбар'}/></label>
      <label className="staff-file-pick wide"><input ref={fileRef} type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" onChange={e=>setFile(e.target.files?.[0]||null)}/><UploadCloud size={18}/><span>{file?file.name:(en?'Choose document file':'Файл сонгох')}</span></label>
      <button type="button" className="btn-primary wide" onClick={upload} disabled={!file||saving}>{saving?<Loader2 className="spin" size={17}/>:<Plus size={17}/>} {en?'Upload document':'Баримт нэмэх'}</button>
    </div>}
    {loading?<div className="staff-doc-loading"><Loader2 className="spin"/> {en?'Loading…':'Ачаалж байна…'}</div>:rows.length?<div className="staff-doc-list">{rows.map(row=>{const expired=Boolean(row.expires_at&&row.expires_at<now);return <article key={row.id} className={expired?'expired':''}><span className="staff-doc-icon"><FileText/></span><div><b>{row.title}</b><small>{row.file_name}</small><em>{row.issued_at&&<><CalendarDays size={12}/>{row.issued_at}</>}{row.expires_at&&<> · {en?'expires':'дуусах'} {row.expires_at}</>}{expired&&<strong>{en?'Expired':'Хугацаа дууссан'}</strong>}</em>{row.notes&&<p>{row.notes}</p>}</div><div className="staff-doc-actions">{row.signedUrl&&<a href={row.signedUrl} target="_blank" rel="noreferrer" title={en?'Download':'Татах'}><Download size={16}/></a>}{profile.role==='owner'&&<button type="button" onClick={()=>setDeleteTarget(row)} title={en?'Delete':'Устгах'}><Trash2 size={16}/></button>}</div></article>})}</div>:<div className="staff-doc-empty"><FileText size={23}/><b>{en?'No documents uploaded yet':'Баримт бичиг хараахан оруулаагүй'}</b></div>}
  </section>
}
