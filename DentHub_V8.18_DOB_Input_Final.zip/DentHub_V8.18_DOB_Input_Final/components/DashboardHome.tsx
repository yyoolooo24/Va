'use client';

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { CalendarDays, CircleDollarSign, Clock3, CreditCard, FileText, UsersRound, ArrowRight, Plus, LayoutGrid } from 'lucide-react';
import type { AppLang, AppProfile, ViewKey } from './DashboardApp';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';

type HomeStats={
  appointments:number; patients:number; pending:number; revenue:number;
  nextAppointment?:{starts_at:string;service_name?:string|null;room?:string|null;doctor?:string|null};
  visits:number; clinics:number; users:number; employees:number; clients:number;
  recentClinics:Array<{id:string;name:string;plan:string;status:string}>;
};
const zero:HomeStats={appointments:0,patients:0,pending:0,revenue:0,visits:0,clinics:0,users:0,employees:0,clients:0,recentClinics:[]};
function isDoctorProfile(profile:AppProfile){return profile.role==='employee'&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(String(profile.specialty||''))}

export default function DashboardHome({ profile, clinicName, onNavigate, lang }: { profile: AppProfile; clinicName:string; onNavigate: (view: ViewKey, id?: string) => void; lang:AppLang }) {
  const en=lang==='EN';
  const production=useMemo(()=>isSupabaseConfigured()&&process.env.NEXT_PUBLIC_DEMO_MODE!=='true',[]);
  const [stats,setStats]=useState<HomeStats>(zero);
  const [loading,setLoading]=useState(production);

  useEffect(()=>{
    if(!production||!profile.id){setLoading(false);return}
    let active=true;
    (async()=>{
      const s=getSupabaseBrowser(); if(!s)return;
      if(profile.role==='platform_admin'){
        const [{count:clinics},{count:users},{count:employees},{count:clients},{data:recent}]=await Promise.all([
          s.from('clinics').select('id',{count:'exact',head:true}).eq('status','active'),
          s.from('profiles').select('id',{count:'exact',head:true}).eq('active',true),
          s.from('profiles').select('id',{count:'exact',head:true}).eq('active',true).eq('role','employee'),
          s.from('profiles').select('id',{count:'exact',head:true}).eq('active',true).eq('role','client'),
          s.from('clinics').select('id,name,plan,status').order('created_at',{ascending:false}).limit(4),
        ]);
        if(active)setStats(v=>({...v,clinics:clinics||0,users:users||0,employees:employees||0,clients:clients||0,recentClinics:(recent||[]) as any[]}));
        return;
      }
      if(profile.role==='client'){
        const {data:patient}=await s.from('patients').select('id').eq('user_id',profile.id).is('deleted_at',null).maybeSingle();
        if(!patient){if(active)setStats(zero);return}
        const now=new Date().toISOString();
        const [{count:visits},{count:appointments},{data:next}]=await Promise.all([
          s.from('encounters').select('id',{count:'exact',head:true}).eq('patient_id',patient.id).is('deleted_at',null),
          s.from('appointments').select('id',{count:'exact',head:true}).eq('patient_id',patient.id),
          s.from('appointments').select('starts_at,service_name,room,doctor:profiles!appointments_doctor_id_fkey(full_name)').eq('patient_id',patient.id).gte('starts_at',now).neq('status','cancelled').order('starts_at',{ascending:true}).limit(1).maybeSingle(),
        ]);
        const n:any=next;
        if(active)setStats(v=>({...v,visits:visits||0,appointments:appointments||0,nextAppointment:n?{starts_at:n.starts_at,service_name:n.service_name,room:n.room,doctor:n.doctor?.full_name}:undefined}));
        return;
      }
      if(!profile.clinic_id)return;
      const start=new Date(); start.setHours(0,0,0,0); const end=new Date(start); end.setDate(end.getDate()+1);
      const doctorMode=isDoctorProfile(profile);
      const appBase=()=>s.from('appointments').select('id',{count:'exact',head:true}).eq('clinic_id',profile.clinic_id!).gte('starts_at',start.toISOString()).lt('starts_at',end.toISOString());
      const apptQuery=doctorMode?appBase().eq('doctor_id',profile.id):appBase();
      const pendingQuery=doctorMode?appBase().eq('doctor_id',profile.id).in('status',['scheduled','checked_in','in_progress']):appBase().in('status',['scheduled','checked_in','in_progress']);
      const promises:any[]=[apptQuery,pendingQuery];
      if(profile.role==='owner') promises.push(s.from('finance_transactions').select('amount').eq('clinic_id',profile.clinic_id).eq('kind','income').gte('created_at',start.toISOString()).lt('created_at',end.toISOString()));
      const results=await Promise.all(promises);
      let patientCount=0;
      if(doctorMode){
        const [a,e]=await Promise.all([
          s.from('appointments').select('patient_id').eq('clinic_id',profile.clinic_id).eq('doctor_id',profile.id),
          s.from('encounters').select('patient_id').eq('clinic_id',profile.clinic_id).eq('doctor_id',profile.id).is('deleted_at',null),
        ]);
        patientCount=new Set([...(a.data||[]),...(e.data||[])].map((x:any)=>String(x.patient_id||'')).filter(Boolean)).size;
      }else{
        const {count}=await s.from('patients').select('id',{count:'exact',head:true}).eq('clinic_id',profile.clinic_id).is('deleted_at',null);patientCount=count||0;
      }
      const revenue=profile.role==='owner'?(results[2]?.data||[]).reduce((sum:number,r:any)=>sum+Number(r.amount||0),0):0;
      if(active)setStats(v=>({...v,appointments:results[0]?.count||0,pending:results[1]?.count||0,patients:patientCount,revenue}));
    })().finally(()=>active&&setLoading(false));
    return()=>{active=false};
  },[production,profile.id,profile.role,profile.clinic_id,profile.specialty]);

  if (profile.role === 'platform_admin') {
    return <div className="page-stack">
      <header className="page-head"><div><small>DentHub</small><h1>{en?'Platform overview':'Системийн тойм'}</h1><p>{en?'Live clinics and user counts from your system.':'Эмнэлэг болон хэрэглэгчдийн бодит төлөвийг нэг дор харна.'}</p></div><button className="btn-primary" onClick={() => onNavigate('admin')}><Plus size={18}/> {en?'Add clinic':'Эмнэлэг нэмэх'}</button></header>
      <section className="metric-grid"><Metric icon={<UsersRound />} value={loading?'—':String(stats.clinics)} label={en?'Active clinics':'Идэвхтэй эмнэлэг'} delta={en?'live':'бодит'}/><Metric icon={<FileText />} value={loading?'—':String(stats.users)} label={en?'Active users':'Идэвхтэй хэрэглэгч'} delta={en?'live':'бодит'}/><Metric icon={<UsersRound />} value={loading?'—':String(stats.employees)} label={en?'Employees':'Ажилтан'} delta={en?'active':'идэвхтэй'}/><Metric icon={<UsersRound />} value={loading?'—':String(stats.clients)} label={en?'Clients':'Үйлчлүүлэгч'} delta={en?'active':'идэвхтэй'}/></section>
      <article className="panel-card"><div className="panel-head"><div><h2>{en?'Recent clinics':'Сүүлийн эмнэлгүүд'}</h2><p>{en?'Newest clinics in the platform':'Сүүлд бүртгэгдсэн эмнэлгүүд'}</p></div></div>{stats.recentClinics.length?<div className="simple-list">{stats.recentClinics.map(c=><Row key={c.id} title={c.name} meta={c.plan} tag={c.status.toUpperCase()}/>)}</div>:<Empty text={en?'No clinics yet. Add your first clinic.':'Эмнэлэг хараахан бүртгэгдээгүй байна.'}/>}</article>
    </div>;
  }

  if (profile.role === 'supplier') {
    return <div className="page-stack">
      <header className="page-head"><div><small>DentHub · {clinicName}</small><h1>{en?'Supplier workspace':'Ханган нийлүүлэгчийн хэсэг'}</h1><p>{en?'Manage what you supply, your warehouse and the clinics you work with.':'Нийлүүлэх бараа, агуулах болон хамтран ажилладаг эмнэлгүүдээ нэг дор удирдана.'}</p></div><button className="btn-primary" onClick={() => onNavigate('supplier_warehouse')}><Plus size={18}/>{en?'Supply':'Ханган нийлүүлэх'}</button></header>
      <section className="quick-grid"><button onClick={()=>onNavigate('supplier_warehouse')}><span className="icon-cube"><LayoutGrid/></span><div><b>{en?'Warehouse & supply':'Агуулах & ханган нийлүүлэх'}</b><small>{en?'Stock, SKU and reorder levels':'Бараа, SKU, үлдэгдэл, доод нөөц'}</small></div><ArrowRight size={18}/></button><button onClick={()=>onNavigate('partner_clinics')}><span className="icon-cube"><UsersRound/></span><div><b>{en?'Partner clinics':'Хамтрагч эмнэлгүүд'}</b><small>{en?'Clinics you work with':'Хамтран ажилладаг эмнэлгүүд'}</small></div><ArrowRight size={18}/></button></section>
      <article className="panel-card"><div className="panel-head"><div><h2>{en?'Supplier account':'Нийлүүлэгчийн бүртгэл'}</h2><p>{en?'This workspace is separate from clinic and patient data.':'Энэ хэсэг нь эмнэлэг болон өвчтөний хувийн мэдээллээс тусдаа.'}</p></div><button onClick={()=>onNavigate('chat')}>{en?'Chat':'Чат'} <ArrowRight size={15}/></button></div><Empty text={en?'Add real stock or partner clinics to start working.':'Бодит бараа эсвэл хамтрагч эмнэлгээ нэмээд ажлаа эхлүүлнэ үү.'}/></article>
    </div>;
  }

  if (profile.role === 'client') {
    const next=stats.nextAppointment;
    const nextDate=next?new Date(next.starts_at):null;
    return <div className="page-stack">
      <header className="page-head"><div><small>{clinicName}</small><h1>{en?'Welcome':'Сайн байна уу'}</h1><p>{en?'Your real appointment and visit information.':'Таны бодит цаг товлол болон үзлэгийн мэдээлэл.'}</p></div><button className="btn-primary" onClick={() => onNavigate('appointments')}><Plus size={18}/> {en?'Book appointment':'Цаг авах'}</button></header>
      <section className="metric-grid client-metrics"><Metric icon={<CalendarDays />} value={nextDate?nextDate.toLocaleDateString(en?'en-US':'mn-MN',{month:'2-digit',day:'2-digit'}):'—'} label={en?'Next appointment':'Дараагийн цаг'} delta={nextDate?nextDate.toLocaleTimeString(en?'en-US':'mn-MN',{hour:'2-digit',minute:'2-digit'}):(en?'None':'Алга')}/><Metric icon={<FileText />} value={loading?'—':String(stats.visits)} label={en?'Visit history':'Үзлэгийн түүх'} delta={en?'total':'нийт'}/><Metric icon={<CalendarDays />} value={loading?'—':String(stats.appointments)} label={en?'Appointments':'Цаг товлол'} delta={en?'total':'нийт'}/></section>
      <article className="panel-card"><div className="panel-head"><div><h2>{en?'Next appointment':'Дараагийн цаг'}</h2><p>{nextDate?nextDate.toLocaleString(en?'en-US':'mn-MN'):(en?'No upcoming appointment':'Удахгүй болох цаг алга')}</p></div></div>{next?<div className="appointment-feature"><span className="icon-cube"><CalendarDays /></span><div><b>{next.doctor||next.service_name||(en?'Appointment':'Цаг товлол')}</b><p>{[next.service_name,next.room].filter(Boolean).join(' · ')}</p></div><button className="btn-secondary" onClick={()=>onNavigate('appointments')}>{en?'Details':'Дэлгэрэнгүй'}</button></div>:<Empty text={en?'No upcoming appointment.':'Удахгүй болох цаг алга.'}/>}</article>
    </div>;
  }

  const isEmployee = profile.role === 'employee';
  return <div className="page-stack">
    <header className="page-head dashboard-heading"><div><small>{clinicName}</small><h1>{isEmployee ? (en?'My workspace':'Миний ажлын самбар') : (en?'Daily overview':'Өдрийн тойм')}</h1><p>{isEmployee ? (en?"Today's appointments and work.":'Өнөөдрийн цаг болон хийх ажлууд.') : (en?"Today's live clinic overview.":'Эмнэлгийн өнөөдрийн бодит төлөв.')}</p></div><div className="head-actions"><button className="btn-secondary" onClick={() => onNavigate('patients')}><Plus size={18}/> {en?'Patient':'Өвчтөн'}</button><button className="btn-primary" onClick={() => onNavigate('appointments')}><Plus size={18}/> {en?'Book appointment':'Цаг товлох'}</button></div></header>

    <section className="today-strip"><div><span>{en?"TODAY'S WORK":'ӨНӨӨДРИЙН АЖИЛ'}</span><strong>{loading?'—':stats.appointments} {en?'appointments':'цаг'}</strong><p>{loading?(en?'Loading…':'Ачаалж байна…'):`${stats.pending} ${en?'pending':'хүлээгдэж байна'}`}</p></div><button className="btn-light" onClick={() => onNavigate('appointments')}>{en?'View schedule':'Цаг харах'} <ArrowRight size={17}/></button></section>

    <section className="quick-start"><div className="section-title"><h2>{en?'Quick start':'Хурдан эхлэх'}</h2><p>{en?'Most-used daily actions':'Өдөр бүр хамгийн их ашиглагддаг үйлдлүүд'}</p></div><div className="quick-grid">
      <button onClick={() => onNavigate('patients')}><span className="icon-cube"><UsersRound /></span><div><b>{en?'Register patient':'Өвчтөн бүртгэх'}</b><small>{en?'Add a new patient':'Шинэ өвчтөний мэдээлэл нэмэх'}</small></div><ArrowRight size={18}/></button>
      <button onClick={() => onNavigate('appointments')}><span className="icon-cube"><CalendarDays /></span><div><b>{en?'Book appointment':'Цаг товлох'}</b><small>{en?'Choose doctor, service and time':'Эмч, үйлчилгээ, цаг сонгох'}</small></div><ArrowRight size={18}/></button>
      <button onClick={() => onNavigate('payments')}><span className="icon-cube"><CreditCard /></span><div><b>{en?'Take payment':'Төлбөр авах'}</b><small>POS, QPay, eBarimt</small></div><ArrowRight size={18}/></button>
      {!isEmployee&&<button onClick={() => onNavigate('erp')}><span className="icon-cube"><LayoutGrid /></span><div><b>{en?'ERP modules':'ERP модулиуд'}</b><small>{en?'Supply, finance, staff, lab and more':'Хангамж, санхүү, ажилтан, лаборатори болон бусад'}</small></div><ArrowRight size={18}/></button>}
    </div></section>

    <section className="metric-grid"><Metric icon={<CalendarDays />} value={loading?'—':String(stats.appointments)} label={en?"Today's appointments":'Өнөөдрийн цаг'} delta={en?'today':'өнөөдөр'}/>{!isEmployee&&<Metric icon={<CircleDollarSign />} value={loading?'—':`₮${stats.revenue.toLocaleString()}`} label={en?"Today's revenue":'Өнөөдрийн орлого'} delta={en?'today':'өнөөдөр'}/>}<Metric icon={<UsersRound />} value={loading?'—':String(stats.patients)} label={en?'Patients':'Өвчтөн'} delta={en?'registered':'бүртгэлтэй'}/><Metric icon={<Clock3 />} value={loading?'—':String(stats.pending)} label={en?'Pending':'Хүлээгдэж буй'} delta={en?'today':'өнөөдөр'}/></section>

    <article className="panel-card"><div className="panel-head"><div><h2>{en?'Start working':'Ажлаа эхлэх'}</h2><p>{en?'New data will appear here as your clinic uses the system.':'Эмнэлэг системээ ашиглах тусам бодит мэдээлэл энд нэмэгдэнэ.'}</p></div><button onClick={()=>onNavigate('appointments')}>{en?'Appointments':'Цаг товлол'} <ArrowRight size={15}/></button></div><Empty text={en?'No fake demo charts are shown in production. Your real activity will build this dashboard.':'Бодит орчинд хиймэл үзүүлэлт харуулахгүй. Үйл ажиллагаа эхлэхэд самбар автоматаар бодит мэдээллээр дүүрнэ.'}/></article>
  </div>;
}

function Empty({text}:{text:string}){return <div className="home-empty"><FileText size={22}/><span>{text}</span></div>}
function Metric({icon,value,label,delta,danger}:{icon:ReactNode;value:string;label:string;delta:string;danger?:boolean}){return <article className="metric-card"><div className="metric-top"><span className="icon-cube">{icon}</span><span className={`delta ${danger?'danger':''}`}>{delta}</span></div><strong>{value}</strong><p>{label}</p></article>}
function Row({title,meta,tag}:{title:string;meta:string;tag:string}){return <div className="list-row"><div><b>{title}</b><small>{meta}</small></div><span>{tag}</span></div>}
