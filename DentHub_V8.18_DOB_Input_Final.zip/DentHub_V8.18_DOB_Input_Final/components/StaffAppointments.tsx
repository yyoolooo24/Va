'use client';

import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode, type PointerEvent as ReactPointerEvent } from 'react';
import {
  ArrowLeftRight, Building2, CalendarDays, Check, ChevronDown, ChevronLeft, ChevronRight, Clock3,
  Filter, Gauge, History, Loader2, Plus, Search, Stethoscope, UserRound, UsersRound, X, Settings2, Trash2
} from 'lucide-react';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import { useAppointmentRealtime } from '@/lib/use-appointment-realtime';
import type { AppLang, AppProfile } from './DashboardApp';
import DentSelect from './ui/DentSelect';
import NumericInput from './ui/NumericInput';
import ConfirmDialog from './ui/ConfirmDialog';
import DentDatePicker from './ui/DentDatePicker';

type Patient={id:string;patient_code?:string|null;external_patient_id?:string|null;full_name:string;phone?:string|null;register_no?:string|null;date_of_birth?:string|null;gender?:string|null};
type Doctor={id:string;full_name:string;phone?:string|null;role?:string|null;specialty?:string|null};
type Service={id:string;name:string;category?:string|null;subcategory?:string|null;duration_minutes?:number|null;is_category?:boolean|null};
type Availability={doctor_id:string;weekday:number;start_time:string;end_time:string;slot_minutes:number;max_parallel?:number|null;active:boolean};
type BusinessHour={id?:string;weekday:number;start_time:string;end_time:string;active:boolean};
type Holiday={id:string;holiday_date:string;name?:string|null};
type Appointment={
  id:string;clinic_id:string;patient_id:string;doctor_id?:string|null;service_id?:string|null;service_name?:string|null;
  starts_at:string;ends_at?:string|null;status:string;notes?:string|null;created_at:string;created_by?:string|null;patient_age?:number|null;patient_gender?:string|null;service_request?:string|null;clinical_summary?:string|null;
  patients?:{full_name:string;phone?:string|null;patient_code?:string|null;external_patient_id?:string|null}|null;doctor?:{full_name:string}|null;creator?:{full_name:string}|null;
};

type CalendarMode='day'|'week'|'month';
const STATUS=['pending','confirmed','scheduled','waiting','checked_in','in_progress','completed','done','cancelled','no_show'] as const;
const ACTIVE_STATUSES=new Set(['pending','confirmed','scheduled','waiting','checked_in','in_progress']);
const activeStatus=(s:string)=>!['cancelled','no_show'].includes(s);
const TIME_OPTIONS=Array.from({length:288},(_,i)=>{const h=Math.floor(i*5/60),m=(i*5)%60;const value=`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;return {value,label:value}});
const statusLabel=(s:string,en:boolean)=>{
  const mn:Record<string,string>={pending:'Хүлээгдэж байна',confirmed:'Баталгаажсан',scheduled:'Баталгаажсан',waiting:'Хүлээж байна',checked_in:'Ирсэн',in_progress:'Үзэж байна',completed:'Дууссан',done:'Дууссан',cancelled:'Цуцлагдсан',no_show:'Ирээгүй'};
  const e:Record<string,string>={pending:'Pending',confirmed:'Confirmed',scheduled:'Confirmed',waiting:'Waiting',checked_in:'Checked in',in_progress:'In progress',completed:'Completed',done:'Completed',cancelled:'Cancelled',no_show:'No show'};
  return (en?e:mn)[s]||s;
};
const pad=(n:number)=>String(n).padStart(2,'0');
const dateKey=(d:Date)=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const localDate=(iso:string)=>dateKey(new Date(iso));
const localTime=(iso:string)=>{const d=new Date(iso);return `${pad(d.getHours())}:${pad(d.getMinutes())}`};
const addDays=(d:Date,n:number)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x};
const startOfWeek=(d:Date)=>{const x=new Date(d);const day=(x.getDay()+6)%7;x.setDate(x.getDate()-day);x.setHours(0,0,0,0);return x};
const timeText=(iso:string,en:boolean)=>new Date(iso).toLocaleTimeString(en?'en-US':'mn-MN',{hour:'2-digit',minute:'2-digit'});
const durationMinutes=(a:Appointment)=>Math.max(15,Math.round(((a.ends_at?+new Date(a.ends_at):+new Date(a.starts_at)+30*60000)-+new Date(a.starts_at))/60000));

const MN_MONTHS=['1-р сар','2-р сар','3-р сар','4-р сар','5-р сар','6-р сар','7-р сар','8-р сар','9-р сар','10-р сар','11-р сар','12-р сар'];
const MN_WEEKDAYS=['Ням','Даваа','Мягмар','Лхагва','Пүрэв','Баасан','Бямба'];
const calendarTitle=(anchor:Date,mode:CalendarMode,en:boolean,weekDays:Date[])=>{
  if(en){
    if(mode==='month')return anchor.toLocaleDateString('en-US',{month:'long',year:'numeric'});
    if(mode==='week')return `${weekDays[0].toLocaleDateString('en-US',{month:'short',day:'numeric'})} — ${weekDays[6].toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}`;
    return anchor.toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
  }
  if(mode==='month')return `${anchor.getFullYear()} оны ${MN_MONTHS[anchor.getMonth()]}`;
  if(mode==='week')return `${weekDays[0].getMonth()+1}-р сарын ${weekDays[0].getDate()} — ${weekDays[6].getMonth()+1}-р сарын ${weekDays[6].getDate()}`;
  return `${anchor.getFullYear()} оны ${anchor.getMonth()+1}-р сарын ${anchor.getDate()} · ${MN_WEEKDAYS[anchor.getDay()]}`;
};
const shortCalendarDate=(date:Date,en:boolean)=>en?date.toLocaleDateString('en-US',{month:'short',day:'numeric'}):`${date.getMonth()+1}/${date.getDate()}`;

async function authFetch(url:string,init?:RequestInit){
  const s=getSupabaseBrowser(); if(!s)throw new Error('Supabase холболт алга.');
  const {data}=await s.auth.getSession(); const token=data.session?.access_token;
  if(!token)throw new Error('Нэвтрэх эрх дууссан байна.');
  const res=await fetch(url,{...init,headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`,...(init?.headers||{})}});
  const body=await res.json().catch(()=>({})); if(!res.ok)throw new Error(body.error||'Алдаа гарлаа.'); return body;
}

export default function StaffAppointments({profile,clinicName,lang,onNavigate}:{profile:AppProfile;clinicName:string;lang:AppLang;onNavigate?:(view:'treatments')=>void}){
  const en=lang==='EN'; const clinicId=profile.clinic_id||'';
  const isDoctor=profile.role==='employee'&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(profile.specialty||'');
  const [patients,setPatients]=useState<Patient[]>([]); const [doctors,setDoctors]=useState<Doctor[]>([]); const [services,setServices]=useState<Service[]>([]);
  const [availability,setAvailability]=useState<Availability[]>([]); const [businessHours,setBusinessHours]=useState<BusinessHour[]>([]); const [holidays,setHolidays]=useState<Holiday[]>([]); const [appointments,setAppointments]=useState<Appointment[]>([]);
  const [deleteHolidayTarget,setDeleteHolidayTarget]=useState<Holiday|null>(null);
  const [deleteAppointmentTarget,setDeleteAppointmentTarget]=useState<Appointment|null>(null);
  const [loading,setLoading]=useState(true); const [modal,setModal]=useState(false); const [saving,setSaving]=useState(false); const [error,setError]=useState(''); const [notices,setNotices]=useState<{id:number;text:string}[]>([]);
  const pushNotice=useCallback((text:string)=>{const id=Date.now()+Math.floor(Math.random()*1000);setNotices(list=>[{id,text},...list].slice(0,4));window.setTimeout(()=>setNotices(list=>list.filter(item=>item.id!==id)),3200)},[]);
  const [picker,setPicker]=useState<'patient'|'doctor'|'service'|null>(null); const [pickerSearch,setPickerSearch]=useState('');
  const [serviceSearch,setServiceSearch]=useState(''); const [serviceMode,setServiceMode]=useState<'catalog'|'custom'>('catalog');
  const [form,setForm]=useState({patientMode:'existing' as 'existing'|'new',patientId:'',newPatientName:'',newPatientPhone:'',newPatientExternalId:'',doctorId:'',serviceId:'',serviceText:'',age:'',gender:'',date:dateKey(new Date()),time:'09:00',notes:''});
  const [mode,setMode]=useState<CalendarMode>('day'); const [anchor,setAnchor]=useState(()=>new Date()); const [selected,setSelected]=useState<Appointment|null>(null);
  const [historyOpen,setHistoryOpen]=useState(true); const [calendarDoctor,setCalendarDoctor]=useState('');
  const [filters,setFilters]=useState({year:'',month:'',date:'',status:'',doctor:'',service:'',q:''});
  const [rescheduleOpen,setRescheduleOpen]=useState(false);
  const [moveForm,setMoveForm]=useState({doctorId:'',date:'',time:''});
  const [detailServiceId,setDetailServiceId]=useState('');
  const [detailClinicalSummary,setDetailClinicalSummary]=useState('');
  const [detailNotes,setDetailNotes]=useState('');
  const [scheduleSettingsOpen,setScheduleSettingsOpen]=useState(false);
  const [scheduleDraft,setScheduleDraft]=useState<BusinessHour[]>([]);
  const [holidayDate,setHolidayDate]=useState('');
  const [holidayName,setHolidayName]=useState('');

  const loadAppointments=useCallback(async()=>{
    if(!clinicId||!isSupabaseConfigured())return;
    const s=getSupabaseBrowser(); if(!s)return;
    let q=s.from('appointments')
      .select('id,clinic_id,patient_id,doctor_id,service_id,service_name,service_request,clinical_summary,patient_age,patient_gender,starts_at,ends_at,status,notes,created_at,created_by,patients(full_name,phone,patient_code,external_patient_id),doctor:profiles!appointments_doctor_id_fkey(full_name),creator:profiles!appointments_created_by_fkey(full_name)')
      .eq('clinic_id',clinicId);
    if(isDoctor&&profile.id)q=q.eq('doctor_id',profile.id);
    const {data,error}=await q.order('starts_at',{ascending:true}).limit(1000);
    if(error)throw error; setAppointments((data||[]) as unknown as Appointment[]);
  },[clinicId,isDoctor,profile.id]);

  const loadBase=useCallback(async()=>{
    if(!clinicId||!isSupabaseConfigured()){setLoading(false);return}
    setLoading(true);setError('');
    try{
      const s=getSupabaseBrowser(); if(!s)return;
      let patientQuery=s.from('patients').select('id,patient_code,external_patient_id,full_name,phone,register_no,date_of_birth,gender').eq('clinic_id',clinicId).is('deleted_at',null);
      if(isDoctor&&profile.id){
        const [a,e]=await Promise.all([
          s.from('appointments').select('patient_id').eq('clinic_id',clinicId).eq('doctor_id',profile.id),
          s.from('encounters').select('patient_id').eq('clinic_id',clinicId).eq('doctor_id',profile.id),
        ]);
        const patientIds=Array.from(new Set([...(a.data||[]),...(e.data||[])].map((x:any)=>String(x.patient_id||'')).filter(Boolean)));
        if(patientIds.length)patientQuery=patientQuery.in('id',patientIds);
        else patientQuery=patientQuery.eq('id','00000000-0000-0000-0000-000000000000');
      }
      const [p,d,sv,av,bh,hol]=await Promise.all([
        patientQuery.order('full_name'),
        s.from('profiles').select('id,full_name,phone,role,specialty').eq('clinic_id',clinicId).in('role',['owner','employee']).eq('active',true).order('full_name'),
        s.from('services').select('id,name,category,subcategory,duration_minutes,is_category').eq('clinic_id',clinicId).eq('active',true).order('category').order('subcategory').order('name'),
        s.from('doctor_availability').select('doctor_id,weekday,start_time,end_time,slot_minutes,max_parallel,active').eq('clinic_id',clinicId),
        s.from('clinic_business_hours').select('id,weekday,start_time,end_time,active').eq('clinic_id',clinicId).order('weekday'),
        s.from('clinic_holidays').select('id,holiday_date,name').eq('clinic_id',clinicId).gte('holiday_date',dateKey(new Date())).order('holiday_date'),
      ]);
      if(p.error)throw p.error;if(d.error)throw d.error;if(sv.error)throw sv.error;
      setPatients((p.data||[]) as Patient[]);const staffCandidates=(d.data||[]) as Doctor[];const clinicians=staffCandidates.filter(x=>/(эмч|doctor|dentist|orthodont|surgeon)/i.test(x.specialty||''));setDoctors(isDoctor&&profile.id?clinicians.filter(x=>x.id===profile.id):(clinicians.length?clinicians:staffCandidates));setServices((sv.data||[]) as Service[]);setAvailability((av.data||[]) as Availability[]);setBusinessHours((bh.data||[]) as BusinessHour[]);setHolidays((hol.data||[]) as Holiday[]);
      await loadAppointments();
    }catch(e:unknown){setError(e instanceof Error?e.message:'Цаг товлол ачаалж чадсангүй.')}finally{setLoading(false)}
  },[clinicId,loadAppointments,isDoctor,profile.id]);
  useEffect(()=>{loadBase()},[loadBase]);
  useAppointmentRealtime(clinicId,loadAppointments);

  useEffect(()=>{
    try{
      const raw=sessionStorage.getItem('clinicos-book-patient');
      if(raw){const p=JSON.parse(raw);if(p?.id){setForm(v=>({...v,patientMode:'existing',patientId:p.id}));setModal(true)}sessionStorage.removeItem('clinicos-book-patient')}
    }catch{}
  },[]);

  const patient=patients.find(x=>x.id===form.patientId); const doctor=doctors.find(x=>x.id===form.doctorId); const service=services.find(x=>x.id===form.serviceId);
  const ageFromDob=(dob?:string|null)=>{if(!dob)return '';const b=new Date(`${dob}T12:00:00`);if(Number.isNaN(b.getTime()))return '';const n=new Date();let age=n.getFullYear()-b.getFullYear();const md=n.getMonth()-b.getMonth();if(md<0||(md===0&&n.getDate()<b.getDate()))age--;return age>=0?String(age):''};
  useEffect(()=>{if(!patient)return;setForm(v=>{const nextAge=v.age||ageFromDob(patient.date_of_birth);const nextGender=v.gender||patient.gender||'';return nextAge===v.age&&nextGender===v.gender?v:{...v,age:nextAge,gender:nextGender}})},[patient?.id]);

  const computeSlots=useCallback((doctorId:string,date:string,duration:number,excludeId?:string)=>{
    if(!doctorId||!date)return [] as string[];
    const day=new Date(`${date}T12:00:00`); const weekday=day.getDay();
    const rule=availability.find(a=>a.doctor_id===doctorId&&a.weekday===weekday);const clinicHour=businessHours.find(h=>h.weekday===weekday);
    if(holidays.some(h=>h.holiday_date===date)||clinicHour?.active===false||rule?.active===false)return [] as string[];
    const clinicStart=(clinicHour?.start_time||'09:00').slice(0,5),clinicEnd=(clinicHour?.end_time||'18:00').slice(0,5);const doctorStart=(rule?.start_time||clinicStart).slice(0,5),doctorEnd=(rule?.end_time||clinicEnd).slice(0,5);
    const toMin=(v:string)=>{const [h,m]=v.split(':').map(Number);return h*60+m};const shMin=Math.max(toMin(clinicStart),toMin(doctorStart)),ehMin=Math.min(toMin(clinicEnd),toMin(doctorEnd)),step=rule?.slot_minutes||30; const result:string[]=[];
    const occupied=appointments.filter(a=>a.id!==excludeId&&a.doctor_id===doctorId&&localDate(a.starts_at)===date&&activeStatus(a.status));
    for(let m=shMin;m+duration<=ehMin;m+=step){
      const t=`${pad(Math.floor(m/60))}:${pad(m%60)}`;
      const candidateStart=new Date(`${date}T${t}:00+08:00`).getTime(); const candidateEnd=candidateStart+duration*60000;
      const parallelLimit=Math.max(1,Number(rule?.max_parallel||3));
      const overlapping=occupied.filter(a=>{const a0=+new Date(a.starts_at);const a1=a.ends_at?+new Date(a.ends_at):a0+30*60000;return candidateStart<a1&&candidateEnd>a0}).length;
      if(overlapping<parallelLimit)result.push(t);
    }
    return result;
  },[availability,appointments,businessHours,holidays]);

  const slots=useMemo(()=>computeSlots(form.doctorId,form.date,serviceMode==='custom'?30:Number(service?.duration_minutes||30)),[computeSlots,form.doctorId,form.date,service?.duration_minutes,serviceMode]);
  useEffect(()=>{if(!form.time&&slots.length)setForm(v=>v.time?v:{...v,time:slots.at(0)??''})},[slots,form.time]);

  function openNew(patientId='',preset?:{doctorId?:string;date?:string;time?:string}){
    const anchorDate=new Date(anchor);anchorDate.setHours(0,0,0,0);const defaultDate=anchorDate;
    const doctorId=preset?.doctorId||doctors[0]?.id||'';const p=patients.find(x=>x.id===patientId);
    setForm({patientMode:'existing',patientId,newPatientName:'',newPatientPhone:'',newPatientExternalId:'',doctorId,serviceId:'',serviceText:'',age:ageFromDob(p?.date_of_birth),gender:p?.gender||'',date:preset?.date||dateKey(defaultDate),time:preset?.time||'',notes:''});setPicker(null);setPickerSearch('');setServiceSearch('');setServiceMode('catalog');setError('');setModal(true);
  }
  function quickStaffFuture(months:number){
    const d=new Date();d.setHours(12,0,0,0);d.setMonth(d.getMonth()+months);
    setForm(v=>({...v,date:dateKey(d),time:''}));
  }
  async function book(){
    const patientOk=form.patientMode==='new'?Boolean(form.newPatientName.trim()&&form.newPatientPhone.replace(/\D/g,'').length===8):Boolean(form.patientId);
    const demographicsOk=form.patientMode==='new'||Boolean(form.age&&form.gender);
    if(!patientOk||!form.doctorId||!demographicsOk||!form.date||!form.time){setError(form.patientMode==='new'?(en?'Enter name, phone, doctor, date and time. Service is optional.':'Анх удаа ирж буй хүний нэр, утас, эмч, өдөр, цагаа оруулна уу. Үйлчилгээ заавал биш.'):(en?'Complete patient, age, gender, doctor, date and time. Service is optional.':'Өвчтөн, нас, хүйс, эмч, өдөр, цагаа бүрэн оруулна уу. Үйлчилгээ заавал биш.'));return}
    setSaving(true);setError('');
    try{await authFetch('/api/appointments',{method:'POST',body:JSON.stringify({...form,serviceId:serviceMode==='catalog'?form.serviceId:'',serviceText:serviceMode==='custom'?form.serviceText:''})});setModal(false);pushNotice(en?'Appointment booked.':'Цаг амжилттай товлогдлоо.');await loadAppointments()}
    catch(e:unknown){setError(e instanceof Error?e.message:'Цаг товлож чадсангүй.')}finally{setSaving(false)}
  }
  function applyAppointmentPatch(a:Appointment,patch:Record<string,unknown>):Appointment{
    const duration=('durationMinutes' in patch)?Math.max(15,Number(patch.durationMinutes)||durationMinutes(a)):durationMinutes(a);
    const starts=('date' in patch&&'time' in patch)?new Date(`${String(patch.date)}T${String(patch.time)}:00+08:00`).toISOString():a.starts_at;
    const serviceId=('serviceId' in patch&&patch.serviceId)?String(patch.serviceId):a.service_id;
    return {...a,
      ...(('status' in patch)?{status:String(patch.status)}:{}),
      ...(('notes' in patch)?{notes:String(patch.notes||'')}:{}),
      ...(('clinicalSummary' in patch)?{clinical_summary:String(patch.clinicalSummary||'')}:{}),
      ...(('serviceText' in patch&&patch.serviceText)?{service_name:String(patch.serviceText),service_request:String(patch.serviceText)}:{}),
      ...(serviceId?{service_id:serviceId,service_name:services.find(s=>s.id===serviceId)?.name||a.service_name}:{}),
      ...(('doctorId' in patch)?{doctor_id:String(patch.doctorId||''),doctor:doctors.find(d=>d.id===String(patch.doctorId))?{full_name:doctors.find(d=>d.id===String(patch.doctorId))!.full_name}:a.doctor}:{}),
      starts_at:starts,
      ends_at:new Date(+new Date(starts)+duration*60000).toISOString()
    };
  }
  async function updateAppointment(patch:Record<string,unknown>){
    if(!selected)return;const before=selected;const beforeList=appointments;const optimistic=applyAppointmentPatch(selected,patch);setSelected(optimistic);setAppointments(list=>list.map(a=>a.id===selected.id?optimistic:a));setSaving(true);setError('');
    try{
      await authFetch('/api/appointments',{method:'PATCH',body:JSON.stringify({id:selected.id,...patch})});
      setRescheduleOpen(false);pushNotice(en?'Appointment updated.':'Цагийн мэдээлэл шинэчлэгдлээ.');
      void loadAppointments();
    }
    catch(e:unknown){setSelected(before);setAppointments(beforeList);setError(e instanceof Error?e.message:'Шинэчилж чадсангүй.')}finally{setSaving(false)}
  }


  async function deleteAppointment(){
    const target=deleteAppointmentTarget;if(!target)return;setSaving(true);setError('');
    try{await authFetch('/api/appointments',{method:'DELETE',body:JSON.stringify({id:target.id})});setAppointments(list=>list.filter(x=>x.id!==target.id));if(selected?.id===target.id)setSelected(null);setDeleteAppointmentTarget(null);pushNotice(en?'Appointment deleted.':'Цагийн бүртгэл устгагдлаа.')}catch(e:unknown){setError(e instanceof Error?e.message:'Цаг устгаж чадсангүй.')}finally{setSaving(false)}
  }

  const selectedService=selected?.service_id?services.find(s=>s.id===selected.service_id):undefined;
  const clinicalAccess=profile.role==='owner'||/(эмч|doctor|dentist)/i.test(profile.specialty||'');

  useEffect(()=>{
    if(!selected) return;
    setDetailServiceId(selected.service_id || '');
    setDetailClinicalSummary(selected.clinical_summary || '');
    setDetailNotes(selected.notes || '');
  },[selected?.id]);

  const moveSlots=useMemo(()=>selected?computeSlots(moveForm.doctorId,moveForm.date,Number(selectedService?.duration_minutes||durationMinutes(selected)),selected.id):[],[selected,selectedService?.duration_minutes,moveForm.doctorId,moveForm.date,computeSlots]);
  useEffect(()=>{if(rescheduleOpen&&moveSlots.length&&!moveSlots.includes(moveForm.time))setMoveForm(v=>({...v,time:moveSlots.at(0)??''}));if(rescheduleOpen&&!moveSlots.length)setMoveForm(v=>({...v,time:''}))},[rescheduleOpen,moveSlots]);
  function beginMove(){
    if(!selected)return;
    setError('');setMoveForm({doctorId:selected.doctor_id||doctors[0]?.id||'',date:localDate(selected.starts_at),time:localTime(selected.starts_at)});setRescheduleOpen(true);
  }
  async function saveMove(){
    if(!selected||!moveForm.doctorId||!moveForm.date||!moveForm.time)return;
    await updateAppointment({doctorId:moveForm.doctorId,date:moveForm.date,time:moveForm.time});
  }


  async function saveClinicalDetails(){
    if(!selected) return;
    const patch:Record<string,unknown>={notes:detailNotes,clinicalSummary:detailClinicalSummary.trim()};
    if(detailServiceId) patch.serviceId = detailServiceId;
    await updateAppointment(patch);
  }

  const dayKey=dateKey(anchor); const weekStart=startOfWeek(anchor); const weekDays=Array.from({length:7},(_,i)=>addDays(weekStart,i));
  const monthStart=new Date(anchor.getFullYear(),anchor.getMonth(),1); const monthGridStart=startOfWeek(monthStart); const monthDays=Array.from({length:42},(_,i)=>addDays(monthGridStart,i));
  const visibleAppointments=useMemo(()=>calendarDoctor?appointments.filter(a=>a.doctor_id===calendarDoctor):appointments,[appointments,calendarDoctor]);
  const byDate=(key:string)=>visibleAppointments.filter(a=>localDate(a.starts_at)===key).sort((a,b)=>+new Date(a.starts_at)-+new Date(b.starts_at));
  const dayAppointments=byDate(dayKey);

  const dayDoctors=useMemo(()=>calendarDoctor?doctors.filter(d=>d.id===calendarDoctor):doctors,[doctors,calendarDoctor]);
  const utilization=useMemo(()=>{
    const weekday=anchor.getDay();
    const selectedDoctors=dayDoctors.length?dayDoctors:doctors;
    let capacity=0;
    for(const d of selectedDoctors){
      const rule=availability.find(a=>a.doctor_id===d.id&&a.weekday===weekday);const clinicHour=businessHours.find(h=>h.weekday===weekday);const holiday=holidays.some(h=>h.holiday_date===dayKey);
      if(holiday||clinicHour?.active===false||rule?.active===false)continue;
      const cst=(clinicHour?.start_time||'09:00').slice(0,5),cet=(clinicHour?.end_time||'18:00').slice(0,5),dst=(rule?.start_time||cst).slice(0,5),det=(rule?.end_time||cet).slice(0,5);
      const toMin=(v:string)=>{const [h,m]=v.split(':').map(Number);return h*60+m};const minutes=Math.max(0,Math.min(toMin(cet),toMin(det))-Math.max(toMin(cst),toMin(dst)));capacity+=minutes*Math.max(1,Number(rule?.max_parallel||3));
    }
    const booked=dayAppointments.filter(a=>ACTIVE_STATUSES.has(a.status)).reduce((n,a)=>n+durationMinutes(a),0);
    const pct=capacity?Math.min(100,Math.round(booked/capacity*100)):0;
    return {capacity,booked,pct,freeSlots:Math.max(0,Math.floor((capacity-booked)/30)),count:dayAppointments.filter(a=>ACTIVE_STATUSES.has(a.status)).length};
  },[dayAppointments,dayDoctors,doctors,availability,businessHours,holidays,anchor,dayKey]);

  const years=useMemo<number[]>(()=>Array.from(new Set<number>(appointments.map(a=>new Date(a.starts_at).getFullYear()))).sort((a,b)=>b-a),[appointments]);
  const history=useMemo(()=>appointments.filter(a=>{
    const d=new Date(a.starts_at);const q=filters.q.trim().toLowerCase();
    if(filters.year&&d.getFullYear()!==Number(filters.year))return false;if(filters.month&&d.getMonth()+1!==Number(filters.month))return false;if(filters.date&&localDate(a.starts_at)!==filters.date)return false;
    if(filters.status&&a.status!==filters.status)return false;if(filters.doctor&&a.doctor_id!==filters.doctor)return false;if(filters.service&&a.service_id!==filters.service)return false;
    if(q&&!`${a.patients?.full_name||''} ${a.patients?.phone||''} ${a.patients?.patient_code||''} ${a.patients?.external_patient_id||''}`.toLowerCase().includes(q))return false;return true;
  }).sort((a,b)=>+new Date(b.starts_at)-+new Date(a.starts_at)),[appointments,filters]);
  const visiblePatients=patients.filter(p=>`${p.full_name} ${p.phone||''} ${p.register_no||''} ${p.patient_code||''} ${p.external_patient_id||''}`.toLowerCase().includes(pickerSearch.toLowerCase()));

  const weekdayNames=en?['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']:['Ням','Даваа','Мягмар','Лхагва','Пүрэв','Баасан','Бямба'];
  function openScheduleSettings(){
    const next=Array.from({length:7},(_,weekday)=>{const h=businessHours.find(x=>x.weekday===weekday);return {id:h?.id,weekday,start_time:(h?.start_time||'09:00').slice(0,5),end_time:(h?.end_time||'18:00').slice(0,5),active:h?.active??true}});setScheduleDraft(next);setHolidayDate('');setHolidayName('');setError('');setScheduleSettingsOpen(true);
  }
  async function saveScheduleSettings(){
    if(profile.role!=='owner'||!clinicId)return;const s=getSupabaseBrowser();if(!s)return;setSaving(true);setError('');
    try{for(const h of scheduleDraft){if(h.active&&h.start_time>=h.end_time)throw new Error(`${weekdayNames[h.weekday]}: эхлэх цаг дуусах цагаас өмнө байна.`)}const payload=scheduleDraft.map(h=>({clinic_id:clinicId,weekday:h.weekday,start_time:h.start_time,end_time:h.end_time,active:h.active}));const {error}=await s.from('clinic_business_hours').upsert(payload,{onConflict:'clinic_id,weekday'});if(error)throw error;setBusinessHours(scheduleDraft);setScheduleSettingsOpen(false);pushNotice(en?'Working hours saved.':'Ажлын цаг, амралтын өдрийн тохиргоо хадгалагдлаа.')}catch(e:unknown){setError(e instanceof Error?e.message:'Ажлын цаг хадгалж чадсангүй.')}finally{setSaving(false)}
  }
  async function addHoliday(){
    if(profile.role!=='owner'||!clinicId||!holidayDate)return;const s=getSupabaseBrowser();if(!s)return;setSaving(true);setError('');try{const {data,error}=await s.from('clinic_holidays').upsert({clinic_id:clinicId,holiday_date:holidayDate,name:holidayName.trim()||null},{onConflict:'clinic_id,holiday_date'}).select('id,holiday_date,name').single();if(error)throw error;setHolidays(list=>[...list.filter(x=>x.holiday_date!==holidayDate),data as Holiday].sort((a,b)=>a.holiday_date.localeCompare(b.holiday_date)));setHolidayDate('');setHolidayName('')}catch(e:unknown){setError(e instanceof Error?e.message:'Амралтын өдөр нэмэж чадсангүй.')}finally{setSaving(false)}
  }
  async function confirmRemoveHoliday(){const item=deleteHolidayTarget;const s=getSupabaseBrowser();if(!item||!s||profile.role!=='owner')return;setSaving(true);const {error}=await s.from('clinic_holidays').delete().eq('id',item.id);setSaving(false);if(error){setError(error.message);return}setHolidays(list=>list.filter(x=>x.id!==item.id));setDeleteHolidayTarget(null);pushNotice(en?'Holiday removed.':'Амралтын өдөр устгагдлаа.')}

  async function changeParallelCapacity(value:number){
    if(!calendarDoctor||!clinicId)return;const s=getSupabaseBrowser();if(!s)return;setSaving(true);setError('');
    try{
      const weekday=anchor.getDay();const current=availability.find(a=>a.doctor_id===calendarDoctor&&a.weekday===weekday);
      const row={clinic_id:clinicId,doctor_id:calendarDoctor,weekday,start_time:current?.start_time||'09:00',end_time:current?.end_time||'18:00',slot_minutes:current?.slot_minutes||30,max_parallel:value,active:true};
      const {error}=await s.from('doctor_availability').upsert(row,{onConflict:'doctor_id,weekday'});if(error)throw error;
      setAvailability(list=>{const found=list.findIndex(a=>a.doctor_id===calendarDoctor&&a.weekday===weekday);if(found<0)return[...list,{doctor_id:calendarDoctor,weekday,start_time:String(row.start_time),end_time:String(row.end_time),slot_minutes:Number(row.slot_minutes),max_parallel:value,active:true}];return list.map((a,i)=>i===found?{...a,max_parallel:value,active:true}:a)});
      pushNotice(en?'Parallel capacity updated.':`30 минутын нэг блокт зэрэг хүлээн авах дээд тоо ${value} боллоо.`);
    }catch(e:unknown){setError(e instanceof Error?e.message:'Багтаамж шинэчилж чадсангүй.')}finally{setSaving(false)}
  }
  const selectedParallel=Math.max(1,Number(availability.find(a=>a.doctor_id===calendarDoctor&&a.weekday===anchor.getDay())?.max_parallel||3));

  async function moveCalendarAppointment(item:Appointment,doctorId:string,time:string){
    if(saving)return;const before=appointments;const optimistic=applyAppointmentPatch(item,{doctorId,date:dayKey,time,durationMinutes:durationMinutes(item)});setAppointments(list=>list.map(a=>a.id===item.id?optimistic:a));setSelected(v=>v?.id===item.id?optimistic:v);setSaving(true);setError('');
    try{await authFetch('/api/appointments',{method:'PATCH',body:JSON.stringify({id:item.id,doctorId,date:dayKey,time,durationMinutes:durationMinutes(item)})});pushNotice(en?'Appointment moved.':'Цагийг шинэ байрлалд шилжүүллээ.');void loadAppointments()}
    catch(e:unknown){setAppointments(before);setSelected(v=>v?.id===item.id?item:v);setError(e instanceof Error?e.message:'Цаг шилжүүлж чадсангүй.')}finally{setSaving(false)}
  }
  async function resizeCalendarAppointment(item:Appointment,minutes:number){
    if(saving)return;const before=appointments;const optimistic=applyAppointmentPatch(item,{durationMinutes:minutes});setAppointments(list=>list.map(a=>a.id===item.id?optimistic:a));setSelected(v=>v?.id===item.id?optimistic:v);setSaving(true);setError('');
    try{await authFetch('/api/appointments',{method:'PATCH',body:JSON.stringify({id:item.id,durationMinutes:minutes})});pushNotice(en?'Appointment duration updated.':'Цагийн үргэлжлэх хугацаа шинэчлэгдлээ.');void loadAppointments()}
    catch(e:unknown){setAppointments(before);setSelected(v=>v?.id===item.id?item:v);setError(e instanceof Error?e.message:'Үргэлжлэх хугацааг өөрчилж чадсангүй.')}finally{setSaving(false)}
  }

  function shiftAnchor(dir:number){
    if(mode==='day')setAnchor(d=>addDays(d,dir)); else if(mode==='week')setAnchor(d=>addDays(d,dir*7)); else setAnchor(d=>new Date(d.getFullYear(),d.getMonth()+dir,1));
  }

  return <div className="page-stack staff-appointments-page">
    <header className="page-head"><div><small>{clinicName}</small><h1>{en?'Schedule':'Цагийн хуваарь'}</h1><p>{en?'Parallel capacity, drag/resize and clinic working hours in one schedule.':'Зэрэг хүлээн авах багтаамж, чирж шилжүүлэх/уртасгах болон эмнэлгийн ажлын цагтай хуваарь.'}</p></div><div className="head-actions">{profile.role==='owner'&&<button className="btn-secondary" onClick={openScheduleSettings}><Settings2 size={18}/>{en?'Working hours':'Ажлын цаг'}</button>}<button className="btn-primary calendar-add-btn" onClick={()=>openNew()}><Plus size={18}/>{en?'Book appointment':'Цаг товлох'}</button></div></header>
    {notices.length>0&&<div className={`app-toast-stack ${(loading||saving)?'with-busy':''}`} role="status" aria-live="polite">{notices.map((notice,index)=><div key={notice.id} className="app-toast success" style={{'--toast-index':index} as CSSProperties}><Check size={17}/><span>{notice.text}</span><button onClick={()=>setNotices(list=>list.filter(item=>item.id!==notice.id))}><X size={16}/></button></div>)}</div>}
    {(loading||saving)&&<div className="workspace-busy-notice" role="status" aria-live="polite"><Loader2 className="spin" size={17}/><span>{loading?(en?'Loading schedule… Please wait.':'Хуваарийн мэдээллийг уншиж байна… Түр хүлээнэ үү.'):(en?'Saving changes… Please wait.':'Өөрчлөлтийг хадгалж байна… Түр хүлээнэ үү.')}</span></div>}

    <section className="schedule-overview">
      <article className="schedule-occupancy-card"><div className="schedule-occupancy-top"><span><Gauge size={19}/>{en?'Daily occupancy':'Өдрийн дүүргэлт'}</span><strong>{utilization.pct}%</strong></div><div className="schedule-progress"><i style={{width:`${utilization.pct}%`}}/></div><small>{en?`${utilization.booked} of ${utilization.capacity} capacity-minutes booked`:`Нийт ${utilization.capacity} багтаамж-минутаас ${utilization.booked} минут захиалгатай`}</small></article>
      <article className="schedule-kpi"><span><CalendarDays/></span><div><b>{utilization.count}</b><small>{en?'appointments':'захиалгатай цаг'}</small></div></article>
      <article className="schedule-kpi"><span><Clock3/></span><div><b>{utilization.freeSlots}</b><small>{en?'approx. free slots':'ойролцоогоор сул слот'}</small></div></article>
    </section>

    <section className="panel-card appt-calendar-card emerald-calendar">
      <div className="appt-calendar-toolbar">
        <div className="appt-nav"><button onClick={()=>shiftAnchor(-1)} aria-label={en?'Previous period':'Өмнөх хугацаа'}><ChevronLeft/></button><button className="appt-today-btn" onClick={()=>setAnchor(new Date())}>{en?'Today':'Өнөөдөр'}</button><button onClick={()=>shiftAnchor(1)} aria-label={en?'Next period':'Дараагийн хугацаа'}><ChevronRight/></button></div>
        <strong>{calendarTitle(anchor,mode,en,weekDays)}</strong>
        <div className="appt-toolbar-right"><DentSelect searchable value={calendarDoctor} placeholder={en?'All doctors':'Бүх эмч'} onChange={setCalendarDoctor} options={doctors.map(d=>({value:d.id,label:d.full_name}))}/>{calendarDoctor&&<label className="parallel-capacity-control"><span>{en?'Parallel / 30m':'30 мин-д зэрэг'}</span><DentSelect value={String(selectedParallel)} disabled={saving} onChange={v=>changeParallelCapacity(Number(v))} options={Array.from({length:8},(_,i)=>({value:String(i+1),label:String(i+1)}))}/></label>}<div className="appt-mode-switch"><button className={mode==='day'?'active':''} onClick={()=>setMode('day')}>{en?'Day':'Өдөр'}</button><button className={mode==='week'?'active':''} onClick={()=>setMode('week')}>{en?'Week':'7 хоног'}</button><button className={mode==='month'?'active':''} onClick={()=>setMode('month')}>{en?'Month':'Сар'}</button></div></div>
      </div>
      {loading?<div className="appt-loading"><Loader2 className="spin"/>{en?'Loading schedule…':'Хуваарь ачаалж байна…'}</div>:mode==='day'?<TimelineDay date={anchor} doctors={dayDoctors.length?dayDoctors:doctors} appointments={dayAppointments} availability={availability} businessHours={businessHours} holidays={holidays} en={en} onOpen={setSelected} onCreate={(doctorId,time)=>openNew('',{doctorId,date:dayKey,time})} onMove={moveCalendarAppointment} onResize={resizeCalendarAppointment}/>:mode==='week'?<WeekView days={weekDays} byDate={byDate} en={en} onOpen={setSelected}/>:<MonthView days={monthDays} anchor={anchor} byDate={byDate} en={en} onOpen={setSelected}/>}    
    </section>

    <section className="panel-card appt-history-card">
      <div className="panel-head"><div><h2><History size={19}/>{en?' Appointment history':' Цагийн түүх'}</h2><p>{en?'Realtime history with combined filters.':'Жил, сар, өдөр, төлөвөөр зэрэг шүүнэ.'}</p></div><button className="btn-secondary" onClick={()=>setHistoryOpen(v=>!v)}><Filter size={17}/>{historyOpen?(en?'Hide filters':'Шүүлтүүр нуух'):(en?'Filters':'Шүүлтүүр')}</button></div>
      {historyOpen&&<div className="appt-filters"><div className="module-search"><Search size={17}/><input value={filters.q} onChange={e=>setFilters(v=>({...v,q:e.target.value}))} placeholder={en?'Patient name, phone or ID…':'Өвчтөний нэр, утас эсвэл ID…'}/></div><DentSelect value={filters.year} placeholder={en?'All years':'Бүх жил'} onChange={year=>setFilters(v=>({...v,year}))} options={years.map(y=>({value:String(y),label:String(y)}))}/><DentSelect value={filters.month} placeholder={en?'All months':'Бүх сар'} onChange={month=>setFilters(v=>({...v,month}))} options={Array.from({length:12},(_,i)=>({value:String(i+1),label:String(i+1)}))}/><DentDatePicker value={filters.date} onChange={date=>setFilters(v=>({...v,date}))} lang={lang} placeholder={en?'Any date':'Бүх өдөр'}/><DentSelect value={filters.status} placeholder={en?'All statuses':'Бүх төлөв'} onChange={status=>setFilters(v=>({...v,status}))} options={STATUS.map(x=>({value:x,label:statusLabel(x,en)}))}/><DentSelect searchable value={filters.doctor} placeholder={en?'All doctors':'Бүх эмч'} onChange={doctor=>setFilters(v=>({...v,doctor}))} options={doctors.map(d=>({value:d.id,label:d.full_name}))}/><DentSelect searchable value={filters.service} placeholder={en?'All services':'Бүх үйлчилгээ'} onChange={service=>setFilters(v=>({...v,service}))} options={services.map(x=>({value:x.id,label:x.name}))}/></div>}
      <div className="appt-history-table"><div className="appt-history-head"><span>{en?'Date / time':'Огноо / цаг'}</span><span>{en?'Patient':'Өвчтөн'}</span><span>{en?'Doctor / service':'Эмч / үйлчилгээ'}</span><span>{en?'Status':'Төлөв'}</span></div>{history.length?history.map(a=><div key={a.id} className="appt-history-entry"><button className="appt-history-row" onClick={()=>setSelected(a)}><span><b>{new Date(a.starts_at).toLocaleDateString(en?'en-US':'mn-MN')}</b><small>{timeText(a.starts_at,en)}</small></span><span><b>{a.patients?.full_name||'—'}</b><small>{[a.patients?.patient_code,a.patients?.external_patient_id,a.patients?.phone].filter(Boolean).join(' · ')||'—'}</small></span><span><b>{a.doctor?.full_name||'—'}</b><small>{a.service_name||'—'}</small></span><span><i className={`appt-status status-${a.status}`}>{statusLabel(a.status,en)}</i></span></button>{profile.role==='owner'&&<button type="button" className="appt-history-delete" title={en?'Delete appointment':'Цагийн түүх устгах'} aria-label={en?'Delete appointment':'Цагийн түүх устгах'} onClick={()=>setDeleteAppointmentTarget(a)}><Trash2 size={16}/></button>}</div>):<div className="empty-state"><CalendarDays/><b>{en?'No matching appointments':'Тохирох цаг олдсонгүй'}</b></div>}</div>
    </section>

    {modal&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&setModal(false)}><div className="modal-card staff-booking-modal"><header><div><small>{clinicName}</small><h2>{en?'Book appointment':'Цаг товлох'}</h2></div><button onClick={()=>setModal(false)}><X/></button></header><div className="staff-booking-body"><div className="staff-clinic-lock"><Building2 size={18}/><div><span>{en?'Clinic':'Эмнэлэг'}</span><b>{clinicName}</b></div><Check size={18}/></div>
      <div className="patient-mode-switch"><button type="button" className={form.patientMode==='existing'?'active':''} onClick={()=>setForm(v=>({...v,patientMode:'existing'}))}>{en?'Registered patient':'Бүртгэлтэй өвчтөн'}</button><button type="button" className={form.patientMode==='new'?'active':''} onClick={()=>{setPicker(null);setForm(v=>({...v,patientMode:'new',patientId:''}))}}>{en?'First visit':'Анх удаа ирж байгаа'}</button></div>
      {form.patientMode==='existing'?<Picker label={en?'Patient':'Өвчтөн'} value={patient?.full_name||''} icon={<UsersRound/>} open={picker==='patient'} onToggle={()=>{setPicker(picker==='patient'?null:'patient');setPickerSearch('')}}><div className="picker-search"><Search size={16}/><input autoFocus value={pickerSearch} onChange={e=>setPickerSearch(e.target.value)} placeholder={en?'Name, phone, patient ID…':'Нэр, утас, ID-аар хайх…'}/></div>{visiblePatients.map(p=><button key={p.id} onClick={()=>{setForm(v=>({...v,patientMode:'existing',patientId:p.id,age:ageFromDob(p.date_of_birth)||v.age,gender:p.gender||v.gender}));setPicker(null)}} className={p.id===form.patientId?'selected':''}><span><b>{p.full_name}</b><small>{[p.patient_code,p.external_patient_id,p.phone,p.register_no].filter(Boolean).join(' · ')}</small></span>{p.id===form.patientId&&<Check/>}</button>)}</Picker>:<div className="quick-patient-grid"><label><span>{en?'Name':'Нэр'}</span><input value={form.newPatientName} onChange={e=>setForm(v=>({...v,newPatientName:e.target.value}))} placeholder={en?'First-time visitor name':'Анх удаа ирж буй хүний нэр'}/></label><label><span>{en?'Phone':'Утас'}</span><NumericInput value={form.newPatientPhone} onValueChange={newPatientPhone=>setForm(v=>({...v,newPatientPhone}))} maxDigits={8} placeholder="99112233"/></label><label className="wide"><span>{en?'Client ID (optional)':'Үйлчлүүлэгчийн ID (заавал биш)'}</span><input value={form.newPatientExternalId} onChange={e=>setForm(v=>({...v,newPatientExternalId:e.target.value}))} placeholder={en?'Clinic/customer reference ID':'Эмнэлгийн өөрийн ID дугаар'}/></label><p className="wide">{en?'A lightweight patient record is created automatically and can be completed later.':'Цаг хадгалахад өвчтөний хөнгөн бүртгэл автоматаар үүснэ. Дараа нь Өвчтөн хэсгээс мэдээллийг гүйцээж болно.'}</p></div>}
      {form.patientMode==='existing'&&<div className="booking-demographics"><label><span>{en?'Age':'Нас'}</span><NumericInput value={form.age} onValueChange={age=>setForm(v=>({...v,age}))} maxDigits={3} maxValue={130} placeholder="25"/></label><label><span>{en?'Gender':'Хүйс'}</span><DentSelect value={form.gender} placeholder={en?'Choose':'Сонгох'} onChange={gender=>setForm(v=>({...v,gender}))} options={[{value:'female',label:en?'Female':'Эмэгтэй'},{value:'male',label:en?'Male':'Эрэгтэй'},{value:'other',label:en?'Other':'Бусад'},{value:'unspecified',label:en?'Prefer not to say':'Хэлэхгүй'}]}/></label></div>}
      <div className="booking-two-col single-doctor"><Picker label={en?'Doctor':'Эмч'} value={doctor?.full_name||''} icon={<Stethoscope/>} open={picker==='doctor'} onToggle={()=>setPicker(picker==='doctor'?null:'doctor')}>{doctors.map(d=><button key={d.id} onClick={()=>{setForm(v=>({...v,doctorId:d.id,time:''}));setPicker(null)}} className={d.id===form.doctorId?'selected':''}>{d.full_name}{d.id===form.doctorId&&<Check/>}</button>)}</Picker></div>
      <StaffServiceChoice en={en} services={services} selectedId={form.serviceId} selectedName={service?.name||''} customText={form.serviceText} mode={serviceMode} search={serviceSearch} open={picker==='service'} onOpen={()=>setPicker(picker==='service'?null:'service')} onSearch={setServiceSearch} onMode={m=>{setServiceMode(m);setPicker(null);setForm(v=>({...v,time:'',serviceText:m==='custom'?v.serviceText:'',serviceId:m==='catalog'?v.serviceId:''}))}} onSelect={id=>{setForm(v=>({...v,serviceId:id,serviceText:'',time:''}));setPicker(null)}} onCustom={text=>setForm(v=>({...v,serviceText:text,serviceId:'',time:''}))}/>
      <div className="booking-date-time-grid"><label className="staff-date-field"><span>{en?'Appointment date':'Товлох өдөр'}</span><DentDatePicker value={form.date} onChange={date=>setForm(v=>({...v,date,time:''}))} lang={lang}/><small>{en?'Past, today and future dates are supported for clinic records and follow-ups.':'Өнгөрсөн бүртгэл, өнөөдөр болон урт хугацааны хяналтын өдрийг сонгож болно.'}</small></label><label className="staff-date-field"><span>{en?'Appointment time':'Товлох цаг'}</span><DentSelect searchable value={form.time} placeholder={en?'Choose time':'Цаг сонгох'} onChange={time=>setForm(v=>({...v,time}))} options={TIME_OPTIONS}/><small>{en?'Choose an exact 5-minute time or pick a recommended free slot below.':'5 минутын нарийвчлалтай цаг эсвэл доорх санал болгосон сул цагаас сонгоно.'}</small></label></div><div className="staff-future-shortcuts"><span>{en?'Quick future booking':'Ирээдүйн цаг хурдан сонгох'}</span><button type="button" onClick={()=>quickStaffFuture(1)}>{en?'+1 month':'+1 сар'}</button><button type="button" onClick={()=>quickStaffFuture(2)}>{en?'+2 months':'+2 сар'}</button><button type="button" onClick={()=>quickStaffFuture(3)}>{en?'+3 months':'+3 сар'}</button></div>
      <div className="staff-slot-section"><div><b>{en?'Suggested available times':'Санал болгох сул цаг'}</b><small>{doctor?doctor.full_name:(en?'Choose a doctor first':'Эмчээ эхлээд сонгоно уу')}</small></div><div className="staff-slot-grid">{slots.length?slots.map(t=><button key={t} className={form.time===t?'active':''} onClick={()=>setForm(v=>({...v,time:t}))}><Clock3 size={15}/>{t}</button>):<p>{en?'No suggested slots. You can still enter another future time above; DentHub validates clinic hours and capacity on save.':'Санал болгох сул цаг алга. Дээр хүссэн ирээдүйн цагаа бичиж болно; хадгалах үед ажлын цаг, багтаамжийг шалгана.'}</p>}</div></div>
      <label className="staff-notes"><span>{en?'Note (optional)':'Тэмдэглэл (заавал биш)'}</span><textarea rows={3} value={form.notes} onChange={e=>setForm(v=>({...v,notes:e.target.value}))}/></label>{error&&<div className="form-error">{error}</div>}
    </div><footer><button className="btn-secondary" onClick={()=>setModal(false)}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={book} disabled={saving||!form.time}>{saving?<Loader2 className="spin"/>:<Check/>}{saving?(en?'Booking…':'Товлож байна…'):(en?'Confirm appointment':'Цаг баталгаажуулах')}</button></footer></div></div>}

    {scheduleSettingsOpen&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&!saving&&setScheduleSettingsOpen(false)}><div className="modal-card schedule-settings-modal"><header><div><small>{clinicName}</small><h2>{en?'Working hours & holidays':'Ажлын цаг & амралтын өдөр'}</h2></div><button onClick={()=>setScheduleSettingsOpen(false)} disabled={saving}><X/></button></header><div className="schedule-settings-body"><div className="working-hours-grid">{scheduleDraft.map((h,index)=><div className={`working-hour-row ${!h.active?'off':''}`} key={h.weekday}><label className="working-day-toggle"><input type="checkbox" checked={h.active} onChange={e=>setScheduleDraft(list=>list.map((x,i)=>i===index?{...x,active:e.target.checked}:x))}/><span>{weekdayNames[h.weekday]}</span></label><input type="time" disabled={!h.active} value={h.start_time} onChange={e=>setScheduleDraft(list=>list.map((x,i)=>i===index?{...x,start_time:e.target.value}:x))}/><span>—</span><input type="time" disabled={!h.active} value={h.end_time} onChange={e=>setScheduleDraft(list=>list.map((x,i)=>i===index?{...x,end_time:e.target.value}:x))}/><em>{h.active?(en?'Open':'Ажиллана'):(en?'Closed':'Амарна')}</em></div>)}</div><div className="holiday-settings"><div><b>{en?'Special holidays':'Тусгай амралтын өдрүүд'}</b><p>{en?'No appointments can be booked on these dates.':'Эдгээр өдөр цаг товлох боломжгүй байна.'}</p></div><div className="holiday-add-row"><DentDatePicker min={dateKey(new Date())} value={holidayDate} onChange={setHolidayDate} lang={lang}/><input value={holidayName} onChange={e=>setHolidayName(e.target.value)} placeholder={en?'Holiday name (optional)':'Тайлбар (заавал биш)'}/><button className="btn-secondary" disabled={!holidayDate||saving} onClick={addHoliday}><Plus size={16}/>{en?'Add':'Нэмэх'}</button></div><div className="holiday-list">{holidays.length?holidays.map(h=><div key={h.id}><span><b>{new Date(`${h.holiday_date}T12:00:00`).toLocaleDateString(en?'en-US':'mn-MN')}</b><small>{h.name|| (en?'Closed':'Амарна')}</small></span><button onClick={()=>setDeleteHolidayTarget(h)}><Trash2 size={15}/></button></div>):<p>{en?'No special holidays added.':'Тусгай амралтын өдөр нэмээгүй байна.'}</p>}</div></div>{error&&<div className="form-error">{error}</div>}</div><footer><button className="btn-secondary" onClick={()=>setScheduleSettingsOpen(false)}>{en?'Cancel':'Болих'}</button><button className="btn-primary" disabled={saving} onClick={saveScheduleSettings}><Check size={17}/>{en?'Save schedule':'Хуваарь хадгалах'}</button></footer></div></div>}

    <ConfirmDialog open={Boolean(deleteAppointmentTarget)} busy={saving} title={en?'Delete this appointment?':'Энэ цагийн бүртгэлийг устгах уу?'} description={deleteAppointmentTarget?(profile.role==='owner'?(en?'The appointment record will be deleted. Any medical treatment history already created from it will remain protected.':'Цаг товлолын бүртгэл устна. Үүнээс үүссэн эмчилгээний түүх байвал устахгүй, тусдаа хадгалагдана.'):(en?'Employees can delete only cancelled or no-show appointments.':'Ажилтан зөвхөн Цуцалсан эсвэл Ирээгүй төлөвтэй цагийг устгана.')):''} confirmLabel={en?'Delete appointment':'Цаг устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!saving&&setDeleteAppointmentTarget(null)} onConfirm={deleteAppointment}/>
    <ConfirmDialog open={Boolean(deleteHolidayTarget)} busy={saving} title={en?'Remove this holiday?':'Энэ амралтын өдрийг устгах уу?'} description={deleteHolidayTarget?(en?`${deleteHolidayTarget.holiday_date} will become bookable again.`:`${deleteHolidayTarget.holiday_date} өдөр дахин цаг товлох боломжтой болно.`):''} confirmLabel={en?'Remove holiday':'Устгах'} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!saving&&setDeleteHolidayTarget(null)} onConfirm={confirmRemoveHoliday}/>
    {selected&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&!rescheduleOpen&&setSelected(null)}><div className="modal-card appt-detail-modal"><header><div><small>{en?'Appointment':'Цаг товлол'}</small><h2>{selected.patients?.full_name||'Өвчтөн'}</h2></div><button onClick={()=>{setSelected(null);setRescheduleOpen(false)}}><X/></button></header>
      {!rescheduleOpen?<><div className="appt-detail-scroll"><div className="detail-lines"><div><span>{en?'Date / time':'Огноо / цаг'}</span><b>{new Date(selected.starts_at).toLocaleString(en?'en-US':'mn-MN')}</b></div><div><span>{en?'Doctor':'Эмч'}</span><b>{selected.doctor?.full_name||'—'}</b></div><div><span>{en?'Current service':'Одоогийн үйлчилгээ'}</span><b>{selected.service_name||'—'}</b></div><div><span>{en?'Age / gender':'Нас / хүйс'}</span><b>{selected.patient_age??'—'} · {selected.patient_gender==='female'?'Эмэгтэй':selected.patient_gender==='male'?'Эрэгтэй':selected.patient_gender==='other'?'Бусад':selected.patient_gender==='unspecified'?'Хэлэхгүй':'—'}</b></div><div><span>{en?'Patient can cancel':'Өвчтөн өөрөө цуцлах'}</span><b>{['pending','confirmed','scheduled','waiting'].includes(selected.status)?(en?'Allowed':'Болно'):(en?'Not allowed':'Болохгүй')}</b></div><div><span>{en?'Created by':'Бүртгэсэн'}</span><b>{selected.creator?.full_name||'—'}</b></div><div className="full"><span>{en?'Patient description':'Өвчтөний тайлбар'}</span><b>{selected.service_request||'—'}</b></div></div>{clinicalAccess&&<div className="service-detail-grid"><label><span>{en?'Doctor-selected service':'Эмч сонгосон үйлчилгээ'}</span><DentSelect searchable value={detailServiceId} placeholder={en?'Choose service later / custom':'Сонгохгүй / өөрөө бичих'} onChange={setDetailServiceId} options={services.map(x=>({value:x.id,label:x.name}))}/></label><label className="wide"><span>{en?'Clinical summary / diagnosis':'Эмчилгээний тайлбар / онош'}</span><textarea rows={3} value={detailClinicalSummary} onChange={e=>setDetailClinicalSummary(e.target.value)} placeholder={en?'Doctor can describe the actual treatment here':'Эмч хийсэн үйлчилгээ эсвэл оношийг энд бичиж болно'}/></label><label className="wide"><span>{en?'Clinical notes':'Тэмдэглэл'}</span><textarea rows={4} value={detailNotes} onChange={e=>setDetailNotes(e.target.value)} placeholder={en?'Notes visible to staff':'Ажилтнуудад харагдах тэмдэглэл'}/></label></div>}<div className="appt-status-actions">{['confirmed','waiting','checked_in','in_progress','completed','cancelled','no_show'].map(s=><button type="button" key={s} className={selected.status===s?'active':''} disabled={saving} onClick={()=>updateAppointment({status:s})}>{statusLabel(s,en)}</button>)}</div></div><footer>{clinicalAccess&&<button className="btn-secondary" onClick={saveClinicalDetails} disabled={saving}><Check size={17}/>{en?'Save details':'Дэлгэрэнгүй хадгалах'}</button>}{['checked_in','in_progress'].includes(selected.status)&&onNavigate&&<button className="btn-primary" onClick={()=>{setSelected(null);onNavigate('treatments')}}><Stethoscope size={17}/>{en?'Open treatment':'Үзлэг, эмчилгээ рүү'}</button>}{(profile.role==='owner'||(activeStatus(selected.status)&&!['completed','done'].includes(selected.status)))&&<button className="btn-secondary move-appointment-btn" onClick={beginMove}><ArrowLeftRight size={17}/>{en?'Reschedule':'Цаг шилжүүлэх'}</button>}{(profile.role==='owner'||['cancelled','no_show'].includes(selected.status))&&<button className="btn-danger" onClick={()=>setDeleteAppointmentTarget(selected)}><Trash2 size={17}/>{en?'Delete appointment':'Цаг устгах'}</button>}<button className="btn-secondary" onClick={()=>setSelected(null)}>{en?'Close':'Хаах'}</button></footer></>:
      <div className="reschedule-panel"><div className="reschedule-callout"><ArrowLeftRight/><div><b>{en?'Move this appointment':'Цаг шилжүүлэх'}</b><p>{en?'Only free slots can be selected. The old slot is released automatically.':'Зөвхөн сул цаг сонгоно. Хуучин цаг автоматаар суллагдана.'}</p></div></div><label>{en?'Doctor':'Эмч'}<DentSelect searchable value={moveForm.doctorId} onChange={doctorId=>setMoveForm(v=>({...v,doctorId}))} options={doctors.map(d=>({value:d.id,label:d.full_name}))}/></label><label>{en?'New date':'Шинэ өдөр'}<DentDatePicker value={moveForm.date} onChange={date=>setMoveForm(v=>({...v,date,time:''}))} lang={lang}/></label><div className="staff-slot-section"><div><b>{en?'Free time':'Сул цаг'}</b><small>{moveSlots.length} {en?'available':'сонголт'}</small></div><div className="staff-slot-grid">{moveSlots.length?moveSlots.map(t=><button key={t} className={moveForm.time===t?'active':''} onClick={()=>setMoveForm(v=>({...v,time:t}))}>{t}</button>):<p>{en?'No free time. Choose another date or doctor.':'Сул цаг алга. Өөр өдөр эсвэл эмч сонгоно уу.'}</p>}</div></div>{error&&<div className="form-error">{error}</div>}<footer><button className="btn-secondary" onClick={()=>{setRescheduleOpen(false);setError('')}}>{en?'Back':'Буцах'}</button><button className="btn-primary" disabled={saving||!moveForm.time||!moveSlots.includes(moveForm.time)} onClick={saveMove}>{saving?<Loader2 className="spin"/>:<Check/>}{en?'Move appointment':'Шилжүүлэх'}</button></footer></div>}
    </div></div>}
  </div>
}

function Picker({label,value,icon,open,onToggle,children}:{label:string;value:string;icon:ReactNode;open:boolean;onToggle:()=>void;children:ReactNode}){
  return <div className={`staff-picker ${open?'open':''}`}><span>{label}</span><button type="button" className="staff-picker-trigger" onClick={onToggle}>{icon}<b>{value||label}</b><ChevronDown/></button>{open&&<div className="staff-picker-menu">{children}</div>}</div>
}


function StaffServiceChoice({en,services,selectedId,selectedName,customText,mode,search,open,onOpen,onSearch,onMode,onSelect,onCustom}:{en:boolean;services:Service[];selectedId:string;selectedName:string;customText:string;mode:'catalog'|'custom';search:string;open:boolean;onOpen:()=>void;onSearch:(v:string)=>void;onMode:(m:'catalog'|'custom')=>void;onSelect:(id:string)=>void;onCustom:(v:string)=>void}){
  const filtered=services.filter(s=>!s.is_category&&`${s.name} ${s.category||''} ${s.subcategory||''}`.toLowerCase().includes(search.toLowerCase()));
  const categories=Array.from(new Set(filtered.map(s=>s.category||'Бусад')));
  return <section className="service-choice-box staff-service-choice"><div className="service-choice-head"><div><span className="booking-field-label">{en?'Service (optional)':'Үйлчилгээ (заавал биш)'}</span><small>{en?'Leave empty, choose from catalog, or type a request':'Хоосон үлдээх, жагсаалтаас сонгох эсвэл хүссэн үйлчилгээг бичиж болно'}</small></div><div className="service-mode-switch"><button className={mode==='catalog'?'active':''} onClick={()=>onMode('catalog')}>{en?'Choose':'Сонгох'}</button><button className={mode==='custom'?'active':''} onClick={()=>onMode('custom')}>{en?'Type':'Бичих'}</button></div></div>
    {mode==='catalog'?<div className={`booking-picker service-tree-picker ${open?'open':''}`}><button type="button" className="booking-picker-trigger" onClick={onOpen}><span>{selectedName||(en?'No service selected':'Үйлчилгээ сонгоогүй')}</span><ChevronDown/></button>{open&&<div className="booking-picker-menu service-tree-menu"><div className="picker-search"><Search size={16}/><input autoFocus value={search} onChange={e=>onSearch(e.target.value)} placeholder={en?'Search service…':'Үйлчилгээ хайх…'}/></div><button type="button" className="service-tree-clear" onClick={()=>onSelect('')}>{en?'— No service —':'— Үйлчилгээ сонгохгүй —'}</button>
      {categories.map(category=>{const categoryItems=filtered.filter(s=>(s.category||'Бусад')===category);const subcategories=Array.from(new Set(categoryItems.map(s=>s.subcategory||'')));return <div className="service-tree-category" key={category}><div className="service-tree-category-name">{category}</div><div className="service-tree-branch">{subcategories.map(sub=><div className="service-tree-group" key={`${category}-${sub||'root'}`}>{sub&&<div className="service-tree-title">{sub}</div>}{categoryItems.filter(s=>(s.subcategory||'')===sub).map(s=><button key={s.id} className={s.id===selectedId?'selected':''} onClick={()=>onSelect(s.id)}><span>{s.name}</span>{s.id===selectedId&&<Check/>}</button>)}</div>)}</div></div>})}
      {!filtered.length&&<p className="service-tree-empty">{en?'No services found':'Үйлчилгээ олдсонгүй'}</p>}</div>}</div>:<label className="custom-service-input"><UserRound size={18}/><input value={customText} maxLength={180} onChange={e=>onCustom(e.target.value)} placeholder={en?'Example: tooth pain consultation':'Жишээ: Шүд өвдөөд үзүүлэх'}/></label>}
  </section>;
}

function TimelineDay({date,doctors,appointments,availability,businessHours,holidays,en,onOpen,onCreate,onMove,onResize}:{date:Date;doctors:Doctor[];appointments:Appointment[];availability:Availability[];businessHours:BusinessHour[];holidays:Holiday[];en:boolean;onOpen:(a:Appointment)=>void;onCreate:(doctorId:string,time:string)=>void;onMove:(a:Appointment,doctorId:string,time:string)=>void;onResize:(a:Appointment,minutes:number)=>void}){
  const step=30; const weekday=date.getDay(); const dateIso=dateKey(date);
  const clinicHour=businessHours.find(h=>h.weekday===weekday); const holiday=holidays.find(h=>h.holiday_date===dateIso);
  const rules=availability.filter(a=>a.weekday===weekday&&doctors.some(d=>d.id===a.doctor_id));
  const toMin=(v:string)=>{const [h,m]=v.slice(0,5).split(':').map(Number);return h*60+m};
  const clinicStart=toMin(clinicHour?.start_time||'09:00'); const clinicEnd=toMin(clinicHour?.end_time||'18:00');
  const ruleStarts=rules.filter(r=>r.active).map(r=>Math.max(clinicStart,toMin(r.start_time)));
  const ruleEnds=rules.filter(r=>r.active).map(r=>Math.min(clinicEnd,toMin(r.end_time)));
  // Keep the visible schedule strictly inside the clinic's configured working hours.
  // Historical records outside the window remain in history, but do not stretch the daily calendar.
  const startMin=Math.max(0,Math.floor(clinicStart/step)*step); const endMin=Math.min(24*60,Math.ceil(clinicEnd/step)*step); const rows=Math.max(1,(endMin-startMin)/step);
  const colCount=Math.max(doctors.length,1);
  const [columnWidths,setColumnWidths]=useState<Record<string,number>>({});
  const gridRef=useRef<HTMLDivElement|null>(null);
  const scrollRef=useRef<HTMLDivElement|null>(null);
  const lastGestureEnd=useRef(0);
  const suppressClickUntil=useRef(0);
  const [draggingId,setDraggingId]=useState<string|null>(null);
  const [dragTarget,setDragTarget]=useState<{doctorId:string;time:string}|null>(null);
  const [resizePreview,setResizePreview]=useState<{id:string;duration:number;height:number}|null>(null);
  const [gestureHud,setGestureHud]=useState<{x:number;y:number;text:string}|null>(null);
  const rowHeight=44;const headerHeight=56;const timeColumnWidth=78;
  const defaultWidth=Math.max(260,Math.min(390,Math.floor(1320/Math.max(1,doctors.length))));
  const autoFitColumns=doctors.length>0&&doctors.length<=3;
  const doctorColumns=doctors.length?(autoFitColumns?doctors.map(()=>`minmax(280px,1fr)`).join(' '):doctors.map(d=>`${columnWidths[d.id]||defaultWidth}px`).join(' ')):`minmax(280px,1fr)`;
  const style={gridTemplateColumns:`${timeColumnWidth}px ${doctorColumns}`,gridTemplateRows:`${headerHeight}px repeat(${rows}, ${rowHeight}px)`,minWidth:autoFitColumns?'100%':`${timeColumnWidth+Math.max(1,doctors.length)*defaultWidth}px`} as CSSProperties;
  const today=dateIso===dateKey(new Date()); const now=new Date(); const nowMinute=now.getHours()*60+now.getMinutes(); const showNow=today&&nowMinute>=startMin&&nowMinute<=endMin;
  const doctorWindow=(doctorId:string)=>{
    const rule=rules.find(r=>r.doctor_id===doctorId);
    const closed=Boolean(holiday)||clinicHour?.active===false||rule?.active===false;
    return {rule,closed,start:Math.max(clinicStart,toMin(rule?.start_time||clinicHour?.start_time||'09:00')),end:Math.min(clinicEnd,toMin(rule?.end_time||clinicHour?.end_time||'18:00'))};
  };
  const capacityAt=(doctorId:string,minute:number,excludeId?:string)=>{
    const window=doctorWindow(doctorId); const outside=window.closed||minute<window.start||minute+step>window.end;
    const limit=Math.max(1,Number(window.rule?.max_parallel||3));
    const cellStart=new Date(`${dateIso}T${pad(Math.floor(minute/60))}:${pad(minute%60)}:00+08:00`).getTime(); const cellEnd=cellStart+step*60000;
    const used=appointments.filter(a=>a.id!==excludeId&&a.doctor_id===doctorId&&activeStatus(a.status)&&cellStart<(a.ends_at?+new Date(a.ends_at):+new Date(a.starts_at)+30*60000)&&cellEnd>+new Date(a.starts_at)).length;
    return {used,limit,full:used>=limit,closed:outside};
  };
  const laneInfo=new Map<string,{lane:number;count:number}>();
  for(const doctor of doctors){
    const list=appointments.filter(a=>a.doctor_id===doctor.id&&activeStatus(a.status)).sort((a,b)=>+new Date(a.starts_at)-+new Date(b.starts_at));
    const laneEnds:number[]=[];const assigned:{id:string;lane:number}[]=[];
    for(const a of list){const s=+new Date(a.starts_at);const e=a.ends_at?+new Date(a.ends_at):s+30*60000;let lane=laneEnds.findIndex(v=>v<=s);if(lane<0){lane=laneEnds.length;laneEnds.push(e)}else laneEnds[lane]=e;assigned.push({id:a.id,lane})}
    const count=Math.max(1,laneEnds.length);for(const x of assigned)laneInfo.set(x.id,{lane:x.lane,count});
  }

  function beginEventDrag(e:ReactPointerEvent<HTMLButtonElement>,a:Appointment){
    if(!activeStatus(a.status)||['completed','done'].includes(a.status))return;
    if((e.target as HTMLElement).closest('.timeline-resize-handle'))return;
    const startX=e.clientX,startY=e.clientY,pointerId=e.pointerId;let moved=false;let target: {doctorId:string;time:string}|null=null;
    const source=e.currentTarget;source.setPointerCapture?.(pointerId);
    const locate=(clientX:number,clientY:number)=>{
      const grid=gridRef.current;if(!grid)return null;const rect=grid.getBoundingClientRect();
      const y=clientY-rect.top-headerHeight;if(y<0)return null;const row=Math.floor(y/rowHeight);if(row<0||row>=rows)return null;
      const minute=startMin+row*step;
      const doctorHeader=Array.from(grid.querySelectorAll<HTMLElement>('.timeline-doctor[data-doctor-id]')).find(node=>{const r=node.getBoundingClientRect();return clientX>=r.left&&clientX<=r.right});
      const doctorId=doctorHeader?.dataset.doctorId;const doctor=doctors.find(d=>d.id===doctorId);
      if(!doctor)return null;const cap=capacityAt(doctor.id,minute,a.id);if(cap.closed||cap.full)return null;
      return {doctorId:doctor.id,time:`${pad(Math.floor(minute/60))}:${pad(minute%60)}`};
    };
    const autoScroll=(clientY:number)=>{const edge=86;if(clientY<edge)window.scrollBy({top:-Math.max(10,(edge-clientY)*.34),behavior:'auto'});else if(clientY>window.innerHeight-edge)window.scrollBy({top:Math.max(10,(clientY-(window.innerHeight-edge))*.34),behavior:'auto'})};
    const move=(ev:PointerEvent)=>{if(!moved&&Math.hypot(ev.clientX-startX,ev.clientY-startY)>4){moved=true;setDraggingId(a.id);document.body.classList.add('calendar-dragging')}if(moved){ev.preventDefault();autoScroll(ev.clientY);target=locate(ev.clientX,ev.clientY);setDragTarget(target);const duration=durationMinutes(a);setGestureHud({x:ev.clientX,y:ev.clientY,text:target?`${target.time} · ${duration} мин`:`${duration} мин`})}};
    const finish=(ev:PointerEvent)=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',finish);window.removeEventListener('pointercancel',finish);document.body.classList.remove('calendar-dragging');setDraggingId(null);setDragTarget(null);setGestureHud(null);if(moved){const now=Date.now();lastGestureEnd.current=now;suppressClickUntil.current=now+520;const finalTarget=target||locate(ev.clientX,ev.clientY);if(finalTarget&&(finalTarget.doctorId!==a.doctor_id||finalTarget.time!==localTime(a.starts_at)))onMove(a,finalTarget.doctorId,finalTarget.time)}};
    window.addEventListener('pointermove',move,{passive:false});window.addEventListener('pointerup',finish,{once:true});window.addEventListener('pointercancel',finish,{once:true});
  }

  function beginColumnResize(e:ReactPointerEvent<HTMLSpanElement>,doctorId:string){
    e.preventDefault();e.stopPropagation();const startX=e.clientX;const startWidth=columnWidths[doctorId]||defaultWidth;const pointerId=e.pointerId;const target=e.currentTarget;target.setPointerCapture?.(pointerId);
    const move=(ev:PointerEvent)=>{const next=Math.max(220,Math.min(620,startWidth+(ev.clientX-startX)));setColumnWidths(v=>({...v,[doctorId]:next}))};
    const finish=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',finish)};
    window.addEventListener('pointermove',move);window.addEventListener('pointerup',finish,{once:true});
  }

  function beginResize(e:ReactPointerEvent<HTMLSpanElement>,a:Appointment){
    e.preventDefault();e.stopPropagation();
    const startY=e.clientY;const startDuration=durationMinutes(a);const target=e.currentTarget;target.setPointerCapture?.(e.pointerId);
    suppressClickUntil.current=Date.now()+800;document.body.classList.add('calendar-resizing');
    const autoScroll=(clientY:number)=>{const edge=90;if(clientY<edge)window.scrollBy({top:-Math.max(10,(edge-clientY)*.32),behavior:'auto'});else if(clientY>window.innerHeight-edge)window.scrollBy({top:Math.max(10,(clientY-(window.innerHeight-edge))*.32),behavior:'auto'})};
    const move=(ev:PointerEvent)=>{ev.preventDefault();autoScroll(ev.clientY);const px=ev.clientY-startY;const raw=startDuration+(px/rowHeight)*step;const next=Math.max(15,Math.min(360,Math.round(raw/15)*15));setResizePreview({id:a.id,duration:next,height:Math.max(34,(next/step)*rowHeight-4)});setGestureHud({x:ev.clientX,y:ev.clientY,text:`${next} мин`})};
    const finish=(ev:PointerEvent)=>{ev.preventDefault();window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',finish);window.removeEventListener('pointercancel',finish);document.body.classList.remove('calendar-resizing');setGestureHud(null);const preview=resizePreview;const px=ev.clientY-startY;const raw=startDuration+(px/rowHeight)*step;const next=preview?.id===a.id?preview.duration:Math.max(15,Math.min(360,Math.round(raw/15)*15));setResizePreview(null);const now=Date.now();lastGestureEnd.current=now;suppressClickUntil.current=now+620;if(next!==startDuration)onResize(a,next)};
    window.addEventListener('pointermove',move,{passive:false});window.addEventListener('pointerup',finish,{once:true});window.addEventListener('pointercancel',finish,{once:true});
  }
  return <div className="timeline-scroll" ref={scrollRef}><div ref={gridRef} data-doctors={doctors.length} className={`schedule-timeline ${holiday||clinicHour?.active===false?'clinic-closed-day':''}`} style={style}>
    <div className="timeline-corner">{shortCalendarDate(date,en)}</div>
    {doctors.length?doctors.map((d,i)=>{const w=doctorWindow(d.id);return <div key={d.id} data-doctor-id={d.id} className="timeline-doctor" style={{gridColumn:i+2,gridRow:1}}><Stethoscope size={14}/><span>{d.full_name}</span><small>{w.closed?(en?'closed':'амарна'):`${en?'parallel':'зэрэг'} ${Math.max(1,Number(w.rule?.max_parallel||3))}`}</small>{!autoFitColumns&&<span className="timeline-column-resize" title={en?'Drag to resize doctor column':'Эмчийн баганын өргөнийг чирж өөрчилнө'} onPointerDown={e=>beginColumnResize(e,d.id)}/>}</div>}):<div className="timeline-doctor" style={{gridColumn:2,gridRow:1}}>{en?'No doctors':'Эмч бүртгэгдээгүй'}</div>}
    {Array.from({length:rows},(_,r)=>{const minute=startMin+r*step;const label=`${pad(Math.floor(minute/60))}:${pad(minute%60)}`;return <div key={`t-${r}`} className="timeline-time" style={{gridColumn:1,gridRow:r+2}}>{label}</div>})}
    {Array.from({length:rows},(_,r)=>doctors.map((d,c)=>{const minute=startMin+r*step;const past=today&&minute+step<=nowMinute;const cap=capacityAt(d.id,minute);const time=`${pad(Math.floor(minute/60))}:${pad(minute%60)}`;const disabled=cap.closed;return <button type="button" aria-label={`${d.full_name} ${time}`} title={cap.closed?(holiday?(en?'Clinic holiday':'Эмнэлэг амарна'):(en?'Outside working hours':'Ажлын бус цаг')):cap.full?(en?'All slots are booked':'Бүх слот товлогдсон'):past?(en?'Past time':'Өнгөрсөн цаг'):(en?`${cap.used}/${cap.limit} booked · click or drop`:`${cap.used}/${cap.limit} товлогдсон · дарж эсвэл чирж байрлуулна`)} disabled={disabled} aria-disabled={disabled||cap.full} onDragOver={e=>{if(!disabled)e.preventDefault()}} onDrop={e=>{e.preventDefault();const id=e.dataTransfer.getData('text/denthub-appointment');const a=appointments.find(x=>x.id===id);if(a&&!disabled&&!capacityAt(d.id,minute,a.id).full)onMove(a,d.id,time)}} onClick={()=>{if(!cap.full&&!disabled)onCreate(d.id,time)}} key={`${d.id}-${r}`} className={`timeline-cell ${cap.closed?'closed':''} ${cap.full?'busy':''} ${cap.used>0&&!cap.full?'partial':''} ${past?'past':''} ${dragTarget?.doctorId===d.id&&dragTarget?.time===time?'drag-target':''}`} style={{gridColumn:c+2,gridRow:r+2}}><span>{cap.used>0?`${cap.used}/${cap.limit}`:''}</span></button>}))}
    {holiday&&<div className="timeline-closed-banner" style={{gridColumn:`2 / span ${colCount}`,gridRow:'2 / -1'}}><Building2/><b>{en?'Clinic is closed on this date':'Энэ өдөр эмнэлэг амарна'}</b><span>{holiday.name||''}</span></div>}
    {showNow&&<div className="timeline-now-line" style={{top:`${headerHeight+((nowMinute-startMin)/step)*rowHeight}px`}}><span>{en?'Now':'Одоо'} {pad(now.getHours())}:{pad(now.getMinutes())}</span></div>}
    {appointments.filter(a=>a.doctor_id&&doctors.some(d=>d.id===a.doctor_id)).map(a=>{
      const d=new Date(a.starts_at);const mins=d.getHours()*60+d.getMinutes();if(mins<startMin||mins>=endMin)return null;
      const minutes=durationMinutes(a);const row=Math.floor((mins-startMin)/step)+2;const span=Math.max(1,Math.ceil(minutes/step));const col=doctors.findIndex(x=>x.id===a.doctor_id)+2;const lane=laneInfo.get(a.id)||{lane:0,count:1};const width=100/lane.count;
      const draggable=activeStatus(a.status)&&!['completed','done'].includes(a.status);
      const preview=resizePreview?.id===a.id?resizePreview:null;const eventHeight=Math.max(30,(minutes/step)*rowHeight-4);
      return <button type="button" key={a.id} className={`timeline-event ${minutes<=step?'short':''} status-${a.status} ${draggable?'draggable':''} ${draggingId===a.id?'is-dragging':''} ${preview?'is-resizing':''}`} style={{gridColumn:col,gridRow:`${row} / span ${span}`,height:`${preview?preview.height:eventHeight}px`,maxHeight:`${preview?preview.height:eventHeight}px`,alignSelf:'start',width:`calc(${width}% - 6px)`,marginLeft:`calc(${lane.lane*width}% + 3px)`,...(preview?{zIndex:45}: {})}} onPointerDown={e=>beginEventDrag(e,a)} onClick={e=>{if(Date.now()<suppressClickUntil.current||Date.now()-lastGestureEnd.current<520||draggingId===a.id||resizePreview?.id===a.id){e.preventDefault();e.stopPropagation();return}onOpen(a)}}><div className="timeline-event-top"><b>{timeText(a.starts_at,en)} · {a.patients?.full_name||'—'}</b><strong className="timeline-duration-badge">{preview?preview.duration:minutes} мин</strong></div><span>{a.service_name||'—'}</span><small className="timeline-status-label">{statusLabel(a.status,en)}</small>{draggable&&<span className="timeline-resize-handle" title={en?'Drag to change duration':'Доош/дээш чирж үргэлжлэх хугацааг өөрчилнө'} onClick={e=>{e.preventDefault();e.stopPropagation()}} onPointerDown={e=>beginResize(e,a)}/>}</button>
    })}
    {gestureHud&&<div className="calendar-gesture-hud" style={{left:gestureHud.x+16,top:gestureHud.y+16}}><Clock3 size={14}/><b>{gestureHud.text}</b></div>}
  </div></div>
}

function ApptMini({a,en,onOpen}:{a:Appointment;en:boolean;onOpen:(a:Appointment)=>void}){const minutes=durationMinutes(a);return <button className="appt-mini" onClick={()=>onOpen(a)}><b>{timeText(a.starts_at,en)} · {a.patients?.full_name||'—'}</b><small>{a.doctor?.full_name||'—'} · {a.service_name||'—'}</small><em>{minutes} мин</em><i className={`appt-status status-${a.status}`}>{statusLabel(a.status,en)}</i></button>}
function WeekView({days,byDate,en,onOpen}:{days:Date[];byDate:(k:string)=>Appointment[];en:boolean;onOpen:(a:Appointment)=>void}){return <div className="appt-week-view">{days.map(d=><div className={`appt-week-day ${dateKey(d)===dateKey(new Date())?'today':''}`} key={dateKey(d)}><header><span>{d.toLocaleDateString(en?'en-US':'mn-MN',{weekday:'short'})}</span><b>{d.getDate()}</b></header><div>{byDate(dateKey(d)).map(a=><ApptMini key={a.id} a={a} en={en} onOpen={onOpen}/>)}</div></div>)}</div>}
function MonthView({days,anchor,byDate,en,onOpen}:{days:Date[];anchor:Date;byDate:(k:string)=>Appointment[];en:boolean;onOpen:(a:Appointment)=>void}){return <div className="appt-month-view">{days.map(d=>{const items=byDate(dateKey(d));return <div className={`appt-month-day ${d.getMonth()!==anchor.getMonth()?'outside':''} ${dateKey(d)===dateKey(new Date())?'today':''}`} key={dateKey(d)}><b>{d.getDate()}</b>{items.slice(0,3).map(a=>{const minutes=durationMinutes(a);return <button key={a.id} onClick={()=>onOpen(a)}><span>{timeText(a.starts_at,en)} · {minutes} мин</span>{a.patients?.full_name||'—'}</button>})}{items.length>3&&<small>+{items.length-3}</small>}</div>})}</div>}
