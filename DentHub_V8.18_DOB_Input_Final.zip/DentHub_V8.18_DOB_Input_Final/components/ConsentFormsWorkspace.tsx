'use client';

import { useEffect, useMemo, useState } from 'react';
import { Check, FileCheck2, Loader2, Pencil, Plus, Printer, Save, Search, ShieldCheck, Trash2, UserRound, X } from 'lucide-react';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import type { AppLang, AppProfile } from './DashboardApp';
import DentSelect from './ui/DentSelect';
import ConfirmDialog from './ui/ConfirmDialog';

type Patient={id:string;full_name:string;patient_code?:string|null;external_patient_id?:string|null;phone?:string|null;register_no?:string|null};
type Consent={id:string;patient_id:string;consent_type:string;title:string;procedure_name?:string|null;consent_text:string;guardian_name?:string|null;doctor_name?:string|null;notes?:string|null;consent_date:string;created_at?:string;updated_at?:string};

type Form={patientId:string;consentType:string;title:string;procedureName:string;consentText:string;guardianName:string;doctorName:string;notes:string;consentDate:string};

const TEMPLATES={
  treatment:{mn:'Эмчилгээний зөвшөөрөл',en:'Treatment consent',bodyMn:'Би дээр дурдсан эмчилгээ, ажилбарын зорилго, явц, боломжит эрсдэл, хүндрэл болон өөр сонголтуудын талаар эмчээс ойлгомжтой тайлбар авсан. Асуух зүйлээ асууж, хангалттай хариулт авсан тул тухайн эмчилгээ, ажилбарыг хийлгэхийг сайн дурын үндсэн дээр зөвшөөрч байна.',bodyEn:'I confirm that the purpose, process, possible risks, complications and alternatives of the proposed treatment/procedure were explained to me. I had the opportunity to ask questions and voluntarily consent to the treatment/procedure.'},
  privacy:{mn:'Мэдээлэл ба нууцлалын зөвшөөрөл',en:'Information & privacy consent',bodyMn:'Би эмнэлгийн тусламж үйлчилгээ үзүүлэх, эмчилгээний түүх хөтлөх, төлбөр тооцоо болон хуульд заасан тайлагналын зорилгоор миний хувийн болон эрүүл мэндийн мэдээллийг шаардлагатай хэмжээнд боловсруулахыг зөвшөөрч байна.',bodyEn:'I consent to the processing of my personal and health information as necessary for care delivery, medical record keeping, billing and legally required reporting.'},
  imaging:{mn:'Рентген / зураг авах зөвшөөрөл',en:'X-ray / imaging consent',bodyMn:'Оношилгоо, эмчилгээний төлөвлөгөө болон явцыг хянах зорилгоор шаардлагатай рентген болон бусад эмнэлгийн зураг авахыг зөвшөөрч байна. Боломжит эрсдэл, хамгаалалтын арга хэмжээний талаар тайлбар авсан.',bodyEn:'I consent to clinically necessary X-rays and other medical images for diagnosis, treatment planning and follow-up. Relevant risks and protective measures were explained to me.'},
  surgery:{mn:'Мэс ажилбарын зөвшөөрөл',en:'Surgical procedure consent',bodyMn:'Надад төлөвлөсөн мэс ажилбарын зорилго, үе шат, мэдээ алдуулалт, боломжит эрсдэл, хүндрэл, эдгэрэлтийн явц болон өөр хувилбаруудыг тайлбарласан. Би сайн дурын үндсэн дээр уг ажилбарыг зөвшөөрч байна.',bodyEn:'The planned surgical procedure, anesthesia, risks, possible complications, recovery and alternatives were explained to me. I voluntarily consent to the procedure.'},
  custom:{mn:'Бусад зөвшөөрөл',en:'Other consent',bodyMn:'Энэхүү зөвшөөрлийн хуудасны агуулгыг уншиж ойлгосон бөгөөд доор дурдсан нөхцөл, ажилбарыг сайн дурын үндсэн дээр зөвшөөрч байна.',bodyEn:'I have read and understood this consent form and voluntarily agree to the conditions/procedure described below.'},
} as const;

function today(){return new Date().toISOString().slice(0,10)}
function phone(v?:string|null){const d=String(v||'').replace(/\D/g,'').replace(/^976/,'');return d.length===8?`${d.slice(0,4)} ${d.slice(4)}`:(v||'—')}
function isDoctorProfile(profile:AppProfile){return profile.role==='employee'&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(String(profile.specialty||''))}

export default function ConsentFormsWorkspace({profile,clinicName,clinicLogoUrl,lang}:{profile:AppProfile;clinicName:string;clinicLogoUrl?:string|null;lang:AppLang}){
  const en=lang==='EN';const clinicId=profile.clinic_id||'';
  const [patients,setPatients]=useState<Patient[]>([]);const [selectedId,setSelectedId]=useState('');const [consents,setConsents]=useState<Consent[]>([]);const [query,setQuery]=useState('');const [loading,setLoading]=useState(true);const [saving,setSaving]=useState(false);const [editingId,setEditingId]=useState<string|null>(null);const [deleteItem,setDeleteItem]=useState<Consent|null>(null);const [error,setError]=useState('');const [notice,setNotice]=useState('');const [printItem,setPrintItem]=useState<Consent|null>(null);
  const defaultType='treatment';const defaultTemplate=TEMPLATES[defaultType];
  const [form,setForm]=useState<Form>({patientId:'',consentType:defaultType,title:defaultTemplate.mn,procedureName:'',consentText:defaultTemplate.bodyMn,guardianName:'',doctorName:profile.full_name||'',notes:'',consentDate:today()});
  const patient=patients.find(p=>p.id===selectedId)||null;
  const filtered=useMemo(()=>{const q=query.toLowerCase();return patients.filter(p=>`${p.full_name} ${p.patient_code||''} ${p.external_patient_id||''} ${p.phone||''}`.toLowerCase().includes(q))},[patients,query]);
  const patientMap=useMemo(()=>new Map(patients.map(p=>[p.id,p])),[patients]);
  const typeOptions=Object.entries(TEMPLATES).map(([value,t])=>({value,label:en?t.en:t.mn}));

  async function token(){const s=getSupabaseBrowser();if(!s)return '';const {data}=await s.auth.getSession();return data.session?.access_token||''}
  async function api(path:string,init?:RequestInit){const t=await token();const res=await fetch(path,{...init,headers:{'Content-Type':'application/json',Authorization:`Bearer ${t}`,...(init?.headers||{})}});const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Алдаа гарлаа.');return body}

  async function loadPatients(){
    if(!clinicId||!isSupabaseConfigured()){setLoading(false);return}const s=getSupabaseBrowser();if(!s)return;setLoading(true);setError('');
    try{let patientIds:string[]|null=null;if(isDoctorProfile(profile)&&profile.id){const [a,e]=await Promise.all([s.from('appointments').select('patient_id').eq('clinic_id',clinicId).eq('doctor_id',profile.id),s.from('encounters').select('patient_id').eq('clinic_id',clinicId).eq('doctor_id',profile.id)]);patientIds=Array.from(new Set([...(a.data||[]),...(e.data||[])].map((x:any)=>String(x.patient_id||'')).filter(Boolean)));if(!patientIds.length){setPatients([]);setSelectedId('');setLoading(false);return}}
      let q=s.from('patients').select('id,full_name,patient_code,external_patient_id,phone,register_no').eq('clinic_id',clinicId).is('deleted_at',null);if(patientIds)q=q.in('id',patientIds);const {data,error:e}=await q.order('full_name');if(e)throw e;const list=(data||[]) as Patient[];setPatients(list);setSelectedId(v=>v&&list.some(p=>p.id===v)?v:(list[0]?.id||''));
    }catch(e:any){setError(e?.message||'Өвчтөн ачаалж чадсангүй.')}finally{setLoading(false)}
  }
  async function loadConsents(patientId:string){if(!patientId){setConsents([]);return}try{const body=await api(`/api/consents?patientId=${encodeURIComponent(patientId)}`);setConsents(body.items||[])}catch(e:any){setError(e.message)}}
  useEffect(()=>{loadPatients()},[clinicId,profile.id,profile.role,profile.specialty]);
  useEffect(()=>{if(selectedId){setForm(v=>({...v,patientId:selectedId}));loadConsents(selectedId)}else setConsents([])},[selectedId]);
  useEffect(()=>{if(!notice)return;const t=window.setTimeout(()=>setNotice(''),2600);return()=>window.clearTimeout(t)},[notice]);

  function applyType(next:string){const t=(TEMPLATES as any)[next]||TEMPLATES.custom;setForm(v=>({...v,consentType:next,title:en?t.en:t.mn,consentText:en?t.bodyEn:t.bodyMn}))}
  function reset(){const t=(TEMPLATES as any)[defaultType];setEditingId(null);setForm({patientId:selectedId,consentType:defaultType,title:en?t.en:t.mn,procedureName:'',consentText:en?t.bodyEn:t.bodyMn,guardianName:'',doctorName:profile.full_name||'',notes:'',consentDate:today()})}
  function edit(item:Consent){setEditingId(item.id);setSelectedId(item.patient_id);setForm({patientId:item.patient_id,consentType:item.consent_type||'custom',title:item.title||'',procedureName:item.procedure_name||'',consentText:item.consent_text||'',guardianName:item.guardian_name||'',doctorName:item.doctor_name||'',notes:item.notes||'',consentDate:item.consent_date||today()});window.scrollTo({top:0,behavior:'smooth'})}
  async function save(){if(!form.patientId||!form.title.trim()||!form.consentText.trim()){setError(en?'Choose a patient and enter the consent title/text.':'Өвчтөн сонгож, зөвшөөрлийн гарчиг ба агуулгыг оруулна уу.');return}setSaving(true);setError('');try{const body={id:editingId||undefined,patientId:form.patientId,consentType:form.consentType,title:form.title,procedureName:form.procedureName,consentText:form.consentText,guardianName:form.guardianName,doctorName:form.doctorName,notes:form.notes,consentDate:form.consentDate};await api('/api/consents',{method:editingId?'PATCH':'POST',body:JSON.stringify(body)});setNotice(editingId?(en?'Consent updated.':'Зөвшөөрлийн хуудас шинэчлэгдлээ.'):(en?'Consent saved.':'Зөвшөөрлийн хуудас хадгалагдлаа.'));await loadConsents(form.patientId);reset()}catch(e:any){setError(e.message)}finally{setSaving(false)}}
  async function remove(){if(!deleteItem)return;setSaving(true);try{await api('/api/consents',{method:'DELETE',body:JSON.stringify({id:deleteItem.id})});setConsents(v=>v.filter(x=>x.id!==deleteItem.id));setDeleteItem(null);setNotice(en?'Consent removed.':'Зөвшөөрлийн хуудас устгагдлаа.')}catch(e:any){setError(e.message)}finally{setSaving(false)}}
  function printConsent(item:Consent){setPrintItem(item);window.setTimeout(()=>window.print(),60)}

  const printPatient=printItem?patientMap.get(printItem.patient_id):null;
  return <div className="page-stack consent-page">
    <header className="page-head"><div><small>{clinicName}</small><h1>{en?'Consent forms':'Зөвшөөрлийн хуудас'}</h1><p>{en?'Create, save and print patient consent forms with the clinic logo and identity.':'Өвчтөний зөвшөөрлийн хуудсыг эмнэлгийн лого, нэртэйгээр үүсгэж хадгалаад хэвлэнэ.'}</p></div><span className="icon-cube"><ShieldCheck/></span></header>
    {notice&&<div className="app-toast success"><Check size={16}/><span>{notice}</span></div>}{error&&<div className="form-error">{error}</div>}
    <section className="consent-layout">
      <aside className="panel-card consent-patient-panel"><div className="module-search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={en?'Search patient…':'Өвчтөн хайх…'}/></div>{loading?<div className="purchase-loading"><Loader2 className="spin"/></div>:<div className="consent-patient-list">{filtered.map(p=><button key={p.id} className={selectedId===p.id?'active':''} onClick={()=>{setSelectedId(p.id);setEditingId(null)}}><UserRound size={17}/><span><b>{p.full_name}</b><small>{[p.patient_code||p.external_patient_id,phone(p.phone)].filter(Boolean).join(' · ')}</small></span></button>)}</div>}</aside>
      <main className="panel-card consent-editor">
        <div className="consent-brand-preview">{clinicLogoUrl?<img src={clinicLogoUrl} alt={`${clinicName} logo`}/>:<span className="consent-brand-placeholder"><FileCheck2/></span>}<div><b>{clinicName}</b><small>{en?'PATIENT CONSENT FORM':'ӨВЧТӨНИЙ ЗӨВШӨӨРЛИЙН ХУУДАС'}</small></div></div>
        <div className="consent-editor-head"><div><small>{patient?`${patient.full_name} · ${patient.patient_code||patient.external_patient_id||''}`:(en?'Choose patient':'Өвчтөн сонгоно уу')}</small><h2>{editingId?(en?'Edit consent':'Зөвшөөрөл засах'):(en?'New consent':'Шинэ зөвшөөрөл')}</h2></div>{editingId&&<button className="btn-secondary" onClick={reset}><X size={16}/>{en?'Cancel edit':'Засвар болих'}</button>}</div>
        <div className="modal-fields consent-fields">
          <label><span>{en?'Consent type':'Зөвшөөрлийн төрөл'}</span><DentSelect value={form.consentType} onChange={applyType} options={typeOptions}/></label>
          <label><span>{en?'Date':'Огноо'}</span><input type="date" value={form.consentDate} onChange={e=>setForm(v=>({...v,consentDate:e.target.value}))}/></label>
          <label className="wide"><span>{en?'Title':'Гарчиг'}</span><input value={form.title} onChange={e=>setForm(v=>({...v,title:e.target.value}))}/></label>
          <label className="wide"><span>{en?'Treatment / procedure':'Эмчилгээ / ажилбар'}</span><input value={form.procedureName} onChange={e=>setForm(v=>({...v,procedureName:e.target.value}))} placeholder={en?'Optional treatment or procedure':'Хийх эмчилгээ, ажилбар (заавал биш)'}/></label>
          <label className="wide"><span>{en?'Consent text':'Зөвшөөрлийн агуулга'}</span><textarea rows={8} value={form.consentText} onChange={e=>setForm(v=>({...v,consentText:e.target.value}))}/></label>
          <label><span>{en?'Guardian / representative':'Асран хамгаалагч'}</span><input value={form.guardianName} onChange={e=>setForm(v=>({...v,guardianName:e.target.value}))}/></label>
          <label><span>{en?'Doctor / staff':'Эмч / ажилтан'}</span><input value={form.doctorName} onChange={e=>setForm(v=>({...v,doctorName:e.target.value}))}/></label>
          <label className="wide"><span>{en?'Note':'Тэмдэглэл'}</span><textarea rows={3} value={form.notes} onChange={e=>setForm(v=>({...v,notes:e.target.value}))}/></label>
        </div>
        <div className="consent-editor-actions"><button className="btn-primary" onClick={save} disabled={!selectedId||saving}>{saving?<Loader2 className="spin" size={17}/>:<Save size={17}/>} {editingId?(en?'Save changes':'Өөрчлөлт хадгалах'):(en?'Save consent':'Зөвшөөрөл хадгалах')}</button></div>
      </main>
    </section>
    <section className="panel-card consent-history"><div className="panel-head"><div><h2>{en?'Saved consent forms':'Хадгалсан зөвшөөрлийн хуудас'}</h2><p>{patient?.full_name||''}</p></div><span className="ledger-count">{consents.length}</span></div>{!selectedId?<div className="empty-state"><UserRound/><b>{en?'Choose a patient':'Өвчтөн сонгоно уу'}</b></div>:consents.length?<div className="consent-history-list">{consents.map(item=><article key={item.id}><div><b>{item.title}</b><small>{item.consent_date} · {item.doctor_name||'—'}{item.procedure_name?` · ${item.procedure_name}`:''}</small></div><div className="consent-row-actions"><button className="btn-light" onClick={()=>printConsent(item)}><Printer size={15}/>{en?'Print':'Хэвлэх'}</button><button className="btn-light" onClick={()=>edit(item)}><Pencil size={15}/>{en?'Edit':'Засах'}</button>{profile.role==='owner'&&<button className="btn-light danger" onClick={()=>setDeleteItem(item)}><Trash2 size={15}/>{en?'Delete':'Устгах'}</button>}</div></article>)}</div>:<div className="empty-state"><FileCheck2/><b>{en?'No consent forms yet':'Зөвшөөрлийн хуудас алга'}</b></div>}</section>

    {printItem&&<article className="consent-print-root" aria-hidden="true"><header className="consent-print-header"><div className="consent-print-brand">{clinicLogoUrl&&<img src={clinicLogoUrl} alt={`${clinicName} logo`}/>}<div><b>{clinicName}</b><span>{printItem.title}</span></div></div><strong>Огноо: {printItem.consent_date}</strong></header><section className="consent-print-patient"><div><span>Өвчтөн:</span><b>{printPatient?.full_name||'—'}</b></div><div><span>Patient ID:</span><b>{printPatient?.patient_code||printPatient?.external_patient_id||'—'}</b></div><div><span>Утас:</span><b>{phone(printPatient?.phone)}</b></div><div><span>Регистр:</span><b>{printPatient?.register_no||'—'}</b></div></section>{printItem.procedure_name&&<section className="consent-print-procedure"><b>Эмчилгээ / ажилбар:</b><p>{printItem.procedure_name}</p></section>}<section className="consent-print-body"><p>{printItem.consent_text}</p></section>{printItem.notes&&<section className="consent-print-note"><b>Тэмдэглэл:</b><p>{printItem.notes}</p></section>}<section className="consent-signatures"><div><span>Өвчтөн / асран хамгаалагчийн нэр</span><b>{printItem.guardian_name||printPatient?.full_name||''}</b><i>Гарын үсэг: ____________________</i></div><div><span>Эмч / ажилтан</span><b>{printItem.doctor_name||profile.full_name}</b><i>Гарын үсэг: ____________________</i></div></section></article>}
    <ConfirmDialog open={Boolean(deleteItem)} title={en?'Delete this consent form?':'Энэ зөвшөөрлийн хуудсыг устгах уу?'} description={en?'The record will be hidden from normal use but audit fields are retained.':'Энгийн жагсаалтаас алга болох боловч audit мэдээлэл хадгалагдана.'} confirmLabel={en?'Delete':'Устгах'} cancelLabel={en?'Cancel':'Болих'} busy={saving} onCancel={()=>!saving&&setDeleteItem(null)} onConfirm={remove}/>
  </div>
}
