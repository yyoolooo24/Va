'use client';

import { Bell, Heart, MessageCircle, UserPlus, CheckCircle2, ArrowUpRight } from 'lucide-react';
import type { AppLang, NotificationItem } from './DashboardApp';

function Icon({type}:{type:NotificationItem['type']}){
  if(type==='comment') return <MessageCircle/>;
  if(type==='like') return <Heart/>;
  if(type==='connection'||type==='follow') return <UserPlus/>;
  return <Bell/>;
}

export default function Notifications({items,onOpen,onMarkAll,lang}:{items:NotificationItem[];onOpen:(item:NotificationItem)=>void;onMarkAll:()=>void;lang:AppLang}) {
  const en=lang==='EN';
  const unread=items.filter(i=>i.unread).length;
  return <div className="page-stack notifications-page">
    <header className="page-head"><div><small>{en?'Recent activity':'Таны шинэ үйлдлүүд'}</small><h1>{en?'Notifications':'Мэдэгдэл'}</h1><p>{en?'Open chat, appointment and system notifications from one place.':'Чат, цаг товлол болон системийн мэдэгдлээ нэг дороос нээнэ.'}</p></div>{unread>0&&<button className="btn-secondary" onClick={onMarkAll}><CheckCircle2 size={18}/> {en?'Mark all as read':'Бүгдийг уншсан болгох'}</button>}</header>
    <section className="notification-list-pro">
      {items.length===0?<div className="empty-state"><Bell/><b>{en?'No notifications yet':'Мэдэгдэл алга'}</b></div>:items.map(item=><button key={item.id} className={`notification-row ${item.unread?'unread':''}`} onClick={()=>onOpen(item)}>
        <span className="icon-cube"><Icon type={item.type}/></span>
        <div><b>{item.title}</b><p>{item.detail}</p><small>{item.time}</small></div>
        {item.unread&&<span className="unread-dot"/>}<ArrowUpRight className="row-open" size={18}/>
      </button>)}
    </section>
  </div>;
}
