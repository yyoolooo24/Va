'use client';

import {
  ArrowLeftRight, BadgePercent, Banknote, Boxes, CircleDollarSign, ContactRound, FileText,
  HandCoins, Landmark, PackageSearch, ReceiptText, RotateCcw, ShieldPlus, ShoppingBag,
  ShoppingCart, Tags, TestTube2, Truck, UserCog, Warehouse, Wrench, Clock3, ClipboardList, BookOpenCheck, Building2
} from 'lucide-react';
import type { AppLang, AppProfile, ViewKey } from './DashboardApp';

type Card={key:ViewKey;mn:string;en:string;mnDesc:string;enDesc:string;icon:any};
type Group={mn:string;en:string;cards:Card[]};

const groups:Group[]=[
  {mn:'POS & борлуулалт',en:'POS & sales',cards:[
    {key:'sales',mn:'Борлуулалт',en:'Sales',mnDesc:'Өвчтөн ID-гаар холбосон борлуулалт, төлбөрийн хэлбэр.',enDesc:'Patient-ID linked sales and payment methods.',icon:ShoppingBag},
    {key:'sales_returns',mn:'Буцаалт',en:'Returns',mnDesc:'Өмнөх борлуулалттай холбосон буцаалт, шалтгаан.',enDesc:'Returns linked to prior sales with reasons.',icon:RotateCcw},
    {key:'cashbook',mn:'Кассын журнал',en:'Cashbook',mnDesc:'Кассын орлого, зарлага, төлбөрийн сувгийн хөдөлгөөн.',enDesc:'Cash in/out and payment-channel movement.',icon:Banknote},
    {key:'price_lists',mn:'Үнийн жагсаалт',en:'Price lists',mnDesc:'Үйлчилгээ, барааны тариф болон идэвхтэй үнэ.',enDesc:'Active service and product price lists.',icon:BadgePercent},
  ]},
  {mn:'Үйлчилгээ & авлага',en:'Service & receivables',cards:[
    {key:'services',mn:'Үйлчилгээ & үнэ',en:'Services & pricing',mnDesc:'Ангилал → үйлчилгээ → хувилбарын бүтэц.',enDesc:'Category → service → variant hierarchy.',icon:Tags},
    {key:'invoices',mn:'Нэхэмжлэх',en:'Invoices',mnDesc:'Өвчтөнтэй ID-аар холбосон нэхэмжлэх.',enDesc:'Invoices linked to the correct patient ID.',icon:ReceiptText},
    {key:'receivables',mn:'Авлага',en:'Receivables',mnDesc:'Төлөгдөөгүй дүн, хугацаа, өвчтөний холбоос.',enDesc:'Outstanding balances, due dates and patient links.',icon:HandCoins},
    {key:'crm',mn:'CRM',en:'CRM',mnDesc:'Харилцагчийн холбоо, follow-up, тэмдэглэл.',enDesc:'Contacts, follow-ups and notes.',icon:ContactRound},
  ]},
  {mn:'Хангамж & агуулах',en:'Supply & inventory',cards:[
    {key:'inventory',mn:'Бараа материал',en:'Inventory',mnDesc:'Үлдэгдэл, SKU, batch/lot, хүчинтэй хугацаа, дахин захиалах босго.',enDesc:'Stock, SKU, batch/lot, expiry and reorder thresholds.',icon:Boxes},
    {key:'stock_movements',mn:'Барааны хөдөлгөөн',en:'Stock movement',mnDesc:'Орлого, зарлага, бодит үлдэгдэл болон хөдөлгөөн хийсэн ажилтан.',enDesc:'Stock in/out, resulting balance and responsible employee.',icon:ArrowLeftRight},
    {key:'suppliers',mn:'Ханган нийлүүлэгч',en:'Suppliers',mnDesc:'Нийлүүлэгчийн бүртгэл, холбоо, нөхцөл.',enDesc:'Supplier directory, contacts and terms.',icon:Truck},
    {key:'procurement',mn:'Худалдан авалт',en:'Procurement',mnDesc:'Худалдан авах хүсэлт, нийлүүлэгч, төсөв.',enDesc:'Purchase requests, suppliers and budgets.',icon:ShoppingCart},
    {key:'purchase_orders',mn:'Захиалга / PO',en:'Purchase orders',mnDesc:'PO дугаар, нийлүүлэгч, төлөв.',enDesc:'PO references, suppliers and statuses.',icon:ClipboardList},
  ]},
  {mn:'Эмнэлгийн ажиллагаа',en:'Clinical operations',cards:[
    {key:'lab_orders',mn:'Лабораторийн захиалга',en:'Lab orders',mnDesc:'Өвчтөнтэй холбосон лабораторийн ажлын урсгал.',enDesc:'Patient-linked dental lab workflow.',icon:TestTube2},
    {key:'insurance',mn:'Даатгал',en:'Insurance',mnDesc:'Өвчтөн, claim, баталгаажуулалтын төлөв.',enDesc:'Patient, claim and approval status.',icon:ShieldPlus},
  ]},
  {mn:'Хүний нөөц & салбар',en:'People & locations',cards:[
    {key:'staff',mn:'Ажилтнууд',en:'Staff',mnDesc:'Ажилтан, албан тушаал, модулийн эрх, гэрээ ба мэргэжлийн баримт.',enDesc:'Staff, positions, permissions and HR/compliance documents.',icon:UserCog},
    {key:'shifts',mn:'Ээлж & цагийн хуваарь',en:'Shifts & roster',mnDesc:'Ажилтны ээлж, эхлэх/дуусах цаг.',enDesc:'Staff shifts and roster.',icon:Clock3},
    {key:'branches',mn:'Салбарууд',en:'Branches',mnDesc:'Салбар, хаяг, менежер.',enDesc:'Branches, addresses and managers.',icon:Warehouse},
    {key:'assets',mn:'Үндсэн хөрөнгө',en:'Assets',mnDesc:'Тоног төхөөрөмж, серийн дугаар, байршил.',enDesc:'Equipment, serials and locations.',icon:Wrench},
  ]},
  {mn:'Санхүү & хяналт',en:'Finance & control',cards:[
    {key:'expenses',mn:'Зардал',en:'Expenses',mnDesc:'Зардлын ангилал, төлбөрийн хэлбэр.',enDesc:'Expense categories and payment methods.',icon:CircleDollarSign},
    {key:'finance',mn:'Санхүү',en:'Finance',mnDesc:'Төлөх өглөг, эмнэлгийн өр/зээл, тогтмол зардал.',enDesc:'Payables, clinic debt and recurring expenses.',icon:Landmark},
    {key:'reports',mn:'Тайлан',en:'Reports',mnDesc:'Сарын тайлан болон жилийн эцсийн тайланг тусад нь гаргана.',enDesc:'Separate monthly and year-end operational/financial reports.',icon:FileText},
    {key:'internal_procedures',mn:'Дотоод журам',en:'Internal procedures',mnDesc:'20 журам, хувилбарын хяналт, ажилтны танилцсан бүртгэл.',enDesc:'Twenty procedures, version control and staff acknowledgement.',icon:BookOpenCheck},
    {key:'health_department',mn:'Нийслэлийн ЭМГ',en:'Health Department',mnDesc:'НЭМГ-т өгөх тайлан, бичиг баримтыг ангиллаар удирдана.',enDesc:'Category-based regulatory reports and document workspace.',icon:Building2},
  ]},
];

export default function ERPOverview({profile,clinicName,lang,onNavigate}:{profile:AppProfile;clinicName:string;lang:AppLang;onNavigate:(view:ViewKey)=>void}){
  const en=lang==='EN';
  const visibleGroups=groups.map(group=>({...group,cards:profile.role==='employee'&&profile.allowed_modules?.length?group.cards.filter(card=>profile.allowed_modules!.includes(card.key)):group.cards})).filter(g=>g.cards.length);
  const visibleCount=visibleGroups.reduce((n,g)=>n+g.cards.length,0);
  return <div className="page-stack erp-overview">
    <header className="page-head"><div><small>{clinicName}</small><h1>{en?'ERP & POS operations':'ERP & POS ажиллагаа'}</h1><p>{en?'A fast operational flow inside DentHub with patient identity, inventory and clinical links.':'DentHub-ийн өвчтөн, агуулах, эмчилгээний мэдээллийг нэг хурдан урсгалд холбоно.'}</p></div><span className="erp-count">{visibleCount} {en?'modules':'модуль'}</span></header>
    <section className="erp-overview-hero panel-card"><div><small>DENTHUB OPERATIONS</small><h2>{en?'One patient. One identity. Every transaction linked.':'Нэг өвчтөн. Нэг ID. Бүх гүйлгээ зөв хүнтэй холбогдоно.'}</h2><p>{en?'Sales, invoices, receivables and clinical records use the registered patient instead of repeating names manually.':'Борлуулалт, нэхэмжлэх, авлага, эмчилгээний бүртгэлд нэрийг дахин гараар бичихгүй — бүртгэлтэй өвчтөнийг сонгож ID-гаар холбоно.'}</p></div><div className="erp-overview-metrics"><span><b>ID</b><small>{en?'Patient-linked':'Өвчтөнтэй холбоно'}</small></span><span><b>POS</b><small>{en?'Sales flow':'Борлуулалтын урсгал'}</small></span><span><b>ERP</b><small>{en?'Stock & finance':'Агуулах & санхүү'}</small></span><span><b>RBAC</b><small>{en?'Role access':'Эрхийн хяналт'}</small></span></div></section>
    {visibleGroups.map(group=><section className="erp-group" key={group.en}><div className="section-title"><h2>{en?group.en:group.mn}</h2><span>{group.cards.length}</span></div><div className="erp-card-grid">{group.cards.map(card=>{const Icon=card.icon;return <button className="erp-module-card" key={card.key} onClick={()=>onNavigate(card.key)}><span className="icon-cube"><Icon/></span><div><b>{en?card.en:card.mn}</b><p>{en?card.enDesc:card.mnDesc}</p></div><span className="erp-arrow">→</span></button>})}</div></section>)}
    {profile.role!=='owner'&&profile.role!=='platform_admin'&&<p className="erp-access-note">{en?'Only modules assigned to your role are shown here.':'Таны эрхэд оноосон модулиудыг л энд харуулна.'}</p>}
  </div>
}
