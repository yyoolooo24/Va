'use client';

import { useEffect, useMemo, useState } from 'react';
import {
  Archive, Ban, CheckCircle2, Clock3, Loader2, MoreHorizontal, Pencil, RotateCcw,
  Search, Send, Trash2, X,
} from 'lucide-react';
import { getSupabaseBrowser } from '@/lib/supabase-browser';
import {
  BUILTIN_SUBSCRIPTION_PLANS, MODULE_LABELS, sanitizeClinicModules, type ClinicModule, type SubscriptionPlanDefinition,
} from '@/lib/subscription';
import type { AppLang } from './DashboardApp';
import DentSelect from './ui/DentSelect';
import ConfirmDialog from './ui/ConfirmDialog';
import ModuleAccessPicker from './ModuleAccessPicker';
import DentDatePicker from './ui/DentDatePicker';

type ClinicRow = {
  id:string;name:string;plan:string;status:string;enabled_modules:string[];employee_limit:number;
  subscription_price?:number|null;billing_cycle?:string|null;subscription_started_at?:string|null;subscription_ends_at?:string|null;
  trial_ends_at?:string|null;grace_ends_at?:string|null;platform_notes?:string|null;created_at:string;users?:number;
};
type RequestRow={id:string;clinic_id:string;modules:string[];note?:string|null;status:string;created_at:string};
type ConfirmAction='suspend'|'archive'|'permanent_delete';
type ClinicFilter='current'|'pending'|'archived'|'all';
type PlanRow=SubscriptionPlanDefinition;

function statusLabel(status:string,en:boolean){
  const labels:Record<string,[string,string]>={active:['Active','Идэвхтэй'],trial:['Trial','Туршилт'],pending:['Pending','Хүлээгдэж буй'],past_due:['Past due','Хугацаа хэтэрсэн'],suspended:['Suspended','Түр хаасан'],cancelled:['Cancelled','Цуцалсан'],archived:['Archived','Архивласан']};
  const value=labels[status]||[status,status];return en?value[0]:value[1];
}
function addMonths(date:Date,months:number){const d=new Date(date);d.setMonth(d.getMonth()+months);return d.toISOString().slice(0,10)}

export default function PlatformClinicControl({lang}:{lang:AppLang}){
  const en=lang==='EN';
  const [clinics,setClinics]=useState<ClinicRow[]>([]);
  const [requests,setRequests]=useState<RequestRow[]>([]);
  const [plans,setPlans]=useState<PlanRow[]>(BUILTIN_SUBSCRIPTION_PLANS);
  const [loading,setLoading]=useState(true);
  const [busy,setBusy]=useState('');
  const [notice,setNotice]=useState<{kind:'success'|'error';text:string}|null>(null);
  const [edit,setEdit]=useState<ClinicRow|null>(null);
  const [menuClinicId,setMenuClinicId]=useState<string|null>(null);
  const [confirm,setConfirm]=useState<{clinic:ClinicRow;action:ConfirmAction}|null>(null);
  const [filter,setFilter]=useState<ClinicFilter>('current');
  const [search,setSearch]=useState('');
  const [moduleSearch,setModuleSearch]=useState('');
  const [form,setForm]=useState({plan:'START',modules:[] as string[],employeeLimit:'25',price:'',billingCycle:'monthly',subscriptionEndsAt:'',trialEndsAt:'',graceEndsAt:'',notes:''});

  async function token(){const s=getSupabaseBrowser();const {data}=s?await s.auth.getSession():({data:{session:null}} as any);return data.session?.access_token||''}

  async function loadPlans(){
    const s=getSupabaseBrowser();if(!s)return;
    const {data,error}=await s.from('platform_subscription_plans').select('code,name_mn,name_en,description_mn,description_en,enabled_modules,employee_limit,price,billing_cycle,duration_months,active,sort_order').eq('active',true).order('sort_order');
    if(!error&&data?.length)setPlans(data.map((p:any)=>({...p,enabled_modules:sanitizeClinicModules(p.enabled_modules),employee_limit:Number(p.employee_limit||1),price:Number(p.price||0),duration_months:Number(p.duration_months||1),active:p.active!==false,sort_order:Number(p.sort_order||0)})) as PlanRow[]);
  }

  async function load(){
    const s=getSupabaseBrowser();if(!s)return;setLoading(true);
    try{
      const [{data:c,error:ce},{data:r,error:re},{data:p,error:pe}]=await Promise.all([
        s.from('clinics').select('id,name,plan,status,enabled_modules,employee_limit,subscription_price,billing_cycle,subscription_started_at,subscription_ends_at,trial_ends_at,grace_ends_at,platform_notes,created_at').order('created_at',{ascending:false}),
        s.from('clinic_module_requests').select('id,clinic_id,modules,note,status,created_at').eq('status','pending').order('created_at',{ascending:false}),
        s.from('profiles').select('clinic_id').in('role',['owner','employee']).eq('active',true),
      ]);
      if(ce)throw ce;if(re)throw re;if(pe)throw pe;
      const counts=new Map<string,number>();(p||[]).forEach((x:any)=>x.clinic_id&&counts.set(x.clinic_id,(counts.get(x.clinic_id)||0)+1));
      setClinics((c||[]).map((x:any)=>({...x,enabled_modules:x.enabled_modules||[],users:counts.get(x.id)||0})));
      setRequests((r||[]) as RequestRow[]);await loadPlans();
    }catch(e:any){setNotice({kind:'error',text:e?.message||(en?'Could not load clinic data.':'Эмнэлгийн мэдээллийг ачаалж чадсангүй.')})}finally{setLoading(false)}
  }
  useEffect(()=>{void load()},[]);
  useEffect(()=>{if(!notice)return;const id=window.setTimeout(()=>setNotice(null),5200);return()=>window.clearTimeout(id)},[notice]);

  const planMap=useMemo(()=>new Map(plans.map(p=>[p.code,p])),[plans]);
  const planOptions=useMemo(()=>plans.map(p=>({value:p.code,label:`${en?p.name_en:p.name_mn} · ${p.enabled_modules.length} ${en?'modules':'модуль'}`})),[plans,en]);
  const clinicById=useMemo(()=>new Map(clinics.map(c=>[c.id,c])),[clinics]);
  const pending=clinics.filter(c=>c.status==='pending');
  const visibleClinics=useMemo(()=>clinics.filter(c=>{
    const q=search.trim().toLowerCase();if(q&&!`${c.name} ${c.plan} ${c.status}`.toLowerCase().includes(q))return false;
    if(filter==='pending')return c.status==='pending';if(filter==='archived')return c.status==='archived';if(filter==='current')return c.status!=='archived'&&c.status!=='pending';return true;
  }),[clinics,filter,search]);

  function planName(code:string){const p=planMap.get(code);return p?(en?p.name_en:p.name_mn):code}
  function applyPlan(code:string){
    const p=planMap.get(code);if(!p){setForm(v=>({...v,plan:code}));return}
    setForm(v=>({...v,plan:code,modules:[...p.enabled_modules],employeeLimit:String(p.employee_limit),price:p.price?String(p.price):'',billingCycle:p.billing_cycle,subscriptionEndsAt:addMonths(new Date(),p.duration_months||1)}));
  }
  function openEditor(c:ClinicRow){
    setEdit(c);setMenuClinicId(null);setModuleSearch('');
    setForm({plan:c.plan||'START',modules:c.enabled_modules||[],employeeLimit:String(c.employee_limit||25),price:c.subscription_price==null?'':String(c.subscription_price),billingCycle:c.billing_cycle||'monthly',subscriptionEndsAt:c.subscription_ends_at?.slice(0,10)||'',trialEndsAt:c.trial_ends_at?.slice(0,10)||'',graceEndsAt:c.grace_ends_at?.slice(0,10)||'',notes:c.platform_notes||''});
    setNotice(null);
  }

  async function call(action:string,clinicId:string,extra:Record<string,any>={}){
    setBusy(`${action}:${clinicId}`);setMenuClinicId(null);setNotice(null);
    try{
      const t=await token();const res=await fetch('/api/admin/clinic-subscription',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${t}`},body:JSON.stringify({action,clinicId,...extra})});
      const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Action failed');
      const text=action==='archive'?(en?'Clinic removed from the active list. Its history is preserved.':'Эмнэлгийг идэвхтэй жагсаалтаас хаслаа. Өмнөх түүх бүрэн хадгалагдана.'):action==='permanent_delete'?(en?'Empty test clinic permanently deleted.':'Хоосон тест эмнэлгийг бүр мөсөн устгалаа.'):(en?'Changes saved successfully.':'Өөрчлөлт амжилттай хадгалагдлаа.');
      setNotice({kind:'success',text});setEdit(null);setConfirm(null);await load();
    }catch(e:any){setNotice({kind:'error',text:e?.message||(en?'Something went wrong.':'Үйлдлийг гүйцэтгэж чадсангүй.')})}finally{setBusy('')}
  }
  async function save(action:'approve'|'update'){
    if(!edit)return;await call(action,edit.id,{plan:form.plan,enabledModules:form.modules,employeeLimit:Number(form.employeeLimit||25),subscriptionPrice:form.price,billingCycle:form.billingCycle,subscriptionEndsAt:form.subscriptionEndsAt,trialEndsAt:form.trialEndsAt,graceEndsAt:form.graceEndsAt,platformNotes:form.notes});
  }

  return <div className="platform-clinic-control">
    {notice&&<div className={`platform-action-toast ${notice.kind}`} role="status"><div>{notice.kind==='success'?<CheckCircle2 size={17}/>:<X size={17}/>}<span>{notice.text}</span></div><button onClick={()=>setNotice(null)} aria-label={en?'Close':'Хаах'}><X size={15}/></button></div>}

    {pending.length>0&&<section className="panel-card platform-approval-card"><div className="panel-head"><div><h2>{en?'Awaiting approval':'Зөвшөөрөл хүлээж буй'}</h2><p>{en?'Review a clinic before its workspace becomes available.':'Эмнэлгийн хүсэлтийг шалгасны дараа системийн нэвтрэх эрхийг идэвхжүүлнэ.'}</p></div><span className="status-count">{pending.length}</span></div><div className="platform-clinic-list">{pending.map(c=><article key={c.id}><span className="row-leading-icon"><Clock3 size={17}/></span><div><b>{c.name}</b><small>{new Date(c.created_at).toLocaleString(en?'en-US':'mn-MN')} · {c.users||0} {en?'users':'хэрэглэгч'}</small></div><button className="btn-primary compact" onClick={()=>openEditor(c)}><CheckCircle2 size={15}/>{en?'Review':'Шалгах'}</button></article>)}</div></section>}

    {requests.length>0&&<section className="panel-card platform-request-card"><div className="panel-head"><div><h2>{en?'Module requests':'Модулийн хүсэлт'}</h2><p>{en?'Approve or reject additional access requested by clinic owners.':'Эмнэлгийн эзэмшигчийн нэмэлт модуль авах хүсэлтийг зөвшөөрөх эсвэл татгалзана.'}</p></div><Send size={18}/></div><div className="platform-request-list">{requests.map(r=><article key={r.id}><div><b>{clinicById.get(r.clinic_id)?.name||r.clinic_id}</b><small>{r.modules.map(m=>MODULE_LABELS[m as ClinicModule]?.[en?'en':'mn']||m).join(' · ')}</small>{r.note&&<p>{r.note}</p>}</div><div><button className="btn-primary compact" disabled={!!busy} onClick={()=>call('approve_request',r.clinic_id,{requestId:r.id})}>{en?'Approve':'Зөвшөөрөх'}</button><button className="btn-secondary compact" disabled={!!busy} onClick={()=>call('reject_request',r.clinic_id,{requestId:r.id})}>{en?'Reject':'Татгалзах'}</button></div></article>)}</div></section>}

    <section className="panel-card platform-directory-card">
      <div className="platform-directory-toolbar"><div><h2>{en?'Clinics':'Эмнэлгүүд'}</h2><p>{en?'Manage access without deleting medical or accounting history.':'Багц, эрх, ажилтны хязгаар болон төлөвийг удирдана. Архивласан эмнэлгийн түүх хадгалагдана.'}</p></div><label className="platform-clinic-search"><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={en?'Search clinics…':'Эмнэлэг хайх…'}/></label></div>
      <div className="clinic-filter-tabs">{(['current','pending','archived','all'] as ClinicFilter[]).map(key=><button key={key} className={filter===key?'active':''} onClick={()=>setFilter(key)}>{key==='current'?(en?'Current':'Идэвхтэй'):key==='pending'?(en?'Pending':'Хүлээгдэж буй'):key==='archived'?(en?'Archive':'Архив'):(en?'All':'Бүгд')}<span>{key==='current'?clinics.filter(c=>c.status!=='archived'&&c.status!=='pending').length:key==='pending'?pending.length:key==='archived'?clinics.filter(c=>c.status==='archived').length:clinics.length}</span></button>)}</div>
      {loading?<div className="purchase-loading"><Loader2 className="spin"/> {en?'Loading…':'Ачаалж байна…'}</div>:<div className="platform-clinic-table"><div className="clinic-control-head" aria-hidden="true"><span>{en?'Clinic':'Эмнэлэг'}</span><span>{en?'Status':'Төлөв'}</span><span>{en?'Actions':'Үйлдэл'}</span></div>{visibleClinics.map(c=><article key={c.id} className={`clinic-control-row status-${c.status}`}><div className="clinic-control-copy"><b>{c.name}</b><small>{planName(c.plan)} · {c.enabled_modules.length} {en?'modules':'модуль'} · {c.users||0}/{c.employee_limit} {en?'staff':'ажилтан'}</small></div><span className={`status-pill ${c.status}`}>{statusLabel(c.status,en)}</span><div className="clinic-control-actions"><button className="clinic-edit-action" title={en?'Edit subscription':'Багц, эрх засах'} onClick={()=>openEditor(c)}><Pencil size={14}/><span>{en?'Edit':'Засах'}</span></button><div className="clinic-more-wrap"><button className="clinic-more-trigger" aria-label={en?'More actions':'Бусад үйлдэл'} aria-expanded={menuClinicId===c.id} onClick={()=>setMenuClinicId(v=>v===c.id?null:c.id)}><MoreHorizontal size={17}/></button>{menuClinicId===c.id&&<div className="clinic-more-menu">{['suspended','cancelled','archived'].includes(c.status)?<button onClick={()=>call('reactivate',c.id)}><RotateCcw size={15}/>{en?'Restore access':'Эрх сэргээх'}</button>:c.status!=='pending'?<button onClick={()=>{setMenuClinicId(null);setConfirm({clinic:c,action:'suspend'})}}><Ban size={15}/>{en?'Suspend access':'Эрх түр хаах'}</button>:null}{c.status!=='archived'&&<button onClick={()=>{setMenuClinicId(null);setConfirm({clinic:c,action:'archive'})}}><Archive size={15}/>{en?'Remove from active list':'Идэвхтэй жагсаалтаас хасах'}</button>}{c.status==='archived'&&<button className="danger" onClick={()=>{setMenuClinicId(null);setConfirm({clinic:c,action:'permanent_delete'})}}><Trash2 size={15}/>{en?'Delete empty test clinic':'Хоосон тест эмнэлгийг устгах'}</button>}</div>}</div></div></article>)}{!visibleClinics.length&&<div className="clinic-directory-empty">{en?'No clinics in this view.':'Энэ хэсэгт эмнэлэг алга.'}</div>}</div>}
    </section>

    {edit&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&!busy&&setEdit(null)}><div className="modal-card subscription-modal"><header><div><small>{edit.name}</small><h2>{edit.status==='pending'?(en?'Approve clinic':'Эмнэлэг зөвшөөрөх'):(en?'Subscription & access':'Багц ба нэвтрэх эрх')}</h2></div><button onClick={()=>!busy&&setEdit(null)}><X/></button></header><div className="subscription-modal-scroll"><div className="subscription-form"><label>{en?'Plan':'Багц'}<DentSelect value={form.plan} onChange={applyPlan} options={planOptions}/></label><label>{en?'Staff limit':'Ажилтны хязгаар'}<input inputMode="numeric" value={form.employeeLimit} onChange={e=>setForm(v=>({...v,employeeLimit:e.target.value.replace(/\D/g,'').slice(0,4)}))}/></label><label>{en?'Price':'Багцын үнэ'}<input inputMode="numeric" value={form.price} onChange={e=>setForm(v=>({...v,price:e.target.value.replace(/[^0-9.]/g,'')}))} placeholder="0"/></label><label>{en?'Billing cycle':'Төлбөрийн мөчлөг'}<DentSelect value={form.billingCycle} onChange={billingCycle=>setForm(v=>({...v,billingCycle}))} options={[{value:'monthly',label:en?'Monthly':'Сар бүр'},{value:'yearly',label:en?'Yearly':'Жил бүр'},{value:'custom',label:en?'Custom':'Тусгай нөхцөл'}]}/></label><label>{en?'Subscription end':'Багц дуусах огноо'}<DentDatePicker value={form.subscriptionEndsAt} onChange={subscriptionEndsAt=>setForm(v=>({...v,subscriptionEndsAt}))} lang={lang}/></label><label>{en?'Grace period end':'Нэмэлт хугацаа дуусах'}<DentDatePicker value={form.graceEndsAt} onChange={graceEndsAt=>setForm(v=>({...v,graceEndsAt}))} min={form.subscriptionEndsAt||undefined} lang={lang}/></label><label className="wide">{en?'Internal note':'Дотоод тэмдэглэл'}<textarea rows={2} value={form.notes} onChange={e=>setForm(v=>({...v,notes:e.target.value}))}/></label></div><ModuleAccessPicker value={form.modules} onChange={modules=>setForm(v=>({...v,modules}))} lang={lang} search={moduleSearch} onSearchChange={setModuleSearch}/></div><footer><button className="btn-secondary" onClick={()=>setEdit(null)} disabled={!!busy}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={()=>save(edit.status==='pending'?'approve':'update')} disabled={!!busy}>{busy?<Loader2 className="spin"/>:<CheckCircle2/>}{edit.status==='pending'?(en?'Approve & activate':'Зөвшөөрч идэвхжүүлэх'):(en?'Save changes':'Өөрчлөлт хадгалах')}</button></footer></div></div>}

    <ConfirmDialog open={Boolean(confirm)} busy={!!busy} danger title={confirm?.action==='permanent_delete'?(en?'Permanently delete this empty test clinic?':'Энэ хоосон тест эмнэлгийг бүр мөсөн устгах уу?'):confirm?.action==='archive'?(en?'Remove this clinic from the active list?':'Энэ эмнэлгийг идэвхтэй жагсаалтаас хасах уу?'):(en?'Suspend this clinic?':'Энэ эмнэлгийн нэвтрэх эрхийг түр хаах уу?')} description={confirm?.action==='permanent_delete'?(en?'Permanent deletion is allowed only when no patient, treatment, payment or HR history exists.':'Өвчтөн, эмчилгээ, төлбөр эсвэл ажилтны түүхгүй хоосон тест эмнэлгийг л бүр мөсөн устгана.'):confirm?.action==='archive'?(en?'The clinic disappears from the active list, but medical and accounting history stays safely preserved.':'Эмнэлэг идэвхтэй жагсаалтаас алга болно. Харин эмчилгээ, төлбөр болон аудитын түүх аюулгүй хадгалагдана.'):(en?'Users lose access until you restore the clinic. Existing history is preserved.':'Сэргээх хүртэл хэрэглэгчид нэвтрэхгүй. Өмнөх бүх түүх хадгалагдана.')} confirmLabel={confirm?.action==='permanent_delete'?(en?'Permanent delete':'Бүр мөсөн устгах'):confirm?.action==='archive'?(en?'Remove from active list':'Жагсаалтаас хасах'):(en?'Suspend':'Түр хаах')} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!busy&&setConfirm(null)} onConfirm={()=>confirm&&call(confirm.action,confirm.clinic.id)}/>
  </div>;
}
