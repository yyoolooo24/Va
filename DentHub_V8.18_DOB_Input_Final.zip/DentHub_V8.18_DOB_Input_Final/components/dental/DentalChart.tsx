'use client';

import { RotateCcw, Sparkles } from 'lucide-react';

type Dentition='adult'|'child';

type Props={
  value:string[];
  onChange:(teeth:string[])=>void;
  dentition:Dentition;
  onDentitionChange:(value:Dentition)=>void;
  lang?:'MN'|'EN';
  readOnly?:boolean;
  compact?:boolean;
};

const adult={
  upper:['18','17','16','15','14','13','12','11','21','22','23','24','25','26','27','28'],
  lower:['48','47','46','45','44','43','42','41','31','32','33','34','35','36','37','38'],
};
const child={
  upper:['55','54','53','52','51','61','62','63','64','65'],
  lower:['85','84','83','82','81','71','72','73','74','75'],
};

function ToothGlyph({number,selected,readOnly,onClick}:{number:string;selected:boolean;readOnly:boolean;onClick:()=>void}){
  const position=Number(number[1]);
  const molar=position>=6;
  const canine=position===3;
  return <button
    type="button"
    className={`tooth-button ${selected?'selected':''} ${molar?'molar':canine?'canine':'front'}`}
    aria-pressed={selected}
    aria-label={`Tooth ${number}`}
    disabled={readOnly}
    onClick={onClick}
  >
    <svg className="tooth-svg" viewBox="0 0 48 64" aria-hidden="true">
      <path d={molar
        ? 'M10 7 C14 3 19 5 24 8 C29 5 35 3 39 8 C45 16 41 27 38 34 C35 41 36 55 31 59 C27 62 25 53 24 46 C22 53 19 62 15 59 C10 55 12 41 9 34 C5 27 3 15 10 7 Z'
        : canine
          ? 'M12 9 C16 5 21 7 24 3 C27 7 33 5 37 10 C42 17 38 28 35 35 C32 43 32 56 28 60 C25 62 24 51 23 45 C21 52 18 62 14 58 C10 53 12 43 9 35 C6 27 5 16 12 9 Z'
          : 'M13 8 C18 5 21 8 24 8 C27 8 31 5 36 9 C41 16 37 28 34 35 C31 44 31 56 27 60 C24 62 23 51 22 45 C20 52 17 61 14 58 C10 53 12 43 9 35 C6 27 6 15 13 8 Z'} />
    </svg>
    <span>{number}</span>
  </button>;
}

export default function DentalChart({value,onChange,dentition,onDentitionChange,lang='MN',readOnly=false,compact=false}:Props){
  const en=lang==='EN';
  const set=new Set(value);
  const rows=dentition==='adult'?adult:child;
  function toggle(number:string){
    if(readOnly)return;
    const next=new Set(value);
    if(next.has(number))next.delete(number);else next.add(number);
    onChange(Array.from(next));
  }
  return <section className={`dental-chart ${compact?'compact':''} ${readOnly?'read-only':''}`}>
    {!compact&&<div className="dental-chart-head"><div><span className="dental-eyebrow"><Sparkles size={14}/>{en?'Odontogram':'Шүдний схем'}</span><b>{en?'Select treated teeth':'Үзлэг / эмчилгээ хийх шүд сонгох'}</b><small>{en?'FDI numbering · click one or more teeth':'FDI дугаарлалт · нэг эсвэл олон шүд дээр дарж сонгоно'}</small></div><div className="dentition-switch" role="group" aria-label="Dentition"><button type="button" className={dentition==='adult'?'active':''} onClick={()=>onDentitionChange('adult')} disabled={readOnly}>{en?'Adult':'Байнгын'}</button><button type="button" className={dentition==='child'?'active':''} onClick={()=>onDentitionChange('child')} disabled={readOnly}>{en?'Child':'Сүүн'}</button></div></div>}
    <div className="dental-arch" aria-label={en?'Upper teeth':'Дээд шүд'}>{rows.upper.map(n=><ToothGlyph key={n} number={n} selected={set.has(n)} readOnly={readOnly} onClick={()=>toggle(n)}/>)}</div>
    <div className="dental-midline"><span>{en?'RIGHT':'БАРУУН'}</span><i/><span>{en?'LEFT':'ЗҮҮН'}</span></div>
    <div className="dental-arch lower" aria-label={en?'Lower teeth':'Доод шүд'}>{rows.lower.map(n=><ToothGlyph key={n} number={n} selected={set.has(n)} readOnly={readOnly} onClick={()=>toggle(n)}/>)}</div>
    {!readOnly&&<div className="dental-selection-summary"><span>{value.length?`${en?'Selected':'Сонгосон'}: ${value.join(', ')}`:(en?'No tooth selected':'Шүд сонгоогүй')}</span>{value.length>0&&<button type="button" onClick={()=>onChange([])}><RotateCcw size={14}/>{en?'Clear':'Цэвэрлэх'}</button>}</div>}
  </section>;
}
