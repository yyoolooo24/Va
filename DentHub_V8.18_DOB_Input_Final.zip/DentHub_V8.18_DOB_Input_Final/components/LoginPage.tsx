'use client';

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft, ArrowRight, BadgeCheck, Building2, Eye, EyeOff, HeartPulse,
  KeyRound, LockKeyhole, Phone, ShieldCheck, Smartphone, Stethoscope, Truck, UserRound
} from 'lucide-react';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import { phoneToInternalEmail } from '@/lib/auth';
import NumericInput from './ui/NumericInput';

type Mode = 'login' | 'choose' | 'clinic' | 'patient' | 'supplier' | 'recovery' | 'reset';

const registerMeta = {
  clinic: { title:'Эмнэлгийн бүртгэл', desc:'Эмнэлгийн мэдээллээ илгээнэ. Системийн админ зөвшөөрсний дараа ажлын орчин идэвхжинэ.', icon:Building2 },
  patient: { title:'Өвчтөний бүртгэл', desc:'Өөрийн цаг товлол, үзлэгийн мэдээлэл болон төлбөрийн түүхээ нэг бүртгэлээс харна.', icon:HeartPulse },
  supplier: { title:'Ханган нийлүүлэгчийн бүртгэл', desc:'Нийлүүлэгч байгууллагын мэдээлэл, захиалга болон хамтын ажиллагаанд зориулсан бүртгэл.', icon:Truck },
} as const;

function passwordScore(value:string){
  let score=0;
  if(value.length>=8)score++;
  if(value.length>=12)score++;
  if(/[A-Za-zА-Яа-яӨөҮүЁё]/.test(value)&&/\d/.test(value))score++;
  if(/[^A-Za-zА-Яа-яӨөҮүЁё0-9]/.test(value))score++;
  return Math.min(score,4);
}

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<Mode>('login');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword,setConfirmPassword]=useState('');
  const [recoveryCode,setRecoveryCode]=useState('');
  const [fullName, setFullName] = useState('');
  const [clinicName, setClinicName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [show, setShow] = useState(false);
  const [showConfirm,setShowConfirm]=useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const configured = useMemo(() => isSupabaseConfigured(), []);
  const strength=useMemo(()=>passwordScore(password),[password]);

  useEffect(()=>{
    if(new URLSearchParams(window.location.search).get('access')==='clinic-blocked'){
      setError('Энэ эмнэлгийн нэвтрэх эрх одоогоор идэвхгүй байна. DentHub системийн админтай холбогдоно уу.');
    }
  },[]);

  function clearFeedback(){ setError(''); setSuccess(''); }
  function changeMode(next:Mode){ clearFeedback(); setMode(next); if(next!=='reset')setRecoveryCode(''); }

  async function login() {
    clearFeedback();
    if (phone.replace(/\D/g,'').length!==8 || !password) return setError('8 оронтой утасны дугаар болон нууц үгээ оруулна уу.');
    setBusy(true);
    try {
      if (!configured) throw new Error('Supabase тохируулаагүй байна.');
      const supabase = getSupabaseBrowser();
      const { error } = await supabase!.auth.signInWithPassword({ email: phoneToInternalEmail(phone), password });
      if (error) throw error;
      router.push('/dashboard');
    } catch (e: any) {
      const msg = e?.message || 'Нэвтрэхэд алдаа гарлаа.';
      const lower=msg.toLowerCase();
      if (lower.includes('user is banned') || lower.includes('user_banned') || lower.includes('banned')) setError('Таны нэвтрэх эрх идэвхгүй байна. Админтай холбогдоно уу.');
      else if (lower.includes('invalid login')) setError('Утасны дугаар эсвэл нууц үг буруу байна.');
      else setError(msg);
    } finally { setBusy(false); }
  }

  async function register() {
    clearFeedback();
    if (!['clinic','patient','supplier'].includes(mode)) return;
    if (!fullName.trim() || phone.replace(/\D/g,'').length!==8 || !password) return setError('Нэр, 8 оронтой утас, нууц үгээ бүрэн оруулна уу.');
    if (mode==='clinic' && !clinicName.trim()) return setError('Эмнэлгийн нэр оруулна уу.');
    if (mode==='supplier' && !companyName.trim()) return setError('Байгууллагын нэр оруулна уу.');
    if (password.length < 8) return setError('Нууц үг хамгийн багадаа 8 тэмдэгт байна.');
    if (!/[A-Za-zА-Яа-яӨөҮүЁё]/.test(password)||!/\d/.test(password)) return setError('Нууц үгэнд үсэг болон тоо хоёуланг ашиглана уу.');
    if(password!==confirmPassword)return setError('Нууц үг давтан оруулсантай таарахгүй байна.');
    setBusy(true);
    try {
      const res = await fetch('/api/register', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({ accountType:mode, fullName, phone, password, clinicName, companyName })
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || 'Бүртгэхэд алдаа гарлаа.');
      if(body.approvalRequired){
        setSuccess(body.message||'Бүртгэлийн хүсэлт илгээгдлээ. DentHub системийн админ зөвшөөрсний дараа нэвтрэх боломжтой болно.');
        setMode('login'); setPassword(''); setConfirmPassword('');
        return;
      }
      if (!configured) throw new Error('Supabase тохируулаагүй байна.');
      const supabase = getSupabaseBrowser();
      const {error:signInError}=await supabase!.auth.signInWithPassword({email:phoneToInternalEmail(phone),password});
      if(signInError){ setSuccess('Бүртгэл амжилттай. Одоо нэвтэрнэ үү.'); setMode('login'); setPassword(''); setConfirmPassword(''); return; }
      router.push('/dashboard');
    } catch(e:any){ setError(e?.message || 'Бүртгэхэд алдаа гарлаа.'); }
    finally { setBusy(false); }
  }

  async function sendRecoveryCode(){
    clearFeedback();
    if(phone.replace(/\D/g,'').length!==8)return setError('8 оронтой утасны дугаараа оруулна уу.');
    setBusy(true);
    try{
      const res=await fetch('/api/auth/recovery/request',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({phone})});
      const body=await res.json().catch(()=>({}));
      if(!res.ok)throw new Error(body.message||body.error||'Код илгээж чадсангүй.');
      setSuccess(body.message||'Сэргээх код илгээгдлээ.');
      setMode('reset'); setPassword(''); setConfirmPassword(''); setRecoveryCode('');
    }catch(e:any){setError(e?.message||'Код илгээж чадсангүй.');}
    finally{setBusy(false)}
  }

  async function resetPassword(){
    clearFeedback();
    if(recoveryCode.length!==6)return setError('SMS-ээр ирсэн 6 оронтой кодоо оруулна уу.');
    if(password.length<8)return setError('Шинэ нууц үг хамгийн багадаа 8 тэмдэгт байна.');
    if(!/[A-Za-zА-Яа-яӨөҮүЁё]/.test(password)||!/\d/.test(password))return setError('Нууц үгэнд үсэг болон тоо хоёуланг ашиглана уу.');
    if(password!==confirmPassword)return setError('Шинэ нууц үг хоорондоо таарахгүй байна.');
    setBusy(true);
    try{
      const res=await fetch('/api/auth/recovery/verify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({phone,code:recoveryCode,password})});
      const body=await res.json().catch(()=>({}));
      if(!res.ok)throw new Error(body.error||'Нууц үг шинэчилж чадсангүй.');
      setMode('login'); setRecoveryCode(''); setConfirmPassword(''); setPassword(''); setSuccess(body.message||'Нууц үг шинэчлэгдлээ. Одоо нэвтэрнэ үү.');
    }catch(e:any){setError(e?.message||'Нууц үг шинэчилж чадсангүй.');}
    finally{setBusy(false)}
  }

  const isRegister = mode==='clinic'||mode==='patient'||mode==='supplier';
  const meta = isRegister ? registerMeta[mode as keyof typeof registerMeta] : null;
  const RegisterIcon = meta?.icon;

  return (
    <main className="login-page auth-v88">
      <section className="login-brand-panel">
        <BrandLockup/>
        <div className="login-hero-copy">
          <span className="eyebrow">DENTHUB · ЭМНЭЛГИЙН УДИРДЛАГА</span>
          <h1>Эмнэлгийн өдөр тутмын ажлыг нэг системд.</h1>
          <p>Цаг товлол, өвчтөний бүртгэл, эмчилгээ, төлбөр, агуулах болон тайланг нэг ажлын орчноос удирдана.</p>
        </div>
        <div className="login-benefits">
          <div><span className="icon-cube"><ShieldCheck /></span><div><b>Өгөгдөл тусгаарлагдана</b><small>Эмнэлэг бүр өөрийн өгөгдөл, хэрэглэгч болон нэвтрэх эрхтэй.</small></div></div>
          <div><span className="icon-cube"><BadgeCheck /></span><div><b>Үүрэгт тохирсон эрх</b><small>Эмч, бүртгэл, касс болон удирдлагад хэрэгтэй модулийг тусад нь тохируулна.</small></div></div>
          <div><span className="icon-cube"><Smartphone /></span><div><b>Web ба app-д бэлэн</b><small>Компьютер, таблет болон утаснаас нэг ижил ажлын урсгалаар ашиглана.</small></div></div>
        </div>
      </section>

      <section className="login-form-panel">
        <div className="mobile-auth-brand"><BrandLockup/></div>
        <div className={`login-card-pro ${mode==='choose'?'register-choice-card':''}`}>
          {mode==='login' && <>
            <AuthHead icon={<LockKeyhole/>} title="Нэвтрэх" subtitle="Бүртгэлтэй утасны дугаар, нууц үгээ оруулна уу"/>
            <label className="field-label">Утасны дугаар</label>
            <PhoneField phone={phone} setPhone={setPhone}/>
            <div className="label-row"><label className="field-label">Нууц үг</label><button type="button" className="inline-link" onClick={()=>changeMode('recovery')}>Нууц үг мартсан?</button></div>
            <PasswordField password={password} setPassword={setPassword} show={show} setShow={setShow} onEnter={login} autoComplete="current-password"/>
            <Feedback error={error} success={success}/>
            <button className="btn-primary full auth-main-action" onClick={login} disabled={busy}>{busy ? 'Нэвтэрч байна…' : <>Нэвтрэх <ArrowRight size={18} /></>}</button>
            <div className="auth-security-note"><ShieldCheck size={15}/><span>Таны нууц үгийг DentHub харах боломжгүй. Нууц үгээ мартвал SMS кодоор өөрөө сэргээнэ.</span></div>
            <div className="login-register-row"><span>Бүртгэл үүсгэх шаардлагатай юу?</span><button type="button" onClick={()=>changeMode('choose')}>Бүртгэл үүсгэх</button></div>
          </>}

          {mode==='recovery' && <>
            <AuthHead back={()=>changeMode('login')} icon={<KeyRound/>} title="Нууц үг сэргээх" subtitle="Бүртгэлтэй утсандаа 6 оронтой SMS код авна"/>
            <label className="field-label">Бүртгэлтэй утас</label>
            <PhoneField phone={phone} setPhone={setPhone}/>
            <div className="recovery-explain"><Smartphone size={18}/><div><b>Админаас түр нууц үг авах шаардлагагүй</b><span>Сэргээх код таны бүртгэлтэй утсанд очно. Кодоо баталгаажуулаад шинэ нууц үгээ өөрөө тохируулна.</span></div></div>
            <Feedback error={error} success={success}/>
            <button className="btn-primary full auth-main-action" disabled={busy} onClick={sendRecoveryCode}>{busy?'Код илгээж байна…':<>SMS код авах <ArrowRight size={18}/></>}</button>
          </>}

          {mode==='reset' && <>
            <AuthHead back={()=>changeMode('recovery')} icon={<BadgeCheck/>} title="Код баталгаажуулах" subtitle={`+976 ${phone || '--------'} дугаарт илгээсэн код`}/>
            <label className="field-label">6 оронтой код</label>
            <div className="field-shell otp-shell"><BadgeCheck size={19}/><NumericInput value={recoveryCode} onValueChange={setRecoveryCode} maxDigits={6} autoComplete="one-time-code" placeholder="000000" aria-label="SMS код"/></div>
            <label className="field-label">Шинэ нууц үг</label>
            <PasswordField password={password} setPassword={setPassword} show={show} setShow={setShow} onEnter={resetPassword} autoComplete="new-password"/>
            <PasswordStrength value={password} score={strength}/>
            <label className="field-label">Шинэ нууц үгээ давтах</label>
            <PasswordField password={confirmPassword} setPassword={setConfirmPassword} show={showConfirm} setShow={setShowConfirm} onEnter={resetPassword} autoComplete="new-password" placeholder="Нууц үгээ дахин оруулна уу"/>
            <Feedback error={error} success={success}/>
            <button className="btn-primary full auth-main-action" disabled={busy} onClick={resetPassword}>{busy?'Шинэчилж байна…':<>Нууц үг шинэчлэх <ArrowRight size={18}/></>}</button>
            <button className="btn-light full" disabled={busy} onClick={sendRecoveryCode}>Код дахин илгээх</button>
          </>}

          {mode==='choose' && <>
            <AuthHead back={()=>changeMode('login')} title="Бүртгэл үүсгэх" subtitle="Та DentHub-ийг ямар төрлөөр ашиглахаа сонгоно уу"/>
            <div className="register-type-grid">
              <button onClick={()=>changeMode('clinic')}><span className="register-type-icon"><Building2/></span><div><b>Эмнэлэг</b><small>Эмнэлгийн эзэмшигч хүсэлт илгээж, зөвшөөрөл авна</small></div><ArrowRight size={18}/></button>
              <button onClick={()=>changeMode('patient')}><span className="register-type-icon"><HeartPulse/></span><div><b>Өвчтөн</b><small>Өөрийн цаг товлол, үзлэг болон төлбөрийн мэдээлэл</small></div><ArrowRight size={18}/></button>
              <button onClick={()=>changeMode('supplier')}><span className="register-type-icon"><Truck/></span><div><b>Ханган нийлүүлэгч</b><small>Захиалга, нийлүүлэлт болон хамтын ажиллагааны бүртгэл</small></div><ArrowRight size={18}/></button>
            </div>
          </>}

          {isRegister && meta && <>
            <AuthHead back={()=>changeMode('choose')} icon={RegisterIcon?<RegisterIcon/>:undefined} title={meta.title} subtitle={meta.desc}/>
            {mode==='clinic' && <><label className="field-label">Эмнэлгийн нэр</label><TextField icon={<Building2 size={19}/>} value={clinicName} onChange={setClinicName} placeholder="Эмнэлгийн нэр" autoComplete="organization"/></>}
            {mode==='supplier' && <><label className="field-label">Байгууллагын нэр</label><TextField icon={<Truck size={19}/>} value={companyName} onChange={setCompanyName} placeholder="Компанийн / байгууллагын нэр" autoComplete="organization"/></>}
            <label className="field-label">{mode==='clinic'?'Эзэмшигчийн нэр':mode==='supplier'?'Холбоо барих хүний нэр':'Овог нэр'}</label>
            <TextField icon={<UserRound size={19}/>} value={fullName} onChange={setFullName} placeholder="Нэрээ оруулна уу" autoComplete="name"/>
            <label className="field-label">Утасны дугаар</label>
            <PhoneField phone={phone} setPhone={setPhone}/>
            <label className="field-label">Нууц үг</label>
            <PasswordField password={password} setPassword={setPassword} show={show} setShow={setShow} onEnter={register} autoComplete="new-password"/>
            <PasswordStrength value={password} score={strength}/>
            <label className="field-label">Нууц үгээ давтах</label>
            <PasswordField password={confirmPassword} setPassword={setConfirmPassword} show={showConfirm} setShow={setShowConfirm} onEnter={register} autoComplete="new-password" placeholder="Нууц үгээ дахин оруулна уу"/>
            <Feedback error={error} success={success}/>
            <button className="btn-primary full auth-main-action" onClick={register} disabled={busy}>{busy ? 'Бүртгэж байна…' : <>Бүртгэл үүсгэх <ArrowRight size={18}/></>}</button>
          </>}
        </div>
        <small className="auth-footer-copy">DentHub · Эмнэлгийн удирдлагын систем</small>
      </section>
    </main>
  );
}

function BrandLockup(){return <div className="brand-lockup"><div className="brand-mark"><Stethoscope size={24}/></div><div><strong>DENTHUB</strong><span>эмнэлгийн систем</span></div></div>}
function AuthHead({back,icon,title,subtitle}:{back?:()=>void;icon?:ReactNode;title:string;subtitle:string}){return <div className="login-card-head">{back&&<button className="back-square" onClick={back} aria-label="Буцах"><ArrowLeft size={19}/></button>}{icon&&<span className="icon-cube large">{icon}</span>}<div><h2>{title}</h2><p>{subtitle}</p></div></div>}
function Feedback({error,success}:{error:string;success:string}){return <>{error&&<div className="form-error" role="alert">{error}</div>}{success&&<div className="form-success" role="status">{success}</div>}</>}
function PasswordStrength({value,score}:{value:string;score:number}){if(!value)return <small className="password-hint">Хамгийн багадаа 8 тэмдэгт · үсэг + тоо.</small>;const labels=['Маш сул','Сул','Дунд','Сайн','Хүчтэй'];return <div className="password-strength"><div>{[1,2,3,4].map(i=><span key={i} className={i<=score?'active':''}/>)}</div><small>{labels[score]}</small></div>}
function PhoneField({phone,setPhone}:{phone:string;setPhone:(v:string)=>void}){return <div className="field-shell"><Phone size={19}/><span className="country-code">+976</span><NumericInput value={phone} onValueChange={setPhone} maxDigits={8} placeholder="99xx xxxx" autoComplete="tel-national" aria-label="Утасны дугаар"/></div>}
function PasswordField({password,setPassword,show,setShow,onEnter,autoComplete='current-password',placeholder='Нууц үгээ оруулна уу'}:{password:string;setPassword:(v:string)=>void;show:boolean;setShow:(v:boolean)=>void;onEnter:()=>void;autoComplete?:string;placeholder?:string}){return <div className="field-shell"><LockKeyhole size={19}/><input type={show?'text':'password'} value={password} onChange={(e)=>setPassword(e.target.value)} placeholder={placeholder} autoComplete={autoComplete} onKeyDown={(e)=>e.key==='Enter'&&onEnter()}/><button className="eye-btn" type="button" aria-label={show?'Нууц үг нуух':'Нууц үг харах'} onClick={()=>setShow(!show)}>{show?<EyeOff size={18}/>:<Eye size={18}/>}</button></div>}
function TextField({icon,value,onChange,placeholder,autoComplete}:{icon:ReactNode;value:string;onChange:(v:string)=>void;placeholder:string;autoComplete?:string}){return <div className="field-shell">{icon}<input value={value} onChange={(e)=>onChange(e.target.value)} placeholder={placeholder} autoComplete={autoComplete}/></div>}
