'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Check, ClipboardList, Loader2, Pencil, Printer, Save, Search, UserRound, X } from 'lucide-react';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import type { AppLang, AppProfile } from './DashboardApp';
import NumericInput from './ui/NumericInput';
import BirthDateInput, { birthDateToIso, formatBirthDateDisplay } from './ui/BirthDateInput';

type Patient={
  id:string;full_name:string;phone?:string|null;register_no?:string|null;patient_code?:string|null;external_patient_id?:string|null;
  date_of_birth?:string|null;gender?:string|null;address?:string|null;emergency_phone?:string|null;notes?:string|null;
};
type InfoForm={fullName:string;phone:string;registerNo:string;externalPatientId:string;dateOfBirth:string;address:string;emergencyPhone:string;notes:string};
type Answer=''|'yes'|'no';
type QuestionDef={id?:string;key:string;mn:string;en:string};
type CardForm={
  workplace:string;
  questionnaireAnswers:Record<string,Answer>;
  generalWellness:Answer;
  regularMedication:Answer;
  medicationDetails:string;
  surgeryHistory:Answer;
  allergies:Answer;
  aspirin14Days:Answer;
  rheumaticHeartDisease:Answer;
  diabetes:Answer;
  tuberculosis:Answer;
  additionalNotes:string;
};
type TreatmentLedgerRow={id:string;date:string;tooth:string;service:string;doctor:string;price:number|null;notes?:string|null;source:'treatment'|'encounter'|'appointment'};

const EMPTY_CARD:CardForm={
  workplace:'',questionnaireAnswers:{},generalWellness:'',regularMedication:'',medicationDetails:'',surgeryHistory:'',allergies:'',aspirin14Days:'',rheumaticHeartDisease:'',diabetes:'',tuberculosis:'',additionalNotes:''
};

function localPhone(value?:string|null){return String(value||'').replace(/\D/g,'').replace(/^976/,'').slice(-8)}
function displayPhone(value?:string|null){const x=localPhone(value);return x||'—'}
function formatMoney(value:number|null){return value===null?'—':`${Math.round(value).toLocaleString('mn-MN')} ₮`}
function formatDate(value:string){try{return new Date(value).toLocaleDateString('mn-MN')}catch{return value}}
function ageFromDob(value?:string|null){if(!value)return '—';const d=new Date(`${value}T00:00:00`);if(Number.isNaN(d.getTime()))return '—';const now=new Date();let age=now.getFullYear()-d.getFullYear();const m=now.getMonth()-d.getMonth();if(m<0||(m===0&&now.getDate()<d.getDate()))age--;return age>=0?String(age):'—'}
function genderLabel(value?:string|null,en=false){if(value==='male')return en?'Male':'Эр';if(value==='female')return en?'Female':'Эм';if(value==='other')return en?'Other':'Бусад';return '—'}
function isDoctorProfile(profile:AppProfile){return profile.role==='employee'&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(profile.specialty||'')}
function parseCardContent(content?:string|null):CardForm{
  const raw=String(content||'').trim();
  if(!raw)return {...EMPTY_CARD};
  try{
    const parsed=JSON.parse(raw);
    if(parsed&&parsed.schema==='denthub_patient_card_v2'){
      return {...EMPTY_CARD,...parsed.form};
    }
  }catch{}
  return {...EMPTY_CARD,additionalNotes:raw};
}
function serializeCard(form:CardForm){return JSON.stringify({schema:'denthub_patient_card_v2',form});}

async function authJson(url:string,init?:RequestInit){
  const s=getSupabaseBrowser();if(!s)throw new Error('Supabase холболт алга.');
  const {data}=await s.auth.getSession();const token=data.session?.access_token;if(!token)throw new Error('Нэвтрэх эрх дууссан байна.');
  const res=await fetch(url,{...init,headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`,...(init?.headers||{})}});
  const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Алдаа гарлаа.');return body;
}

function YesNoField({value,onChange,en}:{value:Answer;onChange:(next:Answer)=>void;en:boolean}){
  return <div className="patient-card-yesno" role="group" aria-label={en?'Yes or no':'Тийм эсвэл үгүй'}>
    <button type="button" className={value==='yes'?'active':''} onClick={()=>onChange(value==='yes'?'':'yes')}>{en?'Yes':'Тийм'}</button>
    <button type="button" className={value==='no'?'active danger':''} onClick={()=>onChange(value==='no'?'':'no')}>{en?'No':'Үгүй'}</button>
  </div>;
}
function PrintBox({checked}:{checked:boolean}){return <span className={`print-check ${checked?'checked':''}`}>{checked?'✓':''}</span>}

export default function PatientCardsWorkspace({profile,clinicName,clinicLogoUrl,lang}:{profile:AppProfile;clinicName:string;clinicLogoUrl?:string|null;lang:AppLang}){
  const en=lang==='EN';const clinicId=profile.clinic_id||'';
  const [patients,setPatients]=useState<Patient[]>([]);const [selectedId,setSelectedId]=useState('');const [query,setQuery]=useState('');
  const [cardForm,setCardForm]=useState<CardForm>({...EMPTY_CARD});const [savedCard,setSavedCard]=useState<CardForm>({...EMPTY_CARD});
  const [loading,setLoading]=useState(true);const [saving,setSaving]=useState(false);const [error,setError]=useState('');const [savedAt,setSavedAt]=useState<string>('');
  const [ledger,setLedger]=useState<TreatmentLedgerRow[]>([]);const [ledgerLoading,setLedgerLoading]=useState(false);const timerRef=useRef<number|null>(null);
  const [questionDefs,setQuestionDefs]=useState<QuestionDef[]>([
    {key:'generalWellness',mn:'1. Одоо таны биеийн байдал сайн байгаа юу?',en:'1. Is your current general condition good?'},
    {key:'regularMedication',mn:'2. Байнгын хэрэглэдэг эм тариа бий юу?',en:'2. Do you regularly take any medication?'},
    {key:'surgeryHistory',mn:'3. Мэс засал хийлгэж байсан уу?',en:'3. Have you had surgery before?'},
    {key:'allergies',mn:'4. Эм тариа, бодисын харшил бий юу?',en:'4. Do you have medication or substance allergies?'},
    {key:'aspirin14Days',mn:'5. Сүүлийн 14 хоног дотор аспирины төрлийн эм хэрэглэсэн үү?',en:'5. Have you used aspirin-type medicine during the last 14 days?'},
    {key:'rheumaticHeartDisease',mn:'6. Зүрхний хэрх өвчин бий юу?',en:'6. Do you have rheumatic heart disease?'},
    {key:'diabetes',mn:'7. Сахарын өвчин бий юу?',en:'7. Do you have diabetes?'},
    {key:'tuberculosis',mn:'8. Дараах өвчнөөр өвдөж байсан уу? — Сүрьеэ',en:'8. Have you had tuberculosis?'},
  ]);
  const [editingInfo,setEditingInfo]=useState(false);const [infoSaving,setInfoSaving]=useState(false);const [infoForm,setInfoForm]=useState<InfoForm>({fullName:'',phone:'',registerNo:'',externalPatientId:'',dateOfBirth:'',address:'',emergencyPhone:'',notes:''});
  const selected=patients.find(p=>p.id===selectedId)||null;
  const cardDirty=useMemo(()=>serializeCard(cardForm)!==serializeCard(savedCard),[cardForm,savedCard]);

  const loadPatients=useCallback(async()=>{
    if(!clinicId||!isSupabaseConfigured()){setLoading(false);return}
    const s=getSupabaseBrowser();if(!s)return;setLoading(true);
    let patientIds:string[]|null=null;
    if(isDoctorProfile(profile)&&profile.id){
      const [a,e]=await Promise.all([
        s.from('appointments').select('patient_id').eq('clinic_id',clinicId).eq('doctor_id',profile.id),
        s.from('encounters').select('patient_id').eq('clinic_id',clinicId).eq('doctor_id',profile.id),
      ]);
      patientIds=Array.from(new Set([...(a.data||[]),...(e.data||[])].map((x:any)=>String(x.patient_id||'')).filter(Boolean)));
      if(!patientIds.length){setPatients([]);setSelectedId('');setLoading(false);return}
    }
    let q=s.from('patients').select('id,full_name,phone,register_no,patient_code,external_patient_id,date_of_birth,gender,address,emergency_phone,notes').eq('clinic_id',clinicId).is('deleted_at',null);
    if(patientIds)q=q.in('id',patientIds);
    const {data,error:e}=await q.order('full_name');
    if(e)setError(e.message);else{setPatients((data||[]) as Patient[]);if(selectedId&&!(data||[]).some((x:any)=>x.id===selectedId))setSelectedId((data||[])[0]?.id||'');else if(!selectedId&&(data||[])[0]?.id)setSelectedId((data||[])[0].id)}setLoading(false)
  },[clinicId,selectedId,profile.id,profile.role,profile.specialty]);
  useEffect(()=>{loadPatients()},[clinicId]);
  useEffect(()=>{(async()=>{const s=getSupabaseBrowser();if(!s||!clinicId)return;const {data,error}=await s.from('clinic_questionnaire_questions').select('id,question_key,label_mn,label_en,active,sort_order').eq('clinic_id',clinicId).eq('active',true).order('sort_order');if(!error&&data?.length)setQuestionDefs(data.map((q:any)=>({id:q.id,key:q.question_key,mn:q.label_mn,en:q.label_en||q.label_mn})))})()},[clinicId]);

  const loadCard=useCallback(async(patientId:string,silent=false)=>{
    if(!patientId)return;if(!silent)setLoading(true);const s=getSupabaseBrowser();if(!s)return;
    const {data,error:e}=await s.from('patient_cards').select('content,updated_at').eq('clinic_id',clinicId).eq('patient_id',patientId).maybeSingle();
    if(e){setError(e.message)}else{const next=parseCardContent(data?.content);setCardForm(next);setSavedCard(next);setSavedAt(data?.updated_at||'')}if(!silent)setLoading(false)
  },[clinicId]);

  const loadLedger=useCallback(async(patientId:string,silent=false)=>{
    if(!patientId||!clinicId)return;const supabase=getSupabaseBrowser();if(!supabase)return;if(!silent)setLedgerLoading(true);
    try{
      const {data}=await supabase.auth.getSession();const token=data.session?.access_token;if(!token)throw new Error('Нэвтрэх эрх дууссан байна.');
      const res=await fetch(`/api/clinic/treatment-history?patientId=${encodeURIComponent(patientId)}`,{headers:{Authorization:`Bearer ${token}`}});const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Эмчилгээний түүх ачаалж чадсангүй.');
      const rows:TreatmentLedgerRow[]=[];
      for(const item of body.items||[]){
        if(item.source==='encounter'){
          const lines=Array.isArray(item.treatment_lines)?item.treatment_lines:[];
          if(lines.length){for(const line of lines){const rawPrice=line.total_amount??line.unit_price;rows.push({id:`line-${line.id}`,date:line.created_at||item.date,tooth:line.tooth_no||'—',service:line.service_name||item.treatment_plan||item.title||'Эмчилгээ',doctor:item.doctor_name||'—',price:rawPrice===null||rawPrice===undefined?null:Number(rawPrice),notes:line.notes||item.notes||null,source:'treatment'});}}
          else rows.push({id:item.id,date:item.date,tooth:Array.isArray(item.selected_teeth)&&item.selected_teeth.length?item.selected_teeth.join(', '):'—',service:item.treatment_plan||item.diagnosis||item.title||'Үзлэг, эмчилгээ',doctor:item.doctor_name||'—',price:null,notes:item.notes||null,source:'encounter'});
        }else rows.push({id:item.id,date:item.date,tooth:'—',service:item.treatment_plan||item.title||'Эмчилгээ',doctor:item.doctor_name||'—',price:null,notes:item.notes||null,source:'appointment'});
      }
      rows.sort((a,b)=>+new Date(a.date)-+new Date(b.date));setLedger(rows);setError('');
    }catch(e:unknown){setError(e instanceof Error?e.message:'Эмчилгээний түүх ачаалж чадсангүй.')}finally{if(!silent)setLedgerLoading(false)}
  },[clinicId]);

  useEffect(()=>{if(selectedId){loadCard(selectedId);loadLedger(selectedId)}},[selectedId,loadCard,loadLedger]);
  useEffect(()=>{const s=getSupabaseBrowser();if(!s||!clinicId)return;const c=s.channel(`patient-card-live-${clinicId}`).on('postgres_changes',{event:'*',schema:'public',table:'patient_cards',filter:`clinic_id=eq.${clinicId}`},(payload:any)=>{const row:any=payload.new;if(row?.patient_id===selectedId&&!saving)loadCard(selectedId,true)}).on('postgres_changes',{event:'*',schema:'public',table:'encounters'},()=>selectedId&&loadLedger(selectedId,true)).on('postgres_changes',{event:'*',schema:'public',table:'encounter_treatments'},()=>selectedId&&loadLedger(selectedId,true)).on('postgres_changes',{event:'*',schema:'public',table:'appointments'},()=>selectedId&&loadLedger(selectedId,true)).subscribe();return()=>{s.removeChannel(c)}},[clinicId,selectedId,saving,loadCard,loadLedger]);

  useEffect(()=>{
    if(!selected)return;setEditingInfo(false);
    setInfoForm({fullName:selected.full_name||'',phone:localPhone(selected.phone),registerNo:selected.register_no||'',externalPatientId:selected.external_patient_id||'',dateOfBirth:selected.date_of_birth||'',address:selected.address||'',emergencyPhone:localPhone(selected.emergency_phone),notes:selected.notes||''});
  },[selectedId,selected?.full_name,selected?.phone,selected?.date_of_birth,selected?.address,selected?.emergency_phone]);

  async function saveCard(){
    if(!selectedId)return;setSaving(true);setError('');
    try{const s=getSupabaseBrowser();if(!s)return;const content=serializeCard(cardForm);const {data,error:e}=await s.from('patient_cards').upsert({clinic_id:clinicId,patient_id:selectedId,content,updated_by:profile.id||null},{onConflict:'clinic_id,patient_id'}).select('updated_at').single();if(e)throw e;setSavedCard({...cardForm});setSavedAt(data.updated_at)}catch(e:unknown){setError(e instanceof Error?e.message:'Карт хадгалж чадсангүй.')}finally{setSaving(false)}
  }
  useEffect(()=>{if(!cardDirty||!selectedId)return;if(timerRef.current)window.clearTimeout(timerRef.current);timerRef.current=window.setTimeout(()=>saveCard(),900);return()=>{if(timerRef.current)window.clearTimeout(timerRef.current)}},[cardForm,selectedId,cardDirty]);

  async function saveInfo(){
    if(!selected)return;if(!infoForm.fullName.trim()){setError(en?'Patient name is required.':'Өвчтөний нэр оруулна уу.');return}
    if(infoForm.phone&&infoForm.phone.length!==8){setError(en?'Phone must be 8 digits.':'Утас 8 оронтой байна.');return}
    if(infoForm.emergencyPhone&&infoForm.emergencyPhone.length!==8){setError(en?'Emergency phone must be 8 digits.':'Яаралтай үед холбоо барих утас 8 оронтой байна.');return}
    const dobIso=birthDateToIso(infoForm.dateOfBirth);if(infoForm.dateOfBirth&&!dobIso){setError(en?'Enter birth date as YYYY/MM/DD. Example: 2000/08/23':'Төрсөн огноог YYYY/MM/DD хэлбэрээр зөв оруулна уу. Жишээ: 2000/08/23');return}
    setInfoSaving(true);setError('');
    try{const result=await authJson('/api/patients',{method:'PATCH',body:JSON.stringify({id:selected.id,fullName:infoForm.fullName,phone:infoForm.phone,registerNo:infoForm.registerNo,externalPatientId:infoForm.externalPatientId,dateOfBirth:dobIso||'',address:infoForm.address,emergencyPhone:infoForm.emergencyPhone,notes:infoForm.notes})});const p=result.patient as Patient;setPatients(list=>list.map(x=>x.id===p.id?p:x));setEditingInfo(false)}catch(e:unknown){setError(e instanceof Error?e.message:'Өвчтөний мэдээлэл шинэчилж чадсангүй.')}finally{setInfoSaving(false)}
  }

  async function printCard(){if(!selected)return;if(cardDirty)await saveCard();window.print()}
  const filtered=useMemo(()=>{const q=query.toLowerCase();return patients.filter(p=>`${p.full_name} ${p.phone||''} ${p.patient_code||''} ${p.external_patient_id||''} ${p.register_no||''}`.toLowerCase().includes(q))},[patients,query]);
  const answerFor=(key:string):Answer=>cardForm.questionnaireAnswers?.[key]||((cardForm as any)[key] as Answer)||'';
  const setAnswer=(key:string,next:Answer)=>setCardForm(v=>({...v,questionnaireAnswers:{...(v.questionnaireAnswers||{}),[key]:next},...((key in v)?{[key]:next}:{})} as CardForm));

  return <div className="page-stack patient-cards-page"><header className="page-head"><div><small>{clinicName}</small><h1>{en?'Patient card':'Өвчтөний карт'}</h1><p>{en?'Fill the clinic registration form directly, print it, and review all performed treatments below.':'Өвчтөний бүртгэлийн хуудсыг шууд бөглөж, хэвлэж аваад, доороос нь өнөөдрийг хүртэл хийсэн бүх эмчилгээг нэг дор харна.'}</p></div></header><section className="patient-cards-layout"><aside className="panel-card patient-card-sidebar"><div className="module-search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={en?'Search patient…':'Өвчтөн хайх…'}/></div>{loading&&!patients.length?<div className="purchase-loading"><Loader2 className="spin"/></div>:<div className="patient-card-patient-list">{filtered.map(p=><button key={p.id} className={p.id===selectedId?'active':''} onClick={()=>setSelectedId(p.id)}><UserRound size={17}/><span><b>{p.full_name}</b><small>{[p.patient_code,p.external_patient_id,p.phone].filter(Boolean).join(' · ')}</small></span></button>)}</div>}</aside><main className="panel-card patient-card-document-shell">{selected?<><div className="patient-card-visible-brand patient-card-no-print">{clinicLogoUrl?<img src={clinicLogoUrl} alt={`${clinicName} logo`}/>:<span className="patient-card-visible-logo-placeholder"><ClipboardList size={24}/></span>}<div><b>{clinicName}</b><small>{en?'Patient card':'Өвчтөний карт'}</small></div></div><div className="patient-card-doc-head patient-card-no-print"><div><small>{en?'Patient':'Өвчтөн'}</small><h2>{selected.full_name}</h2><p>{[selected.patient_code,selected.external_patient_id,selected.phone,selected.register_no].filter(Boolean).join(' · ')}</p></div><div className="patient-card-head-actions"><button type="button" className="btn-secondary" onClick={()=>setEditingInfo(v=>!v)}>{editingInfo?<X size={15}/>:<Pencil size={15}/>} {editingInfo?(en?'Cancel edit':'Засвар болих'):(en?'Edit patient info':'Мэдээлэл засах')}</button><button type="button" className="btn-primary" onClick={printCard}><Printer size={16}/>{en?'Print card':'Карт хэвлэх'}</button><div className="patient-card-save-state">{saving?<><Loader2 className="spin" size={16}/>{en?'Saving…':'Хадгалж байна…'}</>:!cardDirty?<><Check size={16}/>{savedAt?(en?'Saved':'Хадгалсан'):(en?'Ready':'Бэлэн')}</>:<><Save size={16}/>{en?'Unsaved':'Хадгалаагүй'}</>}</div></div></div>
      <section className={`patient-card-info patient-card-no-print ${editingInfo?'editing':''}`}>{editingInfo?<div className="patient-card-info-form"><label><span>{en?'Full name':'Овог нэр'}</span><input value={infoForm.fullName} onChange={e=>setInfoForm(v=>({...v,fullName:e.target.value}))}/></label><label><span>{en?'Phone':'Утас'}</span><NumericInput value={infoForm.phone} onValueChange={phone=>setInfoForm(v=>({...v,phone}))} maxDigits={8} placeholder="99112233"/></label><label><span>{en?'Date of birth':'Төрсөн он сар өдөр'}</span><BirthDateInput value={infoForm.dateOfBirth} onValueChange={dateOfBirth=>setInfoForm(v=>({...v,dateOfBirth}))} placeholder="XXXX/XX/XX" ariaLabel={en?'Date of birth':'Төрсөн он сар өдөр'}/></label><label><span>{en?'Emergency contact phone':'Яаралтай үед холбоо барих утас'}</span><NumericInput value={infoForm.emergencyPhone} onValueChange={emergencyPhone=>setInfoForm(v=>({...v,emergencyPhone}))} maxDigits={8} placeholder="99112233"/></label><label><span>{en?'Registration':'Регистр'}</span><input value={infoForm.registerNo} onChange={e=>setInfoForm(v=>({...v,registerNo:e.target.value}))}/></label><label><span>{en?'Client ID':'Үйлчлүүлэгчийн ID'}</span><input value={infoForm.externalPatientId} onChange={e=>setInfoForm(v=>({...v,externalPatientId:e.target.value}))}/></label><label className="wide"><span>{en?'Residential address':'Оршин суугаа хаяг'}</span><input value={infoForm.address} onChange={e=>setInfoForm(v=>({...v,address:e.target.value}))}/></label><label className="wide"><span>{en?'Patient note':'Өвчтөний тэмдэглэл'}</span><textarea rows={2} value={infoForm.notes} onChange={e=>setInfoForm(v=>({...v,notes:e.target.value}))}/></label><div className="wide patient-card-info-actions"><button className="btn-primary" onClick={saveInfo} disabled={infoSaving}>{infoSaving?<Loader2 className="spin" size={16}/>:<Check size={16}/>} {en?'Save patient info':'Өвчтөний мэдээлэл хадгалах'}</button></div></div>:<div className="patient-card-info-grid"><div><span>{en?'Phone':'Утас'}</span><b>{displayPhone(selected.phone)}</b></div><div><span>{en?'Date of birth / age':'Төрсөн огноо / нас'}</span><b>{selected.date_of_birth?formatBirthDateDisplay(selected.date_of_birth):'—'} · {ageFromDob(selected.date_of_birth)}</b></div><div className="wide"><span>{en?'Residential address':'Оршин суугаа хаяг'}</span><b>{selected.address||'—'}</b></div><div><span>{en?'Emergency contact':'Яаралтай үед холбоо барих'}</span><b>{displayPhone(selected.emergency_phone)}</b></div><div><span>{en?'Registration':'Регистр'}</span><b>{selected.register_no||'—'}</b></div></div>}</section>

      <section className="patient-registration-form patient-card-no-print"><div className="patient-form-section-head"><div><ClipboardList size={18}/><span><b>{en?'Registration & health questionnaire':'Бүртгэл ба эрүүл мэндийн асуумж'}</b><small>{en?'Based on the clinic registration sheet. Changes save automatically.':'Эмнэлгийн бүртгэлийн хуудсын загвараар. Өөрчлөлт автоматаар хадгалагдана.'}</small></span></div><button type="button" className="btn-secondary" onClick={saveCard} disabled={saving||!cardDirty}><Save size={15}/>{en?'Save now':'Одоо хадгалах'}</button></div>
        <div className="patient-form-top-grid"><label className="wide"><span>{en?'Workplace':'Ажлын газар'}</span><input value={cardForm.workplace} onChange={e=>setCardForm(v=>({...v,workplace:e.target.value}))} placeholder={en?'Workplace / occupation':'Ажлын газар / эрхэлсэн ажил'}/></label></div>
        <div className="patient-questionnaire"><div className="patient-questionnaire-head"><span>{en?'Question':'Асуулт'}</span><span>{en?'Answer':'Хариулт'}</span></div>{questionDefs.map(q=><div className="patient-question-row" key={q.key}><div><b>{en?q.en:q.mn}</b>{q.key==='regularMedication'&&answerFor(q.key)==='yes'&&<textarea rows={2} value={cardForm.medicationDetails} onChange={e=>setCardForm(v=>({...v,medicationDetails:e.target.value}))} placeholder={en?'Which medication?':'Ямар эм тариа? Нэр, тун, давтамж…'}/>}</div><YesNoField en={en} value={answerFor(q.key)} onChange={next=>setAnswer(q.key,next)}/></div>)}</div>
        <label className="patient-card-notes-field"><span>{en?'Additional notes':'Нэмэлт тэмдэглэл'}</span><textarea rows={4} value={cardForm.additionalNotes} onChange={e=>setCardForm(v=>({...v,additionalNotes:e.target.value}))} placeholder={en?'Other medical or clinical notes…':'Бусад эрүүл мэндийн болон эмнэлзүйн тэмдэглэл…'}/></label>
      </section>

      <section className="patient-treatment-ledger patient-card-no-print"><div className="patient-form-section-head"><div><ClipboardList size={18}/><span><b>{en?'Performed treatments to date':'Өнөөдрийг хүртэл хийсэн эмчилгээ'}</b><small>{en?'Automatically pulled from visits and completed appointments.':'Үзлэг, эмчилгээ болон дууссан цаг товлолын бүртгэлээс автоматаар харагдана.'}</small></span></div><span className="ledger-count">{ledger.length}</span></div>{ledgerLoading?<div className="purchase-loading"><Loader2 className="spin"/>{en?'Loading…':'Ачаалж байна…'}</div>:ledger.length?<div className="patient-ledger-table-wrap"><table className="patient-ledger-table"><thead><tr><th>{en?'Date':'Огноо'}</th><th>{en?'Tooth':'Шүд'}</th><th>{en?'Performed treatment':'Хийгдсэн эмчилгээ'}</th><th>{en?'Doctor':'Эмч'}</th><th>{en?'Price':'Үнэ'}</th></tr></thead><tbody>{[...ledger].reverse().map(row=><tr key={row.id}><td>{formatDate(row.date)}</td><td>{row.tooth}</td><td><b>{row.service}</b>{row.notes&&<small>{row.notes}</small>}</td><td>{row.doctor}</td><td>{formatMoney(row.price)}</td></tr>)}</tbody></table></div>:<div className="patient-ledger-empty">{en?'No performed treatments yet.':'Одоогоор хийсэн эмчилгээний бүртгэл алга.'}</div>}</section>

      <article className="patient-card-print-root" aria-hidden="true"><header className="patient-print-header"><div className="patient-print-brand">{clinicLogoUrl&&<img className="patient-print-logo" src={clinicLogoUrl} alt={`${clinicName} logo`}/>}<div><b>{clinicName}</b><span>{en?'PATIENT REGISTRATION CARD':'ӨВЧТӨНИЙ БҮРТГЭЛИЙН ХУУДАС'}</span></div></div><strong>№ {selected.patient_code||selected.external_patient_id||'........'}</strong></header><section className="patient-print-demographics"><div><span>Овог, нэр:</span><b>{selected.full_name}</b></div><div><span>Хүйс:</span><b>{genderLabel(selected.gender,false)}</b></div><div><span>Нас:</span><b>{ageFromDob(selected.date_of_birth)}</b></div><div><span>РД:</span><b>{selected.register_no||'—'}</b></div><div className="wide"><span>Гэрийн хаяг:</span><b>{selected.address||'—'}</b></div><div className="wide"><span>Ажлын газар:</span><b>{cardForm.workplace||'—'}</b></div><div><span>Утас:</span><b>{displayPhone(selected.phone)}</b></div><div><span>Яаралтай үед:</span><b>{displayPhone(selected.emergency_phone)}</b></div></section><section className="patient-print-questions"><div className="patient-print-q-head"><b>Эрүүл мэндийн асуумж</b><span>Тийм</span><span>Үгүй</span></div>{questionDefs.map(q=><div className="patient-print-q" key={q.key}><div><b>{q.mn}</b>{q.key==='regularMedication'&&cardForm.medicationDetails&&<small>Ямар? {cardForm.medicationDetails}</small>}</div><PrintBox checked={answerFor(q.key)==='yes'}/><PrintBox checked={answerFor(q.key)==='no'}/></div>)}{cardForm.additionalNotes&&<div className="patient-print-notes"><b>Нэмэлт тэмдэглэл:</b><p>{cardForm.additionalNotes}</p></div>}</section><section className="patient-print-ledger"><h3>Хийгдсэн эмчилгээний бүртгэл</h3><table><thead><tr><th>Огноо</th><th>Шүд</th><th>Хийгдсэн эмчилгээ</th><th>Эмчийн гарын үсэг</th><th>Үнэ</th></tr></thead><tbody>{ledger.length?ledger.map(row=><tr key={row.id}><td>{formatDate(row.date)}</td><td>{row.tooth}</td><td>{row.service}</td><td>{row.doctor}</td><td>{formatMoney(row.price)}</td></tr>):<tr><td colSpan={5}>Одоогоор эмчилгээний бүртгэл алга.</td></tr>}</tbody></table></section></article>
      {error&&<div className="form-error patient-card-error patient-card-no-print">{error}</div>}</>:<div className="empty-state"><ClipboardList/><b>{en?'Choose a patient':'Өвчтөн сонгоно уу'}</b></div>}</main></section></div>;
}
