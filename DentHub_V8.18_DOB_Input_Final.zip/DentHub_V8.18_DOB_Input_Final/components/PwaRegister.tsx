'use client';
import { useEffect } from 'react';
export default function PwaRegister(){
  useEffect(()=>{
    if('serviceWorker' in navigator && process.env.NODE_ENV==='production'){
      navigator.serviceWorker.register('/sw.js',{scope:'/'}).catch(()=>undefined);
    }
  },[]);
  return null;
}
