'use client';

import { useEffect, useMemo, useState } from 'react';
import { CalendarCheck2, CalendarDays, Clock3, Loader2, Search, XCircle } from 'lucide-react';
import { getSupabaseBrowser } from '@/lib/supabase-browser';
import type { AppLang, AppProfile } from './DashboardApp';

type Item={id:string;date:string;booked_at?:string|null;clinic_name:string;doctor_name?:string|null;status:string};
async function authFetch(url:string){const s=getSupabaseBrowser();if(!s)throw new Error('Supabase холболт алга.');const {data}=await s.auth.getSession();const token=data.session?.access_token;if(!token)throw new Error('Нэвтрэх эрх дууссан байна.');const res=await fetch(url,{headers:{Authorization:`Bearer ${token}`},cache:'no-store'});const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Алдаа гарлаа.');return body}
function statusInfo(status:string,en:boolean){
  if(['completed','done','checked_in','in_progress'].includes(status))return {label:en?'Visited clinic':'Ирж үзүүлсэн',kind:'visited'};
  if(status==='cancelled')return {label:en?'Cancelled':'Цуцалсан',kind:'cancelled'};
  if(status==='no_show')return {label:en?'No show':'Ирээгүй',kind:'noshow'};
  return {label:en?'Appointment booked':'Цаг авсан',kind:'booked'};
}
export default function ClientTreatmentHistory({profile,lang}:{profile:AppProfile;lang:AppLang}){
  const en=lang==='EN';const [items,setItems]=useState<Item[]>([]);const [loading,setLoading]=useState(true);const [error,setError]=useState('');const [q,setQ]=useState('');
  async function load(silent=false){if(!silent)setLoading(true);try{const data=await authFetch('/api/client/treatment-history');setItems(data.items||[]);setError('')}catch(e:any){setError(e?.message||'Үзлэгийн түүх ачаалж чадсангүй.')}finally{if(!silent)setLoading(false)}}
  useEffect(()=>{load();const s=getSupabaseBrowser();if(!s)return;const c=s.channel(`client-visit-history-${profile.id||'me'}`).on('postgres_changes',{event:'*',schema:'public',table:'appointments'},()=>load(true)).subscribe();return()=>{s.removeChannel(c)}},[profile.id]);
  const filtered=useMemo(()=>{const x=q.trim().toLowerCase();return x?items.filter(i=>`${i.clinic_name} ${i.doctor_name||''} ${statusInfo(i.status,en).label}`.toLowerCase().includes(x)):items},[items,q,en]);
  return <div className="page-stack client-treatment-history"><header className="page-head"><div><small>DentHub</small><h1>{en?'Appointment & visit history':'Цаг & үзлэгийн түүх'}</h1><p>{en?'See when you booked, visited, cancelled or missed an appointment. Treatment details are kept in the clinic record.':'Хэдэнд цаг авсан, хэдэнд ирж үзүүлсэн, цуцалсан эсвэл ирээгүй түүхээ эндээс харна. Эмчилгээний дэлгэрэнгүйг энд харуулахгүй.'}</p></div></header>
  <section className="panel-card treatment-history-card"><div className="panel-head"><div><h2><CalendarCheck2 size={20}/>{en?' Visit timeline':' Үзлэгийн timeline'}</h2><p>{en?'Newest appointment first.':'Сүүлийн цаг хамгийн дээр харагдана.'}</p></div></div><div className="module-search treatment-search"><Search size={17}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder={en?'Search clinic or doctor…':'Эмнэлэг эсвэл эмчээр хайх…'}/></div>
  {error&&<div className="form-error">{error}</div>}{loading?<div className="purchase-loading"><Loader2 className="spin"/>{en?'Loading…':'Ачаалж байна…'}</div>:filtered.length?<div className="client-visit-timeline">{filtered.map(item=>{const info=statusInfo(item.status,en);const d=new Date(item.date);return <article key={item.id} className={`client-visit-event ${info.kind}`}><span className="visit-event-icon">{info.kind==='cancelled'?<XCircle/>:<CalendarDays/>}</span><div><div className="visit-event-top"><b>{info.label}</b><em>{d.toLocaleDateString(en?'en-US':'mn-MN')}</em></div><strong>{item.clinic_name}</strong>{item.doctor_name&&<small>{item.doctor_name}</small>}<p><Clock3 size={14}/>{d.toLocaleTimeString(en?'en-US':'mn-MN',{hour:'2-digit',minute:'2-digit'})}</p>{item.booked_at&&<span>{en?'Booked on':'Цаг авсан огноо'}: {new Date(item.booked_at).toLocaleString(en?'en-US':'mn-MN')}</span>}</div></article>})}</div>:<div className="empty-state"><CalendarDays/><b>{en?'No appointment history yet':'Одоогоор цагийн түүх алга'}</b></div>}</section></div>
}
