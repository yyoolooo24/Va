# DentHub V8.13 — Professional UX Finalization

- Separates the fixed DentHub brand mark from clinic-uploaded logos.
- Removes nested module-picker scrollbars: the modal itself is the single vertical scroll surface.
- Expands generic forms and branch manager selection so controls have room to breathe.
- Replaces the service category mystery plus icon with an explicit “Шинэ ангилал” action.
- Calendar doctor columns auto-fit the available width for 1–3 doctors; larger schedules keep horizontal scrolling.
- Adds a floating drag/resize HUD showing exact time and duration while moving/resizing appointments.
- Keeps 15/30/45 minute duration visible on short calendar cards.
- Separates saving/loading and success notification lanes so they no longer overlap.
- Improves modal spacing, hierarchy, select menus, and module-access grouping.

No new Supabase migration is required. Continue using the V8.12.1 deadlock-safe migration if it has not been run yet.
