# DentHub V8.9 — Studio Design System

This release applies the project CLAUDE.md design standard across the shared DentHub application shell and Platform Admin experience while preserving the V8.8 authentication, subscription, security and workflow functionality.

## Design system
- Reworked the core palette to a disciplined medical blue + neutral system.
- Removed violet/purple accents from the application UI.
- Removed decorative gradient/glass treatments from the shared shell and major shared surfaces.
- Reduced card radius, glow shadows and rounded-cube clutter.
- Made typography hierarchy smaller, denser and more deliberate while preserving the client-approved Arimo family.
- Added consistent focus states and reduced-motion behavior.
- Tightened desktop/tablet/mobile spacing.

## Application shell
- Narrower, cleaner sidebar with flatter icons and clearer active state.
- Lower top bar with cleaner search and account controls.
- Reduced decorative framing around tenant/workspace information.
- More restrained content width and spacing.

## Platform Admin
- Renamed mixed Mongolian/English copy to cleaner Mongolian wording.
- Converted tabs from rounded button pills to a simple underline navigation.
- Rebalanced the clinic-create form and clinic directory columns.
- Converted clinic subscriptions to a table-led directory.
- Replaced four tiny action icons per clinic with a clear Edit action + More menu.
- Simplified status badges and approval/module-request panels.
- Improved mobile/tablet stacking and action layout.

## Dashboard
- Cleaned Platform Admin dashboard copy.
- Removed decorative KPI delta pills; live values remain sourced from Supabase.
- Preserved the rule that production does not show fake demo charts.

## Database
No new Supabase migration is required for V8.9.
