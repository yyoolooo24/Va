# DentHub V8.6.22 setup

## 1. Database
Run migrations in version order. If V8.6.21 is already applied, run only:

`supabase/v8_6_22_client_workflow_navigation_affiliations.sql`

This adds clinic questionnaire definitions, contracts, multi-clinic staff memberships/requests, encounter history-delete compatibility, and realtime publication entries.

## 2. Environment
Keep the same Supabase/Vercel environment variables used by the existing DentHub deployment.

## 3. Build and deploy

```bash
npm install
npm run build
npx vercel --prod
```

## 4. Quick acceptance test

1. Owner → Ажилтнууд: invite a registered employee/doctor; accept from staff account; switch active clinic.
2. Owner → Бүртгэл & асуумж: edit/add a question; open a patient card and confirm the new question appears.
3. Owner → Гэрээ: upload/edit/delete a contract.
4. Үзлэг, эмчилгээ: confirm the 7 clinical groups appear.
5. Staff → Эмчилгээний түүх: delete a history row and refresh; it must stay hidden.
6. Patient login → Цаг & үзлэгийн түүх: verify only booked/visited/cancelled/no-show information is shown, not detailed procedures.
7. Confirm sidebar sections are grouped into daily/internal/collaboration headings.
