# DentHub V8.10 — Platform Plans & UX

This package continues from V8.9. Platform Admin can now manage reusable subscription plans, assign modules faster, archive clinics cleanly, and use improved modal/notification/auth UI. See `V8_10_SETUP.md`.

# DentHub V8.7

DentHub is a Mongolian dental / clinic ERP built with Next.js App Router, TypeScript, Supabase and Vercel.

## V8.7 focus

**Subscription, Platform Control & Security** adds Platform Admin approval for clinics, real per-clinic module licensing, subscription status/expiry controls, module requests, employee limits, safe clinic suspension/archive/removal, stronger tenant/RLS enforcement, explicit doctor staff type, doctor-patient privacy, cashier entitlement checks, audit logging, registration throttling, path-aware private document permissions, and an atomic clinic-credit → receivable workflow.

Existing active/trial clinics are preserved and receive the full current module set when the V8.7 migration is first applied. New clinic registrations stay pending until Platform Admin approval.

See `CHANGELOG_V8_7.md` for details.

## Required migration

After all previous migrations through V8.6.26, run:

```text
supabase/v8_7_subscription_platform_security.sql
```

See `V8_7_SETUP.md` for the exact rollout/test order.

## Validate and deploy

```bash
npm install
npm run validate:v8.7
npm run build
npx vercel --prod
```

Production must use Supabase. Browser-only fallback storage is restricted to explicit demo mode (`NEXT_PUBLIC_DEMO_MODE=true`).

## V8.12 — Stability & UX Fix

V8.12 adds a server-validated clinic branding endpoint so owner logo changes are not blocked by Storage RLS, fixes 30-minute calendar-card geometry, adds visible loading/saving feedback, and replaces browser-native date inputs in generic ERP forms with DentHub's date picker.

Run `supabase/v8_12_stability_ux_fix.sql`, then `npm run validate:v8.12` and `npm run build` before deployment.
