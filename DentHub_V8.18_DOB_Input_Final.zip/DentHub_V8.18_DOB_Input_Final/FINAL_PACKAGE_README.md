# DentHub V8.18 — DOB Input Final

## Change in this release
Patient birth date is now entered directly as numbers:

`YYYY/MM/DD` — example `2000/08/23`

- digits only
- slash separators are formatted automatically
- no calendar picker
- numeric keyboard on mobile
- invalid/future dates are rejected
- backend stores the final value safely as ISO `YYYY-MM-DD`
- existing dates display as `YYYY/MM/DD`

Applied to:
- Patient add
- Patient edit
- Patient Card demographic edit

No SQL migration is required.

## Deploy
```bat
npm install
npm run validate:v8.18
npm run build
npx vercel --prod
```
