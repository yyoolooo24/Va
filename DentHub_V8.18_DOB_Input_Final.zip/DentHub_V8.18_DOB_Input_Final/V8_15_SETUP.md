# DentHub V8.15 setup

No new SQL is required specifically for V8.15.

## Windows CMD

```bat
npm install
npm run validate:v8.15
npm run build
```

Only after the build completes successfully:

```bat
npx vercel --prod
```

If your Supabase project has not yet received the deadlock-safe V8.12.1 migration, run `DentHub_V8.12.1_Migration.sql` once in Supabase SQL Editor before production use.
