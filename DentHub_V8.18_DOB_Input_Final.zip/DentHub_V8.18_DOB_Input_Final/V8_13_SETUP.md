# DentHub V8.13 setup

1. If V8.12.1 migration has not been applied yet, run `DentHub_V8.12.1_Migration.sql` in Supabase SQL Editor.
2. No new SQL migration is required specifically for V8.13.
3. Run:
   - `npm install`
   - `npm run validate:v8.13`
   - `npm run build`
4. Only after the build passes: `npx vercel --prod`
