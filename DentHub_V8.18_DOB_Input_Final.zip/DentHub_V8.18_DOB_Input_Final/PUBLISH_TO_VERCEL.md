# Publish DentHub V8.7 to Vercel

1. Back up Supabase.
2. Run `supabase/v8_7_subscription_platform_security.sql` after all previous DentHub migrations through V8.6.26.
3. From this project folder run:

```bash
npm install
npm run validate:v8.7
npm run build
npx vercel --prod
```

Before onboarding clinics, test: new-clinic pending approval, Platform Admin module licensing, suspended-clinic blocking, Doctor A vs Doctor B privacy, treatment → cashier → payment → cashbook, clinic-credit receivable transfer, and HR document privacy.

## V8.10 note
Before deploying V8.10, run `supabase/v8_10_platform_plans_ux.sql` in Supabase SQL Editor, then run:

```bash
npm install
npm run validate:v8.10
npm run build
npx vercel --prod
```

## V8.12 note
Run `supabase/v8_12_stability_ux_fix.sql` after V8.11, then:

```bash
npm install
npm run validate:v8.12
npm run build
npx vercel --prod
```

V8.12 fixes clinic-logo upload reliability, exact appointment-card duration geometry, loading feedback, and browser-native date UI in generic ERP forms.
