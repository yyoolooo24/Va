# DentHub V8.16 Setup

No new SQL is required specifically for V8.16.

If your database has not yet received the deadlock-safe migration, run `DentHub_V8.12.1_Migration.sql` in Supabase SQL Editor.

## Windows CMD

```bat
npm install
npm run validate:v8.16
npm run build
```

Only after `npm run build` succeeds:

```bat
npx vercel --prod
```

## Validation performed before packaging
- V8.14 validator: PASS
- V8.15 validator: PASS
- V8.16 validator: PASS
- 83 TypeScript/TSX files syntax-transpiled: 0 errors
- 205 local imports checked: 0 missing

A dependency-backed `next build` still needs to run in your normal Windows/Vercel environment after `npm install`.
