# DentHub V8.12.1 — Deadlock & Module Picker Hotfix

- Replaced the V8.12 Storage-policy migration with a deadlock-safe hotfix that does not run `DROP POLICY` / `CREATE POLICY` against `storage.objects`.
- Clinic logo writes continue through the server-validated branding API, so browser Storage write policies are not required for the normal flow.
- Rebuilt the module-access picker as compact accordion groups instead of one long checkbox wall.
- Added quick access presets: Үндсэн, Өсөлт, Бүх эрх, Арилгах.
- Module search is always available inside the picker.
- Each module category can be enabled/disabled as one group.
- Only one category needs to be expanded at a time; searches automatically reveal matching groups.
- Module selector remains responsive and scrollable in clinic, subscription, and employee permission modals.
