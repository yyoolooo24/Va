# DentHub V8.7 Setup

## 1. Back up Supabase first

Create a current database backup/snapshot before applying production migrations.

## 2. Apply the migration

In Supabase SQL Editor, run:

```text
supabase/v8_7_subscription_platform_security.sql
```

Run it **after** `v8_6_26_consent_branding_print.sql`.

The migration is additive/idempotent and backfills existing active/trial clinics with the current full module set. New clinic registrations become `pending` and need Platform Admin approval.

## 3. Environment variables

Keep the existing variables from `.env.example`, including the Supabase URL, anon key and server service-role key. Do not expose the service-role key through a `NEXT_PUBLIC_` variable.

`NEXT_PUBLIC_DEMO_MODE` should be unset or `false` in production.

## 4. Install and validate

```bash
npm install
npm run validate:v8.7
npm run build
```

## 5. Deploy

```bash
npx vercel --prod
```

## 6. First production checks

1. Platform Admin → Management: verify existing clinics are ACTIVE and have their current modules.
2. Register a new test clinic: confirm it stays PENDING and cannot enter the workspace.
3. Platform Admin approves the clinic and selects modules.
4. Confirm the clinic owner sees only licensed modules and can request an additional module.
5. Confirm a staff user cannot be granted a module the clinic has not licensed.
6. Suspend the test clinic and confirm its session/data access is blocked.
7. Test Doctor A cannot open an unrelated patient belonging only to Doctor B.
8. Test treatment → cashier → payment → cashbook.
9. Test Clinic Credit creates a receivable and removes the encounter from the cashier queue atomically.
10. Test employee HR documents cannot be opened by unrelated employees.

## Safe clinic removal

Use **Suspend** or **Archive** for real clinics. Permanent delete is intended only for empty/test clinics and the API refuses it when protected clinical, finance, inventory, HR, consent, contract or regulatory data exists.
