# DentHub V8.11 — Usability & Publish Fix

## Build / deploy
- Fixed the Vercel-blocking TypeScript error in `app/api/admin/create-clinic/route.ts` caused by calling `.catch()` on a PostgREST query builder.
- Clinic-create rollback now uses a safe best-effort `try/await/catch` path.

## Booking UX
- Replaced browser-native booking date pickers with DentHub's in-app calendar picker.
- Replaced the native booking time control with searchable 5-minute exact-time options.
- Kept recommended available-time buttons, future shortcuts, clinic-hours validation and capacity checks.
- Reschedule and calendar jump use the same in-app date picker.

## Contracts / reports
- Fixed the Contracts modal layout so labels, text fields, dates, notes and file upload no longer collapse into one line.
- Contracts modal now has a real scrollable body and fixed header/footer.
- Monthly report selection no longer opens the inconsistent browser month picker.

## Navigation / screen fit
- Reduced the expanded desktop sidebar width and density.
- Removed duplicated/misleading sidebar workspace UI and improved clinic context hierarchy.
- Compact sidebar is narrower and aligned consistently.
- Increased usable content width and reduced oversized module spacing so modules fit better at normal browser zoom.
- Large module-permission dialogs are wider, scrollable and use more columns on desktop.

## Clinic branding
- Added a dedicated `Нэр & лого` tab in clinic management.
- Re-hardened the `clinic-logos` bucket and owner update policies with an idempotent migration.

## Login / registration
- Rewrote the main login and registration copy in concise professional Mongolian.
- Simplified clinic, patient and supplier registration descriptions.
