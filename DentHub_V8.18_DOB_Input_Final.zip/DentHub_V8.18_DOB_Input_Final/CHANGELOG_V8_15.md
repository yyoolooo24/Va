# DentHub V8.15 — UI Stability Final

This release fixes the remaining layout regressions reported after the V8.14 responsive pass.

## Authentication
- Fixed the desktop login form panel so the login card and footer are always stacked vertically.
- The small DentHub footer text can no longer float beside the login card.
- Preserved the V8.14 mobile-first login/register/recovery layout.

## Notifications
- A single success notification stays at the original top position.
- Multiple success notifications stack downward from that position.
- A success notification only shifts downward when a loading/saving notice is actually visible.
- Mobile uses the same behavior with phone-safe spacing.

## Appointment calendar
- Removed the duplicate boxed calendar/date control from the main schedule toolbar.
- Restored the cleaner navigation: previous / Today / next + one readable date title.
- Added consistent Mongolian calendar titles instead of depending on browser locale fallback.
- The timeline corner uses a compact numeric date label.

## Dropdowns / clipped controls
- DentSelect menus now render in a viewport portal so dropdowns are not clipped by modal scroll areas or sticky footers.
- Menus automatically choose above/below placement depending on available viewport space.
- Long option labels wrap instead of creating horizontal scrollbars.
- ChoiceSelect menus also wrap long labels and hide horizontal overflow.

## Generic ERP forms
- Increased generic add/edit modal working area.
- Added extra bottom breathing room inside modal forms.
- Sticky footer remains visible while the body is scrollable.

## Health Department report
- Fixed month picker / selected-period text overlap.
- Increased the first period-control column width and removed conflicting minimum widths.
- Added readable period text such as `2026 оны 8-р сар` instead of developer-style `2026-08` in the page UI.
- Cleaned horizontal table scrollbar appearance.

## Database
- No new SQL migration is required for V8.15.
- Continue using the V8.12.1 deadlock-safe migration if it has not already been applied.
