# DentHub V8.14 Setup

V8.14 is a frontend responsive update. No new database migration is required.

## Windows CMD

```bat
npm install
npm run validate:v8.14
npm run build
```

Only deploy after the build succeeds:

```bat
npx vercel --prod
```

If V8.12.1 database migration has not previously been applied successfully, run the existing `DentHub_V8.12.1_Migration.sql` separately in Supabase SQL Editor. Do not run SQL files in CMD.
