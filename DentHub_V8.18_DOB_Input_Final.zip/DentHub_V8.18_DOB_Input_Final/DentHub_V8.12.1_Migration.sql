-- DentHub V8.12.1 — deadlock-safe clinic branding migration hotfix
-- Run after V8.11. If V8.12 failed with ERROR 40P01, run this file instead of rerunning V8.12.
-- Safe to re-run.
--
-- V8.12 recreated policies on storage.objects. Supabase Storage can hold locks on that
-- table while uploads/maintenance are running, and DROP/CREATE POLICY can then deadlock.
-- V8.12.1 intentionally does not alter storage.objects policies. DentHub's clinic logo
-- writes already go through /api/clinic/branding, which validates the owner and writes
-- with the server service role.

set lock_timeout = '8s';
set statement_timeout = '30s';

alter table public.clinics
  add column if not exists logo_url text;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values(
  'clinic-logos',
  'clinic-logos',
  true,
  2097152,
  array['image/png','image/jpeg','image/webp']
)
on conflict (id) do update
set public = excluded.public,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

reset statement_timeout;
reset lock_timeout;

-- No DROP POLICY / CREATE POLICY statements on storage.objects by design.
