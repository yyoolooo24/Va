# DentHub V8.6.23

Client-requested reporting and inventory patch.

## Бараа материал
- Added Excel import directly in Бараа материал.
- Excel supports the same item name with separate batch/lot and expiry dates.
- Inventory screen groups rows by item name and shows summed total stock.
- Each batch remains separately visible with its own SKU, quantity, expiry date and status.
- Added Excel export with two sheets: detailed batches and Нэрээр нийлбэр.

## Нийслэлийн ЭМГ
- Split into Сарын тайлан, Жилийн тайлан, Бичиг баримт.
- Monthly/yearly statistics are generated directly from DentHub records rather than manual entry.
- Uses the client-provided sariin tailan.xlsx structure and age groups.
- Four reporting columns: Шүдний өвчний оношилгоо, эмчилгээ; Нүүр амны гажиг засал; Нүүр амны мэс засал; Нүүр амны согог засал.
- Includes gender, first/repeat visit and age-band counts where the source data supports them.
- Fields not currently captured as structured DentHub data remain numeric 0 rather than invented values.
- Added eBarimt recipient list for the selected reporting period.
- Export creates the statistical report plus an eBarimt recipients sheet.

## Compatibility
- No new Supabase migration is required for V8.6.23 if V8.6.22 migrations are already applied.
- Existing V8.6.22 workflow, 7 treatment groups, multi-clinic staff, questionnaire, contracts and prior fixes are preserved.
