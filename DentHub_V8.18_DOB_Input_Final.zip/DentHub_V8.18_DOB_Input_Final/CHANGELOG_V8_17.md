# DentHub V8.17 — Mobile Calendar

Focused release for the appointment experience on phones.

- Dedicated phone calendar layout instead of shrinking the desktop schedule.
- One doctor fills the phone width with a 58px time rail and no horizontal calendar scroll.
- Multiple doctors remain swipeable as clear 240–260px doctor columns.
- Mobile calendar toolbar has a clearer hierarchy and more breathing room.
- Appointment duration badge remains visible inside short cards.
- Drag/resize feedback is a stable bottom pill above mobile navigation instead of following the finger.
- Saving/loading notice is placed in normal page flow on mobile and no longer covers schedule controls.
- Compact mobile summary cards and touch-safe controls.
- Desktop calendar behavior is intentionally unchanged.

No new Supabase migration is required.
