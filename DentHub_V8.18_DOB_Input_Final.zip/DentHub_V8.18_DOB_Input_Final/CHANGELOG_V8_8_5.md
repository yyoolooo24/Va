# DentHub V8.8.5 — Login / Registration UI Polish

- Reworked the desktop auth layout to a deliberate 42/58 app-style split instead of an oversized 50/50 landing page.
- Reduced hero typography and removed oversized marketing-card styling.
- Converted the left benefits area into compact informational rows.
- Added a real bordered/padded login card with tighter hierarchy, spacing, and field sizing.
- Unified Login, Register, Recovery, and Reset screens under the same auth card sizing.
- Improved tablet/mobile behavior; mobile uses a compact brand header and a single-column card.
- Reworded awkward mixed English/Mongolian auth marketing copy into clearer Mongolian.
- No database migration is required for this visual release.
