# DentHub V8.10 setup

V8.10 continues from V8.9 and requires the previous V8.7 and V8.8 migrations to already be installed.

## 1. Back up Supabase
Take a database backup before applying any production migration.

## 2. Run the V8.10 migration
Open Supabase SQL Editor and run:

`supabase/v8_10_platform_plans_ux.sql`

This creates the persistent Platform subscription-plan catalog and seeds START, GROWTH and NETWORK without changing existing clinic data.

## 3. Validate and build

```bash
npm install
npm run validate:v8.10
npm run build
```

## 4. Deploy

```bash
npx vercel --prod
```

## Important clinic deletion behavior
DentHub does not hard-delete clinics that contain medical, payment, HR or audit history. Use **Идэвхтэй жагсаалтаас хасах** to archive those clinics. Permanent deletion is only available for empty test clinics.
