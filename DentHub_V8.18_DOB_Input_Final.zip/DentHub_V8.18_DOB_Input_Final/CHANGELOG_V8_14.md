# DentHub V8.14 — Mobile-First Responsive Release

This release is focused on making DentHub comfortable on phones, tablets, laptops and large desktop screens.

## Authentication
- Fixed the mobile login layout that placed the DentHub logo, login card and footer next to each other.
- Login / register / forgot-password / reset-password now render as one clean vertical mobile flow.
- Added stronger touch/tablet detection so iPhone/iPad layouts do not fall back to the desktop split-screen composition.
- Form inputs use mobile-safe 16px text to prevent Safari from zooming the page when a field is focused.
- Improved mobile wrapping for titles, helper copy, errors and registration choices.
- Improved safe-area padding around iPhone notches / browser bars.

## App shell
- Mobile sidebar remains an off-canvas drawer and is sized for touch.
- Drawer, tenant identity and navigation use larger tap targets.
- Bottom navigation respects the iPhone home indicator safe area.
- Top-bar controls are reduced on narrow phones so they no longer crowd each other.
- Content padding is reduced intelligently instead of shrinking the entire desktop UI.

## Modals / forms
- Common modals become near-full-screen mobile sheets on phones.
- Sticky headers and actions remain reachable.
- Forms switch to one column on phones.
- Buttons and close actions use 44px+ touch targets.
- Dropdowns become mobile bottom sheets and date pickers use a centered phone-friendly layer.

## Calendars / schedules
- Appointment toolbar reflows into stacked mobile controls.
- Day / Week / Month mode buttons fill the available width.
- Daily doctor schedule is horizontally scrollable rather than compressed until unreadable.
- Week/month views retain controlled horizontal scrolling where necessary.

## Other modules
- Admin tabs scroll horizontally instead of wrapping badly.
- Grid-based ERP, dashboard, reports, payments and settings collapse to mobile columns.
- Notification popover becomes a full mobile notification sheet.
- Common cards, headings and buttons use smaller but readable mobile spacing.

## Breakpoints reviewed
- Narrow phones: 360–380px
- Standard phones: 390–430px
- Tablets: ~768px
- Small laptops/tablets: ~900–1100px
- Desktop / wide desktop retain the existing DentHub desktop composition.

## Database
No new Supabase migration is required for V8.14.
