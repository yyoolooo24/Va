# DentHub V8.11 setup

1. Back up Supabase.
2. Run `supabase/v8_11_usability_publish_fix.sql` in Supabase SQL Editor. It is idempotent and mainly re-checks clinic branding storage/policies.
3. Install and validate:

```bash
npm install
npm run validate:v8.11
npm run build
```

4. Deploy only after the build passes:

```bash
npx vercel --prod
```

## Important
Do not run `npm audit fix --force` as part of this upgrade. Review audit output separately because forced upgrades may introduce breaking dependency changes.
