# V8.6.23 setup

No new SQL migration is required for this patch.

Prerequisite: the V8.6.22 database migrations must already be applied.

Deploy:

```bash
npm install
npm run build
npx vercel --prod
```

Main test cases:
1. Бараа материал -> Excel татах -> add two rows with the same name and different expiry dates -> import -> verify one grouped item with summed stock and separate batches.
2. Нийслэлийн ЭМГ -> Сарын тайлан -> choose a month -> verify direct numeric report and Excel export.
3. Нийслэлийн ЭМГ -> Жилийн тайлан -> choose year -> verify yearly totals.
4. Verify eBarimt recipients appear for successful paid QPay/eBarimt records in the selected period.
