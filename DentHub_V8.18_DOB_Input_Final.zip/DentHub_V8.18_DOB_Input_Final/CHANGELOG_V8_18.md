# DentHub V8.18 — Birth Date Input

- Patient birth date no longer uses a calendar/date picker.
- Users type only numbers in `YYYY/MM/DD` format, e.g. `2000/08/23`.
- `/` separators are inserted automatically while typing.
- Non-numeric characters are blocked.
- Mobile opens the numeric keyboard.
- Invalid dates and future dates are rejected with a clear Mongolian message.
- The API normalizes the typed value back to ISO `YYYY-MM-DD` before saving to Supabase.
- Existing stored ISO dates display as `YYYY/MM/DD` in the patient UI.
- Applied to both patient add/edit and Patient Card demographic editing.
- No SQL migration required.
