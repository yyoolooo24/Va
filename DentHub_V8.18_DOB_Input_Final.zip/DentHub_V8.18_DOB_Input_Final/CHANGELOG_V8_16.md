# DentHub V8.16 — Responsive Workflow Final

## Responsive / device-friendly pass
- Re-tuned the application for phone, tablet, laptop and desktop widths.
- Mobile breakpoint: <= 640px.
- Tablet breakpoint: 641–1024px.
- Desktop breakpoint: >= 1025px.
- Keeps the existing mobile drawer navigation and touch-friendly bottom navigation.
- Important touch targets remain at least ~44px.
- Mobile form controls use 16px text to avoid iOS Safari input zoom.
- Forms, cards and multi-column layouts collapse to one column on small screens.
- Large tables/calendars scroll internally rather than forcing the full page wider.
- Desktop content is capped to a more comfortable working width instead of stretching to every monitor edge.

## Service -> package workflow fix
- Package editor refreshes the active service list whenever New Package or Edit Package opens.
- Saving/editing a service now broadcasts a services-changed event so the package picker can refresh immediately.
- Newly created services can be added to a package without refreshing the whole page.
- Package modal has better responsive sizing on mobile/tablet.

## Report period selector redesign
- Monthly reports now use one combined month/year control such as `2026 оны 8-р сар`.
- Removed the permanent separate year + month dropdown arrangement.
- Year navigation supports previous/next year buttons.
- Clicking the year opens a scrollable year list centered on the currently selected year, not 2100.
- Month selection uses a clean 3x4 grid.
- Added `Энэ сар` shortcut.

## Appointment duration visibility
- Appointment cards have a permanent duration badge: `15 мин`, `30 мин`, `45 мин`, `60 мин`, etc.
- The duration badge stays visible even on short appointments.
- Drag/resize still shows a live duration HUD while changing the appointment.
- Status is separated from the duration so one no longer hides the other.

## Desktop density
- Reduced the global content width to a more deliberate max width.
- Generic modules and purchase-order style screens no longer feel unnecessarily stretched on very wide monitors.
- Data-heavy areas retain their own internal overflow where necessary.

## Database
No new SQL migration is required for V8.16.
Continue using the existing deadlock-safe V8.12.1 migration if it has not been run successfully yet.
