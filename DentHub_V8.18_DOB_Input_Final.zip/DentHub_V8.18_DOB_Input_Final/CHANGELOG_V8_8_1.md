# DentHub V8.8.1 — Build Hotfix

## Fixed

- Fixed the production TypeScript build failure in `app/api/client/treatment-history/route.ts`.
- The legacy appointment fallback query does not select `history_hidden_at` on databases that predate that column. The fallback rows are now normalized with `history_hidden_at: null` before assignment, keeping one consistent result shape for TypeScript and the response mapper.
- No database migration is required for this hotfix beyond the existing V8.8 migration.

## Upgrade

Use this package instead of V8.8.0, then run:

```bash
npm install
npm run validate:v8.8
npm run build
npx vercel --prod
```
