# DentHub V8.18 Setup

No new Supabase SQL migration is required.

Run:

```bat
npm install
npm run validate:v8.18
npm run build
npx vercel --prod
```
