# DentHub V8.17 setup

No new SQL migration is required.

Run:

```bat
npm install
npm run validate:v8.17
npm run build
npx vercel --prod
```

Only deploy after `npm run build` completes successfully.
