# DentHub V8.8 — Public Launch / Auth / App Experience

## Fixed
- Fixed the production TypeScript failure in `app/api/client/card/route.ts` where patient rows were inferred as `unknown`.
- Pinned Next.js to the August 2026 patched maintenance release `15.5.24`.
- Replaced the stale npm SheetJS package with official SheetJS `0.20.3` from `cdn.sheetjs.com` while preserving existing Excel APIs.

## Authentication / registration
- Rebuilt the login/register experience for desktop and mobile.
- Added confirm-password and password-strength feedback to registration.
- Added proper browser password-manager/autofill metadata.
- Added self-service password recovery: phone -> SMS OTP -> new password.
- Recovery no longer requires a clinic owner or Platform Admin to manually assign a temporary password.
- Added database-backed recovery throttling and password-reset audit events.
- New auth users also receive their phone identity while the legacy internal email login remains intact for compatibility.

## App / public launch
- Added web-app manifest, app icon metadata and a minimal service worker for installability.
- The service worker intentionally does not cache pages, API responses, Supabase responses, medical files or patient information.
- Added mobile DentHub branding and responsive auth polish.

## Required migration
Run `supabase/v8_8_auth_public_launch.sql` after the V8.7 migration.
