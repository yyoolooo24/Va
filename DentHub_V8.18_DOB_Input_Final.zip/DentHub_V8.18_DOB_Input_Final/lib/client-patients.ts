export function clientPhoneCandidates(raw?:string|null){
  const digits=String(raw||'').replace(/\D/g,'');
  const local=digits.slice(-8);
  return Array.from(new Set([String(raw||'').trim(),local,local?`+976${local}`:''].filter(Boolean)));
}

export async function ensureClientPatientLinks(admin:any,profile:any){
  const linked=await admin.from('patients').select('id,clinic_id,user_id,phone').eq('user_id',profile.id).is('deleted_at',null);
  if(linked.error)throw linked.error;
  const map=new Map((linked.data||[]).map((p:any)=>[p.id,p]));
  const phones=clientPhoneCandidates(profile.phone);
  if(phones.length){
    const matches=await admin.from('patients').select('id,clinic_id,user_id,phone').in('phone',phones).is('deleted_at',null);
    if(matches.error)throw matches.error;
    for(const patient of matches.data||[]){
      if(patient.user_id&&patient.user_id!==profile.id)continue;
      if(!patient.user_id){
        const updated=await admin.from('patients').update({user_id:profile.id}).eq('id',patient.id).is('user_id',null);
        if(updated.error)throw updated.error;
      }
      map.set(patient.id,{...patient,user_id:profile.id});
    }
  }
  return Array.from(map.values());
}
