'use client';

import { useEffect } from 'react';
import { getSupabaseBrowser, isSupabaseConfigured } from './supabase-browser';

export function useAppointmentRealtime(clinicId:string|undefined|null, onChange:()=>void) {
  useEffect(() => {
    if (!clinicId || !isSupabaseConfigured()) return;
    const supabase = getSupabaseBrowser();
    if (!supabase) return;
    let timer: ReturnType<typeof setTimeout> | null = null;
    const refresh = () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(onChange, 120);
    };
    const channel = supabase
      .channel(`appointments-live-${clinicId}-${Math.random().toString(36).slice(2)}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'appointments', filter: `clinic_id=eq.${clinicId}` }, refresh)
      .subscribe();
    return () => {
      if (timer) clearTimeout(timer);
      supabase.removeChannel(channel);
    };
  }, [clinicId, onChange]);
}
