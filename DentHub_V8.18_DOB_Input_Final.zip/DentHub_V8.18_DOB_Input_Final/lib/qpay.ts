type QPayToken = {
  token_type?: string;
  refresh_token?: string;
  access_token: string;
  expires_in?: number;
};

let tokenCache: { token: string; expiresAt: number } | null = null;

function baseUrl() {
  return process.env.QPAY_BASE_URL || 'https://merchant-sandbox.qpay.mn';
}

export function qpayIsConfigured() {
  return Boolean(process.env.QPAY_CLIENT_ID && process.env.QPAY_CLIENT_SECRET && process.env.QPAY_INVOICE_CODE);
}

export function qpayDemoMode() {
  return process.env.QPAY_DEMO_MODE !== 'false' || !qpayIsConfigured();
}

async function getToken() {
  if (tokenCache && Date.now() < tokenCache.expiresAt - 60_000) return tokenCache.token;
  const clientId = process.env.QPAY_CLIENT_ID!;
  const clientSecret = process.env.QPAY_CLIENT_SECRET!;
  const basic = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  const response = await fetch(`${baseUrl()}/v2/auth/token`, {
    method: 'POST',
    headers: { Authorization: `Basic ${basic}`, 'Content-Type': 'application/json' },
    cache: 'no-store',
  });
  const body = (await response.json()) as QPayToken & { message?: string };
  if (!response.ok || !body.access_token) {
    throw new Error(body.message || `QPay auth failed (${response.status})`);
  }
  tokenCache = {
    token: body.access_token,
    expiresAt: Date.now() + Math.max((body.expires_in || 300) * 1000, 120_000),
  };
  return body.access_token;
}

async function qpayFetch(path: string, init: RequestInit) {
  const token = await getToken();
  const response = await fetch(`${baseUrl()}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...(init.headers || {}),
    },
    cache: 'no-store',
  });
  const text = await response.text();
  let body: any = null;
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
  if (!response.ok) throw new Error(body?.message || body?.error || `QPay request failed (${response.status})`);
  return body;
}

export async function createQPayInvoice(input: {
  senderInvoiceNo: string;
  amount: number;
  description: string;
  receiverCode?: string;
  callbackUrl: string;
}) {
  return qpayFetch('/v2/invoice', {
    method: 'POST',
    body: JSON.stringify({
      invoice_code: process.env.QPAY_INVOICE_CODE,
      sender_invoice_no: input.senderInvoiceNo,
      sender_branch_code: process.env.QPAY_SENDER_BRANCH_CODE || 'MAIN',
      invoice_receiver_code: input.receiverCode || process.env.QPAY_INVOICE_RECEIVER_CODE || 'terminal',
      invoice_description: input.description,
      amount: Math.round(input.amount),
      callback_url: input.callbackUrl,
    }),
  });
}

export async function checkQPayPayment(invoiceId: string) {
  return qpayFetch('/v2/payment/check', {
    method: 'POST',
    body: JSON.stringify({
      object_type: 'INVOICE',
      object_id: invoiceId,
      offset: { page_number: 1, page_limit: 100 },
    }),
  });
}

export async function createQPayEbarimt(input: {
  paymentId: string;
  receiverType: 'CITIZEN' | 'COMPANY';
  receiver?: string;
  districtCode?: string;
  classificationCode?: string;
}) {
  return qpayFetch('/v2/ebarimt_v3/create', {
    method: 'POST',
    body: JSON.stringify({
      payment_id: input.paymentId,
      ebarimt_receiver_type: input.receiverType,
      ...(input.receiver ? { ebarimt_receiver: input.receiver } : {}),
      district_code: input.districtCode || process.env.QPAY_EBARIMT_DISTRICT_CODE || undefined,
      classification_code: input.classificationCode || process.env.QPAY_EBARIMT_CLASSIFICATION_CODE || undefined,
    }),
  });
}
