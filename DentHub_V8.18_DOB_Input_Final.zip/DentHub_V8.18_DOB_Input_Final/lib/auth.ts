import { NextRequest } from 'next/server';
import { getSupabaseAdmin, getSupabasePublicServer } from './supabase-admin';

export type AppRole = 'platform_admin' | 'owner' | 'employee' | 'client' | 'supplier';

export type ClinicAccess = {
  id: string;
  status: string;
  plan: string;
  enabled_modules: string[];
  employee_limit: number;
  subscription_ends_at?: string | null;
  trial_ends_at?: string | null;
  grace_ends_at?: string | null;
};

function clinicUsable(clinic: ClinicAccess) {
  if (!['active', 'trial'].includes(String(clinic.status || '').toLowerCase())) return false;
  const now = Date.now();
  const end = clinic.subscription_ends_at ? new Date(clinic.subscription_ends_at).getTime() : null;
  const grace = clinic.grace_ends_at ? new Date(clinic.grace_ends_at).getTime() : null;
  if (end && end < now && (!grace || grace < now)) return false;
  const trialEnd = clinic.trial_ends_at ? new Date(clinic.trial_ends_at).getTime() : null;
  if (String(clinic.status).toLowerCase() === 'trial' && trialEnd && trialEnd < now) return false;
  return true;
}

export async function requireApiUser(request: NextRequest, allowed?: AppRole[]) {
  const auth = request.headers.get('authorization');
  if (!auth?.startsWith('Bearer ')) throw new Error('UNAUTHORIZED');
  const token = auth.slice(7);
  const publicClient = getSupabasePublicServer();
  const { data, error } = await publicClient.auth.getUser(token);
  if (error || !data.user) throw new Error('UNAUTHORIZED');

  const admin = getSupabaseAdmin();
  const { data: profile, error: profileError } = await admin
    .from('profiles')
    .select('id, clinic_id, role, full_name, phone, active, specialty, staff_type, allowed_modules')
    .eq('id', data.user.id)
    .single();

  if (profileError || !profile) throw new Error('PROFILE_NOT_FOUND');
  if ((profile as any).active === false) throw new Error('ACCOUNT_DISABLED');
  if (allowed && !allowed.includes(profile.role as AppRole)) throw new Error('FORBIDDEN');

  let clinic: ClinicAccess | null = null;
  if (profile.clinic_id && profile.role !== 'platform_admin') {
    const { data: clinicRow, error: clinicError } = await admin
      .from('clinics')
      .select('id,status,plan,enabled_modules,employee_limit,subscription_ends_at,trial_ends_at,grace_ends_at')
      .eq('id', profile.clinic_id)
      .maybeSingle();
    if (clinicError || !clinicRow) throw new Error('CLINIC_NOT_FOUND');
    clinic = clinicRow as ClinicAccess;
    if (!clinicUsable(clinic)) throw new Error('CLINIC_ACCESS_BLOCKED');
  }

  return { user: data.user, profile, clinic, admin };
}

export function requireModule(auth: Awaited<ReturnType<typeof requireApiUser>>, moduleKey: string) {
  if (auth.profile.role === 'platform_admin') return;
  if (!auth.clinic || !auth.clinic.enabled_modules?.includes(moduleKey)) throw new Error('MODULE_NOT_INCLUDED');
  if (auth.profile.role === 'employee') {
    const allowed = Array.isArray(auth.profile.allowed_modules) ? auth.profile.allowed_modules : [];
    if (!allowed.includes(moduleKey)) throw new Error('MODULE_NOT_ALLOWED');
  }
}

export function apiErrorStatus(message: string) {
  if (message === 'UNAUTHORIZED') return 401;
  if (['FORBIDDEN', 'ACCOUNT_DISABLED', 'CLINIC_ACCESS_BLOCKED', 'MODULE_NOT_INCLUDED', 'MODULE_NOT_ALLOWED'].includes(message)) return 403;
  if (['PROFILE_NOT_FOUND', 'CLINIC_NOT_FOUND'].includes(message)) return 404;
  return 500;
}

export function normalizeMongolianPhone(phone: string) {
  const raw = phone.replace(/\D/g, '');
  const digits = raw.startsWith('976') ? raw.slice(3) : raw;
  if (digits.length !== 8) throw new Error('Утасны дугаар 8 оронтой байна.');
  return `+976${digits}`;
}

export function mongolianPhoneDigits(phone: string) {
  const raw = phone.replace(/\D/g, '');
  return (raw.startsWith('976') ? raw.slice(3) : raw).slice(0, 8);
}

// Preserve the legacy internal login mapping so all existing users continue to work.
export function phoneToInternalEmail(phone: string) {
  const normalized = normalizeMongolianPhone(phone);
  const digits = normalized.replace(/\D/g, '');
  return `${digits}@phone.clinicos.app`;
}
