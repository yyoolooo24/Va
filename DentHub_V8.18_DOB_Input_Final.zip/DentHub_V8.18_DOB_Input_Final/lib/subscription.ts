export const CLINIC_MODULES = [
  'appointments','consent_forms','patients','patient_cards','treatment_history','treatments','payments','erp',
  'sales','sales_returns','cashbook','price_lists','services','inventory','stock_movements','suppliers','procurement',
  'purchase_orders','lab_orders','crm','insurance','invoices','receivables','expenses','finance','staff','shifts',
  'assets','branches','internal_procedures','health_department','questionnaire','contracts','reports','chat',
] as const;

export type ClinicModule = typeof CLINIC_MODULES[number];

export const PLAN_MODULES: Record<string, ClinicModule[]> = {
  START: ['appointments','consent_forms','patients','patient_cards','treatment_history','treatments','services','staff','internal_procedures','chat'],
  GROWTH: ['appointments','consent_forms','patients','patient_cards','treatment_history','treatments','payments','erp','sales','cashbook','price_lists','services','inventory','stock_movements','suppliers','procurement','purchase_orders','lab_orders','receivables','expenses','finance','staff','internal_procedures','contracts','reports','chat'],
  NETWORK: [...CLINIC_MODULES],
};

export const MODULE_LABELS: Record<ClinicModule, { mn: string; en: string }> = {
  appointments:{mn:'Цаг товлол',en:'Appointments'}, consent_forms:{mn:'Зөвшөөрлийн хуудас',en:'Consent Forms'}, patients:{mn:'Өвчтөн',en:'Patients'},
  patient_cards:{mn:'Өвчтөний карт',en:'Patient Cards'}, treatment_history:{mn:'Эмчилгээний түүх',en:'Treatment History'}, treatments:{mn:'Үзлэг, эмчилгээ',en:'Treatments'},
  payments:{mn:'Касс',en:'Cashier'}, erp:{mn:'ERP тойм',en:'ERP Overview'}, sales:{mn:'Борлуулалт',en:'Sales'}, sales_returns:{mn:'Буцаалт',en:'Returns'},
  cashbook:{mn:'Кассын журнал',en:'Cashbook'}, price_lists:{mn:'Үнийн жагсаалт',en:'Price Lists'}, services:{mn:'Үйлчилгээ ба үнэ',en:'Services & Pricing'},
  inventory:{mn:'Бараа материал',en:'Inventory'}, stock_movements:{mn:'Барааны хөдөлгөөн',en:'Stock Movement'}, suppliers:{mn:'Ханган нийлүүлэгч',en:'Suppliers'},
  procurement:{mn:'Худалдан авалт',en:'Procurement'}, purchase_orders:{mn:'Худалдан авалтын захиалга',en:'Purchase Orders'}, lab_orders:{mn:'Лабораторийн захиалга',en:'Lab Orders'},
  crm:{mn:'Харилцагчийн бүртгэл',en:'CRM'}, insurance:{mn:'Даатгал',en:'Insurance'}, invoices:{mn:'Нэхэмжлэх',en:'Invoices'}, receivables:{mn:'Авлага',en:'Receivables'},
  expenses:{mn:'Зардал',en:'Expenses'}, finance:{mn:'Санхүү',en:'Finance'}, staff:{mn:'Ажилтнууд',en:'Staff'}, shifts:{mn:'Ээлж ба хуваарь',en:'Shifts'},
  assets:{mn:'Үндсэн хөрөнгө',en:'Assets'}, branches:{mn:'Салбарууд',en:'Branches'}, internal_procedures:{mn:'Дотоод журам',en:'Internal Procedures'},
  health_department:{mn:'Нийслэлийн ЭМГ',en:'Health Department'}, questionnaire:{mn:'Бүртгэл ба асуумж',en:'Questionnaire'}, contracts:{mn:'Гэрээ',en:'Contracts'},
  reports:{mn:'Тайлан',en:'Reports'}, chat:{mn:'Чат',en:'Chat'},
};

export const MODULE_GROUPS: { id:string; mn:string; en:string; descriptionMn:string; descriptionEn:string; modules:ClinicModule[] }[] = [
  {
    id:'clinical', mn:'Өдөр тутмын эмчилгээ', en:'Clinical workflow',
    descriptionMn:'Цаг, өвчтөн, карт, эмчилгээ болон өдөр тутмын харилцаа.',
    descriptionEn:'Appointments, patients, clinical records and everyday communication.',
    modules:['appointments','consent_forms','patients','patient_cards','treatment_history','treatments','services','chat'],
  },
  {
    id:'cashier', mn:'Касс ба санхүү', en:'Cashier & finance',
    descriptionMn:'Төлбөр, борлуулалт, журнал, авлага, зардал болон санхүү.',
    descriptionEn:'Payments, sales, cashbook, receivables, expenses and finance.',
    modules:['payments','sales','sales_returns','cashbook','price_lists','invoices','receivables','expenses','finance'],
  },
  {
    id:'inventory', mn:'Хангамж ба бараа материал', en:'Inventory & supply',
    descriptionMn:'Агуулах, барааны хөдөлгөөн, нийлүүлэгч, худалдан авалт болон лаборатори.',
    descriptionEn:'Inventory, stock movement, suppliers, purchasing and lab orders.',
    modules:['inventory','stock_movements','suppliers','procurement','purchase_orders','lab_orders','assets'],
  },
  {
    id:'management', mn:'Удирдлага ба хүний нөөц', en:'Management & staff',
    descriptionMn:'ERP тойм, ажилтан, ээлж, салбар, журам болон гэрээ.',
    descriptionEn:'ERP overview, staff, shifts, branches, procedures and contracts.',
    modules:['erp','staff','shifts','branches','internal_procedures','contracts'],
  },
  {
    id:'reporting', mn:'Тайлан ба нэмэлт хэрэгсэл', en:'Reporting & extensions',
    descriptionMn:'ЭМГ тайлан, асуумж, CRM, даатгал болон удирдлагын тайлан.',
    descriptionEn:'Regulatory reports, questionnaire, CRM, insurance and reporting.',
    modules:['health_department','questionnaire','crm','insurance','reports'],
  },
];

export type SubscriptionPlanDefinition = {
  code:string;
  name_mn:string;
  name_en:string;
  description_mn?:string|null;
  description_en?:string|null;
  enabled_modules:ClinicModule[];
  employee_limit:number;
  price:number;
  billing_cycle:'monthly'|'yearly'|'custom';
  duration_months:number;
  active:boolean;
  sort_order:number;
};

export const BUILTIN_SUBSCRIPTION_PLANS: SubscriptionPlanDefinition[] = [
  {code:'START',name_mn:'Start',name_en:'Start',description_mn:'Жижиг эмнэлгийн үндсэн өдөр тутмын ажил.',description_en:'Core daily workflow for a small clinic.',enabled_modules:PLAN_MODULES.START,employee_limit:5,price:0,billing_cycle:'monthly',duration_months:1,active:true,sort_order:10},
  {code:'GROWTH',name_mn:'Growth',name_en:'Growth',description_mn:'Өсөж буй эмнэлгийн касс, бараа материал, санхүү.',description_en:'Cashier, inventory and finance for a growing clinic.',enabled_modules:PLAN_MODULES.GROWTH,employee_limit:25,price:0,billing_cycle:'monthly',duration_months:1,active:true,sort_order:20},
  {code:'NETWORK',name_mn:'Network',name_en:'Network',description_mn:'Бүх модуль болон олон салбарын бүрэн эрх.',description_en:'Full module access for larger and multi-branch clinics.',enabled_modules:PLAN_MODULES.NETWORK,employee_limit:100,price:0,billing_cycle:'monthly',duration_months:1,active:true,sort_order:30},
];

export function sanitizeClinicModules(value: unknown): ClinicModule[] {
  const allowed = new Set<string>(CLINIC_MODULES);
  return Array.isArray(value) ? Array.from(new Set(value.map(String).filter(x => allowed.has(x)))) as ClinicModule[] : [];
}

export function planLabel(plan: Pick<SubscriptionPlanDefinition,'code'|'name_mn'|'name_en'>, lang:'MN'|'EN') {
  return (lang==='EN' ? plan.name_en : plan.name_mn) || plan.code;
}
