'use client';

import { getSupabaseBrowser } from '@/lib/supabase-browser';

export const XRAY_BUCKET = 'patient-xrays';
export const XRAY_MAX_BYTES = 10 * 1024 * 1024;
const ALLOWED_EXTENSIONS = ['png', 'jpg', 'jpeg', 'webp'];
const ALLOWED_MIME = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'];

export type PatientXray = {
  id: string;
  patient_id: string;
  storage_path: string;
  original_filename: string | null;
  mime_type: string | null;
  file_size: number | null;
  xray_type: string | null;
  body_part: string | null;
  taken_at: string | null;
  description: string | null;
  doctor_notes: string | null;
  uploaded_by: string | null;
  created_at: string;
  updated_at: string;
  uploader_name?: string | null;
  signed_url?: string | null;
};

export type XrayMetadataInput = {
  xray_type: string;
  body_part: string;
  taken_at: string | null;
  description: string;
  doctor_notes: string;
};

function supabaseOrThrow() {
  const client = getSupabaseBrowser();
  if (!client) throw new Error('SUPABASE_NOT_CONFIGURED');
  return client;
}

function getExtension(file: File) {
  const parts = file.name.toLowerCase().split('.');
  return parts.length > 1 ? parts.pop() || '' : '';
}

export function validateImage(file: File): string | null {
  const ext = getExtension(file);
  const mimeOk = ALLOWED_MIME.includes(file.type);
  const extOk = ALLOWED_EXTENSIONS.includes(ext);
  if (!mimeOk && !extOk) return 'PNG, JPG, JPEG эсвэл WEBP зураг оруулна уу.';
  if (file.size > XRAY_MAX_BYTES) return 'Зургийн хэмжээ 10MB-аас их байж болохгүй.';
  if (file.size <= 0) return 'Зураг хоосон байна. Өөр файл сонгоно уу.';
  return null;
}
export const validatePng = validateImage;

export function formatFileSize(bytes?: number | null) {
  if (!bytes) return '0 KB';
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(bytes < 10240 ? 1 : 0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export async function createXraySignedUrl(storagePath: string, expiresIn = 600, download = false) {
  const supabase = supabaseOrThrow();
  const { data, error } = await supabase.storage.from(XRAY_BUCKET).createSignedUrl(
    storagePath,
    expiresIn,
    download ? { download: true } : undefined,
  );
  if (error) throw error;
  return data.signedUrl;
}

export async function getPatientXrays(patientId: string): Promise<PatientXray[]> {
  const supabase = supabaseOrThrow();
  const { data, error } = await supabase
    .from('patient_xrays')
    .select('id,patient_id,storage_path,original_filename,mime_type,file_size,xray_type,body_part,taken_at,description,doctor_notes,uploaded_by,created_at,updated_at')
    .eq('patient_id', patientId)
    .order('created_at', { ascending: false });
  if (error) throw error;

  const rows = (data || []) as PatientXray[];
  const uploaderIds = [...new Set(rows.map(row => row.uploaded_by).filter(Boolean) as string[])];
  let names = new Map<string, string>();
  if (uploaderIds.length) {
    const { data: profiles } = await supabase.from('profiles').select('id,full_name').in('id', uploaderIds);
    names = new Map((profiles || []).map((p: { id: string; full_name: string }) => [p.id, p.full_name]));
  }

  const withUrls = await Promise.all(rows.map(async row => {
    let signed_url: string | null = null;
    try { signed_url = await createXraySignedUrl(row.storage_path, 900); } catch { signed_url = null; }
    return { ...row, uploader_name: row.uploaded_by ? names.get(row.uploaded_by) || null : null, signed_url };
  }));
  return withUrls;
}

async function uploadOne(input: {
  patientId: string;
  file: File;
  metadata: XrayMetadataInput;
  uploadedBy: string;
}): Promise<PatientXray> {
  const supabase = supabaseOrThrow();
  if (!input.patientId) throw new Error('PATIENT_REQUIRED');
  if (!input.uploadedBy) throw new Error('AUTH_REQUIRED');
  const validationError = validateImage(input.file);
  if (validationError) throw new Error(validationError);

  const ext = getExtension(input.file) || 'png';
  const filename = `${crypto.randomUUID()}.${ext}`;
  const storagePath = `${input.patientId}/${filename}`;
  const { error: uploadError } = await supabase.storage.from(XRAY_BUCKET).upload(storagePath, input.file, {
    contentType: input.file.type || `image/${ext}`,
    cacheControl: '3600',
    upsert: false,
  });
  if (uploadError) throw uploadError;

  const takenAt = input.metadata.taken_at ? `${input.metadata.taken_at}T00:00:00` : null;
  const { data, error: insertError } = await supabase.from('patient_xrays').insert({
    patient_id: input.patientId,
    storage_path: storagePath,
    original_filename: input.file.name,
    mime_type: input.file.type,
    file_size: input.file.size,
    xray_type: input.metadata.xray_type || 'X-ray',
    body_part: input.metadata.body_part || null,
    taken_at: takenAt,
    description: input.metadata.description.trim() || null,
    doctor_notes: input.metadata.doctor_notes.trim() || null,
    uploaded_by: input.uploadedBy,
  }).select('*').single();

  if (insertError) {
    await supabase.storage.from(XRAY_BUCKET).remove([storagePath]);
    throw insertError;
  }
  return data as PatientXray;
}

export async function uploadPatientXray(input: {
  patientId: string;
  file: File;
  metadata: XrayMetadataInput;
  uploadedBy: string;
}): Promise<PatientXray> {
  return uploadOne(input);
}

export async function uploadPatientXrays(input: {
  patientId: string;
  files: File[];
  metadata: XrayMetadataInput;
  uploadedBy: string;
}): Promise<PatientXray[]> {
  if (!input.files.length) throw new Error('Зураг сонгоно уу.');
  const results: PatientXray[] = [];
  for (const file of input.files) {
    results.push(await uploadOne({ ...input, file }));
  }
  return results;
}

export async function updatePatientXray(id: string, metadata: XrayMetadataInput): Promise<PatientXray> {
  const supabase = supabaseOrThrow();
  const takenAt = metadata.taken_at ? `${metadata.taken_at}T00:00:00` : null;
  const { data, error } = await supabase.from('patient_xrays').update({
    xray_type: metadata.xray_type || 'X-ray',
    body_part: metadata.body_part || null,
    taken_at: takenAt,
    description: metadata.description.trim() || null,
    doctor_notes: metadata.doctor_notes.trim() || null,
  }).eq('id', id).select('*').single();
  if (error) throw error;
  return data as PatientXray;
}

export async function deletePatientXray(xray: Pick<PatientXray, 'id' | 'storage_path'>) {
  const supabase = supabaseOrThrow();
  const { error: storageError } = await supabase.storage.from(XRAY_BUCKET).remove([xray.storage_path]);
  if (storageError) throw storageError;
  const { error: rowError } = await supabase.from('patient_xrays').delete().eq('id', xray.id);
  if (rowError) throw rowError;
}
