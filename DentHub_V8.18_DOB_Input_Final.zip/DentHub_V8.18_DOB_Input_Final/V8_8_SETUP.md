# DentHub V8.8 setup

## 1. Database
Back up Supabase, then run these migrations in order if they have not already been run:
1. `supabase/v8_7_subscription_platform_security.sql`
2. `supabase/v8_8_auth_public_launch.sql`

## 2. Enable SMS password recovery
DentHub V8.8 uses Supabase Phone Auth OTP for self-service recovery.

In Supabase Dashboard:
1. Authentication -> Providers -> Phone: enable Phone Auth.
2. Configure an SMS provider supported by your Supabase project (for example Twilio, Vonage, MessageBird or TextLocal where available).
3. Set sensible Auth rate limits and CAPTCHA before a public launch.

DentHub will not fake SMS delivery. If Phone Auth/SMS is not configured, the recovery screen returns a clear configuration error.

## 3. Environment variables
Use the existing `.env.local` values from V8.7. No SMS secret is stored in the DentHub frontend; Supabase owns the SMS provider configuration.

## 4. Install / validate / build
```bash
npm install
npm run validate:v8.8
npm run build
npx vercel --prod
```

## 5. App behavior
The included manifest and service worker make the web app installable where browser/platform rules allow. The service worker does not cache medical or API data. Native App Store / Google Play packaging can wrap the production web app later, but should keep the same server-side auth and Supabase security model.
