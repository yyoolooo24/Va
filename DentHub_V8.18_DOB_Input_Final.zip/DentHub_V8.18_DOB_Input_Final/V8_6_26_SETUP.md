# DentHub V8.6.26 setup

V8.6.25 хүртэлх migration-уудаа ажиллуулсан database дээр дараах SQL-ийг **нэг удаа** ажиллуулна:

`supabase/v8_6_26_consent_branding_print.sql`

Дараа нь:

```bash
npm install
npm run build
npx vercel --prod
```

## Test checklist

1. Owner → Удирдлага → Эмнэлгийн нэр, лого & брэндинг → нэр солих, logo upload хийх.
2. Sidebar дээр шинэ нэр/logo шууд өөрчлөгдөж байгаа эсэх.
3. Өвчтөний карт → logo зүүн дээд талд харагдах, Print хийхэд A4 дээр logo зүүн дээд талд гарах.
4. Өдөр тутмын үйл ажиллагаа → Зөвшөөрлийн хуудас → өвчтөн сонгох → хадгалах → хэвлэх.
5. Дотоод журам → logo/name харагдах → дурын журам дээр Хэвлэх.
