# DentHub V8.12 setup

1. Back up Supabase.
2. Run `supabase/v8_12_stability_ux_fix.sql` in Supabase SQL Editor after the V8.11 migration.
3. Run `npm install`.
4. Run `npm run validate:v8.12`.
5. Run `npm run build`.
6. Only after a successful build, deploy with `npx vercel --prod`.

V8.12 does not replace earlier migrations. It is additive and safe to re-run.
