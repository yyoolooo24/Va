# DentHub V8.6.24 setup

1. Back up your Supabase database.
2. Make sure the migrations through V8.6.23 / V8.6.22 have already been applied.
3. Run `supabase/v8_6_24_cashier_receipt_ortho.sql` in Supabase SQL Editor.
4. Deploy the package:

```bash
npm install
npm run build
npx vercel --prod
```

## Test checklist

1. **Үзлэг, эмчилгээ** → choose a normal treatment → select tooth/teeth → save → confirm only total is shown → **Дуусгаад Касс руу илгээх**.
2. **Касс** → waiting visit appears → choose payment method → save → verify **Кассын журнал** contains the entry.
3. Repeat with **Баримт / eBarimt авах** checked → verify the patient appears in **Нийслэлийн ЭМГ → Сарын тайлан → Баримт / eBarimt авсан хүмүүс**.
4. Choose **Гажиг засал** → search treatment → save without selecting any tooth.
5. Choose another treatment group → verify DentHub still requires at least one tooth.
