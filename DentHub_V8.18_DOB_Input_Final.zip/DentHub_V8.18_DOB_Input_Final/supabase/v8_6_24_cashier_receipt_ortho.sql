-- DentHub V8.6.24 — cashier handoff + cashbook reliability + receipt reporting
-- Run after V8.6.23 / V8.6.22 migrations.

-- Mark any cashier income that was issued/selected with a receipt/eBarimt.
alter table public.finance_transactions
  add column if not exists request_ebarimt boolean not null default false;
alter table public.finance_transactions
  add column if not exists ebarimt_receiver_type text;
alter table public.finance_transactions
  add column if not exists ebarimt_receiver text;
alter table public.finance_transactions
  add column if not exists receipt_reference text;

create index if not exists finance_transactions_receipt_report_idx
  on public.finance_transactions(clinic_id, request_ebarimt, created_at desc)
  where request_ebarimt=true;

-- Cashier-only atomic payment writer. This always creates BOTH:
-- 1) finance_transactions = Кассын журнал
-- 2) encounter_payments = visit payment ledger
-- and keeps encounters.paid_amount/billing_status synchronized.
create or replace function public.denthub_record_encounter_payment_v2(
  p_encounter_id uuid,
  p_amount numeric,
  p_payment_method_id uuid,
  p_note text default null,
  p_request_ebarimt boolean default false,
  p_ebarimt_receiver_type text default null,
  p_ebarimt_receiver text default null
)
returns table(payment_id uuid, finance_transaction_id uuid, paid_amount numeric, remaining_amount numeric, billing_status text)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_clinic uuid;
  v_patient uuid;
  v_total numeric(14,2);
  v_method_name text;
  v_finance_id uuid;
  v_payment_id uuid;
  v_paid numeric(14,2);
  v_status text;
  v_description text;
begin
  if auth.uid() is null or public.current_app_role() not in ('owner','employee') then
    raise exception 'FORBIDDEN';
  end if;
  if p_amount is null or p_amount <= 0 then
    raise exception 'PAYMENT_AMOUNT_INVALID';
  end if;

  select e.clinic_id,e.patient_id,coalesce(e.total_amount,0)
    into v_clinic,v_patient,v_total
  from public.encounters e
  where e.id=p_encounter_id and e.deleted_at is null
  for update;

  if v_clinic is null or v_clinic is distinct from public.current_clinic_id() then
    raise exception 'ENCOUNTER_NOT_FOUND';
  end if;

  select pm.name into v_method_name
  from public.payment_methods pm
  where pm.id=p_payment_method_id and pm.clinic_id=v_clinic and pm.active=true;
  if v_method_name is null then raise exception 'PAYMENT_METHOD_NOT_FOUND'; end if;

  select coalesce(sum(ep.amount),0)::numeric(14,2) into v_paid
  from public.encounter_payments ep where ep.encounter_id=p_encounter_id;

  if v_total > 0 and p_amount > greatest(v_total-v_paid,0) + 0.009 then
    raise exception 'PAYMENT_EXCEEDS_REMAINING';
  end if;

  select coalesce(p.full_name,'Өвчтөн')||' · Үзлэг, эмчилгээ'
    into v_description from public.patients p where p.id=v_patient;

  insert into public.finance_transactions(
    clinic_id,created_by,kind,description,amount,payment_method,patient_id,encounter_id,
    request_ebarimt,ebarimt_receiver_type,ebarimt_receiver
  ) values(
    v_clinic,auth.uid(),'income',coalesce(v_description,'Үзлэг, эмчилгээ'),round(p_amount)::bigint,
    v_method_name,v_patient,p_encounter_id,coalesce(p_request_ebarimt,false),
    nullif(btrim(coalesce(p_ebarimt_receiver_type,'')),''),
    nullif(btrim(coalesce(p_ebarimt_receiver,'')),'')
  ) returning id into v_finance_id;

  insert into public.encounter_payments(
    clinic_id,encounter_id,patient_id,amount,payment_method_id,payment_method_name,
    note,finance_transaction_id,created_by
  ) values(
    v_clinic,p_encounter_id,v_patient,p_amount,p_payment_method_id,v_method_name,
    nullif(btrim(coalesce(p_note,'')),''),v_finance_id,auth.uid()
  ) returning id into v_payment_id;

  select coalesce(sum(ep.amount),0)::numeric(14,2) into v_paid
  from public.encounter_payments ep where ep.encounter_id=p_encounter_id;

  v_status := case
    when v_total <= 0 then 'no_charge'
    when v_paid >= v_total then 'paid'
    when v_paid > 0 then 'partial'
    else 'unpaid'
  end;

  update public.encounters
     set paid_amount=v_paid,billing_status=v_status
   where id=p_encounter_id;

  return query select v_payment_id,v_finance_id,v_paid,greatest(v_total-v_paid,0)::numeric(14,2),v_status;
end $$;

revoke all on function public.denthub_record_encounter_payment_v2(uuid,numeric,uuid,text,boolean,text,text) from public;
grant execute on function public.denthub_record_encounter_payment_v2(uuid,numeric,uuid,text,boolean,text,text) to authenticated;

-- Backfill receipt flags on already-paid QPay transactions where possible.
update public.finance_transactions ft
set request_ebarimt=true,
    ebarimt_receiver_type=coalesce(ft.ebarimt_receiver_type, qi.ebarimt_receiver_type),
    ebarimt_receiver=coalesce(ft.ebarimt_receiver, qi.ebarimt_receiver),
    receipt_reference=coalesce(
      ft.receipt_reference,
      qi.ebarimt_payload->>'ebarimt_lottery',
      qi.ebarimt_payload->>'lottery',
      qi.ebarimt_payload->>'receipt_id',
      qi.ebarimt_payload->>'billId',
      qi.ebarimt_payload->>'bill_id'
    )
from public.qpay_invoices qi
where qi.finance_transaction_id=ft.id
  and qi.request_ebarimt=true
  and qi.status='PAID';
