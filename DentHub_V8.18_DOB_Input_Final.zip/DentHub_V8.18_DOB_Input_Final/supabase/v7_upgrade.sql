-- ClinicOS V7 production upgrade
-- Safe to run after the V6/V6.2 schema in Supabase SQL Editor.

create table if not exists public.encounters (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  patient_id uuid not null references public.patients(id) on delete cascade,
  doctor_id uuid references public.profiles(id) on delete set null,
  diagnosis text,
  treatment_plan text,
  notes text,
  status text not null default 'open' check (status in ('open','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.finance_transactions (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  created_by uuid references public.profiles(id) on delete set null,
  kind text not null check (kind in ('income','expense')),
  description text not null,
  amount bigint not null check (amount >= 0),
  payment_method text,
  created_at timestamptz not null default now()
);

create table if not exists public.direct_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 3000),
  read_at timestamptz,
  created_at timestamptz not null default now(),
  check (sender_id <> recipient_id)
);

create index if not exists idx_encounters_clinic on public.encounters(clinic_id,created_at desc);
create index if not exists idx_finance_clinic on public.finance_transactions(clinic_id,created_at desc);
create index if not exists idx_messages_sender_recipient on public.direct_messages(sender_id,recipient_id,created_at desc);
create index if not exists idx_messages_recipient on public.direct_messages(recipient_id,created_at desc);

alter table public.encounters enable row level security;
alter table public.finance_transactions enable row level security;
alter table public.direct_messages enable row level security;

drop policy if exists "encounters_select" on public.encounters;
create policy "encounters_select" on public.encounters for select to authenticated using (
  public.current_app_role()='platform_admin' or
  (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')) or
  exists(select 1 from public.patients p where p.id=patient_id and p.user_id=auth.uid())
);

drop policy if exists "encounters_staff_write" on public.encounters;
create policy "encounters_staff_write" on public.encounters for all to authenticated using (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
) with check (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
);

drop policy if exists "finance_select" on public.finance_transactions;
create policy "finance_select" on public.finance_transactions for select to authenticated using (
  public.current_app_role()='platform_admin' or
  (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
);

drop policy if exists "finance_owner_write" on public.finance_transactions;
create policy "finance_owner_write" on public.finance_transactions for all to authenticated using (
  clinic_id=public.current_clinic_id() and public.current_app_role()='owner'
) with check (
  clinic_id=public.current_clinic_id() and public.current_app_role()='owner'
);

drop policy if exists "messages_participant_select" on public.direct_messages;
create policy "messages_participant_select" on public.direct_messages for select to authenticated using (
  sender_id=auth.uid() or recipient_id=auth.uid()
);

drop policy if exists "messages_sender_insert" on public.direct_messages;
create policy "messages_sender_insert" on public.direct_messages for insert to authenticated with check (
  sender_id=auth.uid() and public.current_app_role() in ('owner','employee')
);

drop policy if exists "messages_participant_update" on public.direct_messages;
create policy "messages_participant_update" on public.direct_messages for update to authenticated using (
  sender_id=auth.uid() or recipient_id=auth.uid()
) with check (
  sender_id=auth.uid() or recipient_id=auth.uid()
);

-- Notification helpers. These functions run server-side and only create notifications
-- for the affected user. They never expose clinic/private patient data.
create or replace function public.notify_post_comment()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare owner_id uuid; actor_name text;
begin
  select author_id into owner_id from public.posts where id=new.post_id;
  if owner_id is null or owner_id=new.author_id then return new; end if;
  select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.author_id;
  insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
  values(owner_id,new.author_id,'comment',coalesce(actor_name,'Эмч'),'Таны нийтлэлд сэтгэгдэл бичлээ','post',new.post_id);
  return new;
end $$;

create or replace function public.notify_post_like()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare owner_id uuid; actor_name text;
begin
  select author_id into owner_id from public.posts where id=new.post_id;
  if owner_id is null or owner_id=new.user_id then return new; end if;
  select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.user_id;
  insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
  values(owner_id,new.user_id,'like',coalesce(actor_name,'Эмч'),'Таны нийтлэл таалагдлаа','post',new.post_id);
  return new;
end $$;

create or replace function public.notify_follow()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare actor_name text;
begin
  select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.follower_id;
  insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
  values(new.following_id,new.follower_id,'follow',coalesce(actor_name,'Эмч'),'Таныг дагаж эхэллээ','profile',new.follower_id);
  return new;
end $$;

create or replace function public.notify_connection_request()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare actor_name text;
begin
  select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.requester_id;
  insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
  values(new.addressee_id,new.requester_id,'connection',coalesce(actor_name,'Эмч'),'Танд холбоо тогтоох хүсэлт илгээлээ','profile',new.requester_id);
  return new;
end $$;

create or replace function public.notify_connection_accept()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare actor_name text;
begin
  if old.status is distinct from new.status and new.status='accepted' then
    select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.addressee_id;
    insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
    values(new.requester_id,new.addressee_id,'connection',coalesce(actor_name,'Эмч'),'Таны холбоо тогтоох хүсэлтийг зөвшөөрлөө','profile',new.addressee_id);
  end if;
  return new;
end $$;

create or replace function public.notify_direct_message()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare actor_name text;
begin
  select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.sender_id;
  insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
  values(new.recipient_id,new.sender_id,'message',coalesce(actor_name,'Эмч'),'Танд шинэ мессеж ирлээ','chat',new.sender_id);
  return new;
end $$;

drop trigger if exists trg_notify_post_comment on public.comments;
create trigger trg_notify_post_comment after insert on public.comments for each row execute function public.notify_post_comment();
drop trigger if exists trg_notify_post_like on public.post_likes;
create trigger trg_notify_post_like after insert on public.post_likes for each row execute function public.notify_post_like();
drop trigger if exists trg_notify_follow on public.follows;
create trigger trg_notify_follow after insert on public.follows for each row execute function public.notify_follow();
drop trigger if exists trg_notify_connection_request on public.connections;
create trigger trg_notify_connection_request after insert on public.connections for each row execute function public.notify_connection_request();
drop trigger if exists trg_notify_connection_accept on public.connections;
create trigger trg_notify_connection_accept after update on public.connections for each row execute function public.notify_connection_accept();
drop trigger if exists trg_notify_direct_message on public.direct_messages;
create trigger trg_notify_direct_message after insert on public.direct_messages for each row execute function public.notify_direct_message();

-- Realtime is used for Facebook-style notification arrival while the app is open.
do $$ begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null;
end $$;


-- V7.1 access lifecycle compatibility
alter table public.profiles
  add column if not exists active boolean not null default true,
  add column if not exists deactivated_at timestamptz,
  add column if not exists deactivated_by uuid references auth.users(id) on delete set null;
create index if not exists profiles_clinic_active_idx on public.profiles(clinic_id, active);


create or replace function public.current_app_role()
returns text
language sql
stable
security definer
set search_path = public
as $$ select role from public.profiles where id = auth.uid() and active = true $$;

create or replace function public.current_clinic_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$ select clinic_id from public.profiles where id = auth.uid() and active = true $$;


-- Users may update their own harmless profile preferences, but cannot re-enable themselves,
-- change clinic, or promote their own role from the browser.
drop policy if exists "profiles_update_self" on public.profiles;
create policy "profiles_update_self" on public.profiles for update to authenticated
using (id = auth.uid() and active = true)
with check (
  id = auth.uid()
  and active = true
  and role = public.current_app_role()
  and clinic_id is not distinct from public.current_clinic_id()
);
