-- DentHub V8.6.26 — consent forms + clinic branding/print support

create table if not exists public.patient_consent_forms (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  patient_id uuid not null references public.patients(id) on delete cascade,
  consent_type text not null default 'treatment',
  title text not null,
  procedure_name text,
  consent_text text not null,
  guardian_name text,
  doctor_name text,
  notes text,
  consent_date date not null default current_date,
  created_by uuid references public.profiles(id),
  updated_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  deleted_by uuid references public.profiles(id)
);

create index if not exists patient_consent_forms_clinic_patient_idx
  on public.patient_consent_forms(clinic_id, patient_id, consent_date desc)
  where deleted_at is null;

alter table public.patient_consent_forms enable row level security;

drop policy if exists "consent_staff_select" on public.patient_consent_forms;
create policy "consent_staff_select" on public.patient_consent_forms
for select to authenticated using (
  exists (
    select 1 from public.profiles p
    where p.id=auth.uid() and p.active=true
      and p.clinic_id=patient_consent_forms.clinic_id
      and p.role in ('owner','employee')
  )
);

drop policy if exists "consent_staff_insert" on public.patient_consent_forms;
create policy "consent_staff_insert" on public.patient_consent_forms
for insert to authenticated with check (
  exists (
    select 1 from public.profiles p
    where p.id=auth.uid() and p.active=true
      and p.clinic_id=patient_consent_forms.clinic_id
      and p.role in ('owner','employee')
  )
);

drop policy if exists "consent_staff_update" on public.patient_consent_forms;
create policy "consent_staff_update" on public.patient_consent_forms
for update to authenticated using (
  exists (
    select 1 from public.profiles p
    where p.id=auth.uid() and p.active=true
      and p.clinic_id=patient_consent_forms.clinic_id
      and p.role in ('owner','employee')
  )
) with check (
  exists (
    select 1 from public.profiles p
    where p.id=auth.uid() and p.active=true
      and p.clinic_id=patient_consent_forms.clinic_id
      and p.role in ('owner','employee')
  )
);

-- Soft-delete is performed through the authenticated API so audit fields are retained.
