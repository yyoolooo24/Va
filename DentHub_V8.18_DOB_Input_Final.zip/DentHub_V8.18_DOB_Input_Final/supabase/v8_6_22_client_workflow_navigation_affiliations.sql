-- DentHub V8.6.22 — client-requested navigation, questionnaire, contracts, multi-clinic staff
-- Run AFTER v8_6_21_compliance_hr_inventory_finance.sql
create extension if not exists pgcrypto;

-- 1) Clinic-managed patient questionnaire
create table if not exists public.clinic_questionnaire_questions (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  question_key text not null,
  label_mn text not null,
  label_en text,
  answer_type text not null default 'yes_no',
  sort_order integer not null default 100,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(clinic_id,question_key)
);
create index if not exists clinic_questionnaire_clinic_idx on public.clinic_questionnaire_questions(clinic_id,active,sort_order);
alter table public.clinic_questionnaire_questions enable row level security;
drop policy if exists "clinic_questionnaire_select" on public.clinic_questionnaire_questions;
create policy "clinic_questionnaire_select" on public.clinic_questionnaire_questions for select to authenticated using (
  public.current_app_role()='platform_admin' or clinic_id=public.current_clinic_id()
);
drop policy if exists "clinic_questionnaire_owner_write" on public.clinic_questionnaire_questions;
create policy "clinic_questionnaire_owner_write" on public.clinic_questionnaire_questions for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');

insert into public.clinic_questionnaire_questions(clinic_id,question_key,label_mn,label_en,sort_order)
select c.id,x.question_key,x.label_mn,x.label_en,x.sort_order from public.clinics c cross join (values
 ('generalWellness','Одоо таны биеийн байдал сайн байгаа юу?','Is your current general condition good?',10),
 ('regularMedication','Байнгын хэрэглэдэг эм тариа бий юу?','Do you regularly take any medication?',20),
 ('surgeryHistory','Мэс засал хийлгэж байсан уу?','Have you had surgery before?',30),
 ('allergies','Эм тариа, бодисын харшил бий юу?','Do you have medication or substance allergies?',40),
 ('aspirin14Days','Сүүлийн 14 хоног дотор аспирины төрлийн эм хэрэглэсэн үү?','Have you used aspirin-type medicine during the last 14 days?',50),
 ('rheumaticHeartDisease','Зүрхний хэрх өвчин бий юу?','Do you have rheumatic heart disease?',60),
 ('diabetes','Сахарын өвчин бий юу?','Do you have diabetes?',70),
 ('tuberculosis','Сүрьеэгийн түүх бий юу?','Have you had tuberculosis?',80)
) as x(question_key,label_mn,label_en,sort_order)
on conflict(clinic_id,question_key) do nothing;

-- 2) Contracts / external service agreements
create table if not exists public.clinic_contracts (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  category text not null,
  title text not null,
  counterparty text,
  valid_from date,
  valid_until date,
  storage_path text,
  file_name text,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  deleted_at timestamptz,
  deleted_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists clinic_contracts_clinic_idx on public.clinic_contracts(clinic_id,category,valid_until,created_at desc);
alter table public.clinic_contracts enable row level security;
drop policy if exists "clinic_contracts_select" on public.clinic_contracts;
create policy "clinic_contracts_select" on public.clinic_contracts for select to authenticated using (
 public.current_app_role()='platform_admin' or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
);
drop policy if exists "clinic_contracts_owner_write" on public.clinic_contracts;
create policy "clinic_contracts_owner_write" on public.clinic_contracts for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');

-- 3) Multi-clinic employee memberships and bilateral requests
create table if not exists public.staff_clinic_memberships (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  role text not null default 'employee',
  specialty text,
  status text not null default 'accepted' check(status in ('pending','accepted','rejected','disabled')),
  accepted_at timestamptz,
  created_at timestamptz not null default now(),
  unique(user_id,clinic_id)
);
create index if not exists staff_memberships_user_idx on public.staff_clinic_memberships(user_id,status,clinic_id);
create index if not exists staff_memberships_clinic_idx on public.staff_clinic_memberships(clinic_id,status,user_id);

insert into public.staff_clinic_memberships(user_id,clinic_id,role,specialty,status,accepted_at)
select p.id,p.clinic_id,p.role,p.specialty,'accepted',now() from public.profiles p
where p.clinic_id is not null and p.role in ('owner','employee')
on conflict(user_id,clinic_id) do update set specialty=excluded.specialty,status='accepted';

create table if not exists public.staff_clinic_requests (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  requested_by uuid references public.profiles(id) on delete set null,
  direction text not null check(direction in ('staff_to_clinic','clinic_to_staff')),
  status text not null default 'pending' check(status in ('pending','accepted','rejected','cancelled')),
  message text,
  responded_by uuid references public.profiles(id) on delete set null,
  responded_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists staff_requests_clinic_idx on public.staff_clinic_requests(clinic_id,status,created_at desc);
create index if not exists staff_requests_user_idx on public.staff_clinic_requests(user_id,status,created_at desc);
create unique index if not exists staff_requests_one_pending_uidx on public.staff_clinic_requests(clinic_id,user_id) where status='pending';

alter table public.staff_clinic_memberships enable row level security;
alter table public.staff_clinic_requests enable row level security;
drop policy if exists "staff_membership_select_own_or_clinic" on public.staff_clinic_memberships;
create policy "staff_membership_select_own_or_clinic" on public.staff_clinic_memberships for select to authenticated using (
 user_id=auth.uid() or (clinic_id=public.current_clinic_id() and public.current_app_role()='owner') or public.current_app_role()='platform_admin'
);
drop policy if exists "staff_requests_select_own_or_clinic" on public.staff_clinic_requests;
create policy "staff_requests_select_own_or_clinic" on public.staff_clinic_requests for select to authenticated using (
 user_id=auth.uid() or (clinic_id=public.current_clinic_id() and public.current_app_role()='owner') or public.current_app_role()='platform_admin'
);

-- 4) History deletion compatibility: even older deployments without deleted_at hide the encounter.
alter table public.encounters add column if not exists deleted_at timestamptz;
alter table public.encounters add column if not exists deleted_by uuid references public.profiles(id) on delete set null;
create index if not exists encounters_history_visible_idx on public.encounters(clinic_id,patient_id,created_at desc) where deleted_at is null;

-- realtime refresh
DO $$ BEGIN
  BEGIN execute 'alter publication supabase_realtime add table public.clinic_questionnaire_questions'; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN execute 'alter publication supabase_realtime add table public.clinic_contracts'; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN execute 'alter publication supabase_realtime add table public.staff_clinic_memberships'; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN execute 'alter publication supabase_realtime add table public.staff_clinic_requests'; EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;
