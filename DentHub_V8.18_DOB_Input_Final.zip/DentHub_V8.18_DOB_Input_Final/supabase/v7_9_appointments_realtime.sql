-- ClinicOS V7.9 — appointment booking + realtime calendar/history
-- Safe additive migration. It does not delete clinics, patients, appointments, users, or ERP records.

create extension if not exists pgcrypto;

-- Expand existing appointment model without replacing old rows.
alter table public.services add column if not exists duration_minutes integer not null default 30;
alter table public.appointments add column if not exists service_id uuid references public.services(id) on delete set null;
alter table public.appointments add column if not exists notes text;
alter table public.appointments add column if not exists created_by uuid references public.profiles(id) on delete set null;
alter table public.appointments add column if not exists updated_at timestamptz not null default now();

-- Keep legacy values working while supporting the clearer V7.9 names.
alter table public.appointments drop constraint if exists appointments_status_check;
alter table public.appointments add constraint appointments_status_check
  check (status in ('pending','confirmed','scheduled','checked_in','in_progress','completed','done','cancelled','no_show'));

create index if not exists idx_appointments_patient_time on public.appointments(patient_id, starts_at desc);
create index if not exists idx_appointments_doctor_time on public.appointments(doctor_id, starts_at);
create index if not exists idx_appointments_status on public.appointments(clinic_id, status, starts_at);
do $$
begin
  if not exists (
    select 1 from public.appointments
    where doctor_id is not null and status not in ('cancelled','no_show')
    group by doctor_id, starts_at having count(*) > 1
  ) then
    execute 'create unique index if not exists appointments_doctor_start_unique on public.appointments(doctor_id, starts_at) where doctor_id is not null and status not in (''cancelled'',''no_show'')';
  end if;
end $$;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists appointments_set_updated_at on public.appointments;
create trigger appointments_set_updated_at
before update on public.appointments
for each row execute function public.set_updated_at();

-- Doctor working schedule. When no row exists for a doctor/day, ClinicOS falls back to 09:00–18:00.
create table if not exists public.doctor_availability (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  doctor_id uuid not null references public.profiles(id) on delete cascade,
  weekday smallint not null check (weekday between 0 and 6),
  start_time time not null default '09:00',
  end_time time not null default '18:00',
  slot_minutes integer not null default 30 check (slot_minutes between 5 and 240),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(doctor_id, weekday)
);

create index if not exists idx_doctor_availability_clinic on public.doctor_availability(clinic_id, doctor_id, weekday);

create table if not exists public.appointment_status_history (
  id uuid primary key default gen_random_uuid(),
  appointment_id uuid not null references public.appointments(id) on delete cascade,
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  old_status text,
  new_status text not null,
  changed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists idx_appointment_history_appt on public.appointment_status_history(appointment_id, created_at desc);
create index if not exists idx_appointment_history_clinic on public.appointment_status_history(clinic_id, created_at desc);

create or replace function public.log_appointment_status_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.appointment_status_history(appointment_id, clinic_id, old_status, new_status, changed_by)
    values (new.id, new.clinic_id, null, new.status, coalesce(new.created_by, auth.uid()));
  elsif new.status is distinct from old.status then
    insert into public.appointment_status_history(appointment_id, clinic_id, old_status, new_status, changed_by)
    values (new.id, new.clinic_id, old.status, new.status, auth.uid());
  end if;
  return new;
end;
$$;

drop trigger if exists appointments_status_history_trigger on public.appointments;
create trigger appointments_status_history_trigger
after insert or update of status on public.appointments
for each row execute function public.log_appointment_status_change();

alter table public.doctor_availability enable row level security;
alter table public.appointment_status_history enable row level security;

-- Recreate these policies safely if this migration is run more than once.
drop policy if exists "doctor_availability_select" on public.doctor_availability;
create policy "doctor_availability_select" on public.doctor_availability
for select to authenticated using (
  public.current_app_role() = 'platform_admin' or
  clinic_id = public.current_clinic_id() or
  public.current_app_role() = 'client'
);

drop policy if exists "doctor_availability_staff_write" on public.doctor_availability;
create policy "doctor_availability_staff_write" on public.doctor_availability
for all to authenticated
using (clinic_id = public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
with check (clinic_id = public.current_clinic_id() and public.current_app_role() in ('owner','employee'));

drop policy if exists "appointment_history_select" on public.appointment_status_history;
create policy "appointment_history_select" on public.appointment_status_history
for select to authenticated using (
  public.current_app_role() = 'platform_admin' or
  (clinic_id = public.current_clinic_id() and public.current_app_role() in ('owner','employee')) or
  exists (
    select 1 from public.appointments a
    join public.patients p on p.id = a.patient_id
    where a.id = appointment_id and p.user_id = auth.uid()
  )
);

-- Realtime: safe even if a table is already in the publication.
do $$
begin
  begin execute 'alter publication supabase_realtime add table public.appointments'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.appointment_status_history'; exception when duplicate_object then null; end;
end $$;

-- Realtime UPDATE/DELETE payloads need stable row identity.
alter table public.appointments replica identity full;
