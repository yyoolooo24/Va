-- DentHub V8.6.0 — ERP/POS workflow + stable patient identity
-- Safe additive migration for V8.5.x databases.
-- Run this ONE file after your existing V8.5.x migrations.

create extension if not exists pgcrypto;

-- -----------------------------------------------------------------------------
-- 1) Every clinic patient gets a stable, human-readable transaction identity.
--    The UUID remains the real database FK; patient_code is the staff-facing ID.
-- -----------------------------------------------------------------------------
alter table public.patients add column if not exists patient_code text;

update public.patients
set patient_code = 'PT-' || upper(substr(replace(id::text,'-',''),1,12))
where patient_code is null or btrim(patient_code)='';

alter table public.patients alter column patient_code set not null;
create unique index if not exists patients_clinic_patient_code_uidx
  on public.patients(clinic_id, patient_code);
create index if not exists patients_clinic_name_idx
  on public.patients(clinic_id, lower(full_name));

create or replace function public.denthub_patient_identity_guard()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  normalized_phone text;
  normalized_reg text;
begin
  if new.id is null then new.id := gen_random_uuid(); end if;
  if new.patient_code is null or btrim(new.patient_code)='' then
    new.patient_code := 'PT-' || upper(substr(replace(new.id::text,'-',''),1,12));
  end if;

  normalized_phone := right(regexp_replace(coalesce(new.phone,''),'[^0-9]','','g'),8);
  normalized_reg := upper(regexp_replace(coalesce(new.register_no,''),'[[:space:]-]','','g'));

  if normalized_phone <> '' and length(normalized_phone)=8 and exists (
    select 1 from public.patients p
    where p.clinic_id=new.clinic_id
      and p.id<>new.id
      and right(regexp_replace(coalesce(p.phone,''),'[^0-9]','','g'),8)=normalized_phone
  ) then
    raise exception using errcode='23505', message='DENTHUB_DUPLICATE_PATIENT_PHONE';
  end if;

  if normalized_reg <> '' and exists (
    select 1 from public.patients p
    where p.clinic_id=new.clinic_id
      and p.id<>new.id
      and upper(regexp_replace(coalesce(p.register_no,''),'[[:space:]-]','','g'))=normalized_reg
  ) then
    raise exception using errcode='23505', message='DENTHUB_DUPLICATE_PATIENT_REGISTER';
  end if;

  return new;
end;
$$;

drop trigger if exists denthub_patient_identity_guard on public.patients;
create trigger denthub_patient_identity_guard
before insert or update of clinic_id,phone,register_no,patient_code on public.patients
for each row execute function public.denthub_patient_identity_guard();

-- Keep a readable patient reference with payment history even if a patient link
-- is later removed. patient_id is still the canonical relationship.
do $$
begin
  if to_regclass('public.qpay_invoices') is not null then
    execute 'alter table public.qpay_invoices add column if not exists patient_code_snapshot text';
    execute $sql$
      update public.qpay_invoices q
      set patient_code_snapshot=p.patient_code
      from public.patients p
      where q.patient_id=p.id
        and (q.patient_code_snapshot is null or btrim(q.patient_code_snapshot)='')
    $sql$;
    execute 'create index if not exists qpay_invoice_patient_code_idx on public.qpay_invoices(clinic_id,patient_code_snapshot,created_at desc)';
  end if;
end $$;

-- -----------------------------------------------------------------------------
-- 2) Add the operational POS/ERP modules used by DentHub.
--    Existing erp_records data and module keys remain untouched.
-- -----------------------------------------------------------------------------
alter table public.erp_records drop constraint if exists erp_records_module_key_check;
alter table public.erp_records add constraint erp_records_module_key_check check (module_key in (
  'stock_movements','suppliers','procurement','purchase_orders','lab_orders','rooms','crm',
  'insurance','invoices','receivables','expenses','shifts','assets','tasks','branches',
  'supplier_warehouse','partner_clinics',
  'sales','sales_returns','cashbook','price_lists'
));

create index if not exists erp_records_patient_payload_idx
  on public.erp_records ((payload->>'patientId'))
  where payload ? 'patientId';

-- Realtime is useful for POS/ERP records across cashier/owner screens.
do $$
begin
  begin execute 'alter publication supabase_realtime add table public.erp_records';
  exception when duplicate_object then null;
  end;
end $$;
alter table public.erp_records replica identity full;

-- -----------------------------------------------------------------------------
-- 3) ERP records respect the same employee module permissions as the sidebar.
--    This closes the old RLS gap where an employee could SELECT every ERP module
--    in their clinic even when the UI hid it.
-- -----------------------------------------------------------------------------
create or replace function public.denthub_current_user_has_erp_module(p_module text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and coalesce(p.active,true) = true
      and (
        p.role in ('owner','platform_admin')
        or (
          p.role='employee'
          and (
            p_module = any(coalesce(p.allowed_modules,'{}'::text[]))
            or (
              cardinality(coalesce(p.allowed_modules,'{}'::text[]))=0
              and (
                (lower(coalesce(p.specialty,'')) ~ '(nurse|сувила)' and p_module='lab_orders')
                or (lower(coalesce(p.specialty,'')) ~ '(reception|ресеп)' and p_module='sales')
                or (lower(coalesce(p.specialty,'')) ~ '(finance|санхүү|нягт)' and p_module in ('sales','sales_returns','cashbook','invoices','receivables','expenses'))
              )
            )
          )
        )
      )
  );
$$;

drop policy if exists "erp_records_select" on public.erp_records;
create policy "erp_records_select" on public.erp_records
for select to authenticated
using (
  public.current_app_role()='platform_admin'
  or (
    clinic_id=public.current_clinic_id()
    and (
      public.current_app_role()='owner'
      or (public.current_app_role()='employee' and public.denthub_current_user_has_erp_module(module_key))
    )
  )
);

drop policy if exists "erp_records_insert" on public.erp_records;
create policy "erp_records_insert" on public.erp_records
for insert to authenticated
with check (
  clinic_id=public.current_clinic_id()
  and (
    public.current_app_role()='owner'
    or (public.current_app_role()='employee' and public.denthub_current_user_has_erp_module(module_key))
  )
);

drop policy if exists "erp_records_update" on public.erp_records;
create policy "erp_records_update" on public.erp_records
for update to authenticated
using (
  clinic_id=public.current_clinic_id()
  and (
    public.current_app_role()='owner'
    or (public.current_app_role()='employee' and public.denthub_current_user_has_erp_module(module_key))
  )
)
with check (
  clinic_id=public.current_clinic_id()
  and (
    public.current_app_role()='owner'
    or (public.current_app_role()='employee' and public.denthub_current_user_has_erp_module(module_key))
  )
);

-- Deletes remain owner-only so operational history cannot be erased by cashiers.
drop policy if exists "erp_records_delete" on public.erp_records;
create policy "erp_records_delete" on public.erp_records
for delete to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');

-- End DentHub V8.6.0
