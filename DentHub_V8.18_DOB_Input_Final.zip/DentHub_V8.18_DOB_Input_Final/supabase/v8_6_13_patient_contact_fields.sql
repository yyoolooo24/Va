-- DentHub V8.6.13 — editable patient contact details
-- Run AFTER the previous DentHub migrations. Safe to run more than once.

set lock_timeout = '10s';

alter table public.patients
  add column if not exists address text,
  add column if not exists emergency_phone text;

comment on column public.patients.address is 'Patient residential/contact address';
comment on column public.patients.emergency_phone is 'Emergency contact phone (Mongolia, normalized to +976XXXXXXXX when provided)';
