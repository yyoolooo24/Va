-- DentHub V8.6.6 — client-requested appointment → treatment workflow
-- Run AFTER v8_6_0_pos_patient_identity.sql and v8_6_1_packages_odontogram.sql.
-- Safe additive migration.

create extension if not exists pgcrypto;

-- 1) Optional external/customer ID entered by clinic staff.
alter table public.patients add column if not exists external_patient_id text;
create unique index if not exists patients_clinic_external_id_uidx
  on public.patients(clinic_id, lower(btrim(external_patient_id)))
  where external_patient_id is not null and btrim(external_patient_id)<>'';

-- Mark lightweight records created while reception is booking a first-time visitor.
alter table public.patients add column if not exists quick_registered boolean not null default false;

-- 2) Link an encounter directly to the appointment that produced it.
alter table public.encounters add column if not exists appointment_id uuid references public.appointments(id) on delete set null;
create unique index if not exists encounters_appointment_uidx
  on public.encounters(appointment_id) where appointment_id is not null;
create index if not exists encounters_clinic_appointment_idx
  on public.encounters(clinic_id, appointment_id, created_at desc);

-- 3) Tooth-by-tooth treatments. One visit can contain many tooth/service rows.
create table if not exists public.encounter_treatments (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  encounter_id uuid not null references public.encounters(id) on delete cascade,
  tooth_no text,
  service_id uuid references public.services(id) on delete set null,
  service_name text not null,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists encounter_treatments_encounter_idx on public.encounter_treatments(encounter_id, created_at);
create index if not exists encounter_treatments_clinic_idx on public.encounter_treatments(clinic_id, created_at desc);

alter table public.encounter_treatments enable row level security;
drop policy if exists "encounter_treatments_select" on public.encounter_treatments;
create policy "encounter_treatments_select" on public.encounter_treatments for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
  or exists(
    select 1 from public.encounters e
    join public.patients p on p.id=e.patient_id
    where e.id=encounter_id and p.user_id=auth.uid()
  )
);
drop policy if exists "encounter_treatments_write" on public.encounter_treatments;
create policy "encounter_treatments_write" on public.encounter_treatments for all to authenticated using (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
) with check (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
  and exists(select 1 from public.encounters e where e.id=encounter_id and e.clinic_id=clinic_id)
);

-- 4) Patient card: document-like clinical/admin notes with realtime update.
create table if not exists public.patient_cards (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  patient_id uuid not null references public.patients(id) on delete cascade,
  content text not null default '',
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique(clinic_id, patient_id)
);
create index if not exists patient_cards_clinic_idx on public.patient_cards(clinic_id, updated_at desc);
alter table public.patient_cards enable row level security;
drop policy if exists "patient_cards_select" on public.patient_cards;
create policy "patient_cards_select" on public.patient_cards for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
  or exists(select 1 from public.patients p where p.id=patient_id and p.user_id=auth.uid())
);
drop policy if exists "patient_cards_write" on public.patient_cards;
create policy "patient_cards_write" on public.patient_cards for all to authenticated using (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
) with check (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
);

-- Keep updated_at correct even when edits come from another workstation.
create or replace function public.denthub_touch_patient_card()
returns trigger language plpgsql set search_path=public as $$
begin new.updated_at=now(); return new; end $$;
drop trigger if exists denthub_patient_card_touch on public.patient_cards;
create trigger denthub_patient_card_touch before update on public.patient_cards
for each row execute function public.denthub_touch_patient_card();

-- Realtime for doctor's arrival queue, tooth treatment rows, and online patient card.
do $$
begin
  begin execute 'alter publication supabase_realtime add table public.encounter_treatments'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.patient_cards'; exception when duplicate_object then null; end;
end $$;
alter table public.encounter_treatments replica identity full;
alter table public.patient_cards replica identity full;

-- End V8.6.6
