-- DentHub V8.4 — patient history, parallel scheduling, supplier workspace, QPay repair
-- Safe additive migration for an existing V8.2/V8.3 database.
-- Run once in Supabase SQL Editor before deploying the V8.4 frontend.

create extension if not exists pgcrypto;

-- Doctor-entered summary is separate from the patient's booking complaint.
alter table public.appointments add column if not exists clinical_summary text;

-- -----------------------------------------------------------------------------
-- 1) Fix patient-linked purchase history
-- -----------------------------------------------------------------------------
alter table public.qpay_invoices
  add column if not exists patient_id uuid references public.patients(id) on delete set null;

create index if not exists idx_qpay_patient_created
  on public.qpay_invoices(patient_id, created_at desc);

drop policy if exists "qpay_select" on public.qpay_invoices;
create policy "qpay_select" on public.qpay_invoices
for select to authenticated using (
  public.current_app_role() = 'platform_admin'
  or clinic_id = public.current_clinic_id()
  or exists (
    select 1 from public.patients p
    where p.id = patient_id and p.user_id = auth.uid()
  )
);

-- -----------------------------------------------------------------------------
-- 2) Allow several patients in the same 30-minute block, per doctor.
--    Default capacity = 3. Change doctor_availability.max_parallel to 1..12.
-- -----------------------------------------------------------------------------
alter table public.doctor_availability
  add column if not exists max_parallel integer not null default 3;

alter table public.doctor_availability
  drop constraint if exists doctor_availability_max_parallel_check;
alter table public.doctor_availability
  add constraint doctor_availability_max_parallel_check
  check (max_parallel between 1 and 12);

-- The old V7.9 unique slot index prevents parallel appointments.
drop index if exists public.appointments_doctor_start_unique;

-- Replace the old overlap blocker with a capacity-aware blocker.
create or replace function public.prevent_appointment_overlap()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  parallel_limit integer := 3;
  overlapping_count integer := 0;
  local_weekday integer;
begin
  if new.doctor_id is null or new.status in ('cancelled','no_show') then
    return new;
  end if;

  perform pg_advisory_xact_lock(hashtext(new.doctor_id::text)::bigint);

  local_weekday := extract(dow from (new.starts_at at time zone 'Asia/Ulaanbaatar'))::integer;

  select coalesce(da.max_parallel, 3)
    into parallel_limit
  from public.doctor_availability da
  where da.doctor_id = new.doctor_id
    and da.clinic_id = new.clinic_id
    and da.weekday = local_weekday
    and da.active = true
  limit 1;

  parallel_limit := coalesce(parallel_limit, 3);

  select count(*)::integer
    into overlapping_count
  from public.appointments a
  where a.doctor_id = new.doctor_id
    and a.clinic_id = new.clinic_id
    and a.id is distinct from new.id
    and a.status not in ('cancelled','no_show')
    and new.starts_at < coalesce(a.ends_at, a.starts_at + interval '30 minutes')
    and coalesce(new.ends_at, new.starts_at + interval '30 minutes') > a.starts_at;

  if overlapping_count >= parallel_limit then
    raise exception 'APPOINTMENT_CAPACITY_FULL' using errcode = '23P01';
  end if;

  return new;
end;
$$;

drop trigger if exists appointments_prevent_overlap on public.appointments;
create trigger appointments_prevent_overlap
before insert or update of doctor_id, clinic_id, starts_at, ends_at, status on public.appointments
for each row execute function public.prevent_appointment_overlap();

-- -----------------------------------------------------------------------------
-- 3) Supplier-owned warehouse and partner clinics
-- -----------------------------------------------------------------------------
create table if not exists public.supplier_inventory_items (
  id uuid primary key default gen_random_uuid(),
  supplier_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  sku text,
  quantity numeric not null default 0 check (quantity >= 0),
  unit text not null default 'ш',
  reorder_level numeric not null default 0 check (reorder_level >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.supplier_partner_clinics (
  id uuid primary key default gen_random_uuid(),
  supplier_id uuid not null references public.profiles(id) on delete cascade,
  clinic_id uuid references public.clinics(id) on delete set null,
  name text not null,
  contact_name text,
  phone text,
  status text not null default 'active' check (status in ('active','inactive')),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(supplier_id, clinic_id)
);

create index if not exists idx_supplier_inventory_owner
  on public.supplier_inventory_items(supplier_id, created_at desc);
create index if not exists idx_supplier_partner_owner
  on public.supplier_partner_clinics(supplier_id, created_at desc);
create index if not exists idx_supplier_partner_clinic
  on public.supplier_partner_clinics(clinic_id, supplier_id);

-- Keep supplier records' updated_at fields current without relying on an older migration helper.
create or replace function public.denthub_touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists supplier_inventory_set_updated_at on public.supplier_inventory_items;
create trigger supplier_inventory_set_updated_at before update on public.supplier_inventory_items
for each row execute function public.denthub_touch_updated_at();

drop trigger if exists supplier_partner_set_updated_at on public.supplier_partner_clinics;
create trigger supplier_partner_set_updated_at before update on public.supplier_partner_clinics
for each row execute function public.denthub_touch_updated_at();

alter table public.supplier_inventory_items enable row level security;
alter table public.supplier_partner_clinics enable row level security;

drop policy if exists "supplier_inventory_select" on public.supplier_inventory_items;
create policy "supplier_inventory_select" on public.supplier_inventory_items
for select to authenticated using (
  public.current_app_role() = 'platform_admin'
  or (public.current_app_role() = 'supplier' and supplier_id = auth.uid())
);

drop policy if exists "supplier_inventory_insert" on public.supplier_inventory_items;
create policy "supplier_inventory_insert" on public.supplier_inventory_items
for insert to authenticated with check (
  public.current_app_role() = 'supplier' and supplier_id = auth.uid()
);

drop policy if exists "supplier_inventory_update" on public.supplier_inventory_items;
create policy "supplier_inventory_update" on public.supplier_inventory_items
for update to authenticated using (
  public.current_app_role() = 'supplier' and supplier_id = auth.uid()
) with check (
  public.current_app_role() = 'supplier' and supplier_id = auth.uid()
);

drop policy if exists "supplier_inventory_delete" on public.supplier_inventory_items;
create policy "supplier_inventory_delete" on public.supplier_inventory_items
for delete to authenticated using (
  public.current_app_role() = 'supplier' and supplier_id = auth.uid()
);

drop policy if exists "supplier_partner_select" on public.supplier_partner_clinics;
create policy "supplier_partner_select" on public.supplier_partner_clinics
for select to authenticated using (
  public.current_app_role() = 'platform_admin'
  or (public.current_app_role() = 'supplier' and supplier_id = auth.uid())
);

drop policy if exists "supplier_partner_insert" on public.supplier_partner_clinics;
create policy "supplier_partner_insert" on public.supplier_partner_clinics
for insert to authenticated with check (
  public.current_app_role() = 'supplier' and supplier_id = auth.uid()
);

drop policy if exists "supplier_partner_update" on public.supplier_partner_clinics;
create policy "supplier_partner_update" on public.supplier_partner_clinics
for update to authenticated using (
  public.current_app_role() = 'supplier' and supplier_id = auth.uid()
) with check (
  public.current_app_role() = 'supplier' and supplier_id = auth.uid()
);

drop policy if exists "supplier_partner_delete" on public.supplier_partner_clinics;
create policy "supplier_partner_delete" on public.supplier_partner_clinics
for delete to authenticated using (
  public.current_app_role() = 'supplier' and supplier_id = auth.uid()
);

-- Suppliers need a clinic directory only to link a partner clinic.
drop policy if exists "clinic_select" on public.clinics;
create policy "clinic_select" on public.clinics for select to authenticated using (
  public.current_app_role() = 'platform_admin'
  or id = public.current_clinic_id()
  or public.current_app_role() = 'supplier'
);

-- -----------------------------------------------------------------------------
-- 4) Realtime publication
-- -----------------------------------------------------------------------------
do $$
begin
  begin execute 'alter publication supabase_realtime add table public.supplier_inventory_items'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.supplier_partner_clinics'; exception when duplicate_object then null; end;
end $$;

alter table public.supplier_inventory_items replica identity full;
alter table public.supplier_partner_clinics replica identity full;

-- -----------------------------------------------------------------------------
-- 5) Clinic working hours and holidays
-- -----------------------------------------------------------------------------
create table if not exists public.clinic_business_hours (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  weekday smallint not null check (weekday between 0 and 6),
  start_time time not null default '09:00',
  end_time time not null default '18:00',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(clinic_id, weekday),
  check (end_time > start_time)
);

create table if not exists public.clinic_holidays (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  holiday_date date not null,
  name text,
  created_at timestamptz not null default now(),
  unique(clinic_id, holiday_date)
);

drop trigger if exists clinic_business_hours_set_updated_at on public.clinic_business_hours;
create trigger clinic_business_hours_set_updated_at before update on public.clinic_business_hours
for each row execute function public.denthub_touch_updated_at();

-- Preserve current behavior by initially enabling every weekday 09:00-18:00.
insert into public.clinic_business_hours(clinic_id, weekday, start_time, end_time, active)
select c.id, d.weekday, '09:00'::time, '18:00'::time, true
from public.clinics c
cross join (values (0),(1),(2),(3),(4),(5),(6)) as d(weekday)
on conflict (clinic_id, weekday) do nothing;

create index if not exists idx_clinic_hours_clinic on public.clinic_business_hours(clinic_id, weekday);
create index if not exists idx_clinic_holidays_date on public.clinic_holidays(clinic_id, holiday_date);

alter table public.clinic_business_hours enable row level security;
alter table public.clinic_holidays enable row level security;

drop policy if exists "clinic_hours_select" on public.clinic_business_hours;
create policy "clinic_hours_select" on public.clinic_business_hours
for select to authenticated using (
  public.current_app_role() = 'platform_admin'
  or clinic_id = public.current_clinic_id()
);

drop policy if exists "clinic_hours_owner_write" on public.clinic_business_hours;
create policy "clinic_hours_owner_write" on public.clinic_business_hours
for all to authenticated using (
  public.current_app_role() = 'owner' and clinic_id = public.current_clinic_id()
) with check (
  public.current_app_role() = 'owner' and clinic_id = public.current_clinic_id()
);

drop policy if exists "clinic_holidays_select" on public.clinic_holidays;
create policy "clinic_holidays_select" on public.clinic_holidays
for select to authenticated using (
  public.current_app_role() = 'platform_admin'
  or clinic_id = public.current_clinic_id()
);

drop policy if exists "clinic_holidays_owner_write" on public.clinic_holidays;
create policy "clinic_holidays_owner_write" on public.clinic_holidays
for all to authenticated using (
  public.current_app_role() = 'owner' and clinic_id = public.current_clinic_id()
) with check (
  public.current_app_role() = 'owner' and clinic_id = public.current_clinic_id()
);

do $$
begin
  begin execute 'alter publication supabase_realtime add table public.clinic_business_hours'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.clinic_holidays'; exception when duplicate_object then null; end;
end $$;

-- -----------------------------------------------------------------------------
-- 6) Dental service tree correction
--    The imported headings are categories, not bookable services.
-- -----------------------------------------------------------------------------
-- Hide the old heading row for the root-canal category if it was inserted by V8.2.
update public.services
set active = false
where upper(trim(name)) = 'БАЙНГЫН ШҮДНИЙ ХОЛБООСЫН ЭМЧИЛГЭЭ'
  and upper(trim(coalesce(subcategory,''))) in ('БАЙНГЫН ШҮД','');

with root_canal(name, duration_minutes) as (
  values
    ('1 СУВАГТАЙ ШҮД', 45),
    ('2 СУВАГТАЙ ШҮД', 60),
    ('3 СУВАГТАЙ ШҮД', 75),
    ('4 СУВАГТАЙ ШҮД', 90),
    ('ДАНГААР НЬ СУВАГ ЭМЧЛЭХ 1 СУВАГ', 30),
    ('ДАНГААР НЬ СУВАГ ЭМЧЛЭХ 2 СУВАГ', 45)
)
insert into public.services(clinic_id,name,category,subcategory,price,duration_minutes,active)
select c.id, r.name, 'Шүдний эмчилгээ', 'БАЙНГЫН ШҮДНИЙ ХОЛБООСЫН ЭМЧИЛГЭЭ', 0, r.duration_minutes, true
from public.clinics c cross join root_canal r
where not exists (
  select 1 from public.services s
  where s.clinic_id=c.id and lower(trim(s.name))=lower(trim(r.name))
);

-- Keep service/category changes live across open sessions.
do $$
begin
  begin execute 'alter publication supabase_realtime add table public.services'; exception when duplicate_object then null; end;
end $$;
