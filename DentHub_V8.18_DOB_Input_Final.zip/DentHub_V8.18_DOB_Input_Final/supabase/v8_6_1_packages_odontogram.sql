-- DentHub V8.6.1 — Service packages + dental odontogram
-- Safe additive migration. Run AFTER v8_6_0_pos_patient_identity.sql.

create extension if not exists pgcrypto;

-- 1) Save the exact teeth attached to each clinical encounter.
alter table public.encounters add column if not exists selected_teeth text[] not null default '{}'::text[];
alter table public.encounters add column if not exists dentition text not null default 'adult';

do $$
begin
  if not exists (select 1 from pg_constraint where conname='encounters_dentition_check') then
    alter table public.encounters add constraint encounters_dentition_check check (dentition in ('adult','child'));
  end if;
end $$;

create index if not exists encounters_selected_teeth_gin on public.encounters using gin(selected_teeth);

-- 2) Reusable service bundles. Individual services remain canonical service records.
create table if not exists public.service_packages (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  name text not null check (char_length(btrim(name)) between 1 and 160),
  description text,
  price bigint not null default 0 check (price >= 0),
  duration_minutes integer not null default 60 check (duration_minutes between 1 and 1440),
  active boolean not null default true,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists service_packages_clinic_name_uidx on public.service_packages(clinic_id, lower(btrim(name)));
create index if not exists service_packages_clinic_active_idx on public.service_packages(clinic_id, active, created_at desc);

create table if not exists public.service_package_items (
  package_id uuid not null references public.service_packages(id) on delete cascade,
  service_id uuid not null references public.services(id) on delete restrict,
  quantity integer not null default 1 check (quantity between 1 and 100),
  primary key (package_id, service_id)
);

alter table public.service_packages enable row level security;
alter table public.service_package_items enable row level security;

-- Staff in the clinic can read packages; only owner or employees explicitly
-- granted the services module can create/change package definitions.
drop policy if exists "service_packages_select" on public.service_packages;
create policy "service_packages_select" on public.service_packages for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
);

drop policy if exists "service_packages_write" on public.service_packages;
create policy "service_packages_write" on public.service_packages for all to authenticated using (
  clinic_id=public.current_clinic_id()
  and (
    public.current_app_role()='owner'
    or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='employee' and 'services'=any(coalesce(p.allowed_modules,'{}'::text[])))
  )
) with check (
  clinic_id=public.current_clinic_id()
  and (
    public.current_app_role()='owner'
    or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='employee' and 'services'=any(coalesce(p.allowed_modules,'{}'::text[])))
  )
);

drop policy if exists "service_package_items_select" on public.service_package_items;
create policy "service_package_items_select" on public.service_package_items for select to authenticated using (
  exists (
    select 1 from public.service_packages p
    where p.id=package_id
      and (public.current_app_role()='platform_admin' or (p.clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')))
  )
);

drop policy if exists "service_package_items_write" on public.service_package_items;
create policy "service_package_items_write" on public.service_package_items for all to authenticated using (
  exists (
    select 1 from public.service_packages p
    where p.id=package_id and p.clinic_id=public.current_clinic_id()
      and (
        public.current_app_role()='owner'
        or exists(select 1 from public.profiles pr where pr.id=auth.uid() and pr.role='employee' and 'services'=any(coalesce(pr.allowed_modules,'{}'::text[])))
      )
  )
) with check (
  exists (
    select 1 from public.service_packages p
    join public.services s on s.id=service_id
    where p.id=package_id and p.clinic_id=public.current_clinic_id() and s.clinic_id=p.clinic_id
      and (
        public.current_app_role()='owner'
        or exists(select 1 from public.profiles pr where pr.id=auth.uid() and pr.role='employee' and 'services'=any(coalesce(pr.allowed_modules,'{}'::text[])))
      )
  )
);

-- Simple updated_at trigger local to packages.
create or replace function public.denthub_touch_updated_at()
returns trigger language plpgsql set search_path=public as $$
begin new.updated_at=now(); return new; end $$;
drop trigger if exists denthub_service_packages_touch on public.service_packages;
create trigger denthub_service_packages_touch before update on public.service_packages
for each row execute function public.denthub_touch_updated_at();

do $$
begin
  begin execute 'alter publication supabase_realtime add table public.service_packages'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.service_package_items'; exception when duplicate_object then null; end;
end $$;

alter table public.service_packages replica identity full;
alter table public.service_package_items replica identity full;

-- End DentHub V8.6.1
