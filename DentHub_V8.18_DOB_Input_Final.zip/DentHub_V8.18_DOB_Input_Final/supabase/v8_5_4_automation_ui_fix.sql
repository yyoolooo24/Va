-- DentHub V8.5.4 — automation, chat linking and self-contained medical-image fix
-- Safe additive migration. Designed to be runnable even if the older V8.0 X-ray migration was skipped.

create extension if not exists pgcrypto;

-- Repair columns that older partial upgrades may have skipped.
alter table public.appointments add column if not exists clinical_summary text;
alter table public.doctor_availability add column if not exists max_parallel integer not null default 3;
alter table public.services add column if not exists is_category boolean not null default false;
alter table public.profiles add column if not exists specialty text;
alter table public.profiles add column if not exists allowed_modules text[] not null default '{}'::text[];

do $$
begin
  if to_regclass('public.qpay_invoices') is not null then
    execute 'alter table public.qpay_invoices add column if not exists patient_id uuid references public.patients(id) on delete set null';
    execute 'create index if not exists idx_qpay_patient_created on public.qpay_invoices(patient_id, created_at desc)';
  end if;
end $$;

-- -----------------------------------------------------------------------------
-- Patient account linking (patient <-> clinic staff chat)
-- -----------------------------------------------------------------------------
alter table public.patients add column if not exists user_id uuid references public.profiles(id) on delete set null;
create index if not exists idx_patients_user_id on public.patients(user_id);

-- Link existing clinic patient rows to DentHub patient accounts when the same
-- Mongolian phone number is already present in profiles.
update public.patients p
set user_id = pr.id
from public.profiles pr
where p.user_id is null
  and pr.role = 'client'
  and pr.active = true
  and regexp_replace(coalesce(p.phone,''), '\\D', '', 'g') <> ''
  and right(regexp_replace(coalesce(p.phone,''), '\\D', '', 'g'), 8)
      = right(regexp_replace(coalesce(pr.phone,''), '\\D', '', 'g'), 8);

-- -----------------------------------------------------------------------------
-- Direct messages: make realtime patient <-> doctor/staff chat reliable.
-- API still checks relationship permissions before sending/loading messages.
-- -----------------------------------------------------------------------------
create table if not exists public.direct_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 3000),
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists idx_direct_messages_pair_created
  on public.direct_messages(sender_id, recipient_id, created_at);
alter table public.direct_messages enable row level security;

drop policy if exists "direct_messages_participants_select" on public.direct_messages;
create policy "direct_messages_participants_select" on public.direct_messages
for select to authenticated
using (sender_id = auth.uid() or recipient_id = auth.uid());

drop policy if exists "direct_messages_sender_insert" on public.direct_messages;
create policy "direct_messages_sender_insert" on public.direct_messages
for insert to authenticated
with check (sender_id = auth.uid());

drop policy if exists "direct_messages_recipient_update" on public.direct_messages;
create policy "direct_messages_recipient_update" on public.direct_messages
for update to authenticated
using (recipient_id = auth.uid())
with check (recipient_id = auth.uid());

grant select, insert, update on public.direct_messages to authenticated;

do $$
begin
  begin execute 'alter publication supabase_realtime add table public.direct_messages';
  exception when duplicate_object then null;
  end;
end $$;
alter table public.direct_messages replica identity full;

-- -----------------------------------------------------------------------------
-- Medical images / X-ray metadata. Creates the table if it never existed.
-- -----------------------------------------------------------------------------
create table if not exists public.patient_xrays (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.patients(id) on delete cascade,
  storage_path text not null unique,
  original_filename text,
  mime_type text,
  file_size bigint,
  xray_type text,
  body_part text,
  taken_at timestamptz,
  description text,
  doctor_notes text,
  uploaded_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Upgrade older PNG-only installs without failing on clean databases.
alter table public.patient_xrays drop constraint if exists patient_xrays_png_path;
alter table public.patient_xrays drop constraint if exists patient_xrays_png_mime;
alter table public.patient_xrays drop constraint if exists patient_xrays_image_path;
alter table public.patient_xrays drop constraint if exists patient_xrays_image_mime;
alter table public.patient_xrays drop constraint if exists patient_xrays_file_size;

alter table public.patient_xrays
  add constraint patient_xrays_image_path check (
    lower(storage_path) ~ ('^' || patient_id::text || '/[^/]+\.(png|jpg|jpeg|webp)$')
  );
alter table public.patient_xrays
  add constraint patient_xrays_image_mime check (
    mime_type is null or mime_type in ('image/png','image/jpeg','image/jpg','image/webp')
  );
alter table public.patient_xrays
  add constraint patient_xrays_file_size check (
    file_size is null or (file_size > 0 and file_size <= 10485760)
  );

create index if not exists idx_patient_xrays_patient_created on public.patient_xrays(patient_id, created_at desc);
create index if not exists idx_patient_xrays_type on public.patient_xrays(patient_id, xray_type, created_at desc);
create index if not exists idx_patient_xrays_body_part on public.patient_xrays(patient_id, body_part, created_at desc);
create index if not exists idx_patient_xrays_uploader on public.patient_xrays(uploaded_by, created_at desc);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists patient_xrays_set_updated_at on public.patient_xrays;
create trigger patient_xrays_set_updated_at
before update on public.patient_xrays
for each row execute function public.set_updated_at();

alter table public.patient_xrays enable row level security;

drop policy if exists "patient_xrays_staff_select" on public.patient_xrays;
drop policy if exists "patient_xrays_select" on public.patient_xrays;
create policy "patient_xrays_select" on public.patient_xrays
for select to authenticated
using (
  public.current_app_role() = 'platform_admin'
  or (
    public.current_app_role() in ('owner','employee')
    and exists (
      select 1 from public.patients p
      where p.id = patient_id and p.clinic_id = public.current_clinic_id()
    )
  )
  or (
    public.current_app_role() = 'client'
    and exists (
      select 1 from public.patients p
      where p.id = patient_id and p.user_id = auth.uid()
    )
  )
);

drop policy if exists "patient_xrays_staff_insert" on public.patient_xrays;
drop policy if exists "patient_xrays_insert" on public.patient_xrays;
create policy "patient_xrays_insert" on public.patient_xrays
for insert to authenticated
with check (
  uploaded_by = auth.uid()
  and (
    public.current_app_role() = 'platform_admin'
    or (
      public.current_app_role() in ('owner','employee')
      and exists (
        select 1 from public.patients p
        where p.id = patient_id and p.clinic_id = public.current_clinic_id()
      )
    )
  )
);

drop policy if exists "patient_xrays_staff_update" on public.patient_xrays;
drop policy if exists "patient_xrays_update" on public.patient_xrays;
create policy "patient_xrays_update" on public.patient_xrays
for update to authenticated
using (
  public.current_app_role() = 'platform_admin'
  or exists (
    select 1 from public.patients p
    where p.id = patient_id
      and p.clinic_id = public.current_clinic_id()
      and (
        public.current_app_role() = 'owner'
        or (public.current_app_role() = 'employee' and uploaded_by = auth.uid())
      )
  )
)
with check (
  public.current_app_role() = 'platform_admin'
  or exists (
    select 1 from public.patients p
    where p.id = patient_id
      and p.clinic_id = public.current_clinic_id()
      and (
        public.current_app_role() = 'owner'
        or (public.current_app_role() = 'employee' and uploaded_by = auth.uid())
      )
  )
);

drop policy if exists "patient_xrays_staff_delete" on public.patient_xrays;
drop policy if exists "patient_xrays_delete" on public.patient_xrays;
create policy "patient_xrays_delete" on public.patient_xrays
for delete to authenticated
using (
  public.current_app_role() = 'platform_admin'
  or exists (
    select 1 from public.patients p
    where p.id = patient_id
      and p.clinic_id = public.current_clinic_id()
      and (
        public.current_app_role() = 'owner'
        or (public.current_app_role() = 'employee' and uploaded_by = auth.uid())
      )
  )
);

grant select, insert, update, delete on public.patient_xrays to authenticated;

-- Private Storage bucket. Common browser image formats, max 10 MB.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'patient-xrays','patient-xrays',false,10485760,
  array['image/png','image/jpeg','image/jpg','image/webp']
)
on conflict (id) do update set
  public=false,
  file_size_limit=10485760,
  allowed_mime_types=array['image/png','image/jpeg','image/jpg','image/webp'];

drop policy if exists "patient_xrays_storage_select" on storage.objects;
create policy "patient_xrays_storage_select" on storage.objects
for select to authenticated
using (
  bucket_id='patient-xrays'
  and (
    public.current_app_role()='platform_admin'
    or (
      public.current_app_role() in ('owner','employee')
      and exists (
        select 1 from public.patients p
        where p.id::text=(storage.foldername(name))[1]
          and p.clinic_id=public.current_clinic_id()
      )
    )
    or (
      public.current_app_role()='client'
      and exists (
        select 1 from public.patients p
        where p.id::text=(storage.foldername(name))[1]
          and p.user_id=auth.uid()
      )
    )
  )
);

drop policy if exists "patient_xrays_storage_insert" on storage.objects;
create policy "patient_xrays_storage_insert" on storage.objects
for insert to authenticated
with check (
  bucket_id='patient-xrays'
  and lower(name) ~ '\.(png|jpg|jpeg|webp)$'
  and cardinality(storage.foldername(name))=1
  and (
    public.current_app_role()='platform_admin'
    or (
      public.current_app_role() in ('owner','employee')
      and exists (
        select 1 from public.patients p
        where p.id::text=(storage.foldername(name))[1]
          and p.clinic_id=public.current_clinic_id()
      )
    )
  )
);

drop policy if exists "patient_xrays_storage_delete" on storage.objects;
create policy "patient_xrays_storage_delete" on storage.objects
for delete to authenticated
using (
  bucket_id='patient-xrays'
  and (
    public.current_app_role()='platform_admin'
    or exists (
      select 1
      from public.patient_xrays x
      join public.patients p on p.id=x.patient_id
      where x.storage_path=name
        and p.clinic_id=public.current_clinic_id()
        and (
          public.current_app_role()='owner'
          or (public.current_app_role()='employee' and x.uploaded_by=auth.uid())
        )
    )
  )
);

do $$
begin
  begin execute 'alter publication supabase_realtime add table public.patient_xrays';
  exception when duplicate_object then null;
  end;
end $$;
alter table public.patient_xrays replica identity full;

-- End V8.5.4
