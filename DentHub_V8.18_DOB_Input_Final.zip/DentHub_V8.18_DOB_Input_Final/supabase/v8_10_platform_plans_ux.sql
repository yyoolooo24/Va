begin;

create table if not exists public.platform_subscription_plans (
  code text primary key,
  name_mn text not null,
  name_en text not null,
  description_mn text,
  description_en text,
  enabled_modules text[] not null default '{}'::text[],
  employee_limit integer not null default 10 check (employee_limit between 1 and 1000),
  price numeric(14,2) not null default 0 check (price >= 0),
  billing_cycle text not null default 'monthly' check (billing_cycle in ('monthly','yearly','custom')),
  duration_months integer not null default 1 check (duration_months between 1 and 120),
  active boolean not null default true,
  sort_order integer not null default 100,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint platform_subscription_plan_code_format check (code ~ '^[A-Z0-9_]{2,24}$')
);

create index if not exists platform_subscription_plans_active_sort_idx
  on public.platform_subscription_plans(active desc, sort_order asc, created_at asc);

insert into public.platform_subscription_plans(code,name_mn,name_en,description_mn,description_en,enabled_modules,employee_limit,price,billing_cycle,duration_months,active,sort_order)
values
('START','Start','Start','Жижиг эмнэлгийн үндсэн өдөр тутмын ажил.','Core daily workflow for a small clinic.',array['appointments','consent_forms','patients','patient_cards','treatment_history','treatments','services','staff','internal_procedures','chat'],5,0,'monthly',1,true,10),
('GROWTH','Growth','Growth','Өсөж буй эмнэлгийн касс, бараа материал, санхүү.','Cashier, inventory and finance for a growing clinic.',array['appointments','consent_forms','patients','patient_cards','treatment_history','treatments','payments','erp','sales','cashbook','price_lists','services','inventory','stock_movements','suppliers','procurement','purchase_orders','lab_orders','receivables','expenses','finance','staff','internal_procedures','contracts','reports','chat'],25,0,'monthly',1,true,20),
('NETWORK','Network','Network','Бүх модуль болон олон салбарын бүрэн эрх.','Full module access for larger and multi-branch clinics.',array['appointments','consent_forms','patients','patient_cards','treatment_history','treatments','payments','erp','sales','sales_returns','cashbook','price_lists','services','inventory','stock_movements','suppliers','procurement','purchase_orders','lab_orders','crm','insurance','invoices','receivables','expenses','finance','staff','shifts','assets','branches','internal_procedures','health_department','questionnaire','contracts','reports','chat'],100,0,'monthly',1,true,30)
on conflict (code) do nothing;

alter table public.platform_subscription_plans enable row level security;

drop policy if exists "platform_subscription_plans_select" on public.platform_subscription_plans;
create policy "platform_subscription_plans_select"
on public.platform_subscription_plans for select to authenticated
using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='platform_admin' and coalesce(p.active,true)=true));

drop policy if exists "platform_subscription_plans_insert" on public.platform_subscription_plans;
create policy "platform_subscription_plans_insert"
on public.platform_subscription_plans for insert to authenticated
with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='platform_admin' and coalesce(p.active,true)=true));

drop policy if exists "platform_subscription_plans_update" on public.platform_subscription_plans;
create policy "platform_subscription_plans_update"
on public.platform_subscription_plans for update to authenticated
using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='platform_admin' and coalesce(p.active,true)=true))
with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='platform_admin' and coalesce(p.active,true)=true));

drop policy if exists "platform_subscription_plans_delete" on public.platform_subscription_plans;
create policy "platform_subscription_plans_delete"
on public.platform_subscription_plans for delete to authenticated
using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='platform_admin' and coalesce(p.active,true)=true));

grant select,insert,update,delete on public.platform_subscription_plans to authenticated;

commit;
