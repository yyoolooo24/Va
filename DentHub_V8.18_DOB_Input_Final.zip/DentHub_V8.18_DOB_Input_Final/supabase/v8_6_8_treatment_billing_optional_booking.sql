-- DentHub V8.6.8 SQL HOTFIX — performed-treatment billing + optional booking service
-- Run AFTER v8_6_6_client_workflow.sql.
-- Idempotent and safe to re-run after a partially completed V8.6.8 migration.
--
-- Why this hotfix exists:
-- The original migration could deadlock with live app traffic while PostgreSQL
-- was taking schema locks on encounters / encounter_treatments. This version
-- acquires every required table lock together with NOWAIT + retry so it never
-- sits in a circular lock wait.

begin;

set local statement_timeout = '120s';
set local idle_in_transaction_session_timeout = '120s';

-- Fail early with a readable message when prerequisite migrations were skipped.
do $$
begin
  if to_regclass('public.encounters') is null then
    raise exception 'DentHub V8.6.8 prerequisite missing: public.encounters does not exist.';
  end if;
  if to_regclass('public.encounter_treatments') is null then
    raise exception 'DentHub V8.6.8 prerequisite missing: public.encounter_treatments does not exist. Run v8_6_6_client_workflow.sql first.';
  end if;
  if to_regclass('public.services') is null then
    raise exception 'DentHub V8.6.8 prerequisite missing: public.services does not exist.';
  end if;
end $$;

-- Acquire all relations used by this migration as one lock set.
-- NOWAIT prevents PostgreSQL from entering a deadlock. If DentHub is serving a
-- request at this exact moment, wait briefly and retry without keeping partial locks.
do $$
declare
  attempt integer;
  acquired boolean := false;
begin
  for attempt in 1..80 loop
    begin
      lock table
        public.encounter_treatments,
        public.encounters,
        public.services
      in access exclusive mode nowait;

      acquired := true;
      exit;
    exception
      when lock_not_available then
        perform pg_sleep(0.25);
      when deadlock_detected then
        -- Defensive fallback. NOWAIT normally prevents reaching this branch.
        perform pg_sleep(0.25);
    end;
  end loop;

  if not acquired then
    raise exception using
      errcode = '55P03',
      message = 'DentHub V8.6.8 could not get a short schema lock after 20 seconds.',
      hint = 'Close other Supabase SQL tabs/migrations and wait for active DentHub requests to finish, then run this same file again.';
  end if;
end $$;

-- 1) Snapshot price on each performed tooth-treatment row.
alter table public.encounter_treatments
  add column if not exists unit_price numeric(14,2);

alter table public.encounter_treatments
  alter column unit_price set default 0;

update public.encounter_treatments et
set unit_price = coalesce(s.price, 0)::numeric(14,2)
from public.services s
where et.service_id = s.id
  and (et.unit_price is null or et.unit_price = 0);

-- Rows without a linked service are valid and remain zero-priced.
update public.encounter_treatments
set unit_price = 0
where unit_price is null;

alter table public.encounter_treatments
  alter column unit_price set not null;

-- 2) Encounter-level billing summary.
alter table public.encounters
  add column if not exists total_amount numeric(14,2);

alter table public.encounters
  add column if not exists billing_status text;

alter table public.encounters
  alter column total_amount set default 0,
  alter column billing_status set default 'no_charge';

-- Backfill safe defaults first (important when a previous run created columns
-- but failed before applying NOT NULL/defaults).
update public.encounters
set total_amount = coalesce(total_amount, 0),
    billing_status = coalesce(nullif(btrim(billing_status), ''), 'no_charge')
where total_amount is null
   or billing_status is null
   or btrim(billing_status) = '';

-- Recalculate every encounter that has tooth-by-tooth treatments.
with totals as (
  select
    encounter_id,
    coalesce(sum(coalesce(unit_price,0)),0)::numeric(14,2) as total_amount
  from public.encounter_treatments
  group by encounter_id
)
update public.encounters e
set total_amount = t.total_amount,
    billing_status = case
      when t.total_amount > 0 and coalesce(e.billing_status,'') in ('', 'no_charge') then 'unpaid'
      when t.total_amount <= 0 then 'no_charge'
      else e.billing_status
    end
from totals t
where e.id = t.encounter_id
  and (
    e.total_amount is distinct from t.total_amount
    or e.billing_status is null
    or (t.total_amount > 0 and e.billing_status = 'no_charge')
    or (t.total_amount <= 0 and e.billing_status <> 'no_charge')
  );

alter table public.encounters
  alter column total_amount set not null,
  alter column billing_status set not null;

-- Add the status constraint only to public.encounters, and make the check
-- idempotent even if another table happens to use the same constraint name.
do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'encounters_billing_status_chk'
      and conrelid = 'public.encounters'::regclass
  ) then
    alter table public.encounters
      add constraint encounters_billing_status_chk
      check (billing_status in ('no_charge','unpaid','partial','paid','void'))
      not valid;
  end if;
end $$;

alter table public.encounters
  validate constraint encounters_billing_status_chk;

commit;

-- End DentHub V8.6.8 SQL HOTFIX
