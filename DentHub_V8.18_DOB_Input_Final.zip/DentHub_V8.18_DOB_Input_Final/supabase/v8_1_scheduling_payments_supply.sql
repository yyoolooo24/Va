-- ClinicOS V8.1 — scheduling, patient purchase history and supplier ERP expansion
-- Safe additive migration for an existing V8.0 database.
-- It does not delete clinics, patients, appointments, payments, X-rays or ERP records.

-- -----------------------------------------------------------------------------
-- 1) Stronger appointment collision protection
-- -----------------------------------------------------------------------------
create index if not exists idx_appointments_doctor_range
  on public.appointments(doctor_id, starts_at, ends_at)
  where doctor_id is not null and status not in ('cancelled','no_show');

-- Serialize writes per doctor and reject ANY overlapping active time range.
-- This protects against two browsers booking the same slot at the same moment.
create or replace function public.prevent_appointment_overlap()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.doctor_id is null or new.status in ('cancelled','no_show') then
    return new;
  end if;

  perform pg_advisory_xact_lock(hashtext(new.doctor_id::text)::bigint);

  if exists (
    select 1
    from public.appointments a
    where a.doctor_id = new.doctor_id
      and a.id is distinct from new.id
      and a.status not in ('cancelled','no_show')
      and new.starts_at < coalesce(a.ends_at, a.starts_at + interval '30 minutes')
      and coalesce(new.ends_at, new.starts_at + interval '30 minutes') > a.starts_at
  ) then
    raise exception 'APPOINTMENT_TIME_OVERLAP' using errcode = '23P01';
  end if;
  return new;
end;
$$;

drop trigger if exists appointments_prevent_overlap on public.appointments;
create trigger appointments_prevent_overlap
before insert or update of doctor_id, starts_at, ends_at, status on public.appointments
for each row execute function public.prevent_appointment_overlap();

-- Audit trail for appointment moves/reschedules.
create table if not exists public.appointment_reschedule_history (
  id uuid primary key default gen_random_uuid(),
  appointment_id uuid not null references public.appointments(id) on delete cascade,
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  old_doctor_id uuid references public.profiles(id) on delete set null,
  new_doctor_id uuid references public.profiles(id) on delete set null,
  old_starts_at timestamptz not null,
  new_starts_at timestamptz not null,
  changed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists idx_appt_reschedule_appt
  on public.appointment_reschedule_history(appointment_id, created_at desc);
create index if not exists idx_appt_reschedule_clinic
  on public.appointment_reschedule_history(clinic_id, created_at desc);
alter table public.appointment_reschedule_history enable row level security;

drop policy if exists "appointment_reschedule_select" on public.appointment_reschedule_history;
create policy "appointment_reschedule_select" on public.appointment_reschedule_history
for select to authenticated using (
  public.current_app_role() = 'platform_admin'
  or (clinic_id = public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
  or exists (
    select 1 from public.appointments a
    join public.patients p on p.id = a.patient_id
    where a.id = appointment_id and p.user_id = auth.uid()
  )
);

-- Writes happen through trusted server routes using the service role.

-- -----------------------------------------------------------------------------
-- 2) Patient-linked QPay / purchase history
-- -----------------------------------------------------------------------------
alter table public.qpay_invoices
  add column if not exists patient_id uuid references public.patients(id) on delete set null;
create index if not exists idx_qpay_patient_created
  on public.qpay_invoices(patient_id, created_at desc);

drop policy if exists "qpay_select" on public.qpay_invoices;
create policy "qpay_select" on public.qpay_invoices
for select to authenticated using (
  public.current_app_role() = 'platform_admin'
  or clinic_id = public.current_clinic_id()
  or exists (
    select 1 from public.patients p
    where p.id = patient_id and p.user_id = auth.uid()
  )
);

-- -----------------------------------------------------------------------------
-- 3) Supplier / partner-clinic ERP expansion
-- -----------------------------------------------------------------------------
alter table public.erp_records drop constraint if exists erp_records_module_key_check;
alter table public.erp_records add constraint erp_records_module_key_check check (module_key in (
  'stock_movements','suppliers','procurement','purchase_orders','lab_orders','rooms','crm',
  'insurance','invoices','receivables','expenses','shifts','assets','tasks','branches',
  'supplier_warehouse','partner_clinics'
));

-- Recreate insert/update policies so owners can use the new modules.
drop policy if exists "erp_records_insert" on public.erp_records;
create policy "erp_records_insert" on public.erp_records
for insert to authenticated
with check (
  clinic_id = public.current_clinic_id()
  and (
    public.current_app_role() = 'owner'
    or (
      public.current_app_role() = 'employee'
      and module_key in ('lab_orders','rooms','crm','shifts','tasks')
    )
  )
);

drop policy if exists "erp_records_update" on public.erp_records;
create policy "erp_records_update" on public.erp_records
for update to authenticated
using (
  clinic_id = public.current_clinic_id()
  and (
    public.current_app_role() = 'owner'
    or (
      public.current_app_role() = 'employee'
      and module_key in ('lab_orders','rooms','crm','shifts','tasks')
    )
  )
)
with check (
  clinic_id = public.current_clinic_id()
  and (
    public.current_app_role() = 'owner'
    or (
      public.current_app_role() = 'employee'
      and module_key in ('lab_orders','rooms','crm','shifts','tasks')
    )
  )
);

-- -----------------------------------------------------------------------------
-- 4) Realtime
-- -----------------------------------------------------------------------------
do $$
begin
  begin execute 'alter publication supabase_realtime add table public.appointment_reschedule_history'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.qpay_invoices'; exception when duplicate_object then null; end;
end $$;

alter table public.appointment_reschedule_history replica identity full;
