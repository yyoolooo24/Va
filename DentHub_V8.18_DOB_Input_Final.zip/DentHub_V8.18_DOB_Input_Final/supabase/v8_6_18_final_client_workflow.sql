-- DentHub V8.6.18 — final client workflow, clinic logo, patient soft-delete
-- Run after V8.6.17.

alter table public.clinics add column if not exists logo_url text;
alter table public.patients add column if not exists deleted_at timestamptz;
alter table public.patients add column if not exists deleted_by uuid references public.profiles(id) on delete set null;
create index if not exists patients_active_clinic_idx on public.patients(clinic_id,created_at desc) where deleted_at is null;

-- Clinic owners can edit their own clinic branding. Platform admin can edit any clinic.
drop policy if exists "clinic_owner_update" on public.clinics;
create policy "clinic_owner_update" on public.clinics for update to authenticated
using (public.current_app_role()='platform_admin' or (public.current_app_role()='owner' and id=public.current_clinic_id()))
with check (public.current_app_role()='platform_admin' or (public.current_app_role()='owner' and id=public.current_clinic_id()));

-- Public logo bucket. Upload/update/delete is restricted to the owning clinic folder.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('clinic-logos','clinic-logos',true,2097152,array['image/png','image/jpeg','image/webp'])
on conflict (id) do update set public=true,file_size_limit=2097152,allowed_mime_types=array['image/png','image/jpeg','image/webp'];

drop policy if exists "clinic_logo_insert" on storage.objects;
create policy "clinic_logo_insert" on storage.objects for insert to authenticated with check (
  bucket_id='clinic-logos' and (
    public.current_app_role()='platform_admin' or
    (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
);
drop policy if exists "clinic_logo_update" on storage.objects;
create policy "clinic_logo_update" on storage.objects for update to authenticated using (
  bucket_id='clinic-logos' and (
    public.current_app_role()='platform_admin' or
    (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
) with check (
  bucket_id='clinic-logos' and (
    public.current_app_role()='platform_admin' or
    (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
);
drop policy if exists "clinic_logo_delete" on storage.objects;
create policy "clinic_logo_delete" on storage.objects for delete to authenticated using (
  bucket_id='clinic-logos' and (
    public.current_app_role()='platform_admin' or
    (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
);


-- Keep an edited treatment-linked cashbook row and the visit payment totals in sync.
create or replace function public.denthub_update_cashbook_entry(
  p_finance_transaction_id uuid,
  p_kind text,
  p_description text,
  p_amount numeric,
  p_payment_method text
)
returns table(paid_amount numeric, remaining_amount numeric, billing_status text)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_clinic uuid;
  v_encounter uuid;
  v_payment uuid;
  v_total numeric(14,2);
  v_other_paid numeric(14,2);
  v_paid numeric(14,2);
  v_status text;
  v_method_id uuid;
begin
  if auth.uid() is null or public.current_app_role() not in ('owner','employee') then raise exception 'FORBIDDEN'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'PAYMENT_AMOUNT_INVALID'; end if;
  if nullif(btrim(coalesce(p_description,'')),'') is null then raise exception 'DESCRIPTION_REQUIRED'; end if;

  select ft.clinic_id,ft.encounter_id into v_clinic,v_encounter
  from public.finance_transactions ft
  where ft.id=p_finance_transaction_id for update;
  if v_clinic is null or v_clinic is distinct from public.current_clinic_id() then raise exception 'CASHBOOK_ENTRY_NOT_FOUND'; end if;

  if v_encounter is null then
    update public.finance_transactions
       set kind=case when lower(coalesce(p_kind,''))='expense' then 'expense' else 'income' end,
           description=btrim(p_description),amount=round(p_amount),payment_method=coalesce(nullif(btrim(p_payment_method),''),'Бэлэн')
     where id=p_finance_transaction_id;
    return query select 0::numeric,0::numeric,'manual'::text;
    return;
  end if;

  if lower(coalesce(p_kind,''))='expense' then raise exception 'TREATMENT_PAYMENT_MUST_BE_INCOME'; end if;
  select ep.id into v_payment from public.encounter_payments ep where ep.finance_transaction_id=p_finance_transaction_id for update;
  if v_payment is null then raise exception 'LINKED_PAYMENT_NOT_FOUND'; end if;
  select coalesce(e.total_amount,0) into v_total from public.encounters e where e.id=v_encounter and e.deleted_at is null for update;
  if v_total is null then raise exception 'ENCOUNTER_NOT_FOUND'; end if;
  select coalesce(sum(ep.amount),0)::numeric(14,2) into v_other_paid from public.encounter_payments ep where ep.encounter_id=v_encounter and ep.id<>v_payment;
  if v_total>0 and p_amount>greatest(v_total-v_other_paid,0)+0.009 then raise exception 'PAYMENT_EXCEEDS_REMAINING'; end if;
  select pm.id into v_method_id from public.payment_methods pm where pm.clinic_id=v_clinic and lower(btrim(pm.name))=lower(btrim(coalesce(p_payment_method,''))) and pm.active=true limit 1;

  update public.finance_transactions set kind='income',description=btrim(p_description),amount=round(p_amount),payment_method=coalesce(nullif(btrim(p_payment_method),''),'Бэлэн') where id=p_finance_transaction_id;
  update public.encounter_payments set amount=p_amount,payment_method_name=coalesce(nullif(btrim(p_payment_method),''),'Бэлэн'),payment_method_id=v_method_id where id=v_payment;
  select coalesce(sum(ep.amount),0)::numeric(14,2) into v_paid from public.encounter_payments ep where ep.encounter_id=v_encounter;
  v_status:=case when v_total<=0 then 'no_charge' when v_paid>=v_total then 'paid' when v_paid>0 then 'partial' else 'unpaid' end;
  update public.encounters set paid_amount=v_paid,billing_status=v_status where id=v_encounter;
  return query select v_paid,greatest(v_total-v_paid,0)::numeric(14,2),v_status;
end $$;
revoke all on function public.denthub_update_cashbook_entry(uuid,text,text,numeric,text) from public;
grant execute on function public.denthub_update_cashbook_entry(uuid,text,text,numeric,text) to authenticated;

-- Make cashier waiting lists refresh across staff devices.
do $$ begin
  begin execute 'alter publication supabase_realtime add table public.encounters'; exception when duplicate_object then null; end;
end $$;
alter table public.encounters replica identity full;
