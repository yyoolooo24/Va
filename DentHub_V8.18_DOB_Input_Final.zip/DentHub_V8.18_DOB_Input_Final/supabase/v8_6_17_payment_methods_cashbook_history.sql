-- DentHub V8.6.17 — dynamic payment methods, treatment cashbook persistence, history delete
-- Run AFTER V8.6.8 and V8.6.13. Safe additive / idempotent migration.

create extension if not exists pgcrypto;

-- -----------------------------------------------------------------------------
-- 1) Clinic-managed payment methods
-- -----------------------------------------------------------------------------
create table if not exists public.payment_methods (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  name text not null,
  code text,
  active boolean not null default true,
  is_system boolean not null default false,
  sort_order integer not null default 100,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (length(btrim(name)) between 1 and 80)
);
create unique index if not exists payment_methods_clinic_name_uidx
  on public.payment_methods(clinic_id, lower(btrim(name)));
create index if not exists payment_methods_clinic_active_idx
  on public.payment_methods(clinic_id, active, sort_order, name);

alter table public.payment_methods enable row level security;
drop policy if exists "payment_methods_select" on public.payment_methods;
create policy "payment_methods_select" on public.payment_methods for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
);
drop policy if exists "payment_methods_write" on public.payment_methods;
create policy "payment_methods_write" on public.payment_methods for all to authenticated using (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
) with check (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
);

create or replace function public.denthub_touch_payment_method()
returns trigger language plpgsql set search_path=public as $$
begin new.updated_at=now(); return new; end $$;
drop trigger if exists denthub_payment_method_touch on public.payment_methods;
create trigger denthub_payment_method_touch before update on public.payment_methods
for each row execute function public.denthub_touch_payment_method();

-- Seed current clinics with the client-requested defaults.
insert into public.payment_methods(clinic_id,name,code,is_system,sort_order)
select c.id, x.name, x.code, true, x.sort_order
from public.clinics c
cross join (values
  ('Бэлэн','cash',10),
  ('Карт','card',20),
  ('Эмнэлгийн зээл','clinic_credit',30),
  ('Зээлийн апп','loan_app',40),
  ('QPay','qpay',50),
  ('Шилжүүлэг','transfer',60)
) as x(name,code,sort_order)
on conflict do nothing;

-- Future clinics receive the same defaults automatically.
create or replace function public.denthub_seed_payment_methods()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.payment_methods(clinic_id,name,code,is_system,sort_order)
  values
    (new.id,'Бэлэн','cash',true,10),
    (new.id,'Карт','card',true,20),
    (new.id,'Эмнэлгийн зээл','clinic_credit',true,30),
    (new.id,'Зээлийн апп','loan_app',true,40),
    (new.id,'QPay','qpay',true,50),
    (new.id,'Шилжүүлэг','transfer',true,60)
  on conflict do nothing;
  return new;
end $$;
drop trigger if exists denthub_seed_payment_methods_on_clinic on public.clinics;
create trigger denthub_seed_payment_methods_on_clinic
after insert on public.clinics for each row execute function public.denthub_seed_payment_methods();

-- -----------------------------------------------------------------------------
-- 2) Link finance/cashbook entries back to patient + visit
-- -----------------------------------------------------------------------------
alter table public.finance_transactions
  add column if not exists patient_id uuid references public.patients(id) on delete set null;
alter table public.finance_transactions
  add column if not exists encounter_id uuid references public.encounters(id) on delete set null;
create index if not exists finance_transactions_patient_idx
  on public.finance_transactions(clinic_id, patient_id, created_at desc);
create index if not exists finance_transactions_encounter_idx
  on public.finance_transactions(encounter_id, created_at desc);

alter table public.encounters add column if not exists paid_amount numeric(14,2) not null default 0;
alter table public.encounters add column if not exists deleted_at timestamptz;
alter table public.encounters add column if not exists deleted_by uuid references public.profiles(id) on delete set null;

create table if not exists public.encounter_payments (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  encounter_id uuid not null references public.encounters(id) on delete cascade,
  patient_id uuid not null references public.patients(id) on delete cascade,
  amount numeric(14,2) not null check (amount > 0),
  payment_method_id uuid references public.payment_methods(id) on delete set null,
  payment_method_name text not null,
  note text,
  finance_transaction_id uuid references public.finance_transactions(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists encounter_payments_encounter_idx on public.encounter_payments(encounter_id, created_at desc);
create index if not exists encounter_payments_clinic_idx on public.encounter_payments(clinic_id, created_at desc);
create index if not exists encounter_payments_patient_idx on public.encounter_payments(patient_id, created_at desc);

alter table public.encounter_payments enable row level security;
drop policy if exists "encounter_payments_select" on public.encounter_payments;
create policy "encounter_payments_select" on public.encounter_payments for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
  or exists(select 1 from public.patients p where p.id=patient_id and p.user_id=auth.uid())
);
-- Writes are intentionally routed through the RPC below so cashbook + billing update atomically.

-- Record a visit payment and create the matching cashbook entry in one transaction.
create or replace function public.denthub_record_encounter_payment(
  p_encounter_id uuid,
  p_amount numeric,
  p_payment_method_id uuid,
  p_note text default null
)
returns table(payment_id uuid, finance_transaction_id uuid, paid_amount numeric, remaining_amount numeric, billing_status text)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_clinic uuid;
  v_patient uuid;
  v_total numeric(14,2);
  v_method_name text;
  v_finance_id uuid;
  v_payment_id uuid;
  v_paid numeric(14,2);
  v_status text;
  v_description text;
begin
  if auth.uid() is null or public.current_app_role() not in ('owner','employee') then
    raise exception 'FORBIDDEN';
  end if;
  if p_amount is null or p_amount <= 0 then
    raise exception 'PAYMENT_AMOUNT_INVALID';
  end if;

  select e.clinic_id,e.patient_id,coalesce(e.total_amount,0)
  into v_clinic,v_patient,v_total
  from public.encounters e
  where e.id=p_encounter_id and e.deleted_at is null
  for update;

  if v_clinic is null or v_clinic is distinct from public.current_clinic_id() then
    raise exception 'ENCOUNTER_NOT_FOUND';
  end if;

  select pm.name into v_method_name
  from public.payment_methods pm
  where pm.id=p_payment_method_id and pm.clinic_id=v_clinic and pm.active=true;
  if v_method_name is null then raise exception 'PAYMENT_METHOD_NOT_FOUND'; end if;

  select coalesce(sum(ep.amount),0)::numeric(14,2) into v_paid
  from public.encounter_payments ep where ep.encounter_id=p_encounter_id;

  if v_total > 0 and p_amount > greatest(v_total-v_paid,0) + 0.009 then
    raise exception 'PAYMENT_EXCEEDS_REMAINING';
  end if;

  select coalesce(p.full_name,'Өвчтөн')||' · Үзлэг, эмчилгээ'
  into v_description from public.patients p where p.id=v_patient;

  insert into public.finance_transactions(clinic_id,created_by,kind,description,amount,payment_method,patient_id,encounter_id)
  values(v_clinic,auth.uid(),'income',coalesce(v_description,'Үзлэг, эмчилгээ'),round(p_amount)::bigint,v_method_name,v_patient,p_encounter_id)
  returning id into v_finance_id;

  insert into public.encounter_payments(clinic_id,encounter_id,patient_id,amount,payment_method_id,payment_method_name,note,finance_transaction_id,created_by)
  values(v_clinic,p_encounter_id,v_patient,p_amount,p_payment_method_id,v_method_name,nullif(btrim(coalesce(p_note,'')),''),v_finance_id,auth.uid())
  returning id into v_payment_id;

  select coalesce(sum(ep.amount),0)::numeric(14,2) into v_paid
  from public.encounter_payments ep where ep.encounter_id=p_encounter_id;
  v_status := case
    when v_total <= 0 then 'no_charge'
    when v_paid >= v_total then 'paid'
    when v_paid > 0 then 'partial'
    else 'unpaid'
  end;

  update public.encounters
  set paid_amount=v_paid,billing_status=v_status
  where id=p_encounter_id;

  return query select v_payment_id,v_finance_id,v_paid,greatest(v_total-v_paid,0)::numeric(14,2),v_status;
end $$;
revoke all on function public.denthub_record_encounter_payment(uuid,numeric,uuid,text) from public;
grant execute on function public.denthub_record_encounter_payment(uuid,numeric,uuid,text) to authenticated;

-- -----------------------------------------------------------------------------
-- 3) Treatment-history "delete" = soft delete for medical audit safety
-- -----------------------------------------------------------------------------
create or replace function public.denthub_delete_treatment_history(p_encounter_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare v_clinic uuid;
begin
  if auth.uid() is null or public.current_app_role() not in ('owner','employee') then raise exception 'FORBIDDEN'; end if;
  select clinic_id into v_clinic from public.encounters where id=p_encounter_id;
  if v_clinic is null or v_clinic is distinct from public.current_clinic_id() then raise exception 'ENCOUNTER_NOT_FOUND'; end if;
  update public.encounters set deleted_at=now(),deleted_by=auth.uid(),status='cancelled' where id=p_encounter_id;
end $$;
revoke all on function public.denthub_delete_treatment_history(uuid) from public;
grant execute on function public.denthub_delete_treatment_history(uuid) to authenticated;

-- Keep realtime screens in sync.
do $$
begin
  begin execute 'alter publication supabase_realtime add table public.payment_methods'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.encounter_payments'; exception when duplicate_object then null; end;
end $$;
alter table public.payment_methods replica identity full;
alter table public.encounter_payments replica identity full;

-- Backfill paid_amount / billing status from any payment rows that already exist.
with paid as (
  select encounter_id,coalesce(sum(amount),0)::numeric(14,2) amount from public.encounter_payments group by encounter_id
)
update public.encounters e
set paid_amount=p.amount,
    billing_status=case when coalesce(e.total_amount,0)<=0 then 'no_charge' when p.amount>=e.total_amount then 'paid' when p.amount>0 then 'partial' else 'unpaid' end
from paid p where p.encounter_id=e.id;

-- End V8.6.17

-- QPay invoices can now point back to the originating treatment visit so a
-- successful callback can create the same cashbook/payment records as cash/card.
alter table public.qpay_invoices add column if not exists encounter_id uuid references public.encounters(id) on delete set null;
alter table public.qpay_invoices add column if not exists finance_transaction_id uuid references public.finance_transactions(id) on delete set null;
create index if not exists qpay_invoices_encounter_idx on public.qpay_invoices(encounter_id, created_at desc);
create unique index if not exists encounter_payments_finance_uidx on public.encounter_payments(finance_transaction_id) where finance_transaction_id is not null;

-- Cashbook is operational, so clinic staff must be able to see and write its
-- finance rows (manual writes still require the app/module UI permissions).
drop policy if exists "finance_select" on public.finance_transactions;
create policy "finance_select" on public.finance_transactions for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
);
drop policy if exists "finance_owner_write" on public.finance_transactions;
create policy "finance_owner_write" on public.finance_transactions for all to authenticated using (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
) with check (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
);
