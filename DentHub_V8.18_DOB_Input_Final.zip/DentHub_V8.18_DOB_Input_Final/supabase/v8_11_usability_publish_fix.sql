-- DentHub V8.11 — branding hardening / usability release
-- Run after V8.10. Safe to re-run.

begin;

alter table public.clinics add column if not exists logo_url text;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('clinic-logos','clinic-logos',true,2097152,array['image/png','image/jpeg','image/webp'])
on conflict (id) do update
set public=true,
    file_size_limit=2097152,
    allowed_mime_types=array['image/png','image/jpeg','image/webp'];

-- The clinic owner can update branding only for their active clinic.
drop policy if exists "clinic_owner_update" on public.clinics;
create policy "clinic_owner_update" on public.clinics
for update to authenticated
using (
  public.current_app_role()='platform_admin'
  or (public.current_app_role()='owner' and id=public.current_clinic_id())
)
with check (
  public.current_app_role()='platform_admin'
  or (public.current_app_role()='owner' and id=public.current_clinic_id())
);

drop policy if exists "clinic_logo_insert" on storage.objects;
create policy "clinic_logo_insert" on storage.objects
for insert to authenticated
with check (
  bucket_id='clinic-logos' and (
    public.current_app_role()='platform_admin'
    or (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
);

drop policy if exists "clinic_logo_update" on storage.objects;
create policy "clinic_logo_update" on storage.objects
for update to authenticated
using (
  bucket_id='clinic-logos' and (
    public.current_app_role()='platform_admin'
    or (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
)
with check (
  bucket_id='clinic-logos' and (
    public.current_app_role()='platform_admin'
    or (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
);

drop policy if exists "clinic_logo_delete" on storage.objects;
create policy "clinic_logo_delete" on storage.objects
for delete to authenticated
using (
  bucket_id='clinic-logos' and (
    public.current_app_role()='platform_admin'
    or (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
);

commit;
