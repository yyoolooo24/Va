-- ClinicOS V7.4 — ERP expansion
-- Safe migration for an existing V7.3 database.
-- Adds one flexible ERP record table used by procurement, suppliers, PO, stock movement,
-- lab orders, rooms, CRM, insurance, invoices, receivables, expenses, shifts, assets,
-- tasks and branches. This migration does NOT delete existing clinic/patient/payment data.

create table if not exists public.erp_records (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  module_key text not null check (module_key in (
    'stock_movements','suppliers','procurement','purchase_orders','lab_orders','rooms','crm',
    'insurance','invoices','receivables','expenses','shifts','assets','tasks','branches'
  )),
  title text not null,
  subtitle text,
  meta text,
  status text,
  payload jsonb not null default '{}'::jsonb,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists erp_records_clinic_module_created_idx
  on public.erp_records(clinic_id,module_key,created_at desc);

alter table public.erp_records enable row level security;

drop policy if exists "erp_records_select" on public.erp_records;
create policy "erp_records_select" on public.erp_records
for select to authenticated
using (
  public.current_app_role() = 'platform_admin'
  or (
    clinic_id = public.current_clinic_id()
    and public.current_app_role() in ('owner','employee')
  )
);

drop policy if exists "erp_records_insert" on public.erp_records;
create policy "erp_records_insert" on public.erp_records
for insert to authenticated
with check (
  clinic_id = public.current_clinic_id()
  and (
    public.current_app_role() = 'owner'
    or (
      public.current_app_role() = 'employee'
      and module_key in ('lab_orders','rooms','crm','shifts','tasks')
    )
  )
);

drop policy if exists "erp_records_update" on public.erp_records;
create policy "erp_records_update" on public.erp_records
for update to authenticated
using (
  clinic_id = public.current_clinic_id()
  and (
    public.current_app_role() = 'owner'
    or (
      public.current_app_role() = 'employee'
      and module_key in ('lab_orders','rooms','crm','shifts','tasks')
    )
  )
)
with check (
  clinic_id = public.current_clinic_id()
  and (
    public.current_app_role() = 'owner'
    or (
      public.current_app_role() = 'employee'
      and module_key in ('lab_orders','rooms','crm','shifts','tasks')
    )
  )
);

drop policy if exists "erp_records_delete" on public.erp_records;
create policy "erp_records_delete" on public.erp_records
for delete to authenticated
using (clinic_id = public.current_clinic_id() and public.current_app_role() = 'owner');
