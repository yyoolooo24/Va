-- DentHub V8.6.21 — compliance, HR files, expiry tracking and finance obligations
-- Run AFTER the V8.6.20 migration.

create extension if not exists pgcrypto;

-- 1) Inventory expiry / batch tracking
alter table public.inventory_items add column if not exists batch_no text;
alter table public.inventory_items add column if not exists expiry_date date;
create index if not exists inventory_items_expiry_idx on public.inventory_items(clinic_id, expiry_date) where expiry_date is not null;
create index if not exists inventory_items_batch_idx on public.inventory_items(clinic_id, batch_no) where batch_no is not null;

-- 2) Mark encounters moved to clinic-credit receivables, so they do not stay in cashier queue.
alter table public.encounters add column if not exists credit_transferred_at timestamptz;
create index if not exists encounters_credit_transfer_idx on public.encounters(clinic_id, credit_transferred_at) where credit_transferred_at is not null;

-- 3) Private clinic document bucket used for employee files, revised procedures and regulatory uploads.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values(
  'clinic-documents','clinic-documents',false,26214400,
  array[
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'image/png','image/jpeg','image/webp'
  ]
)
on conflict (id) do update set
  public=false,
  file_size_limit=26214400,
  allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "clinic_documents_select" on storage.objects;
create policy "clinic_documents_select" on storage.objects
for select to authenticated
using (
  bucket_id='clinic-documents'
  and (
    public.current_app_role()='platform_admin'
    or (
      public.current_app_role() in ('owner','employee')
      and (storage.foldername(name))[1]=public.current_clinic_id()::text
    )
  )
);

drop policy if exists "clinic_documents_insert" on storage.objects;
create policy "clinic_documents_insert" on storage.objects
for insert to authenticated
with check (
  bucket_id='clinic-documents'
  and (
    public.current_app_role()='platform_admin'
    or (
      public.current_app_role() in ('owner','employee')
      and (storage.foldername(name))[1]=public.current_clinic_id()::text
    )
  )
);

drop policy if exists "clinic_documents_update" on storage.objects;
create policy "clinic_documents_update" on storage.objects
for update to authenticated
using (
  bucket_id='clinic-documents'
  and (
    public.current_app_role()='platform_admin'
    or (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
)
with check (
  bucket_id='clinic-documents'
  and (
    public.current_app_role()='platform_admin'
    or (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
);

drop policy if exists "clinic_documents_delete" on storage.objects;
create policy "clinic_documents_delete" on storage.objects
for delete to authenticated
using (
  bucket_id='clinic-documents'
  and (
    public.current_app_role()='platform_admin'
    or (public.current_app_role()='owner' and (storage.foldername(name))[1]=public.current_clinic_id()::text)
  )
);

-- 4) Employee compliance / HR documents
create table if not exists public.employee_documents (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  employee_id uuid not null references public.profiles(id) on delete cascade,
  document_type text not null,
  title text not null,
  storage_path text not null,
  file_name text not null,
  issued_at date,
  expires_at date,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  deleted_at timestamptz,
  deleted_by uuid references public.profiles(id) on delete set null
);
create index if not exists employee_documents_employee_idx on public.employee_documents(clinic_id,employee_id,created_at desc) where deleted_at is null;
create index if not exists employee_documents_expiry_idx on public.employee_documents(clinic_id,expires_at) where expires_at is not null and deleted_at is null;
alter table public.employee_documents enable row level security;

drop policy if exists "employee_documents_select" on public.employee_documents;
create policy "employee_documents_select" on public.employee_documents for select to authenticated
using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and (public.current_app_role()='owner' or (public.current_app_role()='employee' and employee_id=auth.uid())))
);
drop policy if exists "employee_documents_insert" on public.employee_documents;
create policy "employee_documents_insert" on public.employee_documents for insert to authenticated
with check (
  clinic_id=public.current_clinic_id()
  and (public.current_app_role()='owner' or (public.current_app_role()='employee' and employee_id=auth.uid()))
);
drop policy if exists "employee_documents_update" on public.employee_documents;
create policy "employee_documents_update" on public.employee_documents for update to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');
drop policy if exists "employee_documents_delete" on public.employee_documents;
create policy "employee_documents_delete" on public.employee_documents for delete to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');

-- 5) Clinic procedure version overrides + staff acknowledgement
create table if not exists public.internal_procedures (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  procedure_code text not null,
  title text not null,
  version text not null default '1.0',
  storage_path text not null,
  file_name text not null,
  notes text,
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now(),
  unique(clinic_id,procedure_code)
);
create index if not exists internal_procedures_clinic_idx on public.internal_procedures(clinic_id,procedure_code);
alter table public.internal_procedures enable row level security;
drop policy if exists "internal_procedures_select" on public.internal_procedures;
create policy "internal_procedures_select" on public.internal_procedures for select to authenticated
using (public.current_app_role()='platform_admin' or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')));
drop policy if exists "internal_procedures_owner_write" on public.internal_procedures;
create policy "internal_procedures_owner_write" on public.internal_procedures for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');

create table if not exists public.internal_procedure_acknowledgements (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  procedure_code text not null,
  employee_id uuid not null references public.profiles(id) on delete cascade,
  acknowledged_at timestamptz not null default now(),
  unique(clinic_id,procedure_code,employee_id)
);
create index if not exists internal_procedure_ack_idx on public.internal_procedure_acknowledgements(clinic_id,procedure_code,employee_id);
alter table public.internal_procedure_acknowledgements enable row level security;
drop policy if exists "internal_procedure_ack_select" on public.internal_procedure_acknowledgements;
create policy "internal_procedure_ack_select" on public.internal_procedure_acknowledgements for select to authenticated
using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and (public.current_app_role()='owner' or (public.current_app_role()='employee' and employee_id=auth.uid())))
);
drop policy if exists "internal_procedure_ack_write" on public.internal_procedure_acknowledgements;
create policy "internal_procedure_ack_write" on public.internal_procedure_acknowledgements for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='employee' and employee_id=auth.uid())
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='employee' and employee_id=auth.uid());
-- Owners can also acknowledge procedures under their own account.
drop policy if exists "internal_procedure_ack_owner" on public.internal_procedure_acknowledgements;
create policy "internal_procedure_ack_owner" on public.internal_procedure_acknowledgements for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and employee_id=auth.uid())
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and employee_id=auth.uid());

-- 6) NEMG / regulatory workspace. Categories are intentionally clinic-defined.
create table if not exists public.health_department_categories (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  name text not null,
  sort_order integer not null default 0,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(clinic_id,name)
);
create table if not exists public.health_department_records (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  category_id uuid not null references public.health_department_categories(id) on delete cascade,
  title text not null,
  period text,
  notes text,
  storage_path text,
  file_name text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists health_department_categories_idx on public.health_department_categories(clinic_id,sort_order,name);
create index if not exists health_department_records_idx on public.health_department_records(clinic_id,category_id,created_at desc);
alter table public.health_department_categories enable row level security;
alter table public.health_department_records enable row level security;

drop policy if exists "health_department_categories_select" on public.health_department_categories;
create policy "health_department_categories_select" on public.health_department_categories for select to authenticated
using (public.current_app_role()='platform_admin' or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')));
drop policy if exists "health_department_categories_owner_write" on public.health_department_categories;
create policy "health_department_categories_owner_write" on public.health_department_categories for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');

drop policy if exists "health_department_records_select" on public.health_department_records;
create policy "health_department_records_select" on public.health_department_records for select to authenticated
using (public.current_app_role()='platform_admin' or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')));
drop policy if exists "health_department_records_owner_write" on public.health_department_records;
create policy "health_department_records_owner_write" on public.health_department_records for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');

-- 7) Finance module is obligations/debt/recurring costs, not a duplicate cash journal.
create table if not exists public.finance_obligations (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  obligation_type text not null check(obligation_type in ('payable','clinic_debt','fixed_expense')),
  title text not null,
  counterparty text,
  amount numeric(14,2) not null check(amount>0),
  due_date date,
  recurrence text,
  status text not null default 'Нээлттэй',
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists finance_obligations_clinic_idx on public.finance_obligations(clinic_id,obligation_type,due_date,created_at desc);
alter table public.finance_obligations enable row level security;
drop policy if exists "finance_obligations_select" on public.finance_obligations;
create policy "finance_obligations_select" on public.finance_obligations for select to authenticated
using (public.current_app_role()='platform_admin' or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')));
drop policy if exists "finance_obligations_owner_write" on public.finance_obligations;
create policy "finance_obligations_owner_write" on public.finance_obligations for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');

drop trigger if exists finance_obligations_set_updated_at on public.finance_obligations;
create trigger finance_obligations_set_updated_at before update on public.finance_obligations
for each row execute function public.denthub_touch_updated_at();

-- Realtime for operational compliance screens.
do $$
begin
  begin execute 'alter publication supabase_realtime add table public.employee_documents'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.internal_procedures'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.internal_procedure_acknowledgements'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.finance_obligations'; exception when duplicate_object then null; end;
end $$;

-- End DentHub V8.6.21
