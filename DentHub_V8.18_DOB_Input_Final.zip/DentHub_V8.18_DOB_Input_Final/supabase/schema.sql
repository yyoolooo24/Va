-- ClinicOS V7 — Supabase schema
-- Run in Supabase SQL Editor on a new project.

create extension if not exists pgcrypto;

create table if not exists public.clinics (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  plan text not null default 'START',
  status text not null default 'active' check (status in ('active','trial','suspended','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  clinic_id uuid references public.clinics(id) on delete set null,
  role text not null check (role in ('platform_admin','owner','employee','client','supplier')),
  full_name text not null,
  phone text,
  language text not null default 'mn' check (language in ('mn','en')),
  active boolean not null default true,
  deactivated_at timestamptz,
  deactivated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.supplier_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  company_name text not null,
  registration_no text,
  contact_name text,
  city text,
  website text,
  created_at timestamptz not null default now()
);

create table if not exists public.professional_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  display_name text not null default 'Doctor',
  clinic_name text,
  specialty text,
  bio text,
  city text,
  avatar_url text,
  verified boolean not null default false,
  discoverable boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  clinic_id uuid references public.clinics(id) on delete set null,
  post_type text not null default 'regular' check (post_type in ('regular','question','case')),
  body text not null check (char_length(body) between 1 and 5000),
  image_url text,
  is_anonymous boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1500),
  created_at timestamptz not null default now()
);

create table if not exists public.post_likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id,user_id)
);

create table if not exists public.post_saves (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id,user_id)
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id,following_id),
  check (follower_id <> following_id)
);

create table if not exists public.connections (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  addressee_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined','blocked')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(requester_id,addressee_id),
  check (requester_id <> addressee_id)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  kind text not null,
  title text not null,
  body text,
  target_type text,
  target_id uuid,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.patients (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete set null,
  full_name text not null,
  phone text,
  register_no text,
  date_of_birth date,
  address text,
  emergency_phone text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  patient_id uuid not null references public.patients(id) on delete cascade,
  doctor_id uuid references public.profiles(id) on delete set null,
  starts_at timestamptz not null,
  ends_at timestamptz,
  service_name text,
  room text,
  status text not null default 'scheduled' check (status in ('scheduled','checked_in','in_progress','done','cancelled','no_show')),
  created_at timestamptz not null default now()
);

create table if not exists public.qpay_invoices (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid references public.clinics(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  sender_invoice_no text not null unique,
  qpay_invoice_id text not null,
  amount bigint not null,
  description text,
  status text not null default 'PENDING',
  payment_id text,
  request_ebarimt boolean not null default false,
  ebarimt_receiver_type text,
  ebarimt_receiver text,
  ebarimt_payload jsonb,
  paid_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  name text not null,
  category text,
  price bigint not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.inventory_items (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  name text not null,
  sku text,
  quantity numeric not null default 0,
  min_quantity numeric not null default 0,
  cost bigint not null default 0,
  sale_price bigint not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_profiles_clinic on public.profiles(clinic_id);
create index if not exists idx_posts_created on public.posts(created_at desc);
create index if not exists idx_comments_post on public.comments(post_id,created_at);
create index if not exists idx_notifications_user on public.notifications(user_id,created_at desc);
create index if not exists idx_patients_clinic on public.patients(clinic_id);
create index if not exists idx_appointments_clinic_time on public.appointments(clinic_id,starts_at);
create index if not exists idx_qpay_sender on public.qpay_invoices(sender_invoice_no);

-- Helper functions used by RLS. SECURITY DEFINER avoids recursive RLS lookups.
create or replace function public.current_app_role()
returns text
language sql
stable
security definer
set search_path = public
as $$ select role from public.profiles where id = auth.uid() and active = true $$;

create or replace function public.current_clinic_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$ select clinic_id from public.profiles where id = auth.uid() and active = true $$;

revoke all on function public.current_app_role() from public;
revoke all on function public.current_clinic_id() from public;
grant execute on function public.current_app_role() to authenticated;
grant execute on function public.current_clinic_id() to authenticated;

alter table public.clinics enable row level security;
alter table public.profiles enable row level security;
alter table public.professional_profiles enable row level security;
alter table public.supplier_profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.post_likes enable row level security;
alter table public.post_saves enable row level security;
alter table public.follows enable row level security;
alter table public.connections enable row level security;
alter table public.notifications enable row level security;
alter table public.patients enable row level security;
alter table public.appointments enable row level security;
alter table public.qpay_invoices enable row level security;
alter table public.services enable row level security;
alter table public.inventory_items enable row level security;

-- Clinics
create policy "clinic_select" on public.clinics for select to authenticated using (
  public.current_app_role() = 'platform_admin' or id = public.current_clinic_id()
);

-- Private profiles: self, same-clinic owner, or platform admin.
create policy "profiles_select" on public.profiles for select to authenticated using (
  id = auth.uid() or public.current_app_role() = 'platform_admin' or
  (public.current_app_role() = 'owner' and clinic_id = public.current_clinic_id())
);
create policy "profiles_update_self" on public.profiles for update to authenticated
using (id = auth.uid() and active = true)
with check (
  id = auth.uid() and active = true
  and role = public.current_app_role()
  and clinic_id is not distinct from public.current_clinic_id()
);

-- Supplier profile is private to the supplier and visible to platform admin.
create policy "supplier_profile_select" on public.supplier_profiles for select to authenticated using (
  user_id = auth.uid() or public.current_app_role() = 'platform_admin'
);
create policy "supplier_profile_update_self" on public.supplier_profiles for update to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Professional directory is visible only to professional users (not clients).
create policy "professional_select" on public.professional_profiles for select to authenticated using (
  public.current_app_role() in ('platform_admin','owner','employee')
);
create policy "professional_update_self" on public.professional_profiles for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Community
create policy "posts_select_professionals" on public.posts for select to authenticated using (public.current_app_role() in ('platform_admin','owner','employee'));
create policy "posts_insert_self" on public.posts for insert to authenticated with check (author_id = auth.uid() and public.current_app_role() in ('owner','employee'));
create policy "posts_update_self" on public.posts for update to authenticated using (author_id = auth.uid()) with check (author_id = auth.uid());
create policy "posts_delete_self" on public.posts for delete to authenticated using (author_id = auth.uid());

create policy "comments_select_professionals" on public.comments for select to authenticated using (public.current_app_role() in ('platform_admin','owner','employee'));
create policy "comments_insert_self" on public.comments for insert to authenticated with check (author_id = auth.uid() and public.current_app_role() in ('owner','employee'));
create policy "comments_delete_self" on public.comments for delete to authenticated using (author_id = auth.uid());

create policy "likes_select_professionals" on public.post_likes for select to authenticated using (public.current_app_role() in ('platform_admin','owner','employee'));
create policy "likes_insert_self" on public.post_likes for insert to authenticated with check (user_id = auth.uid());
create policy "likes_delete_self" on public.post_likes for delete to authenticated using (user_id = auth.uid());

create policy "saves_self" on public.post_saves for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "follows_select_professionals" on public.follows for select to authenticated using (public.current_app_role() in ('platform_admin','owner','employee'));
create policy "follows_write_self" on public.follows for all to authenticated using (follower_id = auth.uid()) with check (follower_id = auth.uid());
create policy "connections_participant" on public.connections for select to authenticated using (requester_id = auth.uid() or addressee_id = auth.uid());
create policy "connections_insert_self" on public.connections for insert to authenticated with check (requester_id = auth.uid());
create policy "connections_update_participant" on public.connections for update to authenticated using (requester_id = auth.uid() or addressee_id = auth.uid());
create policy "notifications_self" on public.notifications for select to authenticated using (user_id = auth.uid());
create policy "notifications_update_self" on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Clinic operational data
create policy "patients_staff_select" on public.patients for select to authenticated using (
  public.current_app_role() = 'platform_admin' or
  (clinic_id = public.current_clinic_id() and public.current_app_role() in ('owner','employee')) or
  user_id = auth.uid()
);
create policy "patients_staff_write" on public.patients for all to authenticated using (clinic_id = public.current_clinic_id() and public.current_app_role() in ('owner','employee')) with check (clinic_id = public.current_clinic_id() and public.current_app_role() in ('owner','employee'));

create policy "appointments_select" on public.appointments for select to authenticated using (
  public.current_app_role() = 'platform_admin' or
  (clinic_id = public.current_clinic_id() and public.current_app_role() in ('owner','employee')) or
  exists(select 1 from public.patients p where p.id=patient_id and p.user_id=auth.uid())
);
create policy "appointments_staff_write" on public.appointments for all to authenticated using (clinic_id = public.current_clinic_id() and public.current_app_role() in ('owner','employee')) with check (clinic_id = public.current_clinic_id() and public.current_app_role() in ('owner','employee'));

create policy "qpay_select" on public.qpay_invoices for select to authenticated using (public.current_app_role()='platform_admin' or clinic_id=public.current_clinic_id());
-- QPay writes happen only through the server service role, so there is intentionally no client insert/update policy.

create policy "services_select" on public.services for select to authenticated using (public.current_app_role()='platform_admin' or clinic_id=public.current_clinic_id());
create policy "services_owner_write" on public.services for all to authenticated using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner') with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');
create policy "inventory_select" on public.inventory_items for select to authenticated using (public.current_app_role()='platform_admin' or (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')));
create policy "inventory_owner_write" on public.inventory_items for all to authenticated using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner') with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');

-- Optional post image storage bucket.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('post-media','post-media',false,3145728,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "post_media_professional_read" on storage.objects for select to authenticated using (bucket_id='post-media' and public.current_app_role() in ('platform_admin','owner','employee'));
create policy "post_media_authenticated_upload" on storage.objects for insert to authenticated with check (
  bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text and public.current_app_role() in ('owner','employee')
);
create policy "post_media_owner_update" on storage.objects for update to authenticated using (bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "post_media_owner_delete" on storage.objects for delete to authenticated using (bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text);


-- ==============================
-- V7 operational + notification additions
-- ==============================
-- ClinicOS V7 production upgrade
-- Safe to run after the V6/V6.2 schema in Supabase SQL Editor.

create table if not exists public.encounters (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  patient_id uuid not null references public.patients(id) on delete cascade,
  doctor_id uuid references public.profiles(id) on delete set null,
  diagnosis text,
  treatment_plan text,
  notes text,
  status text not null default 'open' check (status in ('open','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.finance_transactions (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  created_by uuid references public.profiles(id) on delete set null,
  kind text not null check (kind in ('income','expense')),
  description text not null,
  amount bigint not null check (amount >= 0),
  payment_method text,
  created_at timestamptz not null default now()
);

create table if not exists public.direct_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 3000),
  read_at timestamptz,
  created_at timestamptz not null default now(),
  check (sender_id <> recipient_id)
);

create index if not exists idx_encounters_clinic on public.encounters(clinic_id,created_at desc);
create index if not exists idx_finance_clinic on public.finance_transactions(clinic_id,created_at desc);
create index if not exists idx_messages_sender_recipient on public.direct_messages(sender_id,recipient_id,created_at desc);
create index if not exists idx_messages_recipient on public.direct_messages(recipient_id,created_at desc);

alter table public.encounters enable row level security;
alter table public.finance_transactions enable row level security;
alter table public.direct_messages enable row level security;

drop policy if exists "encounters_select" on public.encounters;
create policy "encounters_select" on public.encounters for select to authenticated using (
  public.current_app_role()='platform_admin' or
  (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')) or
  exists(select 1 from public.patients p where p.id=patient_id and p.user_id=auth.uid())
);

drop policy if exists "encounters_staff_write" on public.encounters;
create policy "encounters_staff_write" on public.encounters for all to authenticated using (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
) with check (
  clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee')
);

drop policy if exists "finance_select" on public.finance_transactions;
create policy "finance_select" on public.finance_transactions for select to authenticated using (
  public.current_app_role()='platform_admin' or
  (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
);

drop policy if exists "finance_owner_write" on public.finance_transactions;
create policy "finance_owner_write" on public.finance_transactions for all to authenticated using (
  clinic_id=public.current_clinic_id() and public.current_app_role()='owner'
) with check (
  clinic_id=public.current_clinic_id() and public.current_app_role()='owner'
);

drop policy if exists "messages_participant_select" on public.direct_messages;
create policy "messages_participant_select" on public.direct_messages for select to authenticated using (
  sender_id=auth.uid() or recipient_id=auth.uid()
);

drop policy if exists "messages_sender_insert" on public.direct_messages;
create policy "messages_sender_insert" on public.direct_messages for insert to authenticated with check (
  sender_id=auth.uid() and public.current_app_role() in ('owner','employee')
);

drop policy if exists "messages_participant_update" on public.direct_messages;
create policy "messages_participant_update" on public.direct_messages for update to authenticated using (
  sender_id=auth.uid() or recipient_id=auth.uid()
) with check (
  sender_id=auth.uid() or recipient_id=auth.uid()
);

-- Notification helpers. These functions run server-side and only create notifications
-- for the affected user. They never expose clinic/private patient data.
create or replace function public.notify_post_comment()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare owner_id uuid; actor_name text;
begin
  select author_id into owner_id from public.posts where id=new.post_id;
  if owner_id is null or owner_id=new.author_id then return new; end if;
  select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.author_id;
  insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
  values(owner_id,new.author_id,'comment',coalesce(actor_name,'Эмч'),'Таны нийтлэлд сэтгэгдэл бичлээ','post',new.post_id);
  return new;
end $$;

create or replace function public.notify_post_like()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare owner_id uuid; actor_name text;
begin
  select author_id into owner_id from public.posts where id=new.post_id;
  if owner_id is null or owner_id=new.user_id then return new; end if;
  select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.user_id;
  insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
  values(owner_id,new.user_id,'like',coalesce(actor_name,'Эмч'),'Таны нийтлэл таалагдлаа','post',new.post_id);
  return new;
end $$;

create or replace function public.notify_follow()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare actor_name text;
begin
  select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.follower_id;
  insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
  values(new.following_id,new.follower_id,'follow',coalesce(actor_name,'Эмч'),'Таныг дагаж эхэллээ','profile',new.follower_id);
  return new;
end $$;

create or replace function public.notify_connection_request()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare actor_name text;
begin
  select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.requester_id;
  insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
  values(new.addressee_id,new.requester_id,'connection',coalesce(actor_name,'Эмч'),'Танд холбоо тогтоох хүсэлт илгээлээ','profile',new.requester_id);
  return new;
end $$;

create or replace function public.notify_connection_accept()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare actor_name text;
begin
  if old.status is distinct from new.status and new.status='accepted' then
    select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.addressee_id;
    insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
    values(new.requester_id,new.addressee_id,'connection',coalesce(actor_name,'Эмч'),'Таны холбоо тогтоох хүсэлтийг зөвшөөрлөө','profile',new.addressee_id);
  end if;
  return new;
end $$;

create or replace function public.notify_direct_message()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare actor_name text;
begin
  select coalesce(display_name,'Эмч') into actor_name from public.professional_profiles where user_id=new.sender_id;
  insert into public.notifications(user_id,actor_id,kind,title,body,target_type,target_id)
  values(new.recipient_id,new.sender_id,'message',coalesce(actor_name,'Эмч'),'Танд шинэ мессеж ирлээ','chat',new.sender_id);
  return new;
end $$;

drop trigger if exists trg_notify_post_comment on public.comments;
create trigger trg_notify_post_comment after insert on public.comments for each row execute function public.notify_post_comment();
drop trigger if exists trg_notify_post_like on public.post_likes;
create trigger trg_notify_post_like after insert on public.post_likes for each row execute function public.notify_post_like();
drop trigger if exists trg_notify_follow on public.follows;
create trigger trg_notify_follow after insert on public.follows for each row execute function public.notify_follow();
drop trigger if exists trg_notify_connection_request on public.connections;
create trigger trg_notify_connection_request after insert on public.connections for each row execute function public.notify_connection_request();
drop trigger if exists trg_notify_connection_accept on public.connections;
create trigger trg_notify_connection_accept after update on public.connections for each row execute function public.notify_connection_accept();
drop trigger if exists trg_notify_direct_message on public.direct_messages;
create trigger trg_notify_direct_message after insert on public.direct_messages for each row execute function public.notify_direct_message();

-- Realtime is used for Facebook-style notification arrival while the app is open.
do $$ begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null;
end $$;

