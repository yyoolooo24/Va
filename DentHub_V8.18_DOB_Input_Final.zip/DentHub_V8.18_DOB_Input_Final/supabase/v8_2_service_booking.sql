-- ClinicOS V8.2 — service catalog + patient demographics + safer booking states
-- Safe additive migration. Does not delete existing patients, appointments, clinics or ERP data.

create extension if not exists pgcrypto;

-- Patient demographic information used while booking.
alter table public.patients add column if not exists gender text;

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'patients_gender_check'
  ) then
    alter table public.patients
      add constraint patients_gender_check
      check (gender is null or gender in ('male','female','other','unspecified'));
  end if;
end $$;

-- Keep a snapshot on the appointment because age can change over time.
alter table public.appointments add column if not exists patient_age smallint;
alter table public.appointments add column if not exists patient_gender text;
alter table public.appointments add column if not exists service_request text;

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'appointments_patient_age_check'
  ) then
    alter table public.appointments
      add constraint appointments_patient_age_check
      check (patient_age is null or patient_age between 0 and 130);
  end if;
  if not exists (
    select 1 from pg_constraint where conname = 'appointments_patient_gender_check'
  ) then
    alter table public.appointments
      add constraint appointments_patient_gender_check
      check (patient_gender is null or patient_gender in ('male','female','other','unspecified'));
  end if;
end $$;

-- Hierarchical service catalog. Existing category remains the top group.
alter table public.services add column if not exists subcategory text;
create index if not exists idx_services_clinic_category
  on public.services(clinic_id, category, subcategory, active, name);

-- Add a useful dental starter catalog to each clinic only when that exact service name is missing.
-- These are service definitions only (no fake patients, appointments or payments).
with catalog(name, category, subcategory, duration_minutes) as (
  values
    ('БАЙНГЫН ШҮДНИЙ ХОЛБООСЫН ЭМЧИЛГЭЭ','Шүдний эмчилгээ','Байнгын шүд',30),
    ('ШҮДНИЙ ЦӨГЦ СЭРГЭЭХ ЭМЧИЛГЭЭ','Шүдний эмчилгээ','Байнгын шүд',60),
    ('БАЙНГЫН ШҮДНИЙ ЦООРЛЫН ЭМЧИЛГЭЭ','Шүдний эмчилгээ','Байнгын шүд',45),
    ('ХИЙМЭЛ ШҮД','Шүдний эмчилгээ','Протез',60),
    ('ТУЛГУУРЫН ЭМЧИЛГЭЭ','Шүдний эмчилгээ','Протез',60),
    ('АВАГДДАГГҮЙ ШҮДЭЛБЭР','Шүдний эмчилгээ','Протез',60),
    ('УРЬДЧИЛАН СЭРГИЙЛЭЛТ','Шүдний эмчилгээ','Сүүн шүд',30),
    ('СҮҮН ШҮДНИЙ ЗӨӨЛЦИЙН ЭМЧИЛГЭЭ','Шүдний эмчилгээ','Сүүн шүд',45),
    ('СҮҮН ШҮДНИЙ ЦООРЛЫН ЭМЧИЛГЭЭ','Шүдний эмчилгээ','Сүүн шүд',30),
    ('СҮҮН ШҮДНИЙ ХОЛБООСЫН ЭМЧИЛГЭЭ','Шүдний эмчилгээ','Сүүн шүд',30),
    ('БАЙНГЫН ШҮДНИЙ ЗӨӨЛЦИЙН ЭМЧИЛГЭЭ','Шүдний эмчилгээ','Үзлэг',45),
    ('ШҮД АРЧИЛГААНЫ ЗӨВЛӨГӨӨ','Шүдний эмчилгээ','Үзлэг',30),
    ('ГАЖИГ ЗАСЛЫН ЭМЧИЛГЭЭ','Шүдний эмчилгээ','Гажиг засал',60),
    ('МЭС ЗАСЛЫН ЭМЧИЛГЭЭ','Шүдний эмчилгээ','Мэс засал',60)
)
insert into public.services(clinic_id, name, category, subcategory, price, duration_minutes, active)
select c.id, x.name, x.category, x.subcategory, 0, x.duration_minutes, true
from public.clinics c
cross join catalog x
where not exists (
  select 1 from public.services s
  where s.clinic_id = c.id and lower(trim(s.name)) = lower(trim(x.name))
);

-- Add a clear waiting state. Existing statuses remain valid.
alter table public.appointments drop constraint if exists appointments_status_check;
alter table public.appointments add constraint appointments_status_check
  check (status in (
    'pending','confirmed','scheduled','waiting','checked_in','in_progress',
    'completed','done','cancelled','no_show'
  ));

-- Realtime publication is idempotent.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'services'
  ) then
    alter publication supabase_realtime add table public.services;
  end if;
end $$;
