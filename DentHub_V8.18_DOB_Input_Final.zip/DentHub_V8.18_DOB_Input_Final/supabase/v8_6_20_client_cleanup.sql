-- DentHub V8.6.20 — client cleanup / cashbook delete
-- Run after V8.6.18. Safe to run more than once.

-- Generic DentHub service metadata. These columns are optional for normal manual/Excel services
-- but are kept for backwards-compatible data round trips. No external catalog is required.
alter table if exists public.services
  add column if not exists service_code text,
  add column if not exists external_source text,
  add column if not exists external_source_id text,
  add column if not exists source_group_id text,
  add column if not exists source_category_id text,
  add column if not exists source_meta jsonb not null default '{}'::jsonb;

create unique index if not exists services_external_source_uidx
  on public.services(clinic_id, external_source, external_source_id)
  where external_source is not null and external_source_id is not null;

create index if not exists services_service_code_idx
  on public.services(clinic_id, service_code);


create or replace function public.denthub_delete_cashbook_entry(
  p_finance_transaction_id uuid
)
returns table(paid_amount numeric, remaining_amount numeric, billing_status text)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_clinic uuid;
  v_encounter uuid;
  v_payment uuid;
  v_total numeric(14,2);
  v_paid numeric(14,2);
  v_status text;
begin
  if auth.uid() is null or public.current_app_role() <> 'owner' then
    raise exception 'FORBIDDEN';
  end if;

  select ft.clinic_id, ft.encounter_id
    into v_clinic, v_encounter
  from public.finance_transactions ft
  where ft.id=p_finance_transaction_id
  for update;

  if v_clinic is null or v_clinic is distinct from public.current_clinic_id() then
    raise exception 'CASHBOOK_ENTRY_NOT_FOUND';
  end if;

  if v_encounter is null then
    delete from public.finance_transactions
    where id=p_finance_transaction_id and clinic_id=v_clinic;
    return query select 0::numeric,0::numeric,'deleted'::text;
    return;
  end if;

  select ep.id into v_payment
  from public.encounter_payments ep
  where ep.finance_transaction_id=p_finance_transaction_id
  for update;

  if v_payment is not null then
    delete from public.encounter_payments where id=v_payment;
  end if;

  delete from public.finance_transactions
  where id=p_finance_transaction_id and clinic_id=v_clinic;

  select coalesce(e.total_amount,0) into v_total
  from public.encounters e
  where e.id=v_encounter
  for update;

  if v_total is null then
    return query select 0::numeric,0::numeric,'deleted'::text;
    return;
  end if;

  select coalesce(sum(ep.amount),0)::numeric(14,2) into v_paid
  from public.encounter_payments ep
  where ep.encounter_id=v_encounter;

  v_status:=case
    when v_total<=0 then 'no_charge'
    when v_paid>=v_total then 'paid'
    when v_paid>0 then 'partial'
    else 'unpaid'
  end;

  update public.encounters
     set paid_amount=v_paid,billing_status=v_status
   where id=v_encounter;

  return query select v_paid,greatest(v_total-v_paid,0)::numeric(14,2),v_status;
end $$;

revoke all on function public.denthub_delete_cashbook_entry(uuid) from public;
grant execute on function public.denthub_delete_cashbook_entry(uuid) to authenticated;
