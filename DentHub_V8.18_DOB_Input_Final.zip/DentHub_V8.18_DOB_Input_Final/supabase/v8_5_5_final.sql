-- DentHub V8.5.5 final polish migration
-- Safe to run on an existing V8.5.x database.

-- Service categories are first-class reusable records.
alter table if exists public.services
  add column if not exists is_category boolean not null default false;

-- Backfill one category header for older services that only stored category as text.
insert into public.services (clinic_id,name,category,subcategory,price,duration_minutes,active,is_category)
select distinct s.clinic_id, trim(s.category), trim(s.category), null, 0, 30, true, true
from public.services s
where coalesce(s.is_category,false)=false
  and nullif(trim(s.category),'') is not null
  and not exists (
    select 1 from public.services c
    where c.clinic_id=s.clinic_id
      and coalesce(c.is_category,false)=true
      and lower(trim(c.name))=lower(trim(s.category))
  );

-- Keep category headers predictable and cheap to query.
create index if not exists services_clinic_category_idx
  on public.services (clinic_id, category);
create index if not exists services_clinic_is_category_idx
  on public.services (clinic_id, is_category);

-- Finance amount is intentionally NOT defaulted to a fake value.
-- V8.5.5 validates the amount before insert so no NULL/zero transaction is saved.

-- Realtime for services, if not already enabled.
do $$
begin
  begin
    execute 'alter publication supabase_realtime add table public.services';
  exception when duplicate_object then null;
  end;
end $$;

-- End DentHub V8.5.5
