-- ClinicOS V8.0 — private Patient X-ray / Medical Image module
-- Safe additive migration for an existing ClinicOS V7.9 database.
-- Creates private Storage bucket + metadata table + RLS + Realtime.

create extension if not exists pgcrypto;

create table if not exists public.patient_xrays (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.patients(id) on delete cascade,
  storage_path text not null unique,
  original_filename text,
  mime_type text,
  file_size bigint,
  xray_type text,
  body_part text,
  taken_at timestamptz,
  description text,
  doctor_notes text,
  uploaded_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint patient_xrays_png_path check (lower(storage_path) like patient_id::text || '/%.png'),
  constraint patient_xrays_png_mime check (mime_type is null or mime_type = 'image/png'),
  constraint patient_xrays_file_size check (file_size is null or (file_size > 0 and file_size <= 10485760))
);

create index if not exists idx_patient_xrays_patient_created on public.patient_xrays(patient_id, created_at desc);
create index if not exists idx_patient_xrays_type on public.patient_xrays(patient_id, xray_type, created_at desc);
create index if not exists idx_patient_xrays_body_part on public.patient_xrays(patient_id, body_part, created_at desc);
create index if not exists idx_patient_xrays_uploader on public.patient_xrays(uploaded_by, created_at desc);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists patient_xrays_set_updated_at on public.patient_xrays;
create trigger patient_xrays_set_updated_at
before update on public.patient_xrays
for each row execute function public.set_updated_at();

alter table public.patient_xrays enable row level security;

drop policy if exists "patient_xrays_staff_select" on public.patient_xrays;
create policy "patient_xrays_staff_select" on public.patient_xrays
for select to authenticated
using (
  public.current_app_role() = 'platform_admin'
  or (
    public.current_app_role() in ('owner','employee')
    and exists (
      select 1 from public.patients p
      where p.id = patient_id and p.clinic_id = public.current_clinic_id()
    )
  )
);

drop policy if exists "patient_xrays_staff_insert" on public.patient_xrays;
create policy "patient_xrays_staff_insert" on public.patient_xrays
for insert to authenticated
with check (
  uploaded_by = auth.uid()
  and (
    public.current_app_role() = 'platform_admin'
    or (
      public.current_app_role() in ('owner','employee')
      and exists (
        select 1 from public.patients p
        where p.id = patient_id and p.clinic_id = public.current_clinic_id()
      )
    )
  )
);

drop policy if exists "patient_xrays_staff_update" on public.patient_xrays;
create policy "patient_xrays_staff_update" on public.patient_xrays
for update to authenticated
using (
  public.current_app_role() = 'platform_admin'
  or exists (
    select 1 from public.patients p
    where p.id = patient_id
      and p.clinic_id = public.current_clinic_id()
      and (
        public.current_app_role() = 'owner'
        or (public.current_app_role() = 'employee' and uploaded_by = auth.uid())
      )
  )
)
with check (
  public.current_app_role() = 'platform_admin'
  or exists (
    select 1 from public.patients p
    where p.id = patient_id
      and p.clinic_id = public.current_clinic_id()
      and (
        public.current_app_role() = 'owner'
        or (public.current_app_role() = 'employee' and uploaded_by = auth.uid())
      )
  )
);

drop policy if exists "patient_xrays_staff_delete" on public.patient_xrays;
create policy "patient_xrays_staff_delete" on public.patient_xrays
for delete to authenticated
using (
  public.current_app_role() = 'platform_admin'
  or exists (
    select 1 from public.patients p
    where p.id = patient_id
      and p.clinic_id = public.current_clinic_id()
      and (
        public.current_app_role() = 'owner'
        or (public.current_app_role() = 'employee' and uploaded_by = auth.uid())
      )
  )
);

grant select, insert, update, delete on public.patient_xrays to authenticated;

-- Private medical image bucket. Never make this public.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('patient-xrays', 'patient-xrays', false, 10485760, array['image/png'])
on conflict (id) do update set
  public = false,
  file_size_limit = 10485760,
  allowed_mime_types = array['image/png'];

-- Read only when the first folder is a patient the current staff user is authorized to access.
drop policy if exists "patient_xrays_storage_select" on storage.objects;
create policy "patient_xrays_storage_select" on storage.objects
for select to authenticated
using (
  bucket_id = 'patient-xrays'
  and (
    public.current_app_role() = 'platform_admin'
    or (
      public.current_app_role() in ('owner','employee')
      and exists (
        select 1 from public.patients p
        where p.id::text = (storage.foldername(name))[1]
          and p.clinic_id = public.current_clinic_id()
      )
    )
  )
);

-- Upload path must be: {patient_id}/{uuid}.png and the patient must belong to the staff user's clinic.
drop policy if exists "patient_xrays_storage_insert" on storage.objects;
create policy "patient_xrays_storage_insert" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'patient-xrays'
  and lower(right(name, 4)) = '.png'
  and cardinality(storage.foldername(name)) = 1
  and (
    public.current_app_role() = 'platform_admin'
    or (
      public.current_app_role() in ('owner','employee')
      and exists (
        select 1 from public.patients p
        where p.id::text = (storage.foldername(name))[1]
          and p.clinic_id = public.current_clinic_id()
      )
    )
  )
);

-- Deleting a Storage object follows the same owner/uploader rule as metadata.
drop policy if exists "patient_xrays_storage_delete" on storage.objects;
create policy "patient_xrays_storage_delete" on storage.objects
for delete to authenticated
using (
  bucket_id = 'patient-xrays'
  and (
    public.current_app_role() = 'platform_admin'
    or exists (
      select 1
      from public.patient_xrays x
      join public.patients p on p.id = x.patient_id
      where x.storage_path = name
        and p.clinic_id = public.current_clinic_id()
        and (
          public.current_app_role() = 'owner'
          or (public.current_app_role() = 'employee' and x.uploaded_by = auth.uid())
        )
    )
  )
);

-- Realtime patient image history.
do $$
begin
  begin
    execute 'alter publication supabase_realtime add table public.patient_xrays';
  exception when duplicate_object then null;
  end;
end $$;

alter table public.patient_xrays replica identity full;
