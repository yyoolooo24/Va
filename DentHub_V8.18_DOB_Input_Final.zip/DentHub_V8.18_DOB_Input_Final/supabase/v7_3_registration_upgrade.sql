-- ClinicOS V7.3 — separate public registration types
-- Safe migration for an existing V7.2/V7.2.3 database.
-- Adds Supplier as an account role and a private supplier profile table.
-- Does NOT delete clinics, patients, appointments, payments, posts, or users.

alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles
  add constraint profiles_role_check
  check (role in ('platform_admin','owner','employee','client','supplier'));

create table if not exists public.supplier_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  company_name text not null,
  registration_no text,
  contact_name text,
  city text,
  website text,
  created_at timestamptz not null default now()
);

alter table public.supplier_profiles enable row level security;

drop policy if exists "supplier_profile_select" on public.supplier_profiles;
create policy "supplier_profile_select" on public.supplier_profiles
for select to authenticated
using (user_id = auth.uid() or public.current_app_role() = 'platform_admin');

drop policy if exists "supplier_profile_update_self" on public.supplier_profiles;
create policy "supplier_profile_update_self" on public.supplier_profiles
for update to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());
