-- ClinicOS V7.1 — staff access lifecycle upgrade
-- Safe migration for an existing V7 database. It does not delete clinic/patient/history data.

alter table public.profiles
  add column if not exists active boolean not null default true,
  add column if not exists deactivated_at timestamptz,
  add column if not exists deactivated_by uuid references auth.users(id) on delete set null;

create index if not exists profiles_clinic_active_idx on public.profiles(clinic_id, active);

-- Existing users stay active.
update public.profiles set active = true where active is null;


create or replace function public.current_app_role()
returns text
language sql
stable
security definer
set search_path = public
as $$ select role from public.profiles where id = auth.uid() and active = true $$;

create or replace function public.current_clinic_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$ select clinic_id from public.profiles where id = auth.uid() and active = true $$;

-- Users may update their own harmless profile preferences, but cannot re-enable themselves,
-- change clinic, or promote their own role from the browser.
drop policy if exists "profiles_update_self" on public.profiles;
create policy "profiles_update_self" on public.profiles for update to authenticated
using (id = auth.uid() and active = true)
with check (
  id = auth.uid()
  and active = true
  and role = public.current_app_role()
  and clinic_id is not distinct from public.current_clinic_id()
);
