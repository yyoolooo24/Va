-- DentHub V8.5.3 — permissions, media upload compatibility, role metadata
-- Safe additive migration. Run after v8_5_final.sql.

create extension if not exists pgcrypto;

-- Employee position + module access controlled by the clinic owner.
alter table public.profiles add column if not exists specialty text;
alter table public.profiles add column if not exists allowed_modules text[] not null default '{}'::text[];

create index if not exists idx_profiles_clinic_role_specialty
  on public.profiles(clinic_id, role, specialty);

-- Medical image module now accepts common image formats supported by the UI.
alter table public.patient_xrays drop constraint if exists patient_xrays_png_path;
alter table public.patient_xrays drop constraint if exists patient_xrays_png_mime;
alter table public.patient_xrays drop constraint if exists patient_xrays_image_path;
alter table public.patient_xrays drop constraint if exists patient_xrays_image_mime;

alter table public.patient_xrays
  add constraint patient_xrays_image_path check (
    lower(storage_path) ~ ('^' || patient_id::text || '/[^/]+\.(png|jpg|jpeg|webp)$')
  );
alter table public.patient_xrays
  add constraint patient_xrays_image_mime check (
    mime_type is null or mime_type in ('image/png','image/jpeg','image/jpg','image/webp')
  );

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('patient-xrays', 'patient-xrays', false, 10485760,
  array['image/png','image/jpeg','image/jpg','image/webp'])
on conflict (id) do update set
  public = false,
  file_size_limit = 10485760,
  allowed_mime_types = array['image/png','image/jpeg','image/jpg','image/webp'];

-- Replace older PNG-only upload policy.
drop policy if exists "patient_xrays_storage_insert" on storage.objects;
create policy "patient_xrays_storage_insert" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'patient-xrays'
  and lower(name) ~ '\.(png|jpg|jpeg|webp)$'
  and cardinality(storage.foldername(name)) = 1
  and (
    public.current_app_role() = 'platform_admin'
    or (
      public.current_app_role() in ('owner','employee')
      and exists (
        select 1 from public.patients p
        where p.id::text = (storage.foldername(name))[1]
          and p.clinic_id = public.current_clinic_id()
      )
    )
  )
);

-- Owner can always see/update all staff profile permission metadata in own clinic.
drop policy if exists "profiles_owner_update_staff" on public.profiles;
create policy "profiles_owner_update_staff" on public.profiles
for update to authenticated
using (
  public.current_app_role() = 'platform_admin'
  or (
    public.current_app_role() = 'owner'
    and clinic_id = public.current_clinic_id()
  )
)
with check (
  public.current_app_role() = 'platform_admin'
  or (
    public.current_app_role() = 'owner'
    and clinic_id = public.current_clinic_id()
  )
);

-- Keep profile permission changes live across open sessions.
do $$
begin
  begin execute 'alter publication supabase_realtime add table public.profiles'; exception when duplicate_object then null; end;
end $$;

-- Dental catalog headings are categories, not bookable services.
alter table public.services add column if not exists is_category boolean not null default false;

update public.services
set is_category = true, active = true
where upper(trim(name)) in (
  'БАЙНГЫН ШҮДНИЙ ХОЛБООСЫН ЭМЧИЛГЭЭ',
  'ШҮДНИЙ ЦӨГЦ СЭРГЭЭХ ЭМЧИЛГЭЭ',
  'БАЙНГЫН ШҮДНИЙ ЦООРЛЫН ЭМЧИЛГЭЭ',
  'ХИЙМЭЛ ШҮД',
  'ТУЛГУУРЫН ЭМЧИЛГЭЭ',
  'АВАГДДАГГҮЙ ШҮДЭЛБЭР',
  'УРЬДЧИЛАН СЭРГИЙЛЭЛТ',
  'СҮҮН ШҮДНИЙ ЗӨӨЛЦИЙН ЭМЧИЛГЭЭ',
  'СҮҮН ШҮДНИЙ ЦООРЛЫН ЭМЧИЛГЭЭ',
  'СҮҮН ШҮДНИЙ ХОЛБООСЫН ЭМЧИЛГЭЭ',
  'БАЙНГЫН ШҮДНИЙ ЗӨӨЛЦИЙН ЭМЧИЛГЭЭ',
  'ШҮД АРЧИЛГААНЫ ЗӨВЛӨГӨӨ',
  'ГАЖИГ ЗАСЛЫН ЭМЧИЛГЭЭ',
  'МЭС ЗАСЛЫН ЭМЧИЛГЭЭ'
);
