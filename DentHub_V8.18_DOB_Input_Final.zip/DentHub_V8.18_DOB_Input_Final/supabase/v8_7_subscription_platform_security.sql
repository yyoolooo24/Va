-- DentHub V8.7 — Subscription, Platform Control & Security
-- Run AFTER v8_6_26_consent_branding_print.sql.
-- Additive/idempotent. Existing clinics are backfilled as ACTIVE with all current modules.

begin;

create extension if not exists pgcrypto;

-- -----------------------------------------------------------------------------
-- 1) Clinic subscription / entitlement state
-- -----------------------------------------------------------------------------
alter table public.clinics drop constraint if exists clinics_status_check;
alter table public.clinics
  add constraint clinics_status_check check (status in ('pending','trial','active','past_due','suspended','cancelled','archived'));

alter table public.clinics add column if not exists enabled_modules text[] not null default '{}'::text[];
alter table public.clinics add column if not exists subscription_started_at timestamptz;
alter table public.clinics add column if not exists subscription_ends_at timestamptz;
alter table public.clinics add column if not exists trial_ends_at timestamptz;
alter table public.clinics add column if not exists grace_ends_at timestamptz;
alter table public.clinics add column if not exists employee_limit integer not null default 25;
alter table public.clinics add column if not exists subscription_price numeric(14,2);
alter table public.clinics add column if not exists billing_cycle text not null default 'monthly';
alter table public.clinics add column if not exists platform_notes text;
alter table public.clinics add column if not exists approved_at timestamptz;
alter table public.clinics add column if not exists approved_by uuid references public.profiles(id) on delete set null;
alter table public.clinics add column if not exists suspended_at timestamptz;
alter table public.clinics add column if not exists archived_at timestamptz;
alter table public.clinics add column if not exists updated_at timestamptz not null default now();

-- Existing production clinics keep everything they already had.
update public.clinics
set enabled_modules = array[
  'appointments','consent_forms','patients','patient_cards','treatment_history','treatments','payments','erp',
  'sales','sales_returns','cashbook','price_lists','services','inventory','stock_movements','suppliers','procurement',
  'purchase_orders','lab_orders','crm','insurance','invoices','receivables','expenses','finance','staff','shifts',
  'assets','branches','internal_procedures','health_department','questionnaire','contracts','reports','chat'
]::text[],
    approved_at = coalesce(approved_at, created_at),
    subscription_started_at = coalesce(subscription_started_at, created_at)
where cardinality(coalesce(enabled_modules,'{}'::text[])) = 0
  and status in ('active','trial');

create index if not exists clinics_status_subscription_idx
  on public.clinics(status, subscription_ends_at, trial_ends_at);

-- Central tenant gate. Existing RLS policies already call current_clinic_id(), so
-- pending/suspended/expired clinics lose tenant data access without relying on UI hiding.
create or replace function public.current_clinic_id()
returns uuid
language sql
stable
security definer
set search_path=public
as $$
  select p.clinic_id
  from public.profiles p
  join public.clinics c on c.id=p.clinic_id
  where p.id=auth.uid() and p.active=true
    and c.status in ('active','trial')
    and (c.subscription_ends_at is null or c.subscription_ends_at >= now() or (c.grace_ends_at is not null and c.grace_ends_at >= now()))
    and (c.status <> 'trial' or c.trial_ends_at is null or c.trial_ends_at >= now())
$$;
revoke all on function public.current_clinic_id() from public;
grant execute on function public.current_clinic_id() to authenticated;

-- -----------------------------------------------------------------------------
-- 2) Explicit staff type. Security must not depend on free-form specialty text.
-- -----------------------------------------------------------------------------
alter table public.profiles add column if not exists staff_type text;
alter table public.profiles drop constraint if exists profiles_staff_type_check;
alter table public.profiles add constraint profiles_staff_type_check
  check (staff_type is null or staff_type in ('doctor','nurse','reception','cashier','finance','inventory','manager','other'));

update public.profiles
set staff_type = case
  when lower(coalesce(specialty,'')) ~ '(эмч|doctor|dentist|orthodont)' then 'doctor'
  when lower(coalesce(specialty,'')) ~ '(сувила|nurse)' then 'nurse'
  when lower(coalesce(specialty,'')) ~ '(ресеп|reception)' then 'reception'
  when lower(coalesce(specialty,'')) ~ '(касс|cashier)' then 'cashier'
  when lower(coalesce(specialty,'')) ~ '(санхүү|finance|нягт)' then 'finance'
  else 'other'
end
where role='employee' and staff_type is null;

-- -----------------------------------------------------------------------------
-- 3) Public registration throttling (service-role only; no client policies)
-- -----------------------------------------------------------------------------
create table if not exists public.registration_attempts (
  id bigint generated by default as identity primary key,
  fingerprint text not null,
  account_type text,
  created_at timestamptz not null default now()
);
create index if not exists registration_attempts_fingerprint_idx on public.registration_attempts(fingerprint, created_at desc);
alter table public.registration_attempts enable row level security;

-- -----------------------------------------------------------------------------
-- 4) Module requests and immutable-ish platform audit log
-- -----------------------------------------------------------------------------
create table if not exists public.clinic_module_requests (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  requested_by uuid references public.profiles(id) on delete set null,
  modules text[] not null default '{}'::text[],
  note text,
  status text not null default 'pending' check(status in ('pending','approved','rejected','cancelled')),
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists clinic_module_requests_status_idx on public.clinic_module_requests(status, created_at desc);
create index if not exists clinic_module_requests_clinic_idx on public.clinic_module_requests(clinic_id, created_at desc);
alter table public.clinic_module_requests enable row level security;

drop policy if exists "clinic_module_requests_select" on public.clinic_module_requests;
create policy "clinic_module_requests_select" on public.clinic_module_requests for select to authenticated
using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
);
drop policy if exists "clinic_module_requests_insert" on public.clinic_module_requests;
create policy "clinic_module_requests_insert" on public.clinic_module_requests for insert to authenticated
with check (
  clinic_id=public.current_clinic_id() and requested_by=auth.uid() and public.current_app_role()='owner'
);

create table if not exists public.platform_audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  clinic_id uuid references public.clinics(id) on delete set null,
  action text not null,
  target_type text,
  target_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists platform_audit_log_created_idx on public.platform_audit_log(created_at desc);
create index if not exists platform_audit_log_clinic_idx on public.platform_audit_log(clinic_id, created_at desc);
alter table public.platform_audit_log enable row level security;
drop policy if exists "platform_audit_select" on public.platform_audit_log;
create policy "platform_audit_select" on public.platform_audit_log for select to authenticated
using (public.current_app_role()='platform_admin');

-- -----------------------------------------------------------------------------
-- 5) Central subscription helpers
-- -----------------------------------------------------------------------------
create or replace function public.denthub_clinic_access_active(p_clinic uuid default public.current_clinic_id())
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1 from public.clinics c
    where c.id=p_clinic
      and c.status in ('active','trial')
      and (c.subscription_ends_at is null or c.subscription_ends_at >= now() or (c.grace_ends_at is not null and c.grace_ends_at >= now()))
      and (c.status <> 'trial' or c.trial_ends_at is null or c.trial_ends_at >= now())
  )
$$;

create or replace function public.denthub_clinic_has_module(p_module text, p_clinic uuid default public.current_clinic_id())
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1 from public.clinics c
    where c.id=p_clinic
      and public.denthub_clinic_access_active(c.id)
      and p_module = any(coalesce(c.enabled_modules,'{}'::text[]))
  )
$$;

create or replace function public.denthub_user_has_module(p_module text)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1 from public.profiles p
    where p.id=auth.uid() and coalesce(p.active,true)=true
      and (
        p.role='platform_admin'
        or (
          p.clinic_id is not null
          and public.denthub_clinic_has_module(p_module,p.clinic_id)
          and (
            p.role='owner'
            or (p.role='employee' and p_module=any(coalesce(p.allowed_modules,'{}'::text[])))
          )
        )
      )
  )
$$;

revoke all on function public.denthub_clinic_access_active(uuid) from public;
revoke all on function public.denthub_clinic_has_module(text,uuid) from public;
revoke all on function public.denthub_user_has_module(text) from public;
grant execute on function public.denthub_clinic_access_active(uuid) to authenticated;
grant execute on function public.denthub_clinic_has_module(text,uuid) to authenticated;
grant execute on function public.denthub_user_has_module(text) to authenticated;

-- Generic ERP permission helper now also respects paid clinic entitlement.
create or replace function public.denthub_current_user_has_erp_module(p_module text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.denthub_user_has_module(p_module)
$$;

-- -----------------------------------------------------------------------------
-- 6) Doctor privacy at the database layer
-- -----------------------------------------------------------------------------
create or replace function public.denthub_current_staff_type()
returns text
language sql
stable
security definer
set search_path=public
as $$ select staff_type from public.profiles where id=auth.uid() and active=true $$;

grant execute on function public.denthub_current_staff_type() to authenticated;

create or replace function public.denthub_doctor_has_patient(p_patient uuid)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(select 1 from public.appointments a where a.patient_id=p_patient and a.doctor_id=auth.uid())
      or exists(select 1 from public.encounters e where e.patient_id=p_patient and e.doctor_id=auth.uid() and e.deleted_at is null)
$$;
grant execute on function public.denthub_doctor_has_patient(uuid) to authenticated;

-- Patient reads: doctor only sees patients tied to that doctor; owner/reception/etc.
-- still require the Patients module. Patient login sees only its own linked patient.
drop policy if exists "patients_staff_select" on public.patients;
create policy "patients_staff_select" on public.patients for select to authenticated using (
  public.current_app_role()='platform_admin'
  or user_id=auth.uid()
  or (
    clinic_id=public.current_clinic_id()
    and public.denthub_user_has_module('patients')
    and (
      public.current_app_role()='owner'
      or (
        public.current_app_role()='employee'
        and (
          public.denthub_current_staff_type() <> 'doctor'
          or public.denthub_doctor_has_patient(patients.id)
        )
      )
    )
  )
);

drop policy if exists "patients_staff_write" on public.patients;
create policy "patients_staff_write" on public.patients for all to authenticated
using (
  clinic_id=public.current_clinic_id() and public.denthub_user_has_module('patients')
  and (
    public.current_app_role()='owner'
    or (public.current_app_role()='employee' and public.denthub_current_staff_type()<>'doctor')
    or (public.current_app_role()='employee' and public.denthub_current_staff_type()='doctor' and public.denthub_doctor_has_patient(patients.id))
  )
)
with check (clinic_id=public.current_clinic_id() and public.denthub_user_has_module('patients'));

drop policy if exists "appointments_select" on public.appointments;
create policy "appointments_select" on public.appointments for select to authenticated using (
  public.current_app_role()='platform_admin'
  or exists(select 1 from public.patients p where p.id=patient_id and p.user_id=auth.uid())
  or (
    clinic_id=public.current_clinic_id() and public.denthub_user_has_module('appointments')
    and (
      public.current_app_role()='owner'
      or (public.current_app_role()='employee' and (public.denthub_current_staff_type()<>'doctor' or doctor_id=auth.uid()))
    )
  )
);

drop policy if exists "appointments_staff_write" on public.appointments;
create policy "appointments_staff_write" on public.appointments for all to authenticated
using (
  clinic_id=public.current_clinic_id() and public.denthub_user_has_module('appointments')
  and (public.current_app_role()='owner' or (public.current_app_role()='employee' and (public.denthub_current_staff_type()<>'doctor' or doctor_id=auth.uid())))
)
with check (
  clinic_id=public.current_clinic_id() and public.denthub_user_has_module('appointments')
  and (public.current_app_role()='owner' or (public.current_app_role()='employee' and (public.denthub_current_staff_type()<>'doctor' or doctor_id=auth.uid())))
);

drop policy if exists "encounters_select" on public.encounters;
create policy "encounters_select" on public.encounters for select to authenticated using (
  public.current_app_role()='platform_admin'
  or exists(select 1 from public.patients p where p.id=patient_id and p.user_id=auth.uid())
  or (
    clinic_id=public.current_clinic_id() and public.denthub_user_has_module('treatments')
    and (
      public.current_app_role()='owner'
      or (public.current_app_role()='employee' and (public.denthub_current_staff_type()<>'doctor' or doctor_id=auth.uid()))
    )
  )
);

drop policy if exists "encounters_staff_write" on public.encounters;
create policy "encounters_staff_write" on public.encounters for all to authenticated
using (
  clinic_id=public.current_clinic_id() and public.denthub_user_has_module('treatments')
  and (public.current_app_role()='owner' or (public.current_app_role()='employee' and (public.denthub_current_staff_type()<>'doctor' or doctor_id=auth.uid())))
)
with check (
  clinic_id=public.current_clinic_id() and public.denthub_user_has_module('treatments')
  and (public.current_app_role()='owner' or (public.current_app_role()='employee' and (public.denthub_current_staff_type()<>'doctor' or doctor_id=auth.uid())))
);

-- Services + inventory reads now require clinic entitlement.
drop policy if exists "services_select" on public.services;
create policy "services_select" on public.services for select to authenticated using (
  public.current_app_role()='platform_admin' or (clinic_id=public.current_clinic_id() and public.denthub_clinic_has_module('services'))
);
drop policy if exists "inventory_select" on public.inventory_items;
create policy "inventory_select" on public.inventory_items for select to authenticated using (
  public.current_app_role()='platform_admin' or (clinic_id=public.current_clinic_id() and public.denthub_user_has_module('inventory'))
);

-- Additional module-level RLS. The sidebar is never the security boundary.
drop policy if exists "services_owner_write" on public.services;
create policy "services_owner_write" on public.services for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('services'))
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('services'));

drop policy if exists "inventory_owner_write" on public.inventory_items;
create policy "inventory_owner_write" on public.inventory_items for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('inventory'))
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('inventory'));

drop policy if exists "payment_methods_select" on public.payment_methods;
create policy "payment_methods_select" on public.payment_methods for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.denthub_user_has_module('payments'))
);
drop policy if exists "payment_methods_write" on public.payment_methods;
create policy "payment_methods_write" on public.payment_methods for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('payments'))
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('payments'));

drop policy if exists "finance_select" on public.finance_transactions;
create policy "finance_select" on public.finance_transactions for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (
    clinic_id=public.current_clinic_id()
    and (public.denthub_user_has_module('payments') or public.denthub_user_has_module('cashbook') or public.denthub_user_has_module('finance'))
  )
);
drop policy if exists "finance_owner_write" on public.finance_transactions;
create policy "finance_owner_write" on public.finance_transactions for all to authenticated
using (
  clinic_id=public.current_clinic_id()
  and (public.denthub_user_has_module('payments') or public.denthub_user_has_module('cashbook') or public.denthub_user_has_module('finance'))
)
with check (
  clinic_id=public.current_clinic_id()
  and (public.denthub_user_has_module('payments') or public.denthub_user_has_module('cashbook') or public.denthub_user_has_module('finance'))
);

drop policy if exists "employee_documents_select" on public.employee_documents;
create policy "employee_documents_select" on public.employee_documents for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (
    clinic_id=public.current_clinic_id() and public.denthub_user_has_module('staff')
    and (public.current_app_role()='owner' or (public.current_app_role()='employee' and employee_id=auth.uid()))
  )
);
drop policy if exists "employee_documents_insert" on public.employee_documents;
create policy "employee_documents_insert" on public.employee_documents for insert to authenticated with check (
  clinic_id=public.current_clinic_id() and public.denthub_user_has_module('staff')
  and (public.current_app_role()='owner' or (public.current_app_role()='employee' and employee_id=auth.uid()))
);
drop policy if exists "employee_documents_update" on public.employee_documents;
create policy "employee_documents_update" on public.employee_documents for update to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('staff'))
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('staff'));
drop policy if exists "employee_documents_delete" on public.employee_documents;
create policy "employee_documents_delete" on public.employee_documents for delete to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('staff'));

drop policy if exists "internal_procedures_select" on public.internal_procedures;
create policy "internal_procedures_select" on public.internal_procedures for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.denthub_user_has_module('internal_procedures'))
);
drop policy if exists "internal_procedures_owner_write" on public.internal_procedures;
create policy "internal_procedures_owner_write" on public.internal_procedures for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('internal_procedures'))
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('internal_procedures'));

drop policy if exists "clinic_contracts_select" on public.clinic_contracts;
create policy "clinic_contracts_select" on public.clinic_contracts for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.denthub_user_has_module('contracts'))
);
drop policy if exists "clinic_contracts_owner_write" on public.clinic_contracts;
create policy "clinic_contracts_owner_write" on public.clinic_contracts for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('contracts'))
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('contracts'));

drop policy if exists "health_department_categories_select" on public.health_department_categories;
create policy "health_department_categories_select" on public.health_department_categories for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.denthub_user_has_module('health_department'))
);
drop policy if exists "health_department_categories_owner_write" on public.health_department_categories;
create policy "health_department_categories_owner_write" on public.health_department_categories for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('health_department'))
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('health_department'));

drop policy if exists "health_department_records_select" on public.health_department_records;
create policy "health_department_records_select" on public.health_department_records for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.denthub_user_has_module('health_department'))
);
drop policy if exists "health_department_records_owner_write" on public.health_department_records;
create policy "health_department_records_owner_write" on public.health_department_records for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('health_department'))
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('health_department'));

drop policy if exists "finance_obligations_select" on public.finance_obligations;
create policy "finance_obligations_select" on public.finance_obligations for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (clinic_id=public.current_clinic_id() and public.denthub_user_has_module('finance'))
);
drop policy if exists "finance_obligations_owner_write" on public.finance_obligations;
create policy "finance_obligations_owner_write" on public.finance_obligations for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('finance'))
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner' and public.denthub_user_has_module('finance'));

-- Consent access is both clinic-scoped and module-scoped. Doctors still need a
-- legitimate doctor-patient relationship for patient-linked consent rows.
drop policy if exists "consent_staff_select" on public.patient_consent_forms;
create policy "consent_staff_select" on public.patient_consent_forms for select to authenticated using (
  public.current_app_role()='platform_admin'
  or (
    clinic_id=public.current_clinic_id() and public.denthub_user_has_module('consent_forms')
    and (
      public.current_app_role()='owner'
      or (public.current_app_role()='employee' and (public.denthub_current_staff_type()<>'doctor' or public.denthub_doctor_has_patient(patient_id)))
    )
  )
);
drop policy if exists "consent_staff_insert" on public.patient_consent_forms;
create policy "consent_staff_insert" on public.patient_consent_forms for insert to authenticated with check (
  clinic_id=public.current_clinic_id() and public.denthub_user_has_module('consent_forms')
  and (
    public.current_app_role()='owner'
    or (public.current_app_role()='employee' and (public.denthub_current_staff_type()<>'doctor' or public.denthub_doctor_has_patient(patient_id)))
  )
);
drop policy if exists "consent_staff_update" on public.patient_consent_forms;
create policy "consent_staff_update" on public.patient_consent_forms for update to authenticated
using (
  clinic_id=public.current_clinic_id() and public.denthub_user_has_module('consent_forms')
  and (
    public.current_app_role()='owner'
    or (public.current_app_role()='employee' and (public.denthub_current_staff_type()<>'doctor' or public.denthub_doctor_has_patient(patient_id)))
  )
)
with check (clinic_id=public.current_clinic_id() and public.denthub_user_has_module('consent_forms'));

-- -----------------------------------------------------------------------------
-- 7) Cashier enforcement on atomic payment RPC
-- -----------------------------------------------------------------------------
create or replace function public.denthub_record_encounter_payment_v2(
  p_encounter_id uuid,
  p_amount numeric,
  p_payment_method_id uuid,
  p_note text default null,
  p_request_ebarimt boolean default false,
  p_ebarimt_receiver_type text default null,
  p_ebarimt_receiver text default null
)
returns table(payment_id uuid, finance_transaction_id uuid, paid_amount numeric, remaining_amount numeric, billing_status text)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_clinic uuid; v_patient uuid; v_total numeric(14,2); v_method_name text;
  v_finance_id uuid; v_payment_id uuid; v_paid numeric(14,2); v_status text; v_description text;
begin
  if auth.uid() is null or not public.denthub_user_has_module('payments') then raise exception 'FORBIDDEN'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'PAYMENT_AMOUNT_INVALID'; end if;

  select e.clinic_id,e.patient_id,coalesce(e.total_amount,0) into v_clinic,v_patient,v_total
  from public.encounters e where e.id=p_encounter_id and e.deleted_at is null for update;
  if v_clinic is null or v_clinic is distinct from public.current_clinic_id() then raise exception 'ENCOUNTER_NOT_FOUND'; end if;

  select pm.name into v_method_name from public.payment_methods pm
  where pm.id=p_payment_method_id and pm.clinic_id=v_clinic and pm.active=true;
  if v_method_name is null then raise exception 'PAYMENT_METHOD_NOT_FOUND'; end if;

  select coalesce(sum(ep.amount),0)::numeric(14,2) into v_paid from public.encounter_payments ep where ep.encounter_id=p_encounter_id;
  if v_total > 0 and p_amount > greatest(v_total-v_paid,0) + 0.009 then raise exception 'PAYMENT_EXCEEDS_REMAINING'; end if;
  select coalesce(p.full_name,'Өвчтөн')||' · Үзлэг, эмчилгээ' into v_description from public.patients p where p.id=v_patient;

  insert into public.finance_transactions(clinic_id,created_by,kind,description,amount,payment_method,patient_id,encounter_id,request_ebarimt,ebarimt_receiver_type,ebarimt_receiver)
  values(v_clinic,auth.uid(),'income',coalesce(v_description,'Үзлэг, эмчилгээ'),round(p_amount)::bigint,v_method_name,v_patient,p_encounter_id,
         coalesce(p_request_ebarimt,false),nullif(btrim(coalesce(p_ebarimt_receiver_type,'')),''),nullif(btrim(coalesce(p_ebarimt_receiver,'')),''))
  returning id into v_finance_id;

  insert into public.encounter_payments(clinic_id,encounter_id,patient_id,amount,payment_method_id,payment_method_name,note,finance_transaction_id,created_by)
  values(v_clinic,p_encounter_id,v_patient,p_amount,p_payment_method_id,v_method_name,nullif(btrim(coalesce(p_note,'')),''),v_finance_id,auth.uid())
  returning id into v_payment_id;

  select coalesce(sum(ep.amount),0)::numeric(14,2) into v_paid from public.encounter_payments ep where ep.encounter_id=p_encounter_id;
  v_status := case when v_total<=0 then 'no_charge' when v_paid>=v_total then 'paid' when v_paid>0 then 'partial' else 'unpaid' end;
  update public.encounters set paid_amount=v_paid,billing_status=v_status where id=p_encounter_id;
  return query select v_payment_id,v_finance_id,v_paid,greatest(v_total-v_paid,0)::numeric(14,2),v_status;
end $$;
revoke all on function public.denthub_record_encounter_payment_v2(uuid,numeric,uuid,text,boolean,text,text) from public;
grant execute on function public.denthub_record_encounter_payment_v2(uuid,numeric,uuid,text,boolean,text,text) to authenticated;

-- Clinic-credit handoff is also atomic: create Receivable + mark encounter in one transaction.
create or replace function public.denthub_transfer_encounter_to_receivable(
  p_encounter_id uuid,
  p_amount numeric,
  p_due_date date default null,
  p_note text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_clinic uuid; v_patient uuid; v_name text; v_code text; v_id uuid;
begin
  if auth.uid() is null or not public.denthub_user_has_module('payments') or not public.denthub_clinic_has_module('receivables') then raise exception 'FORBIDDEN'; end if;
  if p_amount is null or p_amount<=0 then raise exception 'PAYMENT_AMOUNT_INVALID'; end if;
  select e.clinic_id,e.patient_id,p.full_name,p.patient_code into v_clinic,v_patient,v_name,v_code
  from public.encounters e join public.patients p on p.id=e.patient_id
  where e.id=p_encounter_id and e.deleted_at is null and e.credit_transferred_at is null
  for update of e;
  if v_clinic is null or v_clinic is distinct from public.current_clinic_id() then raise exception 'ENCOUNTER_NOT_FOUND'; end if;

  insert into public.erp_records(clinic_id,module_key,title,subtitle,meta,status,payload,created_by)
  values(
    v_clinic,'receivables',v_name,concat_ws(' · ',nullif(v_code,''),'Эмнэлгийн зээл'),
    '₮'||round(p_amount)::bigint::text||case when p_due_date is not null then ' · '||p_due_date::text else '' end,
    'Нээлттэй',
    jsonb_build_object('patient',v_name,'patientId',v_patient,'patientCode',coalesce(v_code,''),'amount',round(p_amount)::text,'due',coalesce(p_due_date::text,''),'status','Нээлттэй','source','cashier-clinic-credit','encounterId',p_encounter_id,'note',coalesce(p_note,'')),
    auth.uid()
  ) returning id into v_id;
  update public.encounters set credit_transferred_at=now() where id=p_encounter_id;
  return v_id;
end $$;
revoke all on function public.denthub_transfer_encounter_to_receivable(uuid,numeric,date,text) from public;
grant execute on function public.denthub_transfer_encounter_to_receivable(uuid,numeric,date,text) to authenticated;

-- -----------------------------------------------------------------------------
-- 8) Path-aware private document storage
-- employees/<employee-id>/... is private to that employee + owner.
-- procedures are readable to clinic staff; contracts/regulatory data require modules.
-- owners can manage every clinic document.
-- -----------------------------------------------------------------------------
drop policy if exists "clinic_documents_select" on storage.objects;
create policy "clinic_documents_select" on storage.objects for select to authenticated using (
  bucket_id='clinic-documents' and (
    public.current_app_role()='platform_admin'
    or (
      (storage.foldername(name))[1]=public.current_clinic_id()::text
      and public.denthub_clinic_access_active()
      and (
        ((storage.foldername(name))[2]='employees' and public.denthub_user_has_module('staff')
          and (public.current_app_role()='owner' or (public.current_app_role()='employee' and (storage.foldername(name))[3]=auth.uid()::text))
        )
        or ((storage.foldername(name))[2]='procedures' and public.denthub_user_has_module('internal_procedures'))
        or ((storage.foldername(name))[2]='contracts' and public.denthub_user_has_module('contracts'))
        or ((storage.foldername(name))[2]='health-department' and public.denthub_user_has_module('health_department'))
      )
    )
  )
);

drop policy if exists "clinic_documents_insert" on storage.objects;
create policy "clinic_documents_insert" on storage.objects for insert to authenticated with check (
  bucket_id='clinic-documents'
  and (storage.foldername(name))[1]=public.current_clinic_id()::text
  and public.denthub_clinic_access_active()
  and (
    ((storage.foldername(name))[2]='employees' and public.denthub_user_has_module('staff')
      and (public.current_app_role()='owner' or (public.current_app_role()='employee' and (storage.foldername(name))[3]=auth.uid()::text))
    )
    or ((storage.foldername(name))[2]='procedures' and public.current_app_role()='owner' and public.denthub_user_has_module('internal_procedures'))
    or ((storage.foldername(name))[2]='contracts' and public.current_app_role()='owner' and public.denthub_user_has_module('contracts'))
    or ((storage.foldername(name))[2]='health-department' and public.current_app_role()='owner' and public.denthub_user_has_module('health_department'))
  )
);

drop policy if exists "clinic_documents_update" on storage.objects;
create policy "clinic_documents_update" on storage.objects for update to authenticated
using (
  bucket_id='clinic-documents' and (storage.foldername(name))[1]=public.current_clinic_id()::text and public.current_app_role()='owner'
  and (
    ((storage.foldername(name))[2]='employees' and public.denthub_user_has_module('staff'))
    or ((storage.foldername(name))[2]='procedures' and public.denthub_user_has_module('internal_procedures'))
    or ((storage.foldername(name))[2]='contracts' and public.denthub_user_has_module('contracts'))
    or ((storage.foldername(name))[2]='health-department' and public.denthub_user_has_module('health_department'))
  )
)
with check (
  bucket_id='clinic-documents' and (storage.foldername(name))[1]=public.current_clinic_id()::text and public.current_app_role()='owner'
  and (
    ((storage.foldername(name))[2]='employees' and public.denthub_user_has_module('staff'))
    or ((storage.foldername(name))[2]='procedures' and public.denthub_user_has_module('internal_procedures'))
    or ((storage.foldername(name))[2]='contracts' and public.denthub_user_has_module('contracts'))
    or ((storage.foldername(name))[2]='health-department' and public.denthub_user_has_module('health_department'))
  )
);

drop policy if exists "clinic_documents_delete" on storage.objects;
create policy "clinic_documents_delete" on storage.objects for delete to authenticated using (
  bucket_id='clinic-documents' and (storage.foldername(name))[1]=public.current_clinic_id()::text and public.current_app_role()='owner'
  and (
    ((storage.foldername(name))[2]='employees' and public.denthub_user_has_module('staff'))
    or ((storage.foldername(name))[2]='procedures' and public.denthub_user_has_module('internal_procedures'))
    or ((storage.foldername(name))[2]='contracts' and public.denthub_user_has_module('contracts'))
    or ((storage.foldername(name))[2]='health-department' and public.denthub_user_has_module('health_department'))
  )
);

-- -----------------------------------------------------------------------------
-- 9) RLS for clinic status itself remains viewable to own clinic; writes stay server/admin.
-- -----------------------------------------------------------------------------
drop policy if exists "clinic_select" on public.clinics;
create policy "clinic_select" on public.clinics for select to authenticated using (
  public.current_app_role()='platform_admin' or id=public.current_clinic_id()
);

commit;
