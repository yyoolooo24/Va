-- DentHub V8.6.25
-- Persistent treatment-history hiding + audit metadata for completed appointment fallback rows.
-- Run AFTER V8.6.24.

begin;

alter table public.appointments
  add column if not exists history_hidden_at timestamptz,
  add column if not exists history_hidden_by uuid references public.profiles(id) on delete set null;

create index if not exists appointments_clinic_history_visible_idx
  on public.appointments (clinic_id, starts_at desc)
  where history_hidden_at is null;

comment on column public.appointments.history_hidden_at is
  'When set, this completed appointment is intentionally hidden from treatment/visit history while operational/audit data remains preserved.';
comment on column public.appointments.history_hidden_by is
  'Profile that removed the appointment fallback row from treatment/visit history.';

commit;
