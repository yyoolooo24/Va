import fs from 'node:fs';
import path from 'node:path';
import { createClient } from '@supabase/supabase-js';

const envPath=path.join(process.cwd(),'.env.local');
if(fs.existsSync(envPath)){
  for(const line of fs.readFileSync(envPath,'utf8').split(/\r?\n/)){
    const m=line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*)\s*$/); if(!m||m[1] in process.env)continue;
    let value=m[2].trim(); if((value.startsWith('"')&&value.endsWith('"'))||(value.startsWith("'")&&value.endsWith("'")))value=value.slice(1,-1); process.env[m[1]]=value;
  }
}
const url=process.env.NEXT_PUBLIC_SUPABASE_URL;
const key=process.env.SUPABASE_SERVICE_ROLE_KEY;
if(!url||!key) throw new Error('NEXT_PUBLIC_SUPABASE_URL болон SUPABASE_SERVICE_ROLE_KEY .env.local дотор шаардлагатай.');
const supabase=createClient(url,key,{auth:{autoRefreshToken:false,persistSession:false}});
const demoPhones=new Set(['+97699000001','+97699000002','+97699000003','+97699000004']);
const {data:profiles,error:pError}=await supabase.from('profiles').select('id,phone,clinic_id').in('phone',[...demoPhones]);
if(pError) throw pError;
for(const p of profiles||[]){
  console.log('Removing demo auth user:',p.phone);
  const {error}=await supabase.auth.admin.deleteUser(p.id); if(error) console.warn(error.message);
}
const {data:clinic}=await supabase.from('clinics').select('id,name').eq('slug','demo-clinic').maybeSingle();
if(clinic){
  const {count}=await supabase.from('profiles').select('id',{count:'exact',head:true}).eq('clinic_id',clinic.id);
  if((count||0)===0){const {error}=await supabase.from('clinics').delete().eq('id',clinic.id);if(error)throw error;console.log('Removed demo clinic:',clinic.name)}
  else console.log('Demo clinic kept because non-demo users are still attached to it.');
}
console.log('Demo cleanup finished.');
