import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const required=[
  'components/ui/DentDatePicker.tsx','components/ui/DentMonthPicker.tsx','supabase/v8_11_usability_publish_fix.sql',
  'components/ContractsWorkspace.tsx','components/StaffAppointments.tsx','components/AdminPanel.tsx'
];
for(const f of required)if(!fs.existsSync(path.join(root,f)))throw new Error(`Missing V8.11 file: ${f}`);
const createClinic=fs.readFileSync(path.join(root,'app/api/admin/create-clinic/route.ts'),'utf8');
if(createClinic.includes(".delete().eq('id',clinic.id).catch"))throw new Error('Invalid PostgREST .catch rollback is still present.');
if(!createClinic.includes('best-effort rollback'))throw new Error('Safe clinic-create rollback marker missing.');
const contracts=fs.readFileSync(path.join(root,'components/ContractsWorkspace.tsx'),'utf8');
if(!contracts.includes('DentDatePicker')||!contracts.includes('modal-form-grid'))throw new Error('Contracts form polish missing.');
const appointments=fs.readFileSync(path.join(root,'components/StaffAppointments.tsx'),'utf8');
for(const marker of ['DentDatePicker','TIME_OPTIONS','Товлох өдөр','5 минутын нарийвчлалтай'])if(!appointments.includes(marker))throw new Error(`Appointment UX marker missing: ${marker}`);
const admin=fs.readFileSync(path.join(root,'components/AdminPanel.tsx'),'utf8');
if(!admin.includes("tab==='branding'")||!admin.includes('Нэр & лого'))throw new Error('Dedicated branding tab missing.');
const dashboard=fs.readFileSync(path.join(root,'components/DashboardApp.tsx'),'utf8');
if(!dashboard.includes("<strong>DENTHUB</strong>"))throw new Error('Sidebar brand hierarchy missing.');
const login=fs.readFileSync(path.join(root,'components/LoginPage.tsx'),'utf8');
for(const marker of ['Эмнэлгийн өдөр тутмын ажлыг нэг системд.','Бүртгэлтэй утасны дугаар, нууц үгээ оруулна уу','Ханган нийлүүлэгчийн бүртгэл'])if(!login.includes(marker))throw new Error(`Auth copy marker missing: ${marker}`);
const css=fs.readFileSync(path.join(root,'app/globals.css'),'utf8');
for(const marker of ['DentHub V8.11 — publish fix + usability pass','.dent-date-popover','.modal-form-grid','.clinic-branding-focus'])if(!css.includes(marker))throw new Error(`V8.11 CSS marker missing: ${marker}`);
console.log('DentHub V8.11 usability & publish validation passed.');
