import fs from 'node:fs';
import path from 'node:path';

const root=process.cwd();
const required=[
  'app/globals.css','components/DashboardApp.tsx','components/AdminPanel.tsx',
  'components/PlatformClinicControl.tsx','CHANGELOG_V8_9.md'
];
for(const f of required){if(!fs.existsSync(path.join(root,f)))throw new Error(`Missing V8.9 file: ${f}`)}
const css=fs.readFileSync(path.join(root,'app/globals.css'),'utf8');
const banned=['#7c3aed','#8b5cf6','#a855f7','#6366f1','#5b62c9','#725fd1','#9aa4ff','#a69ae8'];
for(const color of banned){if(css.toLowerCase().includes(color))throw new Error(`Banned violet color remains: ${color}`)}
if(!css.includes('V8.9 — DentHub Studio Design System'))throw new Error('V8.9 design system block missing.');
if(!css.includes('.clinic-more-menu'))throw new Error('Platform clinic action menu styling missing.');
const platform=fs.readFileSync(path.join(root,'components/PlatformClinicControl.tsx'),'utf8');
if(!platform.includes('clinic-control-head'))throw new Error('Platform table header missing.');
if(!platform.includes('MoreHorizontal'))throw new Error('Platform More menu missing.');
console.log('DentHub V8.9 design validation passed.');
