import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const checks=[
  ['app/layout.tsx',/width:\s*'device-width'/,'device-width viewport missing'],
  ['app/layout.tsx',/viewportFit:\s*'cover'/,'safe-area viewport fit missing'],
  ['app/globals.css',/V8\.14 — Mobile-first responsive hardening/,'V8.14 responsive override block missing'],
  ['app/globals.css',/\.auth-v88 \.login-form-panel\{[\s\S]*flex-direction:column!important/,'mobile auth is not forced into one vertical column'],
  ['app/globals.css',/font-size:16px!important[^\n]*prevents iOS focus zoom/,'iOS form zoom protection missing'],
  ['app/globals.css',/env\(safe-area-inset-bottom\)/,'safe-area bottom spacing missing'],
  ['app/globals.css',/\.app-sidebar\{width:min\(88vw,340px\)!important/,'mobile drawer sizing missing'],
  ['app/globals.css',/\.mobile-bottom-nav\{[\s\S]*env\(safe-area-inset-bottom\)/,'mobile bottom navigation safe-area support missing'],
  ['app/globals.css',/\.modal-card,.module-form-modal,[\s\S]*max-height:calc\(100dvh - 10px\)!important/,'mobile full-height modal treatment missing'],
  ['app/globals.css',/\.notification-popover\{[\s\S]*bottom:calc\(78px \+ env\(safe-area-inset-bottom\)\)/,'mobile notification sheet missing'],
  ['app/globals.css',/\.schedule-timeline\{min-width:760px!important/,'mobile calendar horizontal schedule strategy missing'],
  ['components/DashboardApp.tsx',/setSidebarOpen\(false\)/,'mobile drawer must close after navigation'],
];
let failed=[];
for(const [file,re,msg] of checks){const txt=read(file);if(!re.test(txt))failed.push(`${file}: ${msg}`)}
if(failed.length){console.error('DentHub V8.14 validation failed:\n- '+failed.join('\n- '));process.exit(1)}
console.log('DentHub V8.14 mobile-first responsive validation passed.');
