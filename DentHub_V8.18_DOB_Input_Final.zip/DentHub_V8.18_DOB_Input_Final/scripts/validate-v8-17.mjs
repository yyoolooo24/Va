import fs from 'node:fs';
const css=fs.readFileSync('app/globals.css','utf8');
const appt=fs.readFileSync('components/StaffAppointments.tsx','utf8');
const checks=[
  ['mobile single doctor calendar fills viewport', css.includes('.schedule-timeline[data-doctors="0"],.schedule-timeline[data-doctors="1"]') && css.includes('grid-template-columns:58px minmax(0,1fr)!important')],
  ['mobile saving notice is in document flow', css.includes('.staff-appointments-page>.workspace-busy-notice') && css.includes('position:static!important')],
  ['mobile drag HUD is bottom centered', css.includes('bottom:calc(92px + env(safe-area-inset-bottom))!important')],
  ['appointment duration badge remains visible', css.includes('.timeline-duration-badge') && appt.includes('timeline-duration-badge')],
  ['timeline exposes doctor count for responsive grid', appt.includes('data-doctors={doctors.length}')],
  ['dragging resolves real rendered doctor column', appt.includes(".timeline-doctor[data-doctor-id]") && appt.includes('data-doctor-id={d.id}')],
  ['mobile timeline no forced 720 desktop minimum', !/\.schedule-timeline\{min-width:720px!important\}/.test(css.slice(css.lastIndexOf('V8.17')))]
];
const failed=checks.filter(([,ok])=>!ok);
if(failed.length){console.error('DentHub V8.17 validation failed:');for(const [name] of failed)console.error('-',name);process.exit(1)}
console.log('DentHub V8.17 mobile calendar validation passed.');
