import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const required=[
  'app/api/clinic/branding/route.ts','supabase/v8_12_stability_ux_fix.sql','components/StaffAppointments.tsx',
  'components/AdminPanel.tsx','components/ModulePage.tsx','CHANGELOG_V8_12.md','V8_12_SETUP.md'
];
for(const f of required)if(!fs.existsSync(path.join(root,f)))throw new Error(`Missing V8.12 file: ${f}`);
const branding=fs.readFileSync(path.join(root,'app/api/clinic/branding/route.ts'),'utf8');
for(const marker of ["requireApiUser(request, ['owner'])","storage.from('clinic-logos').upload","clinic_branding_logo_updated"]){if(!branding.includes(marker))throw new Error(`Branding server marker missing: ${marker}`)}
const admin=fs.readFileSync(path.join(root,'components/AdminPanel.tsx'),'utf8');
for(const marker of ["brandingRequest('POST'","brandingRequest('PATCH'","brandingRequest('DELETE'",'workspace-busy-notice'])if(!admin.includes(marker))throw new Error(`Branding UX marker missing: ${marker}`);
if(admin.includes("storage.from('clinic-logos').upload(path,file"))throw new Error('Client-side logo upload fallback still present.');
const appointments=fs.readFileSync(path.join(root,'components/StaffAppointments.tsx'),'utf8');
for(const marker of ['const eventHeight=Math.max(30','minutes<=step?\'short\'','Хуваарийн мэдээллийг уншиж байна'])if(!appointments.includes(marker))throw new Error(`Calendar marker missing: ${marker}`);
const modulePage=fs.readFileSync(path.join(root,'components/ModulePage.tsx'),'utf8');
for(const marker of ["import DentDatePicker from './ui/DentDatePicker';","f.type==='date'?<DentDatePicker",'Маягтын мэдээллийг уншиж байна'])if(!modulePage.includes(marker))throw new Error(`Module form marker missing: ${marker}`);
const css=fs.readFileSync(path.join(root,'app/globals.css'),'utf8');
for(const marker of ['DentHub V8.12 — stability, loading feedback and calendar geometry','.timeline-event.short','.workspace-busy-notice','.module-form-modal .dent-date-popover'])if(!css.includes(marker))throw new Error(`V8.12 CSS marker missing: ${marker}`);
console.log('DentHub V8.12 stability & UX validation passed.');
