import fs from 'node:fs';
import path from 'node:path';

const root=process.cwd();
const required=[
  'lib/subscription.ts','lib/auth.ts','components/PlatformClinicControl.tsx','components/ClinicSubscriptionCard.tsx',
  'app/api/admin/clinic-subscription/route.ts','app/api/clinic/module-requests/route.ts',
  'supabase/v8_7_subscription_platform_security.sql','CHANGELOG_V8_7.md','V8_7_SETUP.md'
];
const failures=[];
for(const rel of required){if(!fs.existsSync(path.join(root,rel)))failures.push(`Missing: ${rel}`)}
const walk=(dir)=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);
const files=walk(root).filter(f=>!f.includes(`${path.sep}node_modules${path.sep}`)&&!f.includes(`${path.sep}.next${path.sep}`)&&/\.(ts|tsx|js|mjs|sql|md)$/.test(f));
for(const f of files){const text=fs.readFileSync(f,'utf8');const rel=path.relative(root,f);
  if(/\.(ts|tsx|js|mjs)$/.test(f) && rel!=='scripts/validate-v8-7.mjs' && (/\bwindow\.confirm\s*\(/.test(text)||/\balert\s*\(/.test(text))) failures.push(`Native browser popup: ${rel}`);
  const legacy=new RegExp('\\bWin'+'gs\\b','i');
  if(rel!=='scripts/validate-v8-7.mjs' && legacy.test(text)) failures.push(`Legacy reference-system wording: ${rel}`);
}
const next=fs.readFileSync(path.join(root,'next.config.mjs'),'utf8');
if(/ignoreBuildErrors\s*:\s*true/.test(next))failures.push('next.config.mjs still ignores TypeScript build errors');
const sql=fs.readFileSync(path.join(root,'supabase/v8_7_subscription_platform_security.sql'),'utf8');
for(const needle of ['enabled_modules','clinic_module_requests','platform_audit_log','denthub_user_has_module','denthub_doctor_has_patient','denthub_transfer_encounter_to_receivable','clinic_documents_select'])if(!sql.includes(needle))failures.push(`Migration missing: ${needle}`);
if(failures.length){console.error('DentHub V8.7 validation FAILED');for(const f of failures)console.error(`- ${f}`);process.exit(1)}
console.log(`DentHub V8.7 static validation passed (${files.length} source/config files scanned).`);
