import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const checks=[
  ['components/DashboardApp.tsx',/className="brand-mark"><Stethoscope size=\{23\}/,'DentHub brand must remain the DentHub mark'],
  ['components/DashboardApp.tsx',/tenant-avatar[\s\S]*clinicLogoUrl/,'Clinic logo must stay in clinic identity area'],
  ['components/ModulePage.tsx',/branch-form-modal/,'Branch modal sizing hook missing'],
  ['components/ModulePage.tsx',/category-inline-add[\s\S]*New category[\s\S]*Шинэ ангилал/,'Explicit new-category action missing'],
  ['components/StaffAppointments.tsx',/autoFitColumns/,'Calendar auto-fit columns missing'],
  ['components/StaffAppointments.tsx',/calendar-gesture-hud/,'Calendar drag\/resize duration HUD missing'],
  ['components/StaffAppointments.tsx',/timeline-duration/,'Appointment duration label missing'],
  ['app/globals.css',/One modal = one scrollbar/,'Single-scroll modal rules missing'],
  ['app/globals.css',/\.module-group-list\{max-height:none!important;overflow:visible!important/,'Nested module list scrolling still enabled'],
  ['app/globals.css',/\.app-toast-stack\{top:146px!important/,'Notification stack lane missing'],
];
let failed=[];
for(const [file,re,msg] of checks){const txt=read(file);if(!re.test(txt))failed.push(`${file}: ${msg}`)}
if(failed.length){console.error('DentHub V8.13 validation failed:\n- '+failed.join('\n- '));process.exit(1)}
console.log('DentHub V8.13 professional UX validation passed.');
