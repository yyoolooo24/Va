import fs from 'node:fs';
const checks=[
  ['components/ui/BirthDateInput.tsx','inputMode="numeric"'],
  ['components/ui/BirthDateInput.tsx','maxLength={10}'],
  ['components/ModulePage.tsx',"type:'birthdate'"],
  ['components/PatientCardsWorkspace.tsx','<BirthDateInput'],
  ['app/api/patients/route.ts','normalizeDateOfBirth'],
];
for(const [file,needle] of checks){const text=fs.readFileSync(file,'utf8');if(!text.includes(needle))throw new Error(`V8.18 validation failed: ${file} missing ${needle}`)}
console.log('DentHub V8.18 DOB input validation passed.');
