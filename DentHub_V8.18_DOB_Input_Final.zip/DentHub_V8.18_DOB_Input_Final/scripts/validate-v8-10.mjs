import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const required=[
  'components/PlatformSubscriptionPlans.tsx','components/ModuleAccessPicker.tsx','components/PlatformClinicControl.tsx',
  'app/api/admin/subscription-plans/route.ts','supabase/v8_10_platform_plans_ux.sql','CHANGELOG_V8_10.md','V8_10_SETUP.md'
];
for(const f of required){if(!fs.existsSync(path.join(root,f)))throw new Error(`Missing V8.10 file: ${f}`)}
const dashboard=fs.readFileSync(path.join(root,'components/DashboardApp.tsx'),'utf8');
if(!dashboard.includes("subscriptions: { mn: 'Багцын тохиргоо'"))throw new Error('Platform subscription sidebar item missing.');
if(!dashboard.includes('<PlatformSubscriptionPlans'))throw new Error('Platform subscription page is not rendered.');
const platform=fs.readFileSync(path.join(root,'components/PlatformClinicControl.tsx'),'utf8');
for(const marker of ['clinic-filter-tabs','ModuleAccessPicker','platform-action-toast','Идэвхтэй жагсаалтаас хасах'])if(!platform.includes(marker))throw new Error(`Platform UX marker missing: ${marker}`);
const admin=fs.readFileSync(path.join(root,'components/AdminPanel.tsx'),'utf8');
if(!admin.includes('clinic-access-editor'))throw new Error('New-clinic quick module editor missing.');
if(!admin.includes('platform_subscription_plans'))throw new Error('Admin plan catalog loading missing.');
const css=fs.readFileSync(path.join(root,'app/globals.css'),'utf8');
for(const marker of ['V8.10 — Platform plans','.module-access-picker-pro','.subscription-modal-scroll','.platform-action-toast'])if(!css.includes(marker))throw new Error(`V8.10 CSS marker missing: ${marker}`);

const planApi=fs.readFileSync(path.join(root,'app/api/admin/subscription-plans/route.ts'),'utf8');
if(!planApi.includes("code==='START'&&!active")||!planApi.includes("code==='START')return NextResponse.json"))throw new Error('START default-plan protection missing.');
const clinicApi=fs.readFileSync(path.join(root,'app/api/admin/clinic-subscription/route.ts'),'utf8');
for(const marker of ["action === 'archive'","action === 'permanent_delete'","protectedTables"])if(!clinicApi.includes(marker))throw new Error(`Clinic removal safety marker missing: ${marker}`);

const login=fs.readFileSync(path.join(root,'components/LoginPage.tsx'),'utf8');
if(login.includes('workspace')||login.includes('Clinic owner хэрэггүй'))throw new Error('Unfinished mixed-language login copy remains.');
console.log('DentHub V8.10 platform plans & UX validation passed.');
