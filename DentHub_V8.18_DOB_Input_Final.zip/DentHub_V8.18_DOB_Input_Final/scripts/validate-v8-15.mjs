import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const checks=[
  ['app/globals.css',/V8\.15 — UI stability cleanup/,'V8.15 CSS override block missing'],
  ['app/globals.css',/\.auth-v88 \.login-form-panel\{[\s\S]*?flex-direction:column!important/,'auth form/footer is not forced vertical'],
  ['components/StaffAppointments.tsx',/app-toast-stack \$\{\(loading\|\|saving\)\?'with-busy':''\}/,'appointment notifications are not busy-aware'],
  ['app/globals.css',/\.app-toast-stack\.with-busy\{top:144px!important/,'busy-aware toast offset missing'],
  ['components/StaffAppointments.tsx',/className=\"appt-today-btn\"/,'calendar toolbar simplification missing'],
  ['components/StaffAppointments.tsx',/calendarTitle\(anchor,mode,en,weekDays\)/,'calendar readable title missing'],
  ['components/ui/DentSelect.tsx',/createPortal/,'select portal missing'],
  ['components/ui/DentSelect.tsx',/menuRef\.current\?\.contains/,'portal outside-click protection missing'],
  ['app/globals.css',/\.choice-select-menu button>span\{[\s\S]*?overflow-wrap:anywhere!important/,'long choice labels do not wrap'],
  ['components/HealthDepartmentWorkspace.tsx',/displayLabel/,'health report readable period label missing'],
  ['app/globals.css',/\.health-period-bar\{[\s\S]*?minmax\(300px,360px\)/,'health period overlap layout fix missing'],
];
let failed=[];
for(const [file,re,msg] of checks){const txt=read(file);if(!re.test(txt))failed.push(`${file}: ${msg}`)}
if(failed.length){console.error('DentHub V8.15 validation failed:\n- '+failed.join('\n- '));process.exit(1)}
console.log('DentHub V8.15 UI stability validation passed.');
