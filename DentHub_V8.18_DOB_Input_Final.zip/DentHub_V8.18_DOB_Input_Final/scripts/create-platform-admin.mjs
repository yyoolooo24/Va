import fs from 'node:fs';
import path from 'node:path';
import { createClient } from '@supabase/supabase-js';

const envPath=path.resolve(process.cwd(),'.env.local');
if(fs.existsSync(envPath)){
  for(const line of fs.readFileSync(envPath,'utf8').split(/\r?\n/)){
    const t=line.trim(); if(!t||t.startsWith('#')) continue; const i=t.indexOf('='); if(i<1) continue;
    const k=t.slice(0,i).trim(); let v=t.slice(i+1).trim(); if((v.startsWith('"')&&v.endsWith('"'))||(v.startsWith("'")&&v.endsWith("'")))v=v.slice(1,-1); if(!(k in process.env))process.env[k]=v;
  }
}
const url=process.env.NEXT_PUBLIC_SUPABASE_URL; const key=process.env.SUPABASE_SERVICE_ROLE_KEY;
const phone=(process.env.ADMIN_PHONE||'').replace(/\D/g,''); const password=process.env.ADMIN_PASSWORD||''; const fullName=process.env.ADMIN_NAME||'ClinicOS Admin';
if(!url||!key){console.error('Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in .env.local');process.exit(1)}
if(!phone||password.length<8){console.error('Add ADMIN_PHONE and ADMIN_PASSWORD (8+ chars) to .env.local temporarily, then run npm run create:admin');process.exit(1)}
const normalized=phone.startsWith('976')?phone:`976${phone}`; const email=`${normalized}@phone.clinicos.app`;
const supabase=createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
const {data:list,error:listError}=await supabase.auth.admin.listUsers({page:1,perPage:1000}); if(listError)throw listError;
let user=list.users.find(u=>u.email===email);
if(!user){const {data,error}=await supabase.auth.admin.createUser({email,password,email_confirm:true,user_metadata:{full_name:fullName,phone:`+${normalized}`}});if(error)throw error;user=data.user}else{const {error}=await supabase.auth.admin.updateUserById(user.id,{password,email_confirm:true});if(error)throw error}
const {error:profileError}=await supabase.from('profiles').upsert({id:user.id,clinic_id:null,role:'platform_admin',full_name:fullName,phone:`+${normalized}`,language:'mn'});if(profileError)throw profileError;
console.log(`Platform Admin ready: +${normalized}`);
console.log('Remove ADMIN_PASSWORD from .env.local after this command succeeds.');
