import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const failures=[];
const required=[
  'app/api/auth/recovery/request/route.ts','app/api/auth/recovery/verify/route.ts','supabase/v8_8_auth_public_launch.sql',
  'components/LoginPage.tsx','components/PwaRegister.tsx','app/manifest.ts','public/sw.js','public/denthub-icon.svg',
  'CHANGELOG_V8_8.md','V8_8_SETUP.md'
];
for(const rel of required)if(!fs.existsSync(path.join(root,rel)))failures.push(`Missing: ${rel}`);
const walk=(dir)=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);
const files=walk(root).filter(f=>!f.includes(`${path.sep}node_modules${path.sep}`)&&!f.includes(`${path.sep}.next${path.sep}`)&&/\.(ts|tsx|js|mjs|sql|md|svg)$/.test(f));
for(const f of files){const text=fs.readFileSync(f,'utf8');const rel=path.relative(root,f);
  if(/\.(ts|tsx|js|mjs)$/.test(f) && !rel.startsWith('scripts/validate-') && (/\bwindow\.confirm\s*\(/.test(text)||/\balert\s*\(/.test(text)))failures.push(`Native browser popup: ${rel}`);
  const legacy=new RegExp('\\bWin'+'gs\\b','i');
  if(!rel.startsWith('scripts/validate-')&&legacy.test(text))failures.push(`Legacy wording: ${rel}`);
}
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
if(pkg.dependencies?.next!=='15.5.24')failures.push('Next.js is not pinned to 15.5.24');
if(!String(pkg.dependencies?.xlsx||'').includes('xlsx-0.20.3'))failures.push('SheetJS is not using the patched 0.20.3 package');
const authCss=fs.readFileSync(path.join(root,'app/globals.css'),'utf8');
for(const needle of ['DentHub V8.8.5 — login / registration visual polish','grid-template-columns:minmax(390px,42%) minmax(520px,58%)','width:min(100%,450px);padding:30px 30px 26px'])if(!authCss.includes(needle))failures.push(`V8.8.5 auth UI regression: ${needle}`);
const login=fs.readFileSync(path.join(root,'components/LoginPage.tsx'),'utf8');
for(const needle of ['/api/auth/recovery/request','/api/auth/recovery/verify','one-time-code','confirmPassword'])if(!login.includes(needle))failures.push(`LoginPage missing: ${needle}`);
const card=fs.readFileSync(path.join(root,'app/api/client/card/route.ts'),'utf8');
if(!card.includes('type PatientRow'))failures.push('Client card patient row typing fix missing');
const health=fs.readFileSync(path.join(root,'components/HealthDepartmentWorkspace.tsx'),'utf8');
for(const needle of ['type ReportPatientRow','new Map<string,ReportPatientRow>','new Map<string,ReportAppointmentRow>','new Map<string,ReportServiceRow>','ap?.service_name','svc?.category'])if(!health.includes(needle))failures.push(`Health Department report typing fix missing: ${needle}`);

const modulePage=fs.readFileSync(path.join(root,'components/ModulePage.tsx'),'utf8');
for(const needle of [
  ".at(0)??''",
  'const normalizedForm:Record<string,string>',
  'quantity_after:String(nextQty)',
  'const targetChatId:string=selectedChatId',
  'const localForm:Record<string,string>'
])if(!modulePage.includes(needle))failures.push(`ModulePage strict typing regression: ${needle}`);
if(/matches\[0\]\.replace/.test(modulePage))failures.push('ModulePage unsafe regex first-match indexing returned');
for(const needle of [
  'type ServiceImportKnownRow=',
  "select('id,name,category,subcategory,is_category,service_code')",
  'known:ServiceImportKnownRow[]',
  'type InventoryImportKnownRow=',
  'rowsNow:InventoryImportKnownRow[]'
])if(!modulePage.includes(needle))failures.push(`ModulePage import-row shape regression: ${needle}`);

const staffAppointments=fs.readFileSync(path.join(root,'components/StaffAppointments.tsx'),'utf8');
if(!staffAppointments.includes('value:String(y),label:String(y)'))failures.push('Appointment year filter options are not string-typed');

const sql=fs.readFileSync(path.join(root,'supabase/v8_8_auth_public_launch.sql'),'utf8');
for(const needle of ['password_recovery_attempts','recovery_phone_verified_at','last_password_reset_at'])if(!sql.includes(needle))failures.push(`V8.8 migration missing: ${needle}`);
const next=fs.readFileSync(path.join(root,'next.config.mjs'),'utf8');
if(/ignoreBuildErrors\s*:\s*true/.test(next))failures.push('TypeScript build errors are still ignored');
if(failures.length){console.error('DentHub V8.8 validation FAILED');failures.forEach(f=>console.error(`- ${f}`));process.exit(1)}
console.log(`DentHub V8.8 static validation passed (${files.length} source/config files scanned).`);
