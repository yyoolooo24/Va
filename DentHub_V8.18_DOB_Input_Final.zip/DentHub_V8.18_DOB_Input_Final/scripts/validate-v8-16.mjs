import fs from 'node:fs';
const checks=[
  ['components/ui/DentMonthPicker.tsx','dent-month-popover-v16'],
  ['components/ServicePackagesPanel.tsx','denthub:services-changed'],
  ['components/ServicePackagesPanel.tsx','await loadServices()'],
  ['components/StaffAppointments.tsx','timeline-duration-badge'],
  ['app/globals.css','DentHub V8.16'],
];
for(const [file,needle] of checks){const text=fs.readFileSync(file,'utf8');if(!text.includes(needle))throw new Error(`${file} missing ${needle}`)}
console.log('DentHub V8.16 responsive + workflow validation passed.');
