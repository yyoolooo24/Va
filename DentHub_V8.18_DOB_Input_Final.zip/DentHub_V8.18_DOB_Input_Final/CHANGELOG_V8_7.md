# DentHub V8.7 — Subscription, Platform Control & Security

## Platform subscription control

- New clinic registration now creates a **PENDING** clinic request instead of an immediately active workspace.
- Platform Admin can approve, reject, suspend, reactivate, archive, cancel, or safely delete empty/test clinics.
- Platform Admin controls each clinic's plan, licensed modules, employee limit, subscription price, billing cycle, subscription end, grace period, and internal notes.
- Clinic owners can request additional modules; Platform Admin approves or rejects each request.
- Existing active/trial clinics are backfilled with the full current module set so this migration does not unexpectedly remove their existing access.

## Security

- Added a central active-clinic/subscription tenant gate in Supabase.
- Paid-module access is enforced in server routes and RLS, not only hidden in navigation.
- Added explicit `staff_type` for doctor/security decisions; free-form specialty text is no longer the primary authorization signal.
- Doctors are restricted at database level to patient/appointment/encounter relationships assigned to them.
- Payment/eBarimt and employee-management APIs require the corresponding licensed module.
- Cashier payment RPC now requires Payments entitlement.
- Clinic-credit handoff is a single atomic database RPC: receivable creation + encounter transfer flag.
- Private `clinic-documents` Storage access is path-aware: HR, procedures, contracts, and regulatory documents use different entitlement/privacy rules.
- Public registration gets database-backed throttling.
- Added Platform Admin audit logging for subscription and clinic-control actions.
- Added production security headers and removed `typescript.ignoreBuildErrors`.

## Reliability / UX

- Production generic ERP pages no longer silently fall back to browser-only localStorage when Supabase is unavailable. Demo fallback remains available only with `NEXT_PUBLIC_DEMO_MODE=true`.
- Remaining native Excel `alert()` popups were replaced by DentHub inline/toast-style error handling.
- Added subscription overview/request UI for clinic owners.
- Added Platform Admin approval/subscription/module management UI.

## Required migration

Run `supabase/v8_7_subscription_platform_security.sql` after the V8.6.26 migration.
