# DentHub V8.6.25 setup

## 1. Supabase migration

V8.6.24 хүртэлх migration-ууд ажилласан байх ёстой. Дараа нь Supabase SQL Editor дээр:

`supabase/v8_6_25_doctor_privacy_history_password.sql`

файлыг нэг удаа ажиллуулна.

Migration нь completed appointment fallback history-д audit-safe hide metadata нэмнэ:

- `appointments.history_hidden_at`
- `appointments.history_hidden_by`

## 2. Local validation / deploy

```bash
npm install
npm run build
npx vercel --prod
```

## 3. Quick acceptance tests

1. Owner → Эмчилгээний түүх → нэг completed мөр устгах → refresh → дахин харагдахгүй байх.
2. Doctor A → Өвчтөн / Өвчтөний карт / Цаг товлол / Эмчилгээний түүх → зөвхөн Doctor A-тай холбоотой өвчтөнүүд харагдах.
3. Doctor B-ийн patient ID-г Doctor A-аар patient update API-р өөрчлөх оролдлого → 403.
4. Ажилтан → Миний мэдээлэл → Нууц үг → шинэ password хадгалах → дахин login хийх.
5. Owner → Удирдлага → Ажилтны эрх → Нууц үг сэргээх → temporary password-аар ажилтан login хийх.
6. Platform admin → owner хэрэглэгч дээр temporary password reset хийх боломжтой байх.
