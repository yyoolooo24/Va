# DentHub V7 backend setup

## Login without SMS

The screen asks for phone + password. DentHub converts the phone into a private internal Supabase email identity and signs in with Supabase Email/Password.

Therefore:

- Supabase Email provider = ON
- Supabase Phone provider = OFF
- No Twilio/Textlocal needed for normal login
- SMS can be added later only for recovery/verification

## Existing Supabase project

Run `supabase/v7_upgrade.sql` once. It adds:

- encounters
- finance transactions
- direct messages
- RLS policies
- Facebook-style notification triggers
- Supabase Realtime publication for notifications

## V7 notification behavior

- Comment on a post → the post author gets a notification → clicking it opens that post.
- Like a post → the post author gets a notification → clicking it opens that post.
- Follow / connection → opens the professional network.
- Direct-message notification → opens Chat.
- The top bell listens for new database notifications in realtime while the app is open.

## QPay

Server-only variables:

```env
QPAY_BASE_URL=https://merchant-sandbox.qpay.mn
QPAY_CLIENT_ID=
QPAY_CLIENT_SECRET=
QPAY_INVOICE_CODE=
QPAY_SENDER_BRANCH_CODE=MAIN
QPAY_INVOICE_RECEIVER_CODE=terminal
QPAY_DEMO_MODE=true
```

Live credentials must never be exposed in browser code.

Once the Vercel domain exists, set `NEXT_PUBLIC_APP_URL` to the live domain so QPay callbacks return to the deployed app.

## eBarimt

Use only the district/classification values approved for your merchant configuration:

```env
QPAY_EBARIMT_DISTRICT_CODE=
QPAY_EBARIMT_CLASSIFICATION_CODE=
```
