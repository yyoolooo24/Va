import { NextRequest, NextResponse } from 'next/server';
import { requireApiUser } from '@/lib/auth';

function isDoctorProfile(profile:any){return profile?.role==='employee'&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(String(profile?.specialty||''))}

async function allowed(admin:any,profile:any,targetId:string){
  if(!targetId||targetId===profile.id)return false;
  if(profile.role==='owner'||profile.role==='employee'){
    if(!profile.clinic_id)return false;
    const {data:staff}=await admin.from('profiles').select('id').eq('id',targetId).eq('clinic_id',profile.clinic_id).in('role',['owner','employee']).eq('active',true).maybeSingle();if(staff)return true;
    const {data:patient}=await admin.from('patients').select('id').eq('clinic_id',profile.clinic_id).eq('user_id',targetId).is('deleted_at',null).maybeSingle();
    if(!patient)return false;
    if(isDoctorProfile(profile)){
      const [a,e]=await Promise.all([
        admin.from('appointments').select('id').eq('clinic_id',profile.clinic_id).eq('patient_id',patient.id).eq('doctor_id',profile.id).limit(1),
        admin.from('encounters').select('id').eq('clinic_id',profile.clinic_id).eq('patient_id',patient.id).eq('doctor_id',profile.id).limit(1),
      ]);
      return Boolean(a.data?.length||e.data?.length);
    }
    return true;
  }
  if(profile.role==='client'){
    const {data:patientRows}=await admin.from('patients').select('clinic_id').eq('user_id',profile.id).is('deleted_at',null);const ids=(patientRows||[]).map((p:any)=>p.clinic_id);
    if(!ids.length)return false;const {data:staff}=await admin.from('profiles').select('id').eq('id',targetId).in('clinic_id',ids).in('role',['owner','employee']).eq('active',true).maybeSingle();return Boolean(staff);
  }
  if(profile.role==='supplier'){
    const {data:target}=await admin.from('profiles').select('id,clinic_id,role').eq('id',targetId).eq('role','owner').eq('active',true).maybeSingle();if(!target?.clinic_id)return false;
    const {data:link}=await admin.from('supplier_partner_clinics').select('id').eq('supplier_id',profile.id).eq('clinic_id',target.clinic_id).maybeSingle();return Boolean(link);
  }
  return false;
}

export async function GET(request:NextRequest){
  try{
    const {profile,admin}=await requireApiUser(request,['owner','employee','client','supplier']);const targetId=request.nextUrl.searchParams.get('with')||'';
    if(!(await allowed(admin,profile,targetId)))return NextResponse.json({error:'Энэ хэрэглэгчтэй чатлах эрхгүй байна.'},{status:403});
    const {data,error}=await admin.from('direct_messages').select('id,sender_id,recipient_id,body,read_at,created_at').or(`and(sender_id.eq.${profile.id},recipient_id.eq.${targetId}),and(sender_id.eq.${targetId},recipient_id.eq.${profile.id})`).order('created_at',{ascending:true}).limit(500);if(error)throw error;
    await admin.from('direct_messages').update({read_at:new Date().toISOString()}).eq('sender_id',targetId).eq('recipient_id',profile.id).is('read_at',null);
    return NextResponse.json({messages:data||[]});
  }catch(error:any){const m=error?.message||'Чат ачаалж чадсангүй.';return NextResponse.json({error:m},{status:m==='UNAUTHORIZED'?401:m==='FORBIDDEN'?403:400})}
}

export async function POST(request:NextRequest){
  try{
    const {profile,admin}=await requireApiUser(request,['owner','employee','client','supplier']);const body=await request.json();const recipientId=String(body.recipientId||'');const message=String(body.body||'').trim();
    if(!message||message.length>3000)return NextResponse.json({error:'Мессеж 1–3000 тэмдэгт байна.'},{status:400});
    if(!(await allowed(admin,profile,recipientId)))return NextResponse.json({error:'Энэ хэрэглэгчтэй чатлах эрхгүй байна.'},{status:403});
    const {data,error}=await admin.from('direct_messages').insert({sender_id:profile.id,recipient_id:recipientId,body:message}).select('id,sender_id,recipient_id,body,read_at,created_at').single();if(error)throw error;
    return NextResponse.json({message:data});
  }catch(error:any){const m=error?.message||'Мессеж илгээж чадсангүй.';return NextResponse.json({error:m},{status:m==='UNAUTHORIZED'?401:m==='FORBIDDEN'?403:400})}
}
