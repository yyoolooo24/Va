import { NextRequest, NextResponse } from 'next/server';
import { requireApiUser } from '@/lib/auth';

function isDoctorProfile(profile:any){return profile?.role==='employee'&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(String(profile?.specialty||''))}

export async function GET(request:NextRequest){
  try{
    const {profile,admin}=await requireApiUser(request,['owner','employee','client','supplier']);
    const contacts:any[]=[];
    if(profile.role==='owner'||profile.role==='employee'){
      const clinicId=profile.clinic_id;
      if(!clinicId)return NextResponse.json({contacts:[]});
      const {data:staff}=await admin.from('profiles').select('id,full_name,role,phone').eq('clinic_id',clinicId).in('role',['owner','employee']).eq('active',true).neq('id',profile.id);
      let patientQuery=admin.from('patients').select('id,full_name,phone,user_id').eq('clinic_id',clinicId).is('deleted_at',null).not('user_id','is',null);
      if(isDoctorProfile(profile)){
        const [a,e]=await Promise.all([
          admin.from('appointments').select('patient_id').eq('clinic_id',clinicId).eq('doctor_id',profile.id),
          admin.from('encounters').select('patient_id').eq('clinic_id',clinicId).eq('doctor_id',profile.id),
        ]);
        const patientIds=Array.from(new Set([...(a.data||[]),...(e.data||[])].map((x:any)=>String(x.patient_id||'')).filter(Boolean)));
        patientQuery=patientIds.length?patientQuery.in('id',patientIds):patientQuery.eq('id','00000000-0000-0000-0000-000000000000');
      }
      const {data:patients}=await patientQuery;
      for(const s of staff||[])contacts.push({id:s.id,name:s.full_name,meta:s.role==='owner'?'Эмнэлгийн эзэмшигч':'Эмч / Ажилтан',kind:'staff'});
      const patientUserIds=[...new Set((patients||[]).map((p:any)=>p.user_id).filter(Boolean))];
      if(patientUserIds.length){
        const {data:clientProfiles}=await admin.from('profiles').select('id,full_name,phone,active').in('id',patientUserIds).eq('active',true);
        const patientByUser=new Map((patients||[]).map((p:any)=>[p.user_id,p]));
        for(const c of clientProfiles||[]){const p=patientByUser.get(c.id) as any;contacts.push({id:c.id,name:p?.full_name||c.full_name,meta:[p?.phone||c.phone,'Өвчтөн'].filter(Boolean).join(' · '),kind:'patient'});}
      }
    } else if(profile.role==='client'){
      const {data:patientRows}=await admin.from('patients').select('clinic_id').eq('user_id',profile.id).is('deleted_at',null);
      const clinicIds=[...new Set((patientRows||[]).map((p:any)=>p.clinic_id).filter(Boolean))];
      if(clinicIds.length){
        const {data:staff}=await admin.from('profiles').select('id,clinic_id,full_name,role,active').in('clinic_id',clinicIds).in('role',['owner','employee']).eq('active',true);
        const {data:clinics}=await admin.from('clinics').select('id,name').in('id',clinicIds);
        const clinicMap=new Map((clinics||[]).map((c:any)=>[c.id,c.name]));
        for(const s of staff||[])contacts.push({id:s.id,name:s.full_name,meta:[s.role==='owner'?'Эзэмшигч':'Эмч / Ажилтан',clinicMap.get(s.clinic_id)].filter(Boolean).join(' · '),kind:'staff'});
      }
    } else if(profile.role==='supplier'){
      const {data:links,error:linkError}=await admin.from('supplier_partner_clinics').select('clinic_id').eq('supplier_id',profile.id).not('clinic_id','is',null);
      if(!linkError){
        const clinicIds=[...new Set((links||[]).map((x:any)=>x.clinic_id).filter(Boolean))];
        if(clinicIds.length){
          const {data:owners}=await admin.from('profiles').select('id,clinic_id,full_name,role').in('clinic_id',clinicIds).eq('role','owner').eq('active',true);
          const {data:clinics}=await admin.from('clinics').select('id,name').in('id',clinicIds);const cm=new Map((clinics||[]).map((c:any)=>[c.id,c.name]));
          for(const o of owners||[])contacts.push({id:o.id,name:o.full_name,meta:`${cm.get(o.clinic_id)||'Эмнэлэг'} · Эзэмшигч`,kind:'clinic'});
        }
      }
    }
    const unique=[...new Map(contacts.filter(c=>c.id!==profile.id).map(c=>[c.id,c])).values()].sort((a:any,b:any)=>a.name.localeCompare(b.name,'mn'));
    return NextResponse.json({contacts:unique});
  }catch(error:any){const m=error?.message||'Чатын холбоо ачаалж чадсангүй.';return NextResponse.json({error:m},{status:m==='UNAUTHORIZED'?401:m==='FORBIDDEN'?403:400})}
}
