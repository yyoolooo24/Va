import { createHmac, createHash } from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin, getSupabasePublicServer } from '@/lib/supabase-admin';
import { normalizeMongolianPhone, mongolianPhoneDigits } from '@/lib/auth';

function fingerprint(request:NextRequest){
  const ip=request.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||request.headers.get('x-real-ip')||'';
  const ua=request.headers.get('user-agent')||'';
  return createHash('sha256').update(`${ip}|${ua}`).digest('hex');
}
function phoneHash(phone:string){
  const secret=process.env.SUPABASE_SERVICE_ROLE_KEY||process.env.NEXT_PUBLIC_SUPABASE_URL||'denthub-recovery';
  return createHmac('sha256',secret).update(phone).digest('hex');
}

export async function POST(request:NextRequest){
  const admin=getSupabaseAdmin();
  try{
    const body=await request.json();
    const phone=normalizeMongolianPhone(String(body.phone||''));
    const token=String(body.code||'').replace(/\D/g,'').slice(0,6);
    const password=String(body.password||'');
    if(token.length!==6)return NextResponse.json({error:'6 оронтой кодоо бүрэн оруулна уу.'},{status:400});
    if(password.length<8)return NextResponse.json({error:'Шинэ нууц үг хамгийн багадаа 8 тэмдэгт байна.'},{status:400});
    if(!/[A-Za-zА-Яа-яӨөҮүЁё]/.test(password)||!/\d/.test(password))return NextResponse.json({error:'Нууц үгэнд үсэг болон тоо хоёуланг ашиглана уу.'},{status:400});

    const fp=fingerprint(request), ph=phoneHash(phone), since=new Date(Date.now()-15*60*1000).toISOString();
    const {count,error:countError}=await admin.from('password_recovery_attempts').select('id',{count:'exact',head:true}).eq('fingerprint',fp).eq('event','verify_failed').gte('created_at',since);
    if(countError)throw new Error('RECOVERY_MIGRATION_REQUIRED');
    if((count||0)>=8)return NextResponse.json({error:'Хэт олон буруу код оруулсан байна. 15 минутын дараа дахин оролдоно уу.'},{status:429});

    const publicClient=getSupabasePublicServer();
    const {data,error:verifyError}=await publicClient.auth.verifyOtp({phone,token,type:'sms'});
    if(verifyError||!data.user){
      await admin.from('password_recovery_attempts').insert({fingerprint:fp,phone_hash:ph,event:'verify_failed'});
      return NextResponse.json({error:'Код буруу эсвэл хугацаа нь дууссан байна.'},{status:400});
    }

    const {data:profile,error:profileError}=await admin.from('profiles').select('id,clinic_id,phone,active').eq('id',data.user.id).maybeSingle();
    if(profileError||!profile||profile.active===false||mongolianPhoneDigits(String(profile.phone||''))!==mongolianPhoneDigits(phone)){
      await publicClient.auth.signOut({scope:'global'}).catch(()=>undefined);
      return NextResponse.json({error:'Энэ код DentHub бүртгэлтэй тохирохгүй байна.'},{status:403});
    }

    const {error:updateError}=await admin.auth.admin.updateUserById(data.user.id,{password,phone,phone_confirm:true});
    if(updateError)throw updateError;
    await admin.from('profiles').update({recovery_phone_verified_at:new Date().toISOString(),last_password_reset_at:new Date().toISOString()}).eq('id',data.user.id);
    await admin.from('password_recovery_attempts').insert({fingerprint:fp,phone_hash:ph,event:'reset_success'});
    const auditResult=await admin.from('platform_audit_log').insert({actor_id:data.user.id,clinic_id:profile.clinic_id||null,action:'self_service_password_reset',target_type:'profile',target_id:data.user.id,metadata:{method:'sms_otp'}});
    void auditResult.error;
    await publicClient.auth.signOut({scope:'global'}).catch(()=>undefined);
    return NextResponse.json({ok:true,message:'Нууц үг амжилттай шинэчлэгдлээ. Шинэ нууц үгээрээ нэвтэрнэ үү.'});
  }catch(error:any){
    const message=String(error?.message||'Нууц үг шинэчилж чадсангүй.');
    if(message==='RECOVERY_MIGRATION_REQUIRED')return NextResponse.json({error:'V8.8 migration-ийг Supabase дээр ажиллуулаагүй байна.'},{status:500});
    return NextResponse.json({error:'Нууц үг шинэчилж чадсангүй. Дахин оролдоно уу.'},{status:400});
  }
}
