import { createHmac, createHash } from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin, getSupabasePublicServer } from '@/lib/supabase-admin';
import { normalizeMongolianPhone, mongolianPhoneDigits } from '@/lib/auth';

const GENERIC_MESSAGE='Хэрэв энэ дугаарт DentHub бүртгэл байгаа бол сэргээх код SMS-ээр илгээгдэнэ.';

function fingerprint(request:NextRequest){
  const ip=request.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||request.headers.get('x-real-ip')||'';
  const ua=request.headers.get('user-agent')||'';
  return createHash('sha256').update(`${ip}|${ua}`).digest('hex');
}
function phoneHash(phone:string){
  const secret=process.env.SUPABASE_SERVICE_ROLE_KEY||process.env.NEXT_PUBLIC_SUPABASE_URL||'denthub-recovery';
  return createHmac('sha256',secret).update(phone).digest('hex');
}
function candidates(phone:string){const local=mongolianPhoneDigits(phone);return Array.from(new Set([phone,local,`976${local}`,`+976${local}`]));}
function isProviderError(message:string){const s=message.toLowerCase();return s.includes('sms')||s.includes('provider')||s.includes('phone provider')||s.includes('unsupported phone')||s.includes('not enabled');}

export async function POST(request:NextRequest){
  const admin=getSupabaseAdmin();
  try{
    const body=await request.json();
    const phone=normalizeMongolianPhone(String(body.phone||''));
    const fp=fingerprint(request), ph=phoneHash(phone);
    const since=new Date(Date.now()-15*60*1000).toISOString();
    const [{count:ipCount,error:ipErr},{count:phoneCount,error:phoneErr}]=await Promise.all([
      admin.from('password_recovery_attempts').select('id',{count:'exact',head:true}).eq('fingerprint',fp).gte('created_at',since),
      admin.from('password_recovery_attempts').select('id',{count:'exact',head:true}).eq('phone_hash',ph).gte('created_at',since),
    ]);
    if(ipErr||phoneErr)throw new Error('RECOVERY_MIGRATION_REQUIRED');
    if((ipCount||0)>=8||(phoneCount||0)>=5)return NextResponse.json({error:'Хэт олон код хүссэн байна. 15 минутын дараа дахин оролдоно уу.'},{status:429});

    await admin.from('password_recovery_attempts').insert({fingerprint:fp,phone_hash:ph,event:'request'});
    const {data:profiles,error:profileError}=await admin.from('profiles').select('id,clinic_id,role,phone,active').in('phone',candidates(phone)).limit(3);
    if(profileError)throw profileError;
    const matches=(profiles||[]).filter((p:any)=>p.active!==false && mongolianPhoneDigits(String(p.phone||''))===mongolianPhoneDigits(phone));
    if(matches.length!==1)return NextResponse.json({ok:true,message:GENERIC_MESSAGE});

    const profile:any=matches.at(0);
    if(!profile)return NextResponse.json({ok:true,message:GENERIC_MESSAGE});
    const {data:userData,error:userError}=await admin.auth.admin.getUserById(profile.id);
    if(userError||!userData.user)return NextResponse.json({ok:true,message:GENERIC_MESSAGE});
    if(userData.user.phone!==phone){
      const {error:syncError}=await admin.auth.admin.updateUserById(profile.id,{phone,phone_confirm:true});
      if(syncError){
        await admin.from('password_recovery_attempts').insert({fingerprint:fp,phone_hash:ph,event:'sync_failed'});
        return NextResponse.json({ok:true,message:GENERIC_MESSAGE});
      }
    }

    const publicClient=getSupabasePublicServer();
    const {error:otpError}=await publicClient.auth.signInWithOtp({phone,options:{shouldCreateUser:false}});
    if(otpError){
      await admin.from('password_recovery_attempts').insert({fingerprint:fp,phone_hash:ph,event:'send_failed'});
      if(isProviderError(otpError.message||''))return NextResponse.json({error:'SMS_RECOVERY_NOT_CONFIGURED',message:'SMS сэргээх үйлчилгээ Supabase дээр тохируулагдаагүй байна. Phone Auth + SMS provider-оо идэвхжүүлнэ үү.'},{status:503});
      throw otpError;
    }
    await admin.from('password_recovery_attempts').insert({fingerprint:fp,phone_hash:ph,event:'sent'});
    return NextResponse.json({ok:true,message:GENERIC_MESSAGE});
  }catch(error:any){
    const message=String(error?.message||'Нууц үг сэргээх код илгээж чадсангүй.');
    if(message==='RECOVERY_MIGRATION_REQUIRED')return NextResponse.json({error:'V8.8 migration-ийг Supabase дээр ажиллуулаагүй байна.'},{status:500});
    if(message.includes('Утасны дугаар'))return NextResponse.json({error:message},{status:400});
    return NextResponse.json({error:'Нууц үг сэргээх код илгээж чадсангүй. Дахин оролдоно уу.'},{status:400});
  }
}
