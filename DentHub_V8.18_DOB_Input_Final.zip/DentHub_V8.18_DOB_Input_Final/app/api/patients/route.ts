import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, phoneToInternalEmail, requireApiUser, requireModule } from '@/lib/auth';

function digitsOnly(value:unknown){return String(value??'').replace(/\D/g,'').replace(/^976/,'').slice(0,8)}
function normalizeRegister(value:unknown){return String(value??'').trim().toUpperCase().replace(/\s+/g,'')}
function cleanText(value:unknown,max=2000){return String(value??'').trim().slice(0,max)}
function normalizeGender(value:unknown){const v=String(value??'').trim().toLowerCase();return ['male','female','other','unspecified'].includes(v)?v:null}
function normalizeDateOfBirth(value:unknown){
  const raw=String(value??'').trim();if(!raw)return {value:null as string|null,error:''};
  const digits=raw.replace(/\D/g,'').slice(0,8);if(digits.length!==8)return {value:null,error:'Төрсөн огноог YYYY/MM/DD хэлбэрээр оруулна уу. Жишээ: 2000/08/23'};
  const year=Number(digits.slice(0,4)),month=Number(digits.slice(4,6)),day=Number(digits.slice(6,8));
  const d=new Date(Date.UTC(year,month-1,day));const now=new Date();const today=new Date(Date.UTC(now.getFullYear(),now.getMonth(),now.getDate()));
  if(year<1900||month<1||month>12||day<1||day>31||d.getUTCFullYear()!==year||d.getUTCMonth()!==month-1||d.getUTCDate()!==day||d>today)return {value:null,error:'Төрсөн огноо буруу байна. YYYY/MM/DD хэлбэрээр оруулна уу. Жишээ: 2000/08/23'};
  return {value:`${String(year).padStart(4,'0')}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`,error:''};
}

function isDoctorProfile(profile:any){return profile?.role==='employee'&&(profile?.staff_type==='doctor'||(!profile?.staff_type&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(String(profile?.specialty||''))))}
async function doctorOwnsPatient(admin:any,clinicId:string,doctorId:string,patientId:string){const [a,e]=await Promise.all([admin.from('appointments').select('id').eq('clinic_id',clinicId).eq('patient_id',patientId).eq('doctor_id',doctorId).limit(1),admin.from('encounters').select('id').eq('clinic_id',clinicId).eq('patient_id',patientId).eq('doctor_id',doctorId).limit(1)]);return Boolean(a.data?.length||e.data?.length)}

const patientSelect='id,patient_code,external_patient_id,full_name,phone,register_no,date_of_birth,gender,address,emergency_phone,notes,deleted_at,created_at,user_id,quick_registered';

async function findDuplicate(admin:any,clinicId:string,args:{externalPatientId?:string;registerNo?:string;phone?:string|null;excludeId?:string}){
  const {externalPatientId,registerNo,phone,excludeId}=args;
  if(externalPatientId){
    let q=admin.from('patients').select(patientSelect).eq('clinic_id',clinicId).is('deleted_at',null).ilike('external_patient_id',externalPatientId);
    if(excludeId)q=q.neq('id',excludeId);
    const {data}=await q.limit(1).maybeSingle(); if(data)return data;
  }
  if(registerNo){
    let q=admin.from('patients').select(patientSelect).eq('clinic_id',clinicId).is('deleted_at',null).ilike('register_no',registerNo);
    if(excludeId)q=q.neq('id',excludeId);
    const {data}=await q.limit(1).maybeSingle(); if(data)return data;
  }
  if(phone){
    const digits=digitsOnly(phone);
    for(const candidate of [phone,digits].filter(Boolean)){
      let q=admin.from('patients').select(patientSelect).eq('clinic_id',clinicId).is('deleted_at',null).eq('phone',candidate);
      if(excludeId)q=q.neq('id',excludeId);
      const {data}=await q.limit(1).maybeSingle(); if(data)return data;
    }
  }
  return null;
}

export async function POST(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','employee']);requireModule(auth,'patients');const {profile,admin}=auth;
    if(!profile.clinic_id)return NextResponse.json({error:'Эмнэлгийн холбоос олдсонгүй.'},{status:400});
    const body=await request.json();
    const fullName=cleanText(body.fullName,160);
    const phoneDigits=digitsOnly(body.phone);
    const registerNo=normalizeRegister(body.registerNo);
    const notes=cleanText(body.notes);
    const externalPatientId=cleanText(body.externalPatientId,100);
    const dob=normalizeDateOfBirth(body.dateOfBirth);if(dob.error)return NextResponse.json({error:dob.error},{status:400});const dateOfBirth=dob.value;
    const gender=normalizeGender(body.gender);
    const address=cleanText(body.address,500)||null;
    const emergencyDigits=digitsOnly(body.emergencyPhone);
    if(!fullName)return NextResponse.json({error:'Өвчтөний нэр шаардлагатай.'},{status:400});
    if(body.phone && phoneDigits.length!==8)return NextResponse.json({error:'Утасны дугаар 8 оронтой байна.'},{status:400});
    if(body.emergencyPhone && emergencyDigits.length!==8)return NextResponse.json({error:'Яаралтай үед холбоо барих утас 8 оронтой байна.'},{status:400});
    const phone=phoneDigits?`+976${phoneDigits}`:null;
    const emergencyPhone=emergencyDigits?`+976${emergencyDigits}`:null;

    const existing=await findDuplicate(admin,profile.clinic_id,{externalPatientId,registerNo,phone});
    if(existing){
      return NextResponse.json({
        error:`Энэ өвчтөн аль хэдийн бүртгэлтэй байна${existing.patient_code?` (${existing.patient_code})`:''}. Шинээр давхар үүсгэхийн оронд байгаа бүртгэлийг сонгоно уу.`,
        code:'PATIENT_ALREADY_EXISTS',
        patient:existing,
      },{status:409});
    }

    let linkedUserId:string|null=null;
    if(phone){
      const {data:client}=await admin.from('profiles').select('id').eq('role','client').eq('phone',phone).eq('active',true).maybeSingle();
      linkedUserId=client?.id||null;
    }

    const {data,error}=await admin.from('patients').insert({
      clinic_id:profile.clinic_id,
      user_id:linkedUserId,
      full_name:fullName,
      phone,
      register_no:registerNo||null,
      date_of_birth:dateOfBirth,
      gender,
      address,
      emergency_phone:emergencyPhone,
      notes:notes||null,
      external_patient_id:externalPatientId||null,
      quick_registered:false,
    }).select(patientSelect).single();
    if(error){
      const message=String(error.message||'');
      if(message.includes('DENTHUB_DUPLICATE_PATIENT_PHONE')||message.includes('DENTHUB_DUPLICATE_PATIENT_REGISTER')){
        return NextResponse.json({error:'Энэ өвчтөн аль хэдийн бүртгэлтэй байна. Одоо байгаа өвчтөний бүртгэлийг сонгоно уу.',code:'PATIENT_ALREADY_EXISTS'},{status:409});
      }
      throw error;
    }
    return NextResponse.json({patient:data,linked_account:Boolean(linkedUserId)});
  }catch(error:any){
    const message=error?.message||'Өвчтөн бүртгэж чадсангүй.';
    return NextResponse.json({error:message},{status:(()=>{const x=apiErrorStatus(message);return x===500?400:x})()});
  }
}

export async function PATCH(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','employee']);requireModule(auth,'patients');const {profile,admin}=auth;
    if(!profile.clinic_id)return NextResponse.json({error:'Эмнэлгийн холбоос олдсонгүй.'},{status:400});
    const body=await request.json();
    const id=cleanText(body.id,80);
    if(!id)return NextResponse.json({error:'Өвчтөний ID дутуу байна.'},{status:400});

    const {data:existing,error:findError}=await admin.from('patients').select(patientSelect).eq('id',id).eq('clinic_id',profile.clinic_id).is('deleted_at',null).maybeSingle();
    if(findError)throw findError;
    if(!existing)return NextResponse.json({error:'Өвчтөн олдсонгүй.'},{status:404});
    if(isDoctorProfile(profile)&&!(await doctorOwnsPatient(admin,profile.clinic_id,profile.id,id)))return NextResponse.json({error:'Зөвхөн өөрт оноогдсон өвчтөний мэдээлэлд хандах боломжтой.'},{status:403});

    const fullName=cleanText(body.fullName??existing.full_name,160);
    const rawPhone=body.phone===undefined?existing.phone:body.phone;
    const phoneDigits=digitsOnly(rawPhone);
    const registerNo=body.registerNo===undefined?String(existing.register_no||''):normalizeRegister(body.registerNo);
    const externalPatientId=body.externalPatientId===undefined?String(existing.external_patient_id||''):cleanText(body.externalPatientId,100);
    const rawEmergency=body.emergencyPhone===undefined?existing.emergency_phone:body.emergencyPhone;
    const emergencyDigits=digitsOnly(rawEmergency);
    if(!fullName)return NextResponse.json({error:'Өвчтөний нэр шаардлагатай.'},{status:400});
    if(rawPhone && phoneDigits.length!==8)return NextResponse.json({error:'Утасны дугаар 8 оронтой байна.'},{status:400});
    if(rawEmergency && emergencyDigits.length!==8)return NextResponse.json({error:'Яаралтай үед холбоо барих утас 8 оронтой байна.'},{status:400});
    const phone=phoneDigits?`+976${phoneDigits}`:null;
    const emergencyPhone=emergencyDigits?`+976${emergencyDigits}`:null;

    const duplicate=await findDuplicate(admin,profile.clinic_id,{externalPatientId,registerNo,phone,excludeId:id});
    if(duplicate){
      return NextResponse.json({error:`Ижил утас, регистр эсвэл үйлчлүүлэгчийн ID-тай өөр өвчтөн байна${duplicate.patient_code?` (${duplicate.patient_code})`:''}.`,code:'PATIENT_ALREADY_EXISTS'},{status:409});
    }

    const patch={
      full_name:fullName,
      phone,
      register_no:registerNo||null,
      external_patient_id:externalPatientId||null,
      date_of_birth:body.dateOfBirth===undefined?existing.date_of_birth:(()=>{const dob=normalizeDateOfBirth(body.dateOfBirth);if(dob.error)throw new Error(dob.error);return dob.value})(),
      gender:body.gender===undefined?existing.gender:normalizeGender(body.gender),
      address:body.address===undefined?existing.address:(cleanText(body.address,500)||null),
      emergency_phone:emergencyPhone,
      notes:body.notes===undefined?existing.notes:(cleanText(body.notes)||null),
      quick_registered:false,
    };

    const {data,error}=await admin.from('patients').update(patch).eq('id',id).eq('clinic_id',profile.clinic_id).select(patientSelect).single();
    if(error){
      const message=String(error.message||'');
      if(message.includes('DENTHUB_DUPLICATE_PATIENT_PHONE')||message.includes('DENTHUB_DUPLICATE_PATIENT_REGISTER')){
        return NextResponse.json({error:'Ижил утас эсвэл регистртэй өөр өвчтөн байна.',code:'PATIENT_ALREADY_EXISTS'},{status:409});
      }
      throw error;
    }

    // Keep a linked DentHub patient login in sync when the clinic edits the person's name/phone.
    // Contact/medical fields remain clinic-specific and stay only on the patient record.
    if(existing.user_id){
      const profilePatch={full_name:data.full_name,phone:data.phone};
      const {error:profileError}=await admin.from('profiles').update(profilePatch).eq('id',existing.user_id).eq('role','client');
      if(profileError)throw profileError;
      const authPatch:any={user_metadata:{full_name:data.full_name,phone:data.phone}};
      if(data.phone){const digits=digitsOnly(data.phone);if(digits.length===8)authPatch.email=phoneToInternalEmail(digits)}
      const {error:authError}=await admin.auth.admin.updateUserById(existing.user_id,authPatch);
      if(authError)throw authError;
    }

    return NextResponse.json({ok:true,patient:data});
  }catch(error:any){
    const message=error?.message||'Өвчтөний мэдээлэл шинэчилж чадсангүй.';
    return NextResponse.json({error:message},{status:(()=>{const x=apiErrorStatus(message);return x===500?400:x})()});
  }
}


export async function DELETE(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner']);requireModule(auth,'patients');const {profile,admin}=auth;if(!profile.clinic_id)return NextResponse.json({error:'Эмнэлгийн холбоос олдсонгүй.'},{status:400});
    const body=await request.json();const id=String(body.id||'');if(!id)return NextResponse.json({error:'Өвчтөний ID дутуу байна.'},{status:400});
    const {data:patient,error:findError}=await admin.from('patients').select('id,full_name').eq('id',id).eq('clinic_id',profile.clinic_id).is('deleted_at',null).maybeSingle();if(findError)throw findError;if(!patient)return NextResponse.json({error:'Өвчтөн олдсонгүй.'},{status:404});
    const {error}=await admin.from('patients').update({deleted_at:new Date().toISOString(),deleted_by:profile.id||null}).eq('id',id).eq('clinic_id',profile.clinic_id);if(error)throw error;
    return NextResponse.json({ok:true,patient});
  }catch(error:any){const message=error?.message||'Өвчтөн устгаж чадсангүй.';return NextResponse.json({error:message},{status:(()=>{const x=apiErrorStatus(message);return x===500?400:x})()})}
}
