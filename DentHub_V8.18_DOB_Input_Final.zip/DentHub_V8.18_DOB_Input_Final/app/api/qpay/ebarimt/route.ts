import { NextRequest, NextResponse } from 'next/server';
import { createQPayEbarimt, qpayDemoMode } from '@/lib/qpay';
import { apiErrorStatus, requireApiUser, requireModule } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['platform_admin', 'owner', 'employee']);
    requireModule(auth, 'payments');
    const body = await request.json();
    if (!body.paymentId) return NextResponse.json({ error: 'paymentId шаардлагатай.' }, { status: 400 });
    if (qpayDemoMode()) {
      return NextResponse.json({ demo: true, ebarimt_lottery: 'DEMO-12345678', ebarimt_qr_data: 'DEMO-EBARIMT' });
    }
    const receipt = await createQPayEbarimt({
      paymentId: body.paymentId,
      receiverType: body.receiverType === 'COMPANY' ? 'COMPANY' : 'CITIZEN',
      receiver: body.receiver,
      districtCode: body.districtCode,
      classificationCode: body.classificationCode,
    });
    return NextResponse.json(receipt);
  } catch (error: any) {
    const message = error?.message || 'eBarimt үүсгэхэд алдаа гарлаа.';
    const status = apiErrorStatus(message);
    return NextResponse.json({ error: message }, { status });
  }
}
