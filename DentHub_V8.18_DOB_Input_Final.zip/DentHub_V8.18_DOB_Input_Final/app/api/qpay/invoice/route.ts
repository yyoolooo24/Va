import { NextRequest, NextResponse } from 'next/server';
import { createQPayInvoice, qpayDemoMode } from '@/lib/qpay';
import { apiErrorStatus, requireApiUser, requireModule } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    let clinicId: string | null = null;
    let userId: string | null = null;
    let admin: any = null;
    let role: string | null = null;
    try {
      const auth = await requireApiUser(request, ['platform_admin', 'owner', 'employee']);
      requireModule(auth, 'payments');
      clinicId = auth.profile.clinic_id;userId = auth.user.id;admin = auth.admin;role=auth.profile.role;
    } catch (error) {
      if (process.env.NEXT_PUBLIC_DEMO_MODE !== 'true') throw error;
    }

    const body = await request.json();
    const amount = Number(body.amount);
    if (!Number.isFinite(amount) || amount <= 0) return NextResponse.json({ error: 'Төлбөрийн дүн буруу байна.' }, { status: 400 });

    let patientId:string|null=body.patientId?String(body.patientId):null;
    let encounterId:string|null=body.encounterId?String(body.encounterId):null;
    let patientCode:string|null=null;
    if(admin&&clinicId&&['owner','employee'].includes(role||'')){
      if(!patientId)return NextResponse.json({error:'Өвчтөн сонгоно уу.'},{status:400});
      const {data:patient,error:patientError}=await admin.from('patients').select('id,patient_code').eq('id',patientId).eq('clinic_id',clinicId).maybeSingle();
      if(patientError)throw patientError;if(!patient)return NextResponse.json({error:'Сонгосон өвчтөн олдсонгүй.'},{status:400});
      patientCode=patient.patient_code||null;
      if(encounterId){
        const {data:encounter,error:encounterError}=await admin.from('encounters').select('id,patient_id').eq('id',encounterId).eq('clinic_id',clinicId).is('deleted_at',null).maybeSingle();
        if(encounterError)throw encounterError;
        if(!encounter||encounter.patient_id!==patientId)return NextResponse.json({error:'Үзлэгийн төлбөрийн холбоос буруу байна.'},{status:400});
      }
    }

    const senderInvoiceNo = body.senderInvoiceNo || `DENTHUB-${Date.now()}-${Math.floor(Math.random() * 9000 + 1000)}`;
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || request.nextUrl.origin;

    if (qpayDemoMode()) {
      const demoId=`demo_${Date.now()}`;
      if(admin&&clinicId){
        await admin.from('qpay_invoices').insert({clinic_id:clinicId,patient_id:patientId,encounter_id:encounterId,patient_code_snapshot:patientCode,created_by:userId,sender_invoice_no:senderInvoiceNo,qpay_invoice_id:demoId,amount:Math.round(amount),description:body.description||'DentHub төлбөр',status:'PENDING',request_ebarimt:Boolean(body.requestEbarimt),ebarimt_receiver_type:body.ebarimtReceiverType||null,ebarimt_receiver:body.ebarimtReceiver||null});
      }
      return NextResponse.json({demo:true,patient_code:patientCode,sender_invoice_no:senderInvoiceNo,invoice_id:demoId,qr_text:`QPAY-DEMO:${senderInvoiceNo}:${Math.round(amount)}`,qr_image:null,qPay_shortUrl:null,qpay_urls:[]});
    }

    const invoice = await createQPayInvoice({senderInvoiceNo,amount,description:body.description || 'DentHub төлбөр',receiverCode:body.receiverCode,callbackUrl:`${appUrl}/api/qpay/callback?ref=${encodeURIComponent(senderInvoiceNo)}`});

    if (admin && invoice?.invoice_id) {
      await admin.from('qpay_invoices').insert({clinic_id:clinicId,patient_id:patientId,encounter_id:encounterId,patient_code_snapshot:patientCode,created_by:userId,sender_invoice_no:senderInvoiceNo,qpay_invoice_id:invoice.invoice_id,amount:Math.round(amount),description:body.description||'DentHub төлбөр',status:'PENDING',request_ebarimt:Boolean(body.requestEbarimt),ebarimt_receiver_type:body.ebarimtReceiverType||null,ebarimt_receiver:body.ebarimtReceiver||null});
    }
    return NextResponse.json({...invoice,patient_code:patientCode,sender_invoice_no:senderInvoiceNo});
  } catch (error: any) {
    const message = error?.message || 'QPay invoice үүсгэхэд алдаа гарлаа.';
    return NextResponse.json({ error: message }, { status: apiErrorStatus(message) });
  }
}
