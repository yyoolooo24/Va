import { NextRequest, NextResponse } from 'next/server';
import { checkQPayPayment, createQPayEbarimt, qpayDemoMode } from '@/lib/qpay';
import { getSupabaseAdmin } from '@/lib/supabase-admin';

async function handle(request: NextRequest) {
  try {
    if (qpayDemoMode()) return new NextResponse('SUCCESS', { status: 200 });

    const ref = request.nextUrl.searchParams.get('ref');
    if (!ref) return new NextResponse('MISSING_REF', { status: 400 });

    const admin = getSupabaseAdmin();
    const { data: row, error } = await admin
      .from('qpay_invoices')
      .select('*')
      .eq('sender_invoice_no', ref)
      .single();
    if (error || !row) return new NextResponse('NOT_FOUND', { status: 404 });

    const checked = await checkQPayPayment(row.qpay_invoice_id);
    const rows = checked?.rows || checked?.data?.rows || [];
    const paid = rows.find((item: any) => String(item.payment_status || item.status || '').toUpperCase() === 'PAID') || rows.at(0);

    if (paid?.payment_id) {
      let ebarimt: any = null;
      if (row.request_ebarimt) {
        try {
          ebarimt = await createQPayEbarimt({
            paymentId: paid.payment_id,
            receiverType: row.ebarimt_receiver_type === 'COMPANY' ? 'COMPANY' : 'CITIZEN',
            receiver: row.ebarimt_receiver || undefined,
          });
        } catch (e) {
          console.error('eBarimt create failed', e);
        }
      }

      let financeTransactionId=row.finance_transaction_id||null;
      if(!financeTransactionId&&row.clinic_id){
        const {data:method}=await admin.from('payment_methods').select('id,name').eq('clinic_id',row.clinic_id).eq('code','qpay').eq('active',true).maybeSingle();
        const {data:finance,error:financeError}=await admin.from('finance_transactions').insert({clinic_id:row.clinic_id,created_by:row.created_by||null,kind:'income',description:row.description||'QPay төлбөр',amount:Math.round(Number(row.amount||0)),payment_method:method?.name||'QPay',patient_id:row.patient_id||null,encounter_id:row.encounter_id||null,request_ebarimt:Boolean(row.request_ebarimt),ebarimt_receiver_type:row.ebarimt_receiver_type||null,ebarimt_receiver:row.ebarimt_receiver||null,receipt_reference:ebarimt?String(ebarimt.ebarimt_lottery||ebarimt.lottery||ebarimt.receipt_id||ebarimt.id||ebarimt.billId||ebarimt.bill_id||''):null}).select('id').single();
        if(financeError)throw financeError;financeTransactionId=finance.id;
        if(row.encounter_id&&row.patient_id){
          const {data:existingPayment}=await admin.from('encounter_payments').select('id').eq('finance_transaction_id',financeTransactionId).maybeSingle();
          if(!existingPayment){await admin.from('encounter_payments').insert({clinic_id:row.clinic_id,encounter_id:row.encounter_id,patient_id:row.patient_id,amount:Number(row.amount||0),payment_method_id:method?.id||null,payment_method_name:method?.name||'QPay',note:'QPay',finance_transaction_id:financeTransactionId,created_by:row.created_by||null});}
          const [{data:encounter},{data:payments}]=await Promise.all([admin.from('encounters').select('total_amount').eq('id',row.encounter_id).maybeSingle(),admin.from('encounter_payments').select('amount').eq('encounter_id',row.encounter_id)]);
          const total=Number(encounter?.total_amount||0);const paidTotal=(payments||[]).reduce((sum:number,item:any)=>sum+Number(item.amount||0),0);const billingStatus=total<=0?'no_charge':paidTotal>=total?'paid':paidTotal>0?'partial':'unpaid';
          await admin.from('encounters').update({paid_amount:paidTotal,billing_status:billingStatus}).eq('id',row.encounter_id);
        }
      }

      if(financeTransactionId){await admin.from('finance_transactions').update({request_ebarimt:Boolean(row.request_ebarimt),ebarimt_receiver_type:row.ebarimt_receiver_type||null,ebarimt_receiver:row.ebarimt_receiver||null,receipt_reference:ebarimt?String(ebarimt.ebarimt_lottery||ebarimt.lottery||ebarimt.receipt_id||ebarimt.id||ebarimt.billId||ebarimt.bill_id||''):null}).eq('id',financeTransactionId);}

      await admin.from('qpay_invoices').update({
        status: 'PAID',
        payment_id: paid.payment_id,
        paid_at: new Date().toISOString(),
        ebarimt_payload: ebarimt,
        finance_transaction_id: financeTransactionId,
      }).eq('id', row.id);
    }

    return new NextResponse('SUCCESS', { status: 200 });
  } catch (error) {
    console.error(error);
    return new NextResponse('ERROR', { status: 500 });
  }
}

export async function GET(request: NextRequest) { return handle(request); }
export async function POST(request: NextRequest) { return handle(request); }
