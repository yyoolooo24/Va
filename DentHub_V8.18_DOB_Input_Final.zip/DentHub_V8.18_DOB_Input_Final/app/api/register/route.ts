import { NextRequest, NextResponse } from 'next/server';
import { createHash } from 'node:crypto';
import { getSupabaseAdmin } from '@/lib/supabase-admin';
import { normalizeMongolianPhone, phoneToInternalEmail } from '@/lib/auth';

function clean(value: unknown) {
  return String(value ?? '').trim();
}

function slugify(value: string) {
  const base = value.toLowerCase().trim().replace(/[^a-z0-9а-яөүё]+/gi, '-').replace(/^-|-$/g, '') || 'clinic';
  return `${base}-${Math.random().toString(36).slice(2, 7)}`;
}

function requestFingerprint(request: NextRequest) {
  const forwarded = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || '';
  const realIp = request.headers.get('x-real-ip') || '';
  const ua = request.headers.get('user-agent') || '';
  return createHash('sha256').update(`${forwarded}|${realIp}|${ua}`).digest('hex');
}

export async function POST(request: NextRequest) {
  const admin = getSupabaseAdmin();
  let authUserId: string | null = null;
  let clinicId: string | null = null;
  try {
    const body = await request.json();
    const accountType = clean(body.accountType);
    const fullName = clean(body.fullName);
    const phoneInput = clean(body.phone);
    const password = clean(body.password);
    const clinicName = clean(body.clinicName);
    const companyName = clean(body.companyName);

    if (!['clinic', 'patient', 'supplier'].includes(accountType)) {
      return NextResponse.json({ error: 'Бүртгэлийн төрөл буруу байна.' }, { status: 400 });
    }
    if (!fullName || !phoneInput || !password) {
      return NextResponse.json({ error: 'Нэр, утас, нууц үгээ бүрэн оруулна уу.' }, { status: 400 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: 'Нууц үг хамгийн багадаа 8 тэмдэгт байна.' }, { status: 400 });
    }
    const digits = phoneInput.replace(/\D/g, '').replace(/^976/, '');
    if (digits.length !== 8) {
      return NextResponse.json({ error: 'Монголын 8 оронтой утасны дугаар оруулна уу.' }, { status: 400 });
    }
    if (accountType === 'clinic' && !clinicName) {
      return NextResponse.json({ error: 'Эмнэлгийн нэр оруулна уу.' }, { status: 400 });
    }
    if (accountType === 'supplier' && !companyName) {
      return NextResponse.json({ error: 'Байгууллагын нэр оруулна уу.' }, { status: 400 });
    }

    const phone = normalizeMongolianPhone(phoneInput);
    const email = phoneToInternalEmail(phoneInput);

    // Shared database-backed throttle works consistently across Vercel instances.
    const fingerprint = requestFingerprint(request);
    const since = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    const { count } = await admin
      .from('registration_attempts')
      .select('id', { count: 'exact', head: true })
      .eq('fingerprint', fingerprint)
      .gte('created_at', since);
    if ((count || 0) >= 8) {
      return NextResponse.json({ error: 'Хэт олон бүртгэлийн оролдлого хийсэн байна. 15 минутын дараа дахин оролдоно уу.' }, { status: 429 });
    }
    await admin.from('registration_attempts').insert({ fingerprint, account_type: accountType });

    if (accountType === 'clinic') {
      const { data: clinic, error: clinicError } = await admin.from('clinics').insert({
        name: clinicName,
        slug: slugify(clinicName),
        plan: 'START',
        status: 'pending',
        enabled_modules: [],
        employee_limit: 5,
      }).select('id,name').single();
      if (clinicError || !clinic) throw clinicError || new Error('Эмнэлэг үүсгэж чадсангүй.');
      clinicId = clinic.id;
    }

    const { data: created, error: createError } = await admin.auth.admin.createUser({
      email,
      phone,
      password,
      email_confirm: true,
      user_metadata: { full_name: fullName, phone, account_type: accountType },
    });
    if (createError || !created.user) throw createError || new Error('Хэрэглэгч үүсгэж чадсангүй.');
    authUserId = created.user.id;

    const role = accountType === 'clinic' ? 'owner' : accountType === 'patient' ? 'client' : 'supplier';
    const { error: profileError } = await admin.from('profiles').insert({
      id: authUserId,
      clinic_id: clinicId,
      role,
      full_name: fullName,
      phone,
      language: 'mn',
      active: true,
    });
    if (profileError) throw profileError;

    if (accountType === 'supplier') {
      const { error: supplierError } = await admin.from('supplier_profiles').insert({
        user_id: authUserId,
        company_name: companyName,
        contact_name: fullName,
        city: clean(body.city) || 'Улаанбаатар',
      });
      if (supplierError) throw supplierError;
    }

    if (accountType === 'clinic' && clinicId) {
      await admin.from('platform_audit_log').insert({
        actor_id: authUserId,
        clinic_id: clinicId,
        action: 'clinic_registration_requested',
        target_type: 'clinic',
        target_id: clinicId,
        metadata: { clinic_name: clinicName, owner_name: fullName },
      });
    }

    return NextResponse.json({
      ok: true,
      role,
      phone,
      approvalRequired: accountType === 'clinic',
      message: accountType === 'clinic' ? 'Бүртгэлийн хүсэлт илгээгдлээ. DentHub системийн админ зөвшөөрсний дараа эмнэлгийн ажлын орчин идэвхжинэ.' : undefined,
    });
  } catch (error: any) {
    if (authUserId) await admin.auth.admin.deleteUser(authUserId).catch(() => undefined);
    if (clinicId) await admin.from('clinics').delete().eq('id', clinicId);
    let message = error?.message || 'Бүртгэхэд алдаа гарлаа.';
    const lower = message.toLowerCase();
    if (lower.includes('already') || lower.includes('registered') || lower.includes('unique')) message = 'Энэ утасны дугаартай бүртгэл аль хэдийн байна.';
    if (lower.includes('registration_attempts') || lower.includes('enabled_modules')) message = 'Supabase дээр supabase/v8_7_subscription_platform_security.sql migration-ийг эхлээд ажиллуулна уу.';
    if (lower.includes('profiles_role_check')) message = 'Supabase дээр v7_3_registration_upgrade.sql файлыг эхлээд ажиллуулна уу.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
