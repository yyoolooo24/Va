import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, requireApiUser } from '@/lib/auth';

function safeName(value: unknown) {
  return String(value || '').trim().slice(0, 120);
}

export async function POST(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['owner']);
    const clinicId = String(auth.profile.clinic_id || '');
    if (!clinicId) return NextResponse.json({ error: 'Эмнэлгийн бүртгэл олдсонгүй.' }, { status: 404 });

    const form = await request.formData();
    const file = form.get('file');
    if (!(file instanceof File)) return NextResponse.json({ error: 'Лого зураг сонгоно уу.' }, { status: 400 });
    if (file.size > 2 * 1024 * 1024) return NextResponse.json({ error: 'Лого 2 MB-аас бага хэмжээтэй байна.' }, { status: 400 });
    const allowed = new Map([
      ['image/png', 'png'],
      ['image/jpeg', 'jpg'],
      ['image/webp', 'webp'],
    ]);
    const ext = allowed.get(file.type);
    if (!ext) return NextResponse.json({ error: 'PNG, JPG эсвэл WEBP зураг сонгоно уу.' }, { status: 400 });

    const path = `${clinicId}/clinic-logo.${ext}`;
    const bytes = Buffer.from(await file.arrayBuffer());
    const { error: uploadError } = await auth.admin.storage.from('clinic-logos').upload(path, bytes, {
      upsert: true,
      cacheControl: '3600',
      contentType: file.type,
    });
    if (uploadError) throw uploadError;

    const { data } = auth.admin.storage.from('clinic-logos').getPublicUrl(path);
    const publicUrl = `${data.publicUrl}?v=${Date.now()}`;
    const { error: updateError } = await auth.admin.from('clinics').update({ logo_url: publicUrl }).eq('id', clinicId);
    if (updateError) throw updateError;
    await auth.admin.from('platform_audit_log').insert({
      actor_id: auth.user.id,
      clinic_id: clinicId,
      action: 'clinic_branding_logo_updated',
      target_type: 'clinic',
      target_id: clinicId,
      metadata: { path },
    });
    return NextResponse.json({ logoUrl: publicUrl });
  } catch (error: any) {
    const message = error?.message || 'Лого хадгалж чадсангүй.';
    return NextResponse.json({ error: message }, { status: apiErrorStatus(message) });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['owner']);
    const clinicId = String(auth.profile.clinic_id || '');
    if (!clinicId) return NextResponse.json({ error: 'Эмнэлгийн бүртгэл олдсонгүй.' }, { status: 404 });
    const body = await request.json();
    const name = safeName(body.name);
    if (!name) return NextResponse.json({ error: 'Эмнэлгийн нэр оруулна уу.' }, { status: 400 });
    const { error } = await auth.admin.from('clinics').update({ name }).eq('id', clinicId);
    if (error) throw error;
    await auth.admin.from('platform_audit_log').insert({ actor_id: auth.user.id, clinic_id: clinicId, action: 'clinic_branding_name_updated', target_type: 'clinic', target_id: clinicId, metadata: { name } });
    return NextResponse.json({ name });
  } catch (error: any) {
    const message = error?.message || 'Эмнэлгийн нэр хадгалж чадсангүй.';
    return NextResponse.json({ error: message }, { status: apiErrorStatus(message) });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['owner']);
    const clinicId = String(auth.profile.clinic_id || '');
    if (!clinicId) return NextResponse.json({ error: 'Эмнэлгийн бүртгэл олдсонгүй.' }, { status: 404 });

    const { data: objects } = await auth.admin.storage.from('clinic-logos').list(clinicId, { limit: 20 });
    for (const object of objects || []) {
      if (object.name?.startsWith('clinic-logo.')) await auth.admin.storage.from('clinic-logos').remove([`${clinicId}/${object.name}`]);
    }
    const { error } = await auth.admin.from('clinics').update({ logo_url: null }).eq('id', clinicId);
    if (error) throw error;
    await auth.admin.from('platform_audit_log').insert({ actor_id: auth.user.id, clinic_id: clinicId, action: 'clinic_branding_logo_removed', target_type: 'clinic', target_id: clinicId });
    return NextResponse.json({ ok: true });
  } catch (error: any) {
    const message = error?.message || 'Лого арилгаж чадсангүй.';
    return NextResponse.json({ error: message }, { status: apiErrorStatus(message) });
  }
}
