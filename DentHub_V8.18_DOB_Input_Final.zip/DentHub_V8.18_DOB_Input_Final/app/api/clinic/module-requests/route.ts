import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, requireApiUser } from '@/lib/auth';

function sanitize(value: unknown) {
  return Array.isArray(value) ? Array.from(new Set(value.map(String).filter(x => /^[a-z_]+$/.test(x)))).slice(0, 40) : [];
}

export async function GET(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['owner']);
    const { data, error } = await auth.admin.from('clinic_module_requests').select('*').eq('clinic_id', auth.profile.clinic_id).order('created_at', { ascending: false }).limit(30);
    if (error) throw error;
    return NextResponse.json({ rows: data || [] });
  } catch (error: any) {
    const message = error?.message || 'Хүсэлт ачаалж чадсангүй.';
    return NextResponse.json({ error: message }, { status: apiErrorStatus(message) });
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['owner']);
    const body = await request.json();
    const requested = sanitize(body.modules).filter(x => !auth.clinic?.enabled_modules?.includes(x));
    if (!requested.length) return NextResponse.json({ error: 'Шинээр хүсэх модуль сонгоно уу.' }, { status: 400 });
    const { data: existing } = await auth.admin.from('clinic_module_requests').select('id,modules').eq('clinic_id', auth.profile.clinic_id).eq('status', 'pending').limit(1).maybeSingle();
    if (existing) return NextResponse.json({ error: 'Танай clinic-д шийдэгдээгүй module хүсэлт байна.' }, { status: 409 });
    const { data, error } = await auth.admin.from('clinic_module_requests').insert({ clinic_id: auth.profile.clinic_id, requested_by: auth.user.id, modules: requested, note: String(body.note || '').trim() || null }).select().single();
    if (error) throw error;
    await auth.admin.from('platform_audit_log').insert({ actor_id: auth.user.id, clinic_id: auth.profile.clinic_id, action: 'module_access_requested', target_type: 'module_request', target_id: data.id, metadata: { modules: requested } });
    return NextResponse.json({ ok: true, request: data });
  } catch (error: any) {
    const message = error?.message || 'Module хүсэлт илгээж чадсангүй.';
    return NextResponse.json({ error: message }, { status: apiErrorStatus(message) });
  }
}
