import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, requireApiUser, requireModule } from '@/lib/auth';

function optionalSchemaError(error:any){return ['42703','42P01','PGRST204','PGRST205'].includes(String(error?.code||''))}
function isDoctorProfile(profile:any){return profile?.role==='employee'&&(profile?.staff_type==='doctor'||(!profile?.staff_type&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(String(profile?.specialty||''))))}

async function loadEncounters(admin:any,clinicId:string,patientId?:string,doctorId?:string){
  const full='id,appointment_id,patient_id,doctor_id,diagnosis,treatment_plan,notes,selected_teeth,dentition,status,deleted_at,created_at,patients(full_name,phone),doctor:profiles!encounters_doctor_id_fkey(full_name),treatment_lines:encounter_treatments(id,tooth_no,service_name,notes,unit_price,total_amount,created_at)';
  let q=admin.from('encounters').select(full).eq('clinic_id',clinicId);
  if(patientId)q=q.eq('patient_id',patientId);
  if(doctorId)q=q.eq('doctor_id',doctorId);
  let res=await q.order('created_at',{ascending:false}).limit(1000);
  if(!res.error)return res.data||[];
  if(!optionalSchemaError(res.error))throw res.error;
  const simple='id,appointment_id,patient_id,doctor_id,diagnosis,treatment_plan,notes,selected_teeth,dentition,status,created_at,patients(full_name,phone),doctor:profiles!encounters_doctor_id_fkey(full_name),treatment_lines:encounter_treatments(id,tooth_no,service_name,notes,created_at)';
  q=admin.from('encounters').select(simple).eq('clinic_id',clinicId);
  if(patientId)q=q.eq('patient_id',patientId);
  if(doctorId)q=q.eq('doctor_id',doctorId);
  res=await q.order('created_at',{ascending:false}).limit(1000);
  if(res.error)throw res.error;
  return (res.data||[]).map((x:any)=>({...x,deleted_at:null}));
}

async function loadCompletedAppointments(admin:any,clinicId:string,patientId?:string,doctorId?:string){
  const full='id,patient_id,doctor_id,service_name,service_request,clinical_summary,notes,status,starts_at,history_hidden_at,patients(full_name,phone),doctor:profiles!appointments_doctor_id_fkey(full_name)';
  let q=admin.from('appointments').select(full).eq('clinic_id',clinicId).in('status',['completed','done']).is('history_hidden_at',null);
  if(patientId)q=q.eq('patient_id',patientId);
  if(doctorId)q=q.eq('doctor_id',doctorId);
  let res=await q.order('starts_at',{ascending:false}).limit(1000);
  if(!res.error)return res.data||[];
  if(!optionalSchemaError(res.error))throw res.error;
  let fallback=admin.from('appointments')
    .select('id,patient_id,doctor_id,service_name,service_request,clinical_summary,notes,status,starts_at,patients(full_name,phone),doctor:profiles!appointments_doctor_id_fkey(full_name)')
    .eq('clinic_id',clinicId).in('status',['completed','done']);
  if(patientId)fallback=fallback.eq('patient_id',patientId);
  if(doctorId)fallback=fallback.eq('doctor_id',doctorId);
  const fr=await fallback.order('starts_at',{ascending:false}).limit(1000);
  if(fr.error)throw fr.error;
  return fr.data||[];
}

export async function GET(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['owner','employee']); requireModule(auth, 'treatment_history'); const { profile, admin } = auth;
    const clinicId = profile.clinic_id;
    if (!clinicId) return NextResponse.json({ items: [] });
    const patientId=String(request.nextUrl.searchParams.get('patientId')||'').trim();
    const doctorId=isDoctorProfile(profile)?String(profile.id):undefined;

    if(patientId){
      const {data:patient}=await admin.from('patients').select('id').eq('id',patientId).eq('clinic_id',clinicId).is('deleted_at',null).maybeSingle();
      if(!patient)return NextResponse.json({items:[]});
      if(doctorId){
        const [a,e]=await Promise.all([
          admin.from('appointments').select('id').eq('clinic_id',clinicId).eq('patient_id',patientId).eq('doctor_id',doctorId).limit(1),
          admin.from('encounters').select('id').eq('clinic_id',clinicId).eq('patient_id',patientId).eq('doctor_id',doctorId).limit(1),
        ]);
        if(!(a.data?.length||e.data?.length))return NextResponse.json({items:[]});
      }
    }

    const [allEncounters,appointmentsRaw] = await Promise.all([
      loadEncounters(admin,clinicId,patientId||undefined,doctorId),
      loadCompletedAppointments(admin,clinicId,patientId||undefined,doctorId),
    ]);

    const encounters=(allEncounters||[]).filter((x:any)=>!x.deleted_at&&x.status!=='history_deleted').map((x:any)=>({
      id:`enc-${x.id}`,source:'encounter',date:x.created_at,patient_id:x.patient_id,patient_name:x.patients?.full_name||'Өвчтөн',phone:x.patients?.phone||null,doctor_name:x.doctor?.full_name||null,
      title:x.diagnosis||x.treatment_plan||'Үзлэг, эмчилгээ',diagnosis:x.diagnosis||null,treatment_plan:x.treatment_plan||null,notes:x.notes||null,selected_teeth:x.selected_teeth||[],dentition:x.dentition||'adult',status:x.status,treatment_lines:x.treatment_lines||[],appointment_id:x.appointment_id||null,
    }));
    const appointments=(appointmentsRaw||[]).map((x:any)=>({
      id:`apt-${x.id}`,source:'appointment',date:x.starts_at,patient_id:x.patient_id,patient_name:x.patients?.full_name||'Өвчтөн',phone:x.patients?.phone||null,doctor_name:x.doctor?.full_name||null,
      title:x.service_name||'Эмчилгээ',diagnosis:x.clinical_summary||null,treatment_plan:x.service_name||null,notes:x.notes||null,patient_request:x.service_request||null,status:x.status,
    }));
    const linkedAppointmentIds=new Set((allEncounters||[]).map((x:any)=>x.appointment_id).filter(Boolean).map(String));
    const fallbackAppointments=appointments.filter((x:any)=>!linkedAppointmentIds.has(String(x.id).replace(/^apt-/,'')));
    const items=[...encounters,...fallbackAppointments].sort((a,b)=>+new Date(b.date)-+new Date(a.date));
    return NextResponse.json({items});
  } catch (error:any) {
    const message=error?.message||'Эмчилгээний түүх ачаалж чадсангүй.';
    return NextResponse.json({error:message},{status:(()=>{const x=apiErrorStatus(message);return x===500?400:x})()});
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['owner','employee']); requireModule(auth, 'treatment_history'); const { profile, admin } = auth;
    const clinicId=profile.clinic_id;if(!clinicId)throw new Error('FORBIDDEN');
    const body=await request.json();
    const source=String(body.source||'encounter');
    const rawId=String(body.id||'').replace(/^(enc|apt)-/,'');
    if(!rawId)throw new Error('ID_MISSING');
    const doctorId=isDoctorProfile(profile)?String(profile.id):null;

    if(source==='appointment'){
      let q=admin.from('appointments').select('id,doctor_id').eq('id',rawId).eq('clinic_id',clinicId);
      if(doctorId)q=q.eq('doctor_id',doctorId);
      const {data:apt,error:findError}=await q.maybeSingle();
      if(findError)throw findError;if(!apt)throw new Error('APPOINTMENT_NOT_FOUND');

      let result=await admin.from('appointments').update({history_hidden_at:new Date().toISOString(),history_hidden_by:profile.id}).eq('id',rawId).eq('clinic_id',clinicId);
      if(result.error&&optionalSchemaError(result.error)){
        result=await admin.from('appointments').delete().eq('id',rawId).eq('clinic_id',clinicId).in('status',['completed','done']);
      }
      if(result.error)throw result.error;
      return NextResponse.json({ok:true,id:rawId,source:'appointment'});
    }

    let eq=admin.from('encounters').select('id,doctor_id').eq('id',rawId).eq('clinic_id',clinicId);
    if(doctorId)eq=eq.eq('doctor_id',doctorId);
    const {data:enc,error:findError}=await eq.maybeSingle();if(findError)throw findError;
    if(!enc)throw new Error('ENCOUNTER_NOT_FOUND');
    let result=await admin.from('encounters').update({deleted_at:new Date().toISOString(),deleted_by:profile.id,status:'history_deleted'}).eq('id',rawId).eq('clinic_id',clinicId);
    if(result.error&&optionalSchemaError(result.error)) result=await admin.from('encounters').update({status:'history_deleted'}).eq('id',rawId).eq('clinic_id',clinicId);
    if(result.error)throw result.error;
    return NextResponse.json({ok:true,id:rawId,source:'encounter'});
  } catch(error:any){
    const message=error?.message||'Эмчилгээний түүх устгаж чадсангүй.';
    return NextResponse.json({error:message},{status:(()=>{const x=apiErrorStatus(message);return x===500?400:x})()});
  }
}
