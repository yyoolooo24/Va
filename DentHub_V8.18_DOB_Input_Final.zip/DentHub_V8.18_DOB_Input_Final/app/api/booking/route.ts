import { NextRequest, NextResponse } from 'next/server';
import { requireApiUser } from '@/lib/auth';

function fail(error: unknown, status = 400) {
  const message = error instanceof Error ? error.message : 'Unknown error';
  const map: Record<string,string> = {UNAUTHORIZED:'Нэвтрэх эрх дууссан байна. Дахин нэвтэрнэ үү.',FORBIDDEN:'Энэ үйлдлийг хийх эрхгүй байна.',ACCOUNT_DISABLED:'Таны бүртгэл идэвхгүй байна.',PROFILE_NOT_FOUND:'Хэрэглэгчийн мэдээлэл олдсонгүй.'};
  return NextResponse.json({ error: map[message] || message }, { status: message==='UNAUTHORIZED'?401:message==='FORBIDDEN'?403:status });
}


function clinicAcceptsAppointments(clinic:any){
  if(!clinic||!['active','trial'].includes(String(clinic.status||'')))return false;
  if(!Array.isArray(clinic.enabled_modules)||!clinic.enabled_modules.includes('appointments'))return false;
  const now=Date.now();
  const end=clinic.subscription_ends_at?new Date(clinic.subscription_ends_at).getTime():0;
  const grace=clinic.grace_ends_at?new Date(clinic.grace_ends_at).getTime():0;
  const trial=clinic.trial_ends_at?new Date(clinic.trial_ends_at).getTime():0;
  if(end&&end<now&&(!grace||grace<now))return false;
  if(clinic.status==='trial'&&trial&&trial<now)return false;
  return true;
}

function phoneCandidates(raw?: string | null){
  const digits=String(raw||'').replace(/\D/g,'');
  const local=digits.slice(-8);
  return Array.from(new Set([String(raw||'').trim(),local,local?`+976${local}`:''].filter(Boolean)));
}
async function ensureClientPatientLinks(admin:any,profile:any){
  const linkedRes=await admin.from('patients').select('id,clinic_id,user_id,phone').eq('user_id',profile.id).is('deleted_at',null);
  if(linkedRes.error)throw linkedRes.error;
  const byId=new Map((linkedRes.data||[]).map((p:any)=>[p.id,p]));
  const phones=phoneCandidates(profile.phone);
  if(phones.length){
    const matchRes=await admin.from('patients').select('id,clinic_id,user_id,phone').in('phone',phones).is('deleted_at',null);
    if(matchRes.error)throw matchRes.error;
    for(const patient of matchRes.data||[]){
      if(patient.user_id && patient.user_id!==profile.id)continue;
      if(!patient.user_id){
        const updateRes=await admin.from('patients').update({user_id:profile.id}).eq('id',patient.id).is('user_id',null);
        if(updateRes.error)throw updateRes.error;
      }
      byId.set(patient.id,{...patient,user_id:profile.id});
    }
  }
  return Array.from(byId.values());
}

export async function GET(request: NextRequest) {
  try {
    const { profile, admin } = await requireApiUser(request, ['client']);
    const { data: clinicRows, error: clinicError } = await admin.from('clinics').select('id,name,status,enabled_modules,subscription_ends_at,trial_ends_at,grace_ends_at').in('status',['active','trial']).order('name');
    const clinics=(clinicRows||[]).filter(clinicAcceptsAppointments);
    if (clinicError) throw clinicError;
    const clinicIds=(clinics||[]).map((c:any)=>c.id);
    const [serviceRes,doctorRes,availabilityRes,hoursRes,holidaysRes]=clinicIds.length?await Promise.all([
      admin.from('services').select('id,clinic_id,name,category,subcategory,duration_minutes').in('clinic_id',clinicIds).eq('active',true).order('name'),
      admin.from('profiles').select('id,clinic_id,full_name').in('clinic_id',clinicIds).in('role',['owner','employee']).eq('active',true).order('full_name'),
      admin.from('doctor_availability').select('clinic_id,doctor_id,weekday,start_time,end_time,slot_minutes,max_parallel,active').in('clinic_id',clinicIds),
      admin.from('clinic_business_hours').select('clinic_id,weekday,start_time,end_time,active').in('clinic_id',clinicIds),
      admin.from('clinic_holidays').select('clinic_id,holiday_date,name').in('clinic_id',clinicIds).gte('holiday_date',new Date().toISOString().slice(0,10)),
    ]):[{data:[]},{data:[]},{data:[]},{data:[]},{data:[]}];
    const patients=await ensureClientPatientLinks(admin,profile);
    const patientIds=(patients||[]).map((p:any)=>p.id); let appointments:any[]=[];
    if(patientIds.length){const {data,error}=await admin.from('appointments').select('id,clinic_id,patient_id,doctor_id,starts_at,ends_at,service_name,service_request,room,status,created_at').in('patient_id',patientIds).order('starts_at').limit(150);if(error)throw error;appointments=data||[]}
    const now=new Date(),future=new Date(now.getTime()+370*24*60*60*1000);
    let busy:any[]=[];
    if(clinicIds.length){const {data}=await admin.from('appointments').select('doctor_id,starts_at,ends_at,status').in('clinic_id',clinicIds).not('doctor_id','is',null).gte('starts_at',now.toISOString()).lte('starts_at',future.toISOString()).not('status','in','("cancelled","no_show")').limit(3000);busy=data||[]}
    const clinicMap=new Map((clinics||[]).map((c:any)=>[c.id,c.name])); const doctorMap=new Map((doctorRes.data||[]).map((d:any)=>[d.id,d.full_name]));
    return NextResponse.json({
      clinics:(clinics||[]).map((c:any)=>({id:c.id,name:c.name})),
      services:serviceRes.data||[],
      doctors:doctorRes.data||[],
      availability:availabilityRes.data||[],
      businessHours:hoursRes.data||[],
      holidays:holidaysRes.data||[],
      busy,
      appointments:appointments.map((a:any)=>({...a,clinic_name:clinicMap.get(a.clinic_id)||'Эмнэлэг',doctor_name:a.doctor_id?doctorMap.get(a.doctor_id)||null:null})),
      business_hours:hoursRes.data||[],
    });
  } catch (error) { return fail(error); }
}


async function ensureClinicOpen(admin:any,clinicId:string,start:Date,end:Date){
  const date=start.toLocaleDateString('en-CA',{timeZone:'Asia/Ulaanbaatar'});const weekday=new Date(`${date}T12:00:00+08:00`).getDay();
  const [{data:hour},{data:holiday}]=await Promise.all([
    admin.from('clinic_business_hours').select('start_time,end_time,active').eq('clinic_id',clinicId).eq('weekday',weekday).maybeSingle(),
    admin.from('clinic_holidays').select('name').eq('clinic_id',clinicId).eq('holiday_date',date).maybeSingle(),
  ]);
  if(holiday)throw new Error(`Сонгосон өдөр эмнэлэг амарна${holiday.name?`: ${holiday.name}`:''}. Өөр өдөр сонгоно уу.`);
  if(hour?.active===false)throw new Error('Сонгосон өдөр эмнэлэг амарна. Өөр өдөр сонгоно уу.');
  if(hour){const open=new Date(`${date}T${String(hour.start_time).slice(0,5)}:00+08:00`);const close=new Date(`${date}T${String(hour.end_time).slice(0,5)}:00+08:00`);if(start<open||end>close)throw new Error(`Эмнэлгийн ажлын цаг ${String(hour.start_time).slice(0,5)}–${String(hour.end_time).slice(0,5)} байна.`)}
}
async function ensureCapacity(admin:any,clinicId:string,doctorId:string,start:Date,end:Date){
  const date=start.toLocaleDateString('en-CA',{timeZone:'Asia/Ulaanbaatar'});const weekday=new Date(`${date}T12:00:00+08:00`).getDay();
  const {data:rule}=await admin.from('doctor_availability').select('max_parallel').eq('clinic_id',clinicId).eq('doctor_id',doctorId).eq('weekday',weekday).eq('active',true).maybeSingle();const limit=Math.max(1,Number(rule?.max_parallel||3));
  const dayStart=new Date(`${date}T00:00:00+08:00`),dayEnd=new Date(`${date}T24:00:00+08:00`);
  const {data,error}=await admin.from('appointments').select('id,starts_at,ends_at,status').eq('clinic_id',clinicId).eq('doctor_id',doctorId).gte('starts_at',dayStart.toISOString()).lt('starts_at',dayEnd.toISOString());if(error)throw error;
  const overlapping=(data||[]).filter((a:any)=>!['cancelled','no_show'].includes(a.status)&&start.getTime()<(a.ends_at?+new Date(a.ends_at):+new Date(a.starts_at)+30*60000)&&end.getTime()>+new Date(a.starts_at)).length;
  if(overlapping>=limit)throw new Error('Сонгосон цагийн багтаамж дүүрсэн байна. Өөр сул цаг сонгоно уу.');
}

export async function POST(request: NextRequest) {
  try {
    const { profile, admin } = await requireApiUser(request, ['client']);
    const body=await request.json(); const clinicId=String(body.clinicId||''); const doctorId=String(body.doctorId||''); let serviceId=String(body.serviceId||''); const serviceText=String(body.serviceText||'').trim(); const date=String(body.date||''); const time=String(body.time||'');
    const age=Number(body.age); const gender=String(body.gender||'');
    if(!clinicId||!doctorId||!date||!time)throw new Error('Эмнэлэг, эмч, өдөр, цагаа сонгоно уу.');
    if(!Number.isInteger(age)||age<0||age>130)throw new Error('Насаа зөв оруулна уу.');
    if(!['male','female','other','unspecified'].includes(gender))throw new Error('Хүйсээ сонгоно уу.');
    const {data:clinic}=await admin.from('clinics').select('id,name,status,enabled_modules,subscription_ends_at,trial_ends_at,grace_ends_at').eq('id',clinicId).in('status',['active','trial']).maybeSingle();if(!clinic||!clinicAcceptsAppointments(clinic))throw new Error('Сонгосон эмнэлгийн цаг товлол одоогоор идэвхгүй байна.');
    const {data:doctor}=await admin.from('profiles').select('id,full_name').eq('id',doctorId).eq('clinic_id',clinicId).in('role',['owner','employee']).eq('active',true).maybeSingle();if(!doctor)throw new Error('Сонгосон эмч олдсонгүй.');
    let serviceName='Эмчийн үзлэг',duration=30;
    if(serviceText){serviceName='Эмчийн үзлэг';serviceId='';}
    else if(serviceId){const {data:service}=await admin.from('services').select('id,name,duration_minutes').eq('id',serviceId).eq('clinic_id',clinicId).eq('active',true).maybeSingle();if(!service)throw new Error('Сонгосон үйлчилгээ олдсонгүй.');serviceName=service.name;duration=Number(service.duration_minutes||30)}
    const startsAt=new Date(`${date}T${time}:00+08:00`);if(Number.isNaN(startsAt.getTime()))throw new Error('Огноо эсвэл цаг буруу байна.');if(startsAt.getTime()<Date.now()+5*60*1000)throw new Error('Сонгосон цаг өнгөрсөн эсвэл эхлэхэд хэт ойр байна. Өөр сул цаг сонгоно уу.');const endsAt=new Date(startsAt.getTime()+duration*60000);
    const weekdayForHours=new Date(`${date}T12:00:00+08:00`).getDay();
    const [{data:clinicHour},{data:holiday}]=await Promise.all([
      admin.from('clinic_business_hours').select('start_time,end_time,active').eq('clinic_id',clinicId).eq('weekday',weekdayForHours).maybeSingle(),
      admin.from('clinic_holidays').select('id,name').eq('clinic_id',clinicId).eq('holiday_date',date).maybeSingle(),
    ]);
    if(holiday)throw new Error(`Энэ өдөр эмнэлэг амарна${holiday.name?`: ${holiday.name}`:''}. Өөр өдөр сонгоно уу.`);
    if(clinicHour?.active===false)throw new Error('Энэ өдөр эмнэлэг амарна. Өөр өдөр сонгоно уу.');
    if(clinicHour){const open=new Date(`${date}T${String(clinicHour.start_time).slice(0,5)}:00+08:00`),close=new Date(`${date}T${String(clinicHour.end_time).slice(0,5)}:00+08:00`);if(startsAt<open||endsAt>close)throw new Error(`Эмнэлгийн ажлын цаг ${String(clinicHour.start_time).slice(0,5)}–${String(clinicHour.end_time).slice(0,5)} байна.`)}
    const linkedPatients=await ensureClientPatientLinks(admin,profile);
    let patient:any=linkedPatients.find((p:any)=>p.clinic_id===clinicId)||null;
    if(patient){
      const detail=await admin.from('patients').select('id,full_name').eq('id',patient.id).maybeSingle();
      if(detail.error)throw detail.error; patient=detail.data;
    }
    if(!patient){const created=await admin.from('patients').insert({clinic_id:clinicId,user_id:profile.id,full_name:profile.full_name,phone:profile.phone||null,gender}).select('id,full_name').single();if(created.error||!created.data)throw created.error||new Error('Өвчтөний бүртгэл үүсгэж чадсангүй.');patient=created.data}else{await admin.from('patients').update({gender}).eq('id',patient.id)}
    const dayStart=new Date(`${date}T00:00:00+08:00`),dayEnd=new Date(`${date}T23:59:59+08:00`);
    const {data:existing,error:existingError}=await admin.from('appointments').select('id,starts_at,ends_at,status').eq('clinic_id',clinicId).eq('doctor_id',doctorId).gte('starts_at',dayStart.toISOString()).lte('starts_at',dayEnd.toISOString());if(existingError)throw existingError;
    const weekday=new Date(`${date}T12:00:00+08:00`).getDay();
    const {data:rule}=await admin.from('doctor_availability').select('max_parallel').eq('doctor_id',doctorId).eq('weekday',weekday).eq('active',true).maybeSingle();
    const parallelLimit=Math.max(1,Number(rule?.max_parallel||3));
    const overlapping=(existing||[]).filter((a:any)=>!['cancelled','no_show'].includes(a.status)&&startsAt.getTime()<(a.ends_at?new Date(a.ends_at).getTime():new Date(a.starts_at).getTime()+30*60000)&&endsAt.getTime()>new Date(a.starts_at).getTime()).length;
    if(overlapping>=parallelLimit)throw new Error('Энэ цагийн бүх боломжит слот аль хэдийн товлогдсон байна. Өөр сул цаг сонгоно уу.');
    const {data:appointment,error}=await admin.from('appointments').insert({clinic_id:clinicId,patient_id:patient.id,doctor_id:doctorId,service_id:serviceId||null,starts_at:startsAt.toISOString(),ends_at:endsAt.toISOString(),service_name:serviceName,service_request:serviceText||null,patient_age:age,patient_gender:gender,status:'confirmed',created_by:profile.id}).select('id,clinic_id,starts_at,service_name,status').single();if(error){if(error.code==='23P01'||error.code==='23505')throw new Error('Энэ цагийн бүх боломжит слот аль хэдийн товлогдсон байна. Өөр сул цаг сонгоно уу.');throw error}if(!appointment)throw new Error('Цаг захиалж чадсангүй.');
    return NextResponse.json({ok:true,appointment:{...appointment,clinic_name:clinic.name,doctor_name:doctor.full_name}});
  } catch (error) { return fail(error); }
}


export async function PATCH(request: NextRequest) {
  try {
    const { profile, admin } = await requireApiUser(request, ['client']);
    const body = await request.json();
    const id = String(body.id || '');
    if (!id || body.action !== 'cancel') throw new Error('Цуцлах цагийн мэдээлэл дутуу байна.');
    const { data: patientRows, error: patientError } = await admin.from('patients').select('id').eq('user_id', profile.id).is('deleted_at',null);
    if (patientError) throw patientError;
    const patientIds = (patientRows || []).map((p: any) => p.id);
    if (!patientIds.length) throw new Error('Өвчтөний бүртгэл олдсонгүй.');
    const { data: appointment, error: appointmentError } = await admin.from('appointments')
      .select('id,patient_id,starts_at,status')
      .eq('id', id).in('patient_id', patientIds).maybeSingle();
    if (appointmentError) throw appointmentError;
    if (!appointment) throw new Error('Таны цаг олдсонгүй.');
    if (+new Date(appointment.starts_at) < Date.now()) throw new Error('Өнгөрсөн цагийг цуцлах боломжгүй.');
    if (!['pending','confirmed','scheduled','waiting'].includes(appointment.status)) throw new Error('Ирсэн эсвэл үзлэг эхэлсэн цагийг өвчтөн өөрөө цуцлах боломжгүй.');
    const { error } = await admin.from('appointments').update({ status: 'cancelled' }).eq('id', id).eq('patient_id', appointment.patient_id);
    if (error) throw error;
    return NextResponse.json({ ok: true });
  } catch (error) { return fail(error); }
}
