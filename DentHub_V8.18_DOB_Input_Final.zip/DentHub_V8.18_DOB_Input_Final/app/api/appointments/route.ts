import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, requireApiUser, requireModule } from '@/lib/auth';

function fail(error:unknown,status=400){
  const message=error instanceof Error?error.message:'Unknown error';
  const map:Record<string,string>={UNAUTHORIZED:'Нэвтрэх эрх дууссан байна.',FORBIDDEN:'Энэ үйлдлийг хийх эрхгүй байна.',ACCOUNT_DISABLED:'Таны бүртгэл идэвхгүй байна.',PROFILE_NOT_FOUND:'Хэрэглэгчийн мэдээлэл олдсонгүй.'};
  const secured=apiErrorStatus(message);return NextResponse.json({error:map[message]||message},{status:secured===500?status:secured});
}
function toMongoliaISO(date:string,time:string){const value=new Date(`${date}T${time}:00+08:00`);if(Number.isNaN(value.getTime()))throw new Error('Огноо эсвэл цаг буруу байна.');return value}
function isConflictCode(error:any){return error?.code==='23P01'||error?.code==='23505'}
function isDoctorProfile(profile:any){return profile?.role==='employee'&&(profile?.staff_type==='doctor'||(!profile?.staff_type&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(String(profile?.specialty||''))))}

async function ensureClinicOpen(admin:any,clinicId:string,start:Date,end:Date){
  const date=start.toLocaleDateString('en-CA',{timeZone:'Asia/Ulaanbaatar'});
  const weekday=new Date(`${date}T12:00:00+08:00`).getDay();
  const [{data:hour},{data:holiday}]=await Promise.all([
    admin.from('clinic_business_hours').select('start_time,end_time,active').eq('clinic_id',clinicId).eq('weekday',weekday).maybeSingle(),
    admin.from('clinic_holidays').select('id,name').eq('clinic_id',clinicId).eq('holiday_date',date).maybeSingle(),
  ]);
  if(holiday)throw new Error(`Энэ өдөр эмнэлэг амарна${holiday.name?`: ${holiday.name}`:''}.`);
  if(hour?.active===false)throw new Error('Энэ өдөр эмнэлэг амарна.');
  if(hour){
    const open=new Date(`${date}T${String(hour.start_time).slice(0,5)}:00+08:00`);const close=new Date(`${date}T${String(hour.end_time).slice(0,5)}:00+08:00`);
    if(start<open||end>close)throw new Error(`Эмнэлгийн ажлын цаг ${String(hour.start_time).slice(0,5)}–${String(hour.end_time).slice(0,5)} байна.`);
  }
}

async function getDuration(admin:any,clinicId:string,serviceId?:string|null){
  if(!serviceId)return {name:'Ерөнхий үзлэг',duration:30};
  const {data,error}=await admin.from('services').select('id,name,duration_minutes,active').eq('id',serviceId).eq('clinic_id',clinicId).eq('active',true).maybeSingle();
  if(error)throw error;if(!data)throw new Error('Үйлчилгээ олдсонгүй.');return {name:data.name,duration:Number(data.duration_minutes||30)};
}
async function ensureCapacity(admin:any,args:{clinicId:string;doctorId:string;start:Date;end:Date;excludeId?:string}){
  const {clinicId,doctorId,start,end,excludeId}=args;
  const localDate=start.toLocaleDateString('en-CA',{timeZone:'Asia/Ulaanbaatar'});
  const day=new Date(`${localDate}T00:00:00+08:00`);const next=new Date(`${localDate}T24:00:00+08:00`);
  let q=admin.from('appointments').select('id,starts_at,ends_at,status').eq('clinic_id',clinicId).eq('doctor_id',doctorId).gte('starts_at',day.toISOString()).lt('starts_at',next.toISOString());
  if(excludeId)q=q.neq('id',excludeId);
  const {data,error}=await q;if(error)throw error;
  const weekday=new Date(`${localDate}T12:00:00+08:00`).getDay();
  const {data:rule}=await admin.from('doctor_availability').select('max_parallel').eq('clinic_id',clinicId).eq('doctor_id',doctorId).eq('weekday',weekday).eq('active',true).maybeSingle();
  const parallelLimit=Math.max(1,Number(rule?.max_parallel||3));
  const overlapping=(data||[]).filter((a:any)=>!['cancelled','no_show'].includes(a.status)&&start.getTime()<(a.ends_at?+new Date(a.ends_at):+new Date(a.starts_at)+30*60000)&&end.getTime()>+new Date(a.starts_at)).length;
  if(overlapping>=parallelLimit)throw new Error('Сонгосон цагийн бүх боломжит слот аль хэдийн товлогдсон байна. Өөр сул цаг сонгоно уу.');
}


export async function POST(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','employee']);requireModule(auth,'appointments');const {profile,admin}=auth;
    const body=await request.json();const clinicId=profile.clinic_id;if(!clinicId)throw new Error('Clinic олдсонгүй.');
    let patientId=String(body.patientId||'');let doctorId=String(body.doctorId||'');let serviceId=String(body.serviceId||'');const serviceText=String(body.serviceText||'').trim();const date=String(body.date||'');const time=String(body.time||'');const notes=String(body.notes||'').trim();
    if(isDoctorProfile(profile))doctorId=String(profile.id);
    const rawAge=String(body.age??'').trim();const age=rawAge===''?Number.NaN:Number(rawAge);const gender=String(body.gender||'');
    const patientMode=String(body.patientMode||'existing');
    if(patientMode==='new'){
      const fullName=String(body.newPatientName||'').trim();
      const phone=String(body.newPatientPhone||'').replace(/\D/g,'').slice(0,8);
      const externalPatientId=String(body.newPatientExternalId||'').trim();
      if(!fullName)throw new Error('Анх удаа ирж буй хүний нэрийг оруулна уу.');
      if(phone.length!==8)throw new Error('Утасны дугаар 8 оронтой байна.');
      let existing:any=null;
      const {data:byPhoneFull}=await admin.from('patients').select('id,full_name').eq('clinic_id',clinicId).is('deleted_at',null).eq('phone',`+976${phone}`).maybeSingle();
      const {data:byPhoneLocal}=byPhoneFull?{data:null}:await admin.from('patients').select('id,full_name').eq('clinic_id',clinicId).is('deleted_at',null).eq('phone',phone).maybeSingle();
      existing=byPhoneFull||byPhoneLocal||null;
      if(!existing&&externalPatientId){
        const {data:byExternal}=await admin.from('patients').select('id,full_name').eq('clinic_id',clinicId).is('deleted_at',null).ilike('external_patient_id',externalPatientId).maybeSingle();
        existing=byExternal||null;
      }
      if(existing){
        patientId=existing.id;
      }else{
        const {data:newPatient,error:newPatientError}=await admin.from('patients').insert({clinic_id:clinicId,full_name:fullName,phone:`+976${phone}`,external_patient_id:externalPatientId||null,quick_registered:true,gender:['male','female','other','unspecified'].includes(gender)?gender:null}).select('id').single();
        if(newPatientError)throw newPatientError; patientId=newPatient.id;
      }
    }
    if(!patientId||!doctorId||!date||!time)throw new Error('Өвчтөн, эмч, өдөр, цаг шаардлагатай.');
    const validAge=Number.isInteger(age)&&age>=0&&age<=130;
    const validGender=['male','female','other','unspecified'].includes(gender);
    if(patientMode!=='new'&&!validAge)throw new Error('Өвчтөний насыг зөв оруулна уу.');
    if(patientMode!=='new'&&!validGender)throw new Error('Өвчтөний хүйсийг сонгоно уу.');
    const [{data:patient},{data:doctor}]=await Promise.all([
      admin.from('patients').select('id,full_name').eq('id',patientId).eq('clinic_id',clinicId).is('deleted_at',null).maybeSingle(),
      admin.from('profiles').select('id,full_name,active').eq('id',doctorId).eq('clinic_id',clinicId).in('role',['owner','employee']).eq('active',true).maybeSingle(),
    ]);
    if(!patient)throw new Error('Өвчтөн олдсонгүй.');if(!doctor)throw new Error('Эмч олдсонгүй эсвэл идэвхгүй байна.');if(validGender)await admin.from('patients').update({gender}).eq('id',patientId).eq('clinic_id',clinicId);
    const svc=serviceText?{name:serviceText as string|null,duration:30}:serviceId?await getDuration(admin,clinicId,serviceId):{name:null as string|null,duration:30};if(serviceText)serviceId='';const start=toMongoliaISO(date,time);const end=new Date(start.getTime()+svc.duration*60_000);
    await ensureClinicOpen(admin,clinicId,start,end);
    await ensureCapacity(admin,{clinicId,doctorId,start,end});
    const {data,error}=await admin.from('appointments').insert({clinic_id:clinicId,patient_id:patientId,doctor_id:doctorId,service_id:serviceId||null,service_name:svc.name,service_request:serviceText||null,patient_age:validAge?age:null,patient_gender:validGender?gender:null,starts_at:start.toISOString(),ends_at:end.toISOString(),status:'confirmed',notes:notes||null,created_by:profile.id}).select('id').single();
    if(error){if(isConflictCode(error))throw new Error('Энэ цагийн бүх боломжит слот аль хэдийн товлогдсон байна. Өөр сул цаг сонгоно уу.');throw error}return NextResponse.json({ok:true,id:data.id});
  }catch(error){return fail(error)}
}

export async function PATCH(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','employee']);requireModule(auth,'appointments');const {profile,admin}=auth;const body=await request.json();const id=String(body.id||'');if(!id)throw new Error('Цагийн ID дутуу байна.');
    const clinicId=profile.clinic_id;if(!clinicId)throw new Error('Clinic олдсонгүй.');
    const {data:current,error:currentError}=await admin.from('appointments').select('id,clinic_id,doctor_id,service_id,service_name,service_request,clinical_summary,starts_at,ends_at,status,notes').eq('id',id).eq('clinic_id',clinicId).maybeSingle();if(currentError)throw currentError;if(!current)throw new Error('Цаг олдсонгүй.');
    if(isDoctorProfile(profile)&&String(current.doctor_id||'')!==String(profile.id))throw new Error('FORBIDDEN');
    const patch:Record<string,unknown>={};
    if(typeof body.status==='string'){
      const allowed=['pending','confirmed','scheduled','waiting','checked_in','in_progress','completed','done','cancelled','no_show'];if(!allowed.includes(body.status))throw new Error('Цагийн төлөв буруу байна.');patch.status=body.status;
    }
    if(typeof body.notes==='string')patch.notes=body.notes;
    if(typeof body.clinicalSummary==='string')patch.clinical_summary=body.clinicalSummary.trim()||null;

    let effectiveServiceId=String(current.service_id||'');
    if(typeof body.serviceId==='string'){
      effectiveServiceId=body.serviceId.trim();
      patch.service_id=effectiveServiceId || null;
      if(effectiveServiceId){
        const selectedService=await getDuration(admin,clinicId,effectiveServiceId);
        patch.service_name=selectedService.name;
      } else if(typeof body.serviceText==='string' && body.serviceText.trim()) patch.service_name=body.serviceText.trim();
    }
    if(typeof body.serviceText==='string'){
      const cleaned = body.serviceText.trim();
      patch.service_request = cleaned || null;
      if(cleaned && !effectiveServiceId) patch.service_name = cleaned;
    }
    let requestedDuration:number|null=null;
    if(body.durationMinutes!==undefined){
      const d=Number(body.durationMinutes);if(!Number.isFinite(d)||d<10||d>360)throw new Error('Үргэлжлэх хугацаа 10–360 минут байна.');requestedDuration=Math.round(d/5)*5;
    }
    let doctorId=typeof body.doctorId==='string'&&body.doctorId?body.doctorId:String(current.doctor_id||'');
    if(isDoctorProfile(profile))doctorId=String(profile.id);
    if(doctorId!==current.doctor_id){const {data:doctor}=await admin.from('profiles').select('id').eq('id',doctorId).eq('clinic_id',clinicId).in('role',['owner','employee']).eq('active',true).maybeSingle();if(!doctor)throw new Error('Сонгосон эмч олдсонгүй.');patch.doctor_id=doctorId}

    const moving=Boolean(body.date&&body.time)||doctorId!==current.doctor_id;
    if(moving){
      if(profile.role!=='owner'&&['completed','done','cancelled','no_show'].includes(current.status))throw new Error('Дууссан эсвэл цуцлагдсан цагийг зөвхөн эзэмшигч засна.');
      const date=String(body.date||new Date(current.starts_at).toLocaleDateString('en-CA',{timeZone:'Asia/Ulaanbaatar'}));
      const time=String(body.time||new Date(current.starts_at).toLocaleTimeString('en-GB',{timeZone:'Asia/Ulaanbaatar',hour:'2-digit',minute:'2-digit',hour12:false}));
      const start=toMongoliaISO(date,time);
      const svc=await getDuration(admin,clinicId,effectiveServiceId||current.service_id||null);const duration=requestedDuration||svc.duration;const end=new Date(start.getTime()+duration*60000);
      await ensureClinicOpen(admin,clinicId,start,end);await ensureCapacity(admin,{clinicId,doctorId,start,end,excludeId:id});patch.starts_at=start.toISOString();patch.ends_at=end.toISOString();
      const {error:moveError}=await admin.from('appointments').update(patch).eq('id',id).eq('clinic_id',clinicId);if(moveError){if(isConflictCode(moveError))throw new Error('Сонгосон цагийн бүх боломжит слот аль хэдийн товлогдсон байна. Өөр сул цаг сонгоно уу.');throw moveError}
      await admin.from('appointment_reschedule_history').insert({appointment_id:id,clinic_id:clinicId,old_doctor_id:current.doctor_id,new_doctor_id:doctorId,old_starts_at:current.starts_at,new_starts_at:start.toISOString(),changed_by:profile.id});
      return NextResponse.json({ok:true});
    }
    if(requestedDuration){
      if(profile.role!=='owner'&&['completed','done','cancelled','no_show'].includes(current.status))throw new Error('Дууссан эсвэл цуцлагдсан цагийн хугацааг зөвхөн эзэмшигч өөрчилнө.');
      const start=new Date(current.starts_at);const end=new Date(start.getTime()+requestedDuration*60000);await ensureClinicOpen(admin,clinicId,start,end);await ensureCapacity(admin,{clinicId,doctorId,start,end,excludeId:id});patch.ends_at=end.toISOString();
    }
    const {error}=await admin.from('appointments').update(patch).eq('id',id).eq('clinic_id',clinicId);if(error){if(isConflictCode(error))throw new Error('Цагийн давхцал үүслээ.');throw error}
    if(body.status==='checked_in'){
      const {data:appointment}=await admin.from('appointments').select('id,patient_id,doctor_id,service_name,service_request').eq('id',id).eq('clinic_id',clinicId).maybeSingle();
      if(appointment){
        const {data:existing}=await admin.from('encounters').select('id').eq('clinic_id',clinicId).eq('appointment_id',id).maybeSingle();
        if(!existing){
          const {error:encounterError}=await admin.from('encounters').insert({clinic_id:clinicId,appointment_id:id,patient_id:appointment.patient_id,doctor_id:appointment.doctor_id||null,treatment_plan:appointment.service_name||null,notes:appointment.service_request||null,status:'open'});
          if(encounterError&&encounterError.code!=='23505')throw encounterError;
        }
      }
    }
    if(body.status==='completed'||body.status==='done'){
      await admin.from('encounters').update({status:'completed'}).eq('clinic_id',clinicId).eq('appointment_id',id);
    }
    return NextResponse.json({ok:true});
  }catch(error){return fail(error)}
}


export async function DELETE(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','employee']);requireModule(auth,'appointments');const {profile,admin}=auth;const body=await request.json();const id=String(body.id||'');if(!id)throw new Error('Цагийн ID дутуу байна.');
    const clinicId=profile.clinic_id;if(!clinicId)throw new Error('Clinic олдсонгүй.');
    const {data:appointment,error}=await admin.from('appointments').select('id,status,doctor_id').eq('id',id).eq('clinic_id',clinicId).maybeSingle();if(error)throw error;if(!appointment)throw new Error('Цаг олдсонгүй.');
    if(isDoctorProfile(profile)&&String(appointment.doctor_id||'')!==String(profile.id))throw new Error('FORBIDDEN');
    if(profile.role!=='owner'&&!['cancelled','no_show'].includes(String(appointment.status)))throw new Error('Энэ цагийг устгах эрх зөвхөн эзэмшигчид байна. Ажилтан зөвхөн Цуцалсан эсвэл Ирээгүй цагийг устгана.');
    // appointments -> encounters uses ON DELETE SET NULL, so medical history remains intact.
    await admin.from('appointment_reschedule_history').delete().eq('appointment_id',id).eq('clinic_id',clinicId);
    const {error:deleteError}=await admin.from('appointments').delete().eq('id',id).eq('clinic_id',clinicId);if(deleteError)throw deleteError;
    return NextResponse.json({ok:true});
  }catch(error){return fail(error)}
}
