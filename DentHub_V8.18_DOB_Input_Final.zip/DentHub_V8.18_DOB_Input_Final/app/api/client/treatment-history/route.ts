import { NextRequest, NextResponse } from 'next/server';
import { requireApiUser } from '@/lib/auth';
import { ensureClientPatientLinks } from '@/lib/client-patients';

export async function GET(request: NextRequest) {
  try {
    const { profile, admin } = await requireApiUser(request, ['client']);
    const patients=await ensureClientPatientLinks(admin,profile);
    const patientIds=(patients||[]).map((p:any)=>p.id);
    if(!patientIds.length) return NextResponse.json({items:[]});
    let q=admin.from('appointments')
      .select('id,patient_id,clinic_id,doctor_id,starts_at,created_at,status,history_hidden_at,doctor:profiles!appointments_doctor_id_fkey(full_name),clinics(name)')
      .in('patient_id',patientIds).is('history_hidden_at',null);
    let {data,error}=await q.order('starts_at',{ascending:false}).limit(500);
    if(error&&['42703','PGRST204'].includes(String(error.code||''))){
      const fallback=await admin.from('appointments')
        .select('id,patient_id,clinic_id,doctor_id,starts_at,created_at,status,doctor:profiles!appointments_doctor_id_fkey(full_name),clinics(name)')
        .in('patient_id',patientIds).order('starts_at',{ascending:false}).limit(500);
      // Older databases may not have history_hidden_at yet. Normalize the
      // legacy result to the same shape as the primary query so TypeScript
      // and the response mapper have one consistent row contract.
      data=(fallback.data||[]).map((row:any)=>({...row,history_hidden_at:null}));
      error=fallback.error;
    }
    if(error)throw error;
    const items=(data||[]).map((x:any)=>({
      id:String(x.id),date:x.starts_at,booked_at:x.created_at,clinic_name:x.clinics?.name||'Эмнэлэг',doctor_name:x.doctor?.full_name||null,status:x.status,
    }));
    return NextResponse.json({items});
  } catch (error:any) {
    const message=error?.message||'Үзлэгийн түүх ачаалж чадсангүй.';
    return NextResponse.json({error:message},{status:message==='UNAUTHORIZED'?401:message==='FORBIDDEN'?403:400});
  }
}
