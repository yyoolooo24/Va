import { NextRequest, NextResponse } from 'next/server';
import { requireApiUser } from '@/lib/auth';

type PatientRow = {
  id:string; clinic_id:string; user_id?:string|null; patient_code?:string|null; external_patient_id?:string|null; full_name?:string|null; phone?:string|null; register_no?:string|null; date_of_birth?:string|null; gender?:string|null; address?:string|null; emergency_phone?:string|null; notes?:string|null; created_at?:string|null;
};

function parseCard(content:any){
  const raw=String(content||'').trim();if(!raw)return {form:{}};
  try{const parsed=JSON.parse(raw);if(parsed?.schema==='denthub_patient_card_v2')return {form:parsed.form||{}};}catch{}
  return {form:{additionalNotes:raw}};
}
function optionalSchemaError(error:any){return ['42703','42P01','PGRST204','PGRST205'].includes(String(error?.code||''))}
function phoneCandidates(raw?:string|null){
  const digits=String(raw||'').replace(/\D/g,'');const local=digits.slice(-8);
  return Array.from(new Set([String(raw||'').trim(),local,local?`+976${local}`:''].filter(Boolean)));
}
async function patientRows(admin:any,filter:'linked'|'phone',value:any):Promise<PatientRow[]>{
  let q=admin.from('patients').select('id,clinic_id,user_id,patient_code,external_patient_id,full_name,phone,register_no,date_of_birth,gender,address,emergency_phone,notes,created_at');
  q=filter==='linked'?q.eq('user_id',value):q.in('phone',value);
  let res=await q.is('deleted_at',null).order('created_at');
  if(!res.error)return (res.data||[]) as PatientRow[];
  if(!optionalSchemaError(res.error))throw res.error;
  let fallback=admin.from('patients').select('id,clinic_id,user_id,patient_code,external_patient_id,full_name,phone,register_no,date_of_birth,gender,notes,created_at');
  fallback=filter==='linked'?fallback.eq('user_id',value):fallback.in('phone',value);
  const basic=await fallback.order('created_at');if(basic.error)throw basic.error;
  return (basic.data||[]).map((p:any)=>({...p,address:null,emergency_phone:null})) as PatientRow[];
}
async function ensureLinkedPatients(admin:any,profile:any):Promise<PatientRow[]>{
  const linked=await patientRows(admin,'linked',profile.id);const map=new Map<string,PatientRow>(linked.map((p)=>[p.id,p]));
  const phones=phoneCandidates(profile.phone);
  if(phones.length){
    const matches=await patientRows(admin,'phone',phones);
    for(const p of matches){
      if(p.user_id&&p.user_id!==profile.id)continue;
      if(!p.user_id){
        const upd=await admin.from('patients').update({user_id:profile.id}).eq('id',p.id).is('user_id',null);
        if(upd.error)throw upd.error;
      }
      map.set(p.id,{...p,user_id:profile.id});
    }
  }
  return Array.from(map.values()) as PatientRow[];
}
async function clinicInfo(admin:any,clinicId:string){
  const full=await admin.from('clinics').select('id,name,logo_url').eq('id',clinicId).maybeSingle();
  if(!full.error)return full.data;
  if(!optionalSchemaError(full.error))throw full.error;
  const basic=await admin.from('clinics').select('id,name').eq('id',clinicId).maybeSingle();if(basic.error)throw basic.error;
  return basic.data?{...basic.data,logo_url:null}:null;
}
async function encounterRows(admin:any,clinicId:string,patientId:string){
  const selectFull='id,created_at,diagnosis,treatment_plan,notes,selected_teeth,doctor:profiles!encounters_doctor_id_fkey(full_name),treatment_lines:encounter_treatments(id,tooth_no,service_name,notes,unit_price,total_amount,created_at)';
  let res=await admin.from('encounters').select(selectFull).eq('clinic_id',clinicId).eq('patient_id',patientId).is('deleted_at',null).order('created_at',{ascending:false}).limit(300);
  if(!res.error)return res.data||[];
  if(!optionalSchemaError(res.error))throw res.error;
  res=await admin.from('encounters').select(selectFull).eq('clinic_id',clinicId).eq('patient_id',patientId).order('created_at',{ascending:false}).limit(300);
  if(!res.error)return res.data||[];
  if(!optionalSchemaError(res.error))throw res.error;
  const simple=await admin.from('encounters').select('id,created_at,diagnosis,treatment_plan,notes,selected_teeth,doctor:profiles!encounters_doctor_id_fkey(full_name),treatment_lines:encounter_treatments(id,tooth_no,service_name,notes,created_at)').eq('clinic_id',clinicId).eq('patient_id',patientId).order('created_at',{ascending:false}).limit(300);
  if(simple.error)throw simple.error;return simple.data||[];
}
async function paymentRows(admin:any,clinicId:string,patientId:string){
  const ep=await admin.from('encounter_payments').select('id,amount,payment_method_name,note,created_at,encounter_id').eq('clinic_id',clinicId).eq('patient_id',patientId).order('created_at',{ascending:false}).limit(300);
  if(!ep.error)return ep.data||[];
  if(!optionalSchemaError(ep.error))throw ep.error;
  const ft=await admin.from('finance_transactions').select('id,amount,payment_method,description,created_at,encounter_id').eq('clinic_id',clinicId).eq('patient_id',patientId).eq('kind','income').order('created_at',{ascending:false}).limit(300);
  if(ft.error){if(optionalSchemaError(ft.error))return [];throw ft.error}
  return (ft.data||[]).map((x:any)=>({...x,payment_method_name:x.payment_method,note:x.description}));
}

export async function GET(request:NextRequest){
  try{
    const {profile,admin}=await requireApiUser(request,['client']);
    const patients=await ensureLinkedPatients(admin,profile);
    const cards:any[]=[];
    for(const patient of patients){
      const [clinic,cardRes,encounters,payments,questionRes]=await Promise.all([
        clinicInfo(admin,patient.clinic_id),
        admin.from('patient_cards').select('content,updated_at').eq('clinic_id',patient.clinic_id).eq('patient_id',patient.id).maybeSingle(),
        encounterRows(admin,patient.clinic_id,patient.id),
        paymentRows(admin,patient.clinic_id,patient.id),
        admin.from('clinic_questionnaire_questions').select('question_key,label_mn,label_en,sort_order,active').eq('clinic_id',patient.clinic_id).eq('active',true).order('sort_order'),
      ]);
      if(cardRes.error&&!optionalSchemaError(cardRes.error))throw cardRes.error;
      const treatments:any[]=[];
      for(const enc of encounters||[]){
        const lines=(enc as any).treatment_lines||[];
        if(lines.length){for(const line of lines){treatments.push({id:line.id,date:line.created_at||enc.created_at,tooth:line.tooth_no||'—',service:line.service_name||(enc as any).treatment_plan||(enc as any).diagnosis||'Эмчилгээ',doctor:(enc as any).doctor?.full_name||'—',price:line.total_amount??line.unit_price??null,notes:line.notes||(enc as any).notes||null})}}
        else if((enc as any).treatment_plan||(enc as any).diagnosis||(Array.isArray((enc as any).selected_teeth)&&(enc as any).selected_teeth.length)){
          treatments.push({id:`enc-${enc.id}`,date:enc.created_at,tooth:Array.isArray((enc as any).selected_teeth)&&(enc as any).selected_teeth.length?(enc as any).selected_teeth.join(', '):'—',service:(enc as any).treatment_plan||(enc as any).diagnosis||'Үзлэг, эмчилгээ',doctor:(enc as any).doctor?.full_name||'—',price:null,notes:(enc as any).notes||null});
        }
      }
      cards.push({clinic_id:patient.clinic_id,clinic_name:(clinic as any)?.name||'Эмнэлэг',logo_url:(clinic as any)?.logo_url||null,patient,card:parseCard(cardRes.data?.content),questionnaire:questionRes.error?[]:(questionRes.data||[]),treatments,payments});
    }
    return NextResponse.json({cards});
  }catch(error:any){const message=error?.message||'Өвчтөний карт ачаалж чадсангүй.';return NextResponse.json({error:message},{status:message==='UNAUTHORIZED'?401:message==='FORBIDDEN'?403:400})}
}
