import { NextRequest, NextResponse } from 'next/server';
import { requireApiUser } from '@/lib/auth';
import { ensureClientPatientLinks } from '@/lib/client-patients';

export async function GET(request: NextRequest) {
  try {
    const { profile, admin } = await requireApiUser(request, ['client']);
    const patients=await ensureClientPatientLinks(admin,profile);
    const ids=(patients||[]).map((p:any)=>p.id);
    if(!ids.length)return NextResponse.json({items:[]});
    const { data, error } = await admin.from('qpay_invoices')
      .select('id,patient_id,clinic_id,sender_invoice_no,amount,description,status,payment_id,paid_at,created_at,clinics(name)')
      .in('patient_id', ids).order('created_at',{ascending:false}).limit(300);
    if(error)throw error;
    return NextResponse.json({items:(data||[]).map((x:any)=>({...x,clinic_name:x.clinics?.name||'Эмнэлэг'}))});
  } catch (error:any) {
    const message=error?.message||'Төлбөрийн түүх ачаалж чадсангүй.';
    const lower=String(message).toLowerCase();
    if(lower.includes('qpay_invoices.patient_id') || (lower.includes('patient_id')&&lower.includes('does not exist')) || error?.code==='42703') {
      return NextResponse.json({items:[],setup_required:true});
    }
    return NextResponse.json({error:'Төлбөрийн түүхийг ачаалж чадсангүй. Дахин оролдоно уу.'},{status:message==='UNAUTHORIZED'?401:message==='FORBIDDEN'?403:400});
  }
}
