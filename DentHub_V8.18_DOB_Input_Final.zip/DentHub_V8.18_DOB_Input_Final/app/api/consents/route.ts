import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, requireApiUser, requireModule } from '@/lib/auth';

function text(v:unknown,max=8000){return String(v??'').trim().slice(0,max)}
function isDoctor(profile:any){return profile?.role==='employee'&&(profile?.staff_type==='doctor'||(!profile?.staff_type&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(String(profile?.specialty||''))))}
async function doctorOwnsPatient(admin:any,clinicId:string,doctorId:string,patientId:string){
  const [a,e]=await Promise.all([
    admin.from('appointments').select('id').eq('clinic_id',clinicId).eq('patient_id',patientId).eq('doctor_id',doctorId).limit(1),
    admin.from('encounters').select('id').eq('clinic_id',clinicId).eq('patient_id',patientId).eq('doctor_id',doctorId).limit(1),
  ]);
  return Boolean(a.data?.length||e.data?.length);
}
async function assertPatientAccess(admin:any,profile:any,patientId:string){
  const {data:patient,error}=await admin.from('patients').select('id,full_name,patient_code,external_patient_id,phone,register_no').eq('id',patientId).eq('clinic_id',profile.clinic_id).is('deleted_at',null).maybeSingle();
  if(error)throw error;if(!patient)throw new Error('PATIENT_NOT_FOUND');
  if(isDoctor(profile)&&!(await doctorOwnsPatient(admin,profile.clinic_id,profile.id,patientId)))throw new Error('FORBIDDEN');
  return patient;
}
function status(message:string){if(message==='PATIENT_NOT_FOUND')return 404;const secured=apiErrorStatus(message);return secured===500?400:secured}

export async function GET(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','employee']);requireModule(auth,'consent_forms');const {profile,admin}=auth;
    if(!profile.clinic_id)throw new Error('Эмнэлгийн холбоос олдсонгүй.');
    const patientId=request.nextUrl.searchParams.get('patientId')||'';
    if(patientId)await assertPatientAccess(admin,profile,patientId);
    let q=admin.from('patient_consent_forms').select('id,patient_id,consent_type,title,procedure_name,consent_text,guardian_name,doctor_name,notes,consent_date,created_at,updated_at,created_by,updated_by').eq('clinic_id',profile.clinic_id).is('deleted_at',null).order('consent_date',{ascending:false}).order('created_at',{ascending:false});
    if(patientId)q=q.eq('patient_id',patientId);
    const {data,error}=await q.limit(300);if(error)throw error;
    return NextResponse.json({items:data||[]});
  }catch(e:any){const m=e?.message||'Зөвшөөрлийн хуудас ачаалж чадсангүй.';return NextResponse.json({error:m},{status:status(m)})}
}

export async function POST(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','employee']);requireModule(auth,'consent_forms');const {profile,admin}=auth;
    if(!profile.clinic_id)throw new Error('Эмнэлгийн холбоос олдсонгүй.');
    const b=await request.json();const patientId=text(b.patientId,80);const title=text(b.title,220);const consentText=text(b.consentText,12000);
    if(!patientId||!title||!consentText)return NextResponse.json({error:'Өвчтөн, гарчиг, зөвшөөрлийн агуулга шаардлагатай.'},{status:400});
    await assertPatientAccess(admin,profile,patientId);
    const row={clinic_id:profile.clinic_id,patient_id:patientId,consent_type:text(b.consentType,80)||'treatment',title,procedure_name:text(b.procedureName,300)||null,consent_text:consentText,guardian_name:text(b.guardianName,220)||null,doctor_name:text(b.doctorName,220)||profile.full_name||null,notes:text(b.notes,3000)||null,consent_date:text(b.consentDate,20)||new Date().toISOString().slice(0,10),created_by:profile.id||null,updated_by:profile.id||null};
    const {data,error}=await admin.from('patient_consent_forms').insert(row).select('*').single();if(error)throw error;
    return NextResponse.json({item:data});
  }catch(e:any){const m=e?.message||'Зөвшөөрлийн хуудас хадгалж чадсангүй.';return NextResponse.json({error:m},{status:status(m)})}
}

export async function PATCH(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','employee']);requireModule(auth,'consent_forms');const {profile,admin}=auth;if(!profile.clinic_id)throw new Error('Эмнэлгийн холбоос олдсонгүй.');
    const b=await request.json();const id=text(b.id,80);if(!id)return NextResponse.json({error:'ID дутуу байна.'},{status:400});
    const {data:existing,error:findError}=await admin.from('patient_consent_forms').select('id,patient_id').eq('id',id).eq('clinic_id',profile.clinic_id).is('deleted_at',null).maybeSingle();if(findError)throw findError;if(!existing)return NextResponse.json({error:'Зөвшөөрлийн хуудас олдсонгүй.'},{status:404});
    await assertPatientAccess(admin,profile,existing.patient_id);
    const patch:any={updated_by:profile.id||null,updated_at:new Date().toISOString()};
    if(b.title!==undefined)patch.title=text(b.title,220);if(b.consentType!==undefined)patch.consent_type=text(b.consentType,80)||'treatment';if(b.procedureName!==undefined)patch.procedure_name=text(b.procedureName,300)||null;if(b.consentText!==undefined)patch.consent_text=text(b.consentText,12000);if(b.guardianName!==undefined)patch.guardian_name=text(b.guardianName,220)||null;if(b.doctorName!==undefined)patch.doctor_name=text(b.doctorName,220)||null;if(b.notes!==undefined)patch.notes=text(b.notes,3000)||null;if(b.consentDate!==undefined)patch.consent_date=text(b.consentDate,20)||new Date().toISOString().slice(0,10);
    const {data,error}=await admin.from('patient_consent_forms').update(patch).eq('id',id).eq('clinic_id',profile.clinic_id).select('*').single();if(error)throw error;return NextResponse.json({item:data});
  }catch(e:any){const m=e?.message||'Зөвшөөрлийн хуудас засаж чадсангүй.';return NextResponse.json({error:m},{status:status(m)})}
}

export async function DELETE(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner']);requireModule(auth,'consent_forms');const {profile,admin}=auth;if(!profile.clinic_id)throw new Error('Эмнэлгийн холбоос олдсонгүй.');const b=await request.json();const id=text(b.id,80);if(!id)return NextResponse.json({error:'ID дутуу байна.'},{status:400});
    const {error}=await admin.from('patient_consent_forms').update({deleted_at:new Date().toISOString(),deleted_by:profile.id||null,updated_at:new Date().toISOString()}).eq('id',id).eq('clinic_id',profile.clinic_id).is('deleted_at',null);if(error)throw error;return NextResponse.json({ok:true});
  }catch(e:any){const m=e?.message||'Зөвшөөрлийн хуудас устгаж чадсангүй.';return NextResponse.json({error:m},{status:status(m)})}
}
