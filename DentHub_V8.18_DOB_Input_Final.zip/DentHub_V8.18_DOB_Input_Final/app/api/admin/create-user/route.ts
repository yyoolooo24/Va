import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, normalizeMongolianPhone, phoneToInternalEmail, requireApiUser, requireModule } from '@/lib/auth';
import { sanitizeClinicModules } from '@/lib/subscription';

function inferStaffType(value: unknown) {
  const explicit = String(value || '').toLowerCase();
  if (['doctor','nurse','reception','cashier','finance','inventory','manager','other'].includes(explicit)) return explicit;
  return 'other';
}

export async function POST(request: NextRequest) {
  let createdUserId: string | null = null;
  try {
    const auth = await requireApiUser(request, ['platform_admin', 'owner']);
    if (auth.profile.role !== 'platform_admin') requireModule(auth, 'staff');
    const body = await request.json();
    const role = body.role;
    if (!['owner', 'employee'].includes(role)) return NextResponse.json({ error: 'Role буруу байна.' }, { status: 400 });
    if (auth.profile.role === 'owner' && role !== 'employee') return NextResponse.json({ error: 'Эмнэлгийн account-аас зөвхөн эмч / ажилтны account үүсгэнэ.' }, { status: 403 });

    const clinicId = auth.profile.role === 'platform_admin' ? body.clinicId : auth.profile.clinic_id;
    if (!clinicId) return NextResponse.json({ error: 'Clinic сонгоно уу.' }, { status: 400 });
    if (!body.phone || !body.password || !body.fullName) return NextResponse.json({ error: 'Нэр, утас, нууц үг шаардлагатай.' }, { status: 400 });
    if (String(body.password).length < 8) return NextResponse.json({ error: 'Нууц үг хамгийн багадаа 8 тэмдэгт байна.' }, { status: 400 });

    const { data: clinic, error: clinicError } = await auth.admin.from('clinics').select('id,name,status,enabled_modules,employee_limit').eq('id', clinicId).maybeSingle();
    if (clinicError) throw clinicError;
    if (!clinic) return NextResponse.json({ error: 'Clinic олдсонгүй.' }, { status: 404 });
    if (!['active','trial'].includes(String(clinic.status))) return NextResponse.json({ error: 'Энэ clinic идэвхгүй байна.' }, { status: 403 });

    const { count, error: countError } = await auth.admin.from('profiles').select('id', { count: 'exact', head: true }).eq('clinic_id', clinicId).in('role', ['owner','employee']).eq('active', true);
    if (countError) throw countError;
    if ((count || 0) >= Number(clinic.employee_limit || 25)) return NextResponse.json({ error: `Employee limit хүрсэн байна (${clinic.employee_limit}). Platform Admin-аас limit нэмүүлнэ үү.` }, { status: 409 });

    const phone = normalizeMongolianPhone(body.phone);
    const email = phoneToInternalEmail(body.phone);
    const specialty = typeof body.specialty === 'string' ? body.specialty.trim().slice(0,120) : '';
    const clinicModules = new Set<string>(sanitizeClinicModules(clinic.enabled_modules));
    const requestedModules = sanitizeClinicModules(body.allowedModules);
    const allowedModules = role === 'employee' ? requestedModules.filter(x => clinicModules.has(x)) : [];

    const { data: created, error: createError } = await auth.admin.auth.admin.createUser({
      email,
      password: body.password,
      email_confirm: true,
      user_metadata: { full_name: body.fullName, phone },
    });
    if (createError || !created.user) throw createError || new Error('User create failed');
    createdUserId = created.user.id;

    const { error: profileError } = await auth.admin.from('profiles').insert({
      id: created.user.id,
      clinic_id: clinicId,
      role,
      full_name: body.fullName,
      phone,
      language: 'mn',
      specialty: role === 'employee' ? specialty || null : null,
      staff_type: role === 'employee' ? inferStaffType(body.staffType) : null,
      allowed_modules: allowedModules,
    });
    if (profileError) throw profileError;

    if (role === 'owner' || role === 'employee') {
      await auth.admin.from('professional_profiles').insert({
        user_id: created.user.id,
        display_name: body.fullName,
        clinic_name: clinic.name || null,
        specialty: body.specialty || null,
        bio: body.bio || null,
        city: body.city || 'Улаанбаатар',
        discoverable: true,
      });
    }

    await auth.admin.from('platform_audit_log').insert({ actor_id: auth.user.id, clinic_id: clinicId, action: 'staff_account_created', target_type: 'profile', target_id: created.user.id, metadata: { role, staff_type: inferStaffType(body.staffType), allowed_modules: allowedModules } });
    return NextResponse.json({ id: created.user.id, phone, role, allowedModules });
  } catch (error: any) {
    if (createdUserId) {
      try { const admin = (await requireApiUser(request, ['platform_admin','owner'])).admin; await admin.auth.admin.deleteUser(createdUserId); } catch {}
    }
    const message = error?.message || 'Хэрэглэгч үүсгэхэд алдаа гарлаа.';
    return NextResponse.json({ error: message }, { status: apiErrorStatus(message) });
  }
}
