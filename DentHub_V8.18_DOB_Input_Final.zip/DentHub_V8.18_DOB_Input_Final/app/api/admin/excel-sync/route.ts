import { NextRequest, NextResponse } from 'next/server';
import { normalizeMongolianPhone, phoneToInternalEmail, requireApiUser } from '@/lib/auth';

type Entity = 'clinics' | 'patients' | 'staff';

function text(value: unknown, max = 500) {
  return String(value ?? '').trim().slice(0, max);
}
function bool(value: unknown, fallback = true) {
  if (typeof value === 'boolean') return value;
  const v = String(value ?? '').trim().toLowerCase();
  if (['true','1','yes','y','active','идэвхтэй'].includes(v)) return true;
  if (['false','0','no','n','inactive','идэвхгүй'].includes(v)) return false;
  return fallback;
}
function modules(value: unknown) {
  if (Array.isArray(value)) return value.map(String).filter(x => /^[a-z_]+$/.test(x)).slice(0, 40);
  return String(value ?? '').split(/[;,\n]+/).map(x => x.trim()).filter(x => /^[a-z_]+$/.test(x)).slice(0, 40);
}
function validStatus(value: unknown) {
  const v = text(value, 30).toLowerCase();
  return ['active','trial','suspended','cancelled'].includes(v) ? v : null;
}
function validRole(value: unknown) {
  const v = text(value, 30).toLowerCase();
  return ['owner','employee'].includes(v) ? v : null;
}

async function clinicNameMap(admin: any, ids: string[]) {
  if (!ids.length) return new Map<string,string>();
  const { data } = await admin.from('clinics').select('id,name').in('id', Array.from(new Set(ids)));
  return new Map((data || []).map((c: any) => [c.id, c.name]));
}

export async function GET(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['platform_admin','owner']);
    const entity = request.nextUrl.searchParams.get('entity') as Entity | null;
    if (!entity || !['clinics','patients','staff'].includes(entity)) {
      return NextResponse.json({ error: 'Excel entity буруу байна.' }, { status: 400 });
    }

    if (entity === 'clinics') {
      let q = auth.admin.from('clinics').select('id,name,slug,plan,status,created_at').order('created_at', { ascending: false });
      if (auth.profile.role === 'owner') q = q.eq('id', auth.profile.clinic_id);
      const { data, error } = await q;
      if (error) throw error;
      return NextResponse.json({ rows: (data || []).map((r: any) => ({
        clinic_id: r.id, clinic_name: r.name, slug: r.slug, plan: r.plan, status: r.status, created_at: r.created_at,
      })) });
    }

    if (entity === 'patients') {
      let q = auth.admin.from('patients').select('id,patient_code,user_id,clinic_id,external_patient_id,full_name,phone,register_no,date_of_birth,gender,address,emergency_phone,notes,created_at').is('deleted_at',null).order('created_at',{ascending:false});
      if (auth.profile.role === 'owner') q = q.eq('clinic_id', auth.profile.clinic_id);
      const { data, error } = await q;
      if (error) throw error;
      const names = await clinicNameMap(auth.admin, (data || []).map((r: any) => r.clinic_id).filter(Boolean));
      return NextResponse.json({ rows: (data || []).map((r: any) => ({
        patient_id:r.id, patient_code:r.patient_code, clinic_id:r.clinic_id, clinic_name:names.get(r.clinic_id)||'',
        full_name:r.full_name, external_patient_id:r.external_patient_id||'', phone:r.phone||'', register_no:r.register_no||'', date_of_birth:r.date_of_birth||'', gender:r.gender||'', address:r.address||'', emergency_phone:r.emergency_phone||'', notes:r.notes||'',
        linked_account:r.user_id?'YES':'NO', created_at:r.created_at,
      })) });
    }

    let q = auth.admin.from('profiles').select('id,clinic_id,role,full_name,phone,active,created_at,specialty,allowed_modules').in('role',['owner','employee']).order('created_at',{ascending:false});
    if (auth.profile.role === 'owner') q = q.eq('clinic_id', auth.profile.clinic_id).eq('role','employee');
    const { data, error } = await q;
    if (error) throw error;
    const names = await clinicNameMap(auth.admin, (data || []).map((r: any) => r.clinic_id).filter(Boolean));
    return NextResponse.json({ rows: (data || []).map((r: any) => ({
      user_id:r.id, clinic_id:r.clinic_id, clinic_name:names.get(r.clinic_id)||'', full_name:r.full_name, phone:r.phone||'', role:r.role,
      specialty:r.specialty||'', allowed_modules:Array.isArray(r.allowed_modules)?r.allowed_modules.join(';'): '', active:r.active!==false, created_at:r.created_at,
    })) });
  } catch (error: any) {
    const message = error?.message || 'Excel data татахад алдаа гарлаа.';
    const status = message === 'UNAUTHORIZED' ? 401 : message === 'FORBIDDEN' ? 403 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}

export async function POST(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['platform_admin','owner']);
    const body = await request.json();
    const entity = body.entity as Entity;
    const rows = Array.isArray(body.rows) ? body.rows.slice(0, 2000) : [];
    if (!['clinics','patients','staff'].includes(entity) || !rows.length) {
      return NextResponse.json({ error: 'Импортын мөр олдсонгүй.' }, { status: 400 });
    }

    let updated = 0;
    let created = 0;
    const errors: string[] = [];

    if (entity === 'clinics') {
      for (let i=0;i<rows.length;i++) {
        const row=rows[i]; const id=text(row.clinic_id,80);
        if (!id) { errors.push(`${i+2}: clinic_id байхгүй.`); continue; }
        if(auth.profile.role==='owner' && id!==auth.profile.clinic_id){errors.push(`${i+2}: Энэ clinic-г засах эрхгүй.`);continue;}
        const patch:any={};
        const name=text(row.clinic_name || row.name,160); if(name)patch.name=name;
        if(auth.profile.role==='platform_admin'){const plan=text(row.plan,40); if(plan)patch.plan=plan;const status=validStatus(row.status); if(status)patch.status=status;}
        if(!Object.keys(patch).length)continue;
        const { error }=await auth.admin.from('clinics').update(patch).eq('id',id);
        if(error){errors.push(`${i+2}: ${error.message}`);continue;} updated++;
        if(patch.name){const {data:members}=await auth.admin.from('profiles').select('id').eq('clinic_id',id).in('role',['owner','employee']);const ids=(members||[]).map((x:any)=>x.id);if(ids.length)await auth.admin.from('professional_profiles').update({clinic_name:patch.name}).in('user_id',ids);}
      }
      return NextResponse.json({updated,errors});
    }

    if (entity === 'patients') {
      for (let i=0;i<rows.length;i++) {
        const row=rows[i]; const id=text(row.patient_id,80);
        if(!id){
          if(auth.profile.role!=='owner'){errors.push(`${i+2}: Шинэ өвчтөн нэмэх эрхгүй.`);continue;}
          const fullName=text(row.full_name,160);if(!fullName){errors.push(`${i+2}: full_name байхгүй.`);continue;}
          const patch:any={
            clinic_id:auth.profile.clinic_id,
            full_name:fullName,
            external_patient_id:text(row.external_patient_id,120)||null,
            phone:text(row.phone,30)||null,
            register_no:text(row.register_no,80)||null,
            date_of_birth:text(row.date_of_birth,20)||null,
            gender:text(row.gender,30)||null,
            address:text(row.address,500)||null,
            emergency_phone:text(row.emergency_phone,30)||null,
            notes:text(row.notes,2000)||null,
          };
          if(!patch.clinic_id){errors.push(`${i+2}: Clinic олдсонгүй.`);continue;}
          if(patch.phone){const digits=patch.phone.replace(/\D/g,'').replace(/^976/,'');if(digits.length!==8){errors.push(`${i+2}: Утас 8 оронтой байх ёстой.`);continue;}patch.phone=normalizeMongolianPhone(digits);}
          if(patch.emergency_phone){const digits=patch.emergency_phone.replace(/\D/g,'').replace(/^976/,'');if(digits.length!==8){errors.push(`${i+2}: Яаралтай үед холбоо барих утас 8 оронтой байх ёстой.`);continue;}patch.emergency_phone=normalizeMongolianPhone(digits);}
          const {error:insertError}=await auth.admin.from('patients').insert(patch);
          if(insertError){errors.push(`${i+2}: ${insertError.message}`);continue;}
          created++;continue;
        }
        let existingQ=auth.admin.from('patients').select('id,clinic_id,user_id,external_patient_id,full_name,phone,register_no,date_of_birth,gender,address,emergency_phone,notes').eq('id',id);
        if(auth.profile.role==='owner') existingQ=existingQ.eq('clinic_id',auth.profile.clinic_id);
        const {data:existing,error:findError}=await existingQ.maybeSingle();
        if(findError||!existing){errors.push(`${i+2}: Өвчтөн олдсонгүй эсвэл эрхгүй.`);continue;}
        const patch:any={
          full_name:text(row.full_name,160)||existing.full_name,
          external_patient_id:text(row.external_patient_id,120)||existing.external_patient_id||null,
          phone:text(row.phone,30)||null,
          register_no:text(row.register_no,80)||null,
          date_of_birth:text(row.date_of_birth,20)||null,
          gender:text(row.gender,30)||null,
          address:text(row.address,500)||null,
          emergency_phone:text(row.emergency_phone,30)||null,
          notes:text(row.notes,2000)||null,
        };
        if(patch.phone){const digits=patch.phone.replace(/\D/g,'').replace(/^976/,'');if(digits.length!==8){errors.push(`${i+2}: Утас 8 оронтой байх ёстой.`);continue;}patch.phone=normalizeMongolianPhone(digits);}
        if(patch.emergency_phone){const digits=patch.emergency_phone.replace(/\D/g,'').replace(/^976/,'');if(digits.length!==8){errors.push(`${i+2}: Яаралтай үед холбоо барих утас 8 оронтой байх ёстой.`);continue;}patch.emergency_phone=normalizeMongolianPhone(digits);}
        const {error:updateError}=await auth.admin.from('patients').update(patch).eq('id',id).eq('clinic_id',existing.clinic_id);
        if(updateError){errors.push(`${i+2}: ${updateError.message}`);continue;}
        if(existing.user_id){
          const {data:oldProfile}=await auth.admin.from('profiles').select('full_name,phone').eq('id',existing.user_id).eq('role','client').maybeSingle();
          const profilePatch:any={full_name:patch.full_name,phone:patch.phone};
          const {error:profileError}=await auth.admin.from('profiles').update(profilePatch).eq('id',existing.user_id).eq('role','client');
          if(profileError){await auth.admin.from('patients').update({full_name:existing.full_name,external_patient_id:existing.external_patient_id,phone:existing.phone,register_no:existing.register_no,date_of_birth:existing.date_of_birth,gender:existing.gender,address:existing.address,emergency_phone:existing.emergency_phone,notes:existing.notes}).eq('id',id);errors.push(`${i+2}: linked account update: ${profileError.message}`);continue;}
          const authPayload:any={user_metadata:{full_name:patch.full_name,phone:patch.phone}};
          if(patch.phone){const digits=String(patch.phone).replace(/\D/g,'').slice(-8);authPayload.email=phoneToInternalEmail(digits);}
          const {error:authError}=await auth.admin.auth.admin.updateUserById(existing.user_id,authPayload);
          if(authError){
            await auth.admin.from('patients').update({full_name:existing.full_name,external_patient_id:existing.external_patient_id,phone:existing.phone,register_no:existing.register_no,date_of_birth:existing.date_of_birth,gender:existing.gender,address:existing.address,emergency_phone:existing.emergency_phone,notes:existing.notes}).eq('id',id);
            if(oldProfile)await auth.admin.from('profiles').update({full_name:oldProfile.full_name,phone:oldProfile.phone}).eq('id',existing.user_id);
            errors.push(`${i+2}: Login account шинэчилж чадсангүй: ${authError.message}`);continue;
          }
        }
        updated++;
      }
      return NextResponse.json({updated,created,errors});
    }

    for (let i=0;i<rows.length;i++) {
      const row=rows[i]; const id=text(row.user_id,80);
      if(!id){errors.push(`${i+2}: user_id байхгүй.`);continue;}
      let q=auth.admin.from('profiles').select('id,clinic_id,role,full_name,phone,active,specialty,allowed_modules').eq('id',id).in('role',['owner','employee']);
      if(auth.profile.role==='owner')q=q.eq('clinic_id',auth.profile.clinic_id).eq('role','employee');
      const {data:existing,error:findError}=await q.maybeSingle();
      if(findError||!existing){errors.push(`${i+2}: Ажилтан олдсонгүй эсвэл эрхгүй.`);continue;}
      const role=auth.profile.role==='platform_admin'?(validRole(row.role)||existing.role):'employee';
      const phoneRaw=text(row.phone,30);let phone:string|null=existing.phone;
      if(phoneRaw){const digits=phoneRaw.replace(/\D/g,'').replace(/^976/,'');if(digits.length!==8){errors.push(`${i+2}: Утас 8 оронтой байх ёстой.`);continue;}phone=normalizeMongolianPhone(digits);}
      const active=bool(row.active,existing.active!==false);
      const patch:any={full_name:text(row.full_name,160)||existing.full_name,phone,role,active,specialty:role==='employee'?(text(row.specialty,160)||null):null,allowed_modules:role==='employee'?modules(row.allowed_modules):[]};
      const authPatch:any={user_metadata:{full_name:patch.full_name,phone:patch.phone}};
      if(phone){authPatch.email=phoneToInternalEmail(String(phone).replace(/\D/g,'').slice(-8));}
      authPatch.ban_duration=active?'none':'876000h';
      const {error:authError}=await auth.admin.auth.admin.updateUserById(id,authPatch);
      if(authError){errors.push(`${i+2}: Auth account: ${authError.message}`);continue;}
      const profilePatch:any={...patch};
      if(active){profilePatch.deactivated_at=null;profilePatch.deactivated_by=null;}
      else if(existing.active!==false){profilePatch.deactivated_at=new Date().toISOString();profilePatch.deactivated_by=auth.user.id;}
      const {error:updateError}=await auth.admin.from('profiles').update(profilePatch).eq('id',id);
      if(updateError){
        const rollback:any={user_metadata:{full_name:existing.full_name,phone:existing.phone},ban_duration:existing.active!==false?'none':'876000h'};
        if(existing.phone){const oldDigits=String(existing.phone).replace(/\D/g,'').slice(-8);if(oldDigits.length===8)rollback.email=phoneToInternalEmail(oldDigits);}
        await auth.admin.auth.admin.updateUserById(id,rollback).catch(()=>undefined);
        errors.push(`${i+2}: ${updateError.message}`);continue;
      }
      await auth.admin.from('professional_profiles').update({display_name:patch.full_name,specialty:patch.specialty,discoverable:active}).eq('user_id',id);
      updated++;
    }
    return NextResponse.json({updated,errors});
  } catch (error: any) {
    const message = error?.message || 'Excel өөрчлөлт хадгалахад алдаа гарлаа.';
    const status = message === 'UNAUTHORIZED' ? 401 : message === 'FORBIDDEN' ? 403 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
