import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, requireApiUser } from '@/lib/auth';
import { sanitizeClinicModules } from '@/lib/subscription';

const CODE_RE=/^[A-Z0-9_]{2,24}$/;
const cycle=(value:unknown)=>['monthly','yearly','custom'].includes(String(value))?String(value):'monthly';
const text=(value:unknown,max=180)=>String(value||'').trim().slice(0,max);

export async function POST(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['platform_admin']);
    const body=await request.json();
    const action=String(body.action||'');
    const code=text(body.code,24).toUpperCase();
    if(!code||!CODE_RE.test(code))return NextResponse.json({error:'Багцын код 2–24 тэмдэгттэй, зөвхөн A-Z, 0-9, _ байна.'},{status:400});

    if(action==='create'||action==='update'){
      const originalCode=text(body.originalCode||code,24).toUpperCase();
      const row={
        code,
        name_mn:text(body.nameMn,80)||code,
        name_en:text(body.nameEn,80)||text(body.nameMn,80)||code,
        description_mn:text(body.descriptionMn,300)||null,
        description_en:text(body.descriptionEn,300)||null,
        enabled_modules:sanitizeClinicModules(body.enabledModules),
        employee_limit:Math.max(1,Math.min(1000,Number(body.employeeLimit||10))),
        price:body.price===''||body.price==null?0:Math.max(0,Number(body.price)||0),
        billing_cycle:cycle(body.billingCycle),
        duration_months:Math.max(1,Math.min(120,Number(body.durationMonths||1))),
        active:body.active!==false,
        updated_at:new Date().toISOString(),
      };
      if(action==='create'){
        const {data,error}=await auth.admin.from('platform_subscription_plans').insert(row).select('*').single();
        if(error)throw error;
        await auth.admin.from('platform_audit_log').insert({actor_id:auth.user.id,action:'subscription_plan_created',target_type:'subscription_plan',target_id:code,metadata:{modules:row.enabled_modules,employee_limit:row.employee_limit}});
        return NextResponse.json({ok:true,plan:data});
      }
      if(originalCode!==code)return NextResponse.json({error:'Одоо ашиглагдаж байгаа багцын кодыг сольж болохгүй. Шинэ багц үүсгээд эмнэлгүүдээ шилжүүлнэ үү.'},{status:400});
      const {data,error}=await auth.admin.from('platform_subscription_plans').update(row).eq('code',originalCode).select('*').single();
      if(error)throw error;
      await auth.admin.from('platform_audit_log').insert({actor_id:auth.user.id,action:'subscription_plan_updated',target_type:'subscription_plan',target_id:code,metadata:{modules:row.enabled_modules,employee_limit:row.employee_limit}});
      return NextResponse.json({ok:true,plan:data});
    }

    if(action==='toggle'){
      const active=Boolean(body.active);
      if(code==='START'&&!active)return NextResponse.json({error:'START нь шинэ бүртгэлийн үндсэн багц тул идэвхгүй болгож болохгүй. Тохиргоог нь засаж болно.'},{status:409});
      const {data,error}=await auth.admin.from('platform_subscription_plans').update({active,updated_at:new Date().toISOString()}).eq('code',code).select('*').single();
      if(error)throw error;
      await auth.admin.from('platform_audit_log').insert({actor_id:auth.user.id,action:active?'subscription_plan_activated':'subscription_plan_deactivated',target_type:'subscription_plan',target_id:code});
      return NextResponse.json({ok:true,plan:data});
    }

    if(action==='delete'){
      if(code==='START')return NextResponse.json({error:'START нь шинэ бүртгэлийн үндсэн багц тул устгаж болохгүй.'},{status:409});
      const {count,error:countError}=await auth.admin.from('clinics').select('id',{count:'exact',head:true}).eq('plan',code);
      if(countError)throw countError;
      if((count||0)>0)return NextResponse.json({error:`${count} эмнэлэг энэ багцыг ашиглаж байна. Эхлээд өөр багц руу шилжүүлэх эсвэл багцыг идэвхгүй болгоно уу.`},{status:409});
      const {error}=await auth.admin.from('platform_subscription_plans').delete().eq('code',code);if(error)throw error;
      await auth.admin.from('platform_audit_log').insert({actor_id:auth.user.id,action:'subscription_plan_deleted',target_type:'subscription_plan',target_id:code});
      return NextResponse.json({ok:true,deleted:true});
    }

    return NextResponse.json({error:'Үйлдэл буруу байна.'},{status:400});
  }catch(error:any){
    const message=error?.message||'Багцын тохиргоог хадгалж чадсангүй.';
    return NextResponse.json({error:message},{status:apiErrorStatus(message)});
  }
}
