import { NextRequest, NextResponse } from 'next/server';
import { requireApiUser, requireModule } from '@/lib/auth';

export async function POST(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','platform_admin']);if(auth.profile.role!=='platform_admin')requireModule(auth,'staff');const {profile,admin}=auth;
    const body=await request.json();
    const userId=String(body.userId||'').trim();
    const password=String(body.password||'');
    if(!userId)return NextResponse.json({error:'Хэрэглэгч сонгоно уу.'},{status:400});
    if(password.length<8)return NextResponse.json({error:'Түр нууц үг хамгийн багадаа 8 тэмдэгт байна.'},{status:400});
    const {data:target,error}=await admin.from('profiles').select('id,clinic_id,role,full_name').eq('id',userId).maybeSingle();
    if(error)throw error;if(!target)return NextResponse.json({error:'Хэрэглэгч олдсонгүй.'},{status:404});
    if(profile.role==='owner'){
      if(!profile.clinic_id||target.clinic_id!==profile.clinic_id||target.role!=='employee')throw new Error('FORBIDDEN');
    }
    const {error:authError}=await admin.auth.admin.updateUserById(userId,{password});
    if(authError)throw authError;
    return NextResponse.json({ok:true,user:{id:target.id,full_name:target.full_name}});
  }catch(error:any){
    const message=error?.message||'Нууц үг сэргээж чадсангүй.';
    return NextResponse.json({error:message},{status:message==='UNAUTHORIZED'?401:message==='FORBIDDEN'?403:400});
  }
}
