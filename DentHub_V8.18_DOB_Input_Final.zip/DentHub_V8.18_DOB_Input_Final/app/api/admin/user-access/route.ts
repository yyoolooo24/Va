import { NextRequest, NextResponse } from 'next/server';
import { requireApiUser, requireModule } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['platform_admin', 'owner']);
    if (auth.profile.role !== 'platform_admin') requireModule(auth, 'staff');
    const body = await request.json();
    const userId = String(body.userId || '');
    const action = String(body.action || '');

    if (!userId || !['deactivate', 'reactivate'].includes(action)) {
      return NextResponse.json({ error: 'Хэрэглэгч болон action шаардлагатай.' }, { status: 400 });
    }
    if (userId === auth.user.id) {
      return NextResponse.json({ error: 'Өөрийн эрхийг эндээс цуцлах боломжгүй.' }, { status: 400 });
    }

    const { data: target, error: targetError } = await auth.admin
      .from('profiles')
      .select('id, clinic_id, role, full_name, active')
      .eq('id', userId)
      .single();
    if (targetError || !target) return NextResponse.json({ error: 'Хэрэглэгч олдсонгүй.' }, { status: 404 });

    if (auth.profile.role === 'owner') {
      if (target.clinic_id !== auth.profile.clinic_id) return NextResponse.json({ error: 'Энэ хэрэглэгч танай clinic-д хамаарахгүй.' }, { status: 403 });
      if (target.role === 'owner' || target.role === 'platform_admin') return NextResponse.json({ error: 'Owner нь owner/platform admin эрхийг өөрчилж болохгүй.' }, { status: 403 });
    }
    if (target.role === 'platform_admin') return NextResponse.json({ error: 'Platform admin эрхийг эндээс өөрчилж болохгүй.' }, { status: 403 });

    const active = action === 'reactivate';
    const { error: profileError } = await auth.admin.from('profiles').update({
      active,
      deactivated_at: active ? null : new Date().toISOString(),
      deactivated_by: active ? null : auth.user.id,
    }).eq('id', userId);
    if (profileError) throw profileError;

    // Supabase Auth ban immediately blocks future sign-ins while keeping all historical rows.
    const { error: authError } = await auth.admin.auth.admin.updateUserById(userId, {
      ban_duration: active ? 'none' : '876000h',
    });
    if (authError) throw authError;

    if (!active) {
      await auth.admin.from('professional_profiles').update({ discoverable: false }).eq('user_id', userId);
    } else if (target.role === 'owner' || target.role === 'employee') {
      await auth.admin.from('professional_profiles').update({ discoverable: true }).eq('user_id', userId);
    }

    return NextResponse.json({ ok: true, userId, active });
  } catch (error: any) {
    const message = error?.message || 'Эрх өөрчлөхөд алдаа гарлаа.';
    const status = message === 'UNAUTHORIZED' ? 401 : message === 'FORBIDDEN' ? 403 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
