import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, requireApiUser } from '@/lib/auth';
import { sanitizeClinicModules } from '@/lib/subscription';

function modules(value: unknown) { return sanitizeClinicModules(value); }
function nullableDate(value: unknown) {
  const v = String(value || '').trim();
  if (!v) return null;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) throw new Error('INVALID_DATE');
  return d.toISOString();
}

export async function POST(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['platform_admin']);
    const body = await request.json();
    const clinicId = String(body.clinicId || '');
    const action = String(body.action || 'update');
    if (!clinicId) return NextResponse.json({ error: 'Эмнэлэг сонгоно уу.' }, { status: 400 });

    const { data: current, error: currentError } = await auth.admin
      .from('clinics')
      .select('id,name,status,plan,enabled_modules,employee_limit')
      .eq('id', clinicId)
      .maybeSingle();
    if (currentError) throw currentError;
    if (!current) return NextResponse.json({ error: 'Эмнэлэг олдсонгүй.' }, { status: 404 });

    let patch: Record<string, any> = { updated_at: new Date().toISOString() };
    if (action === 'approve' || action === 'update') {
      const requestedPlan = String(body.plan || current.plan || 'START').slice(0, 24).toUpperCase();
      const { data: planRow } = await auth.admin.from('platform_subscription_plans').select('code,enabled_modules,employee_limit,price,billing_cycle,duration_months').eq('code', requestedPlan).maybeSingle();
      const hasExplicitModules = Array.isArray(body.enabledModules);
      const enabled = hasExplicitModules ? modules(body.enabledModules) : modules(planRow?.enabled_modules || current.enabled_modules);
      patch = {
        ...patch,
        plan: requestedPlan,
        enabled_modules: enabled,
        employee_limit: Math.max(1, Math.min(1000, Number(body.employeeLimit || planRow?.employee_limit || current.employee_limit || 25))),
        subscription_price: body.subscriptionPrice === '' || body.subscriptionPrice == null ? (planRow?.price == null ? null : Math.max(0, Number(planRow.price))) : Math.max(0, Number(body.subscriptionPrice)),
        billing_cycle: ['monthly', 'yearly', 'custom'].includes(String(body.billingCycle)) ? String(body.billingCycle) : (planRow?.billing_cycle || 'monthly'),
        subscription_started_at: nullableDate(body.subscriptionStartedAt) || (action === 'approve' ? new Date().toISOString() : undefined),
        subscription_ends_at: nullableDate(body.subscriptionEndsAt),
        trial_ends_at: nullableDate(body.trialEndsAt),
        grace_ends_at: nullableDate(body.graceEndsAt),
        platform_notes: String(body.platformNotes || '').trim() || null,
      };
      if (action === 'approve') Object.assign(patch, { status: 'active', approved_at: new Date().toISOString(), approved_by: auth.user.id, suspended_at: null, archived_at: null });
    } else if (action === 'suspend') patch = { ...patch, status: 'suspended', suspended_at: new Date().toISOString() };
    else if (action === 'reactivate') patch = { ...patch, status: 'active', suspended_at: null, archived_at: null };
    else if (action === 'archive') patch = { ...patch, status: 'archived', archived_at: new Date().toISOString() };
    else if (action === 'cancel') patch = { ...patch, status: 'cancelled' };
    else if (action === 'reject') patch = { ...patch, status: 'cancelled', archived_at: new Date().toISOString() };
    else if (action === 'approve_request' || action === 'reject_request') {
      const requestId = String(body.requestId || '');
      if (!requestId) return NextResponse.json({ error: 'Модулийн хүсэлтийн дугаар шаардлагатай.' }, { status: 400 });
      const { data: req, error: reqError } = await auth.admin.from('clinic_module_requests').select('id,clinic_id,modules,status').eq('id', requestId).maybeSingle();
      if (reqError) throw reqError;
      if (!req || req.status !== 'pending') return NextResponse.json({ error: 'Хүсэлт олдсонгүй эсвэл аль хэдийн шийдэгдсэн байна.' }, { status: 400 });
      if (action === 'approve_request') {
        const merged = Array.from(new Set([...(current.enabled_modules || []), ...modules(req.modules)]));
        await auth.admin.from('clinics').update({ enabled_modules: merged, updated_at: new Date().toISOString() }).eq('id', req.clinic_id);
      }
      await auth.admin.from('clinic_module_requests').update({ status: action === 'approve_request' ? 'approved' : 'rejected', reviewed_by: auth.user.id, reviewed_at: new Date().toISOString() }).eq('id', requestId);
      await auth.admin.from('platform_audit_log').insert({ actor_id: auth.user.id, clinic_id: req.clinic_id, action, target_type: 'module_request', target_id: requestId, metadata: { modules: req.modules } });
      return NextResponse.json({ ok: true });
    } else if (action === 'permanent_delete') {
      const protectedTables = ['patients','patient_cards','patient_xrays','patient_consent_forms','appointments','encounters','encounter_payments','finance_transactions','qpay_invoices','erp_records','inventory_items','employee_documents','internal_procedures','clinic_contracts','health_department_records'];
      for (const table of protectedTables) {
        const { count, error } = await auth.admin.from(table).select('id', { count: 'exact', head: true }).eq('clinic_id', clinicId).limit(1);
        if (error) throw error;
        if ((count || 0) > 0) return NextResponse.json({ error: `Энэ эмнэлэгт хадгалах шаардлагатай бодит түүх байна (${table}). Бүр мөсөн устгахгүй. Идэвхтэй жагсаалтаас хасаад Архив хэсэгт хадгална уу.` }, { status: 409 });
      }
      const { data: profiles } = await auth.admin.from('profiles').select('id').eq('clinic_id', clinicId);
      for (const row of profiles || []) await auth.admin.auth.admin.deleteUser(row.id).catch(() => undefined);
      const { error: deleteError } = await auth.admin.from('clinics').delete().eq('id', clinicId);
      if (deleteError) throw deleteError;
      await auth.admin.from('platform_audit_log').insert({ actor_id: auth.user.id, action: 'clinic_permanently_deleted', target_type: 'clinic', target_id: clinicId, metadata: { name: current.name } });
      return NextResponse.json({ ok: true, deleted: true });
    } else {
      return NextResponse.json({ error: 'Үйлдэл буруу байна.' }, { status: 400 });
    }

    Object.keys(patch).forEach(k => patch[k] === undefined && delete patch[k]);
    const { data: clinic, error } = await auth.admin.from('clinics').update(patch).eq('id', clinicId).select('*').single();
    if (error) throw error;
    await auth.admin.from('platform_audit_log').insert({ actor_id: auth.user.id, clinic_id: clinicId, action: `clinic_${action}`, target_type: 'clinic', target_id: clinicId, metadata: { before: { status: current.status, plan: current.plan }, after: { status: clinic.status, plan: clinic.plan, enabled_modules: clinic.enabled_modules } } });
    return NextResponse.json({ ok: true, clinic });
  } catch (error: any) {
    const message = error?.message || 'Эмнэлгийн багцын тохиргоог шинэчилж чадсангүй.';
    return NextResponse.json({ error: message }, { status: apiErrorStatus(message) });
  }
}
