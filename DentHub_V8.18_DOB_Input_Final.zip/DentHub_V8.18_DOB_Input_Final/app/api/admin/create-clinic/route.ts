import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, normalizeMongolianPhone, phoneToInternalEmail, requireApiUser } from '@/lib/auth';
import { PLAN_MODULES, sanitizeClinicModules } from '@/lib/subscription';

export async function POST(request: NextRequest) {
  try {
    const auth = await requireApiUser(request, ['platform_admin']);
    const body = await request.json();
    if (!String(body.name || '').trim()) return NextResponse.json({ error: 'Эмнэлгийн нэр оруулна уу.' }, { status: 400 });

    const slug = (body.slug || body.name)
      .toString().toLowerCase().trim().replace(/[^a-z0-9а-яөүё]+/gi, '-').replace(/^-|-$/g, '') || `clinic-${Date.now()}`;
    const requestedPlan=String(body.plan||'START').trim().toUpperCase().slice(0,24);
    const {data:planRow}=await auth.admin.from('platform_subscription_plans').select('code,enabled_modules,employee_limit,price,billing_cycle,duration_months').eq('code',requestedPlan).eq('active',true).maybeSingle();
    const plan=planRow?.code||(['START','GROWTH','NETWORK'].includes(requestedPlan)?requestedPlan:'START');
    const explicitModules=Array.isArray(body.enabledModules)?sanitizeClinicModules(body.enabledModules):null;
    const enabledModules=explicitModules??sanitizeClinicModules(planRow?.enabled_modules||PLAN_MODULES[plan]||PLAN_MODULES.START);
    const employeeLimit=Math.max(1,Math.min(1000,Number(body.employeeLimit||planRow?.employee_limit||(plan==='START'?5:plan==='GROWTH'?25:100))));
    const price=body.subscriptionPrice===''||body.subscriptionPrice==null?Number(planRow?.price||0):Math.max(0,Number(body.subscriptionPrice)||0);
    const billingCycle=['monthly','yearly','custom'].includes(String(body.billingCycle))?String(body.billingCycle):(planRow?.billing_cycle||'monthly');
    const durationMonths=Math.max(1,Math.min(120,Number(planRow?.duration_months||1)));
    const endsAt=new Date();endsAt.setMonth(endsAt.getMonth()+durationMonths);

    const { data: clinic, error } = await auth.admin.from('clinics').insert({
      name: String(body.name).trim(),
      slug,
      plan,
      status: 'active',
      enabled_modules: enabledModules,
      employee_limit: employeeLimit,
      subscription_price: price,
      billing_cycle: billingCycle,
      subscription_started_at: new Date().toISOString(),
      subscription_ends_at: endsAt.toISOString(),
      approved_at: new Date().toISOString(),
      approved_by: auth.user.id,
    }).select().single();
    if (error) throw error;

    let owner = null;
    if (body.ownerPhone && body.ownerPassword && body.ownerName) {
      const phone = normalizeMongolianPhone(body.ownerPhone);
      const email = phoneToInternalEmail(body.ownerPhone);
      const { data: userData, error: userError } = await auth.admin.auth.admin.createUser({
        email,
        password: body.ownerPassword,
        email_confirm: true,
        user_metadata: { full_name: String(body.ownerName).trim(), phone },
      });
      if (userError || !userData.user) {
        try { await auth.admin.from('clinics').delete().eq('id',clinic.id); } catch { /* best-effort rollback */ }
        throw userError || new Error('Эзэмшигчийн бүртгэл үүсгэж чадсангүй.');
      }
      const { error: profileError } = await auth.admin.from('profiles').insert({
        id: userData.user.id,
        clinic_id: clinic.id,
        role: 'owner',
        full_name: String(body.ownerName).trim(),
        phone,
        language: 'mn',
      });
      if (profileError) throw profileError;
      await auth.admin.from('professional_profiles').insert({ user_id: userData.user.id, display_name: String(body.ownerName).trim(), clinic_name: clinic.name, discoverable: true });
      owner = { id: userData.user.id, phone };
    }

    await auth.admin.from('platform_audit_log').insert({ actor_id: auth.user.id, clinic_id: clinic.id, action: 'clinic_created_by_platform', target_type: 'clinic', target_id: clinic.id, metadata: { plan, enabled_modules: enabledModules, employee_limit: employeeLimit } });
    return NextResponse.json({ clinic, owner });
  } catch (error: any) {
    const message = error?.message || 'Эмнэлэг үүсгэхэд алдаа гарлаа.';
    return NextResponse.json({ error: message }, { status: apiErrorStatus(message) });
  }
}
