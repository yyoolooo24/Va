import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import { Arimo } from 'next/font/google';
import './globals.css';
import PwaRegister from '@/components/PwaRegister';

const arimo = Arimo({
  subsets: ['latin', 'cyrillic'],
  display: 'swap',
  variable: '--font-arimo',
});

export const metadata: Metadata = {
  title: 'DentHub — Эмнэлгийн систем',
  description: 'DentHub — эмнэлгийн цаг товлол, өвчтөн, эмчилгээ, төлбөр, бараа материал болон ERP систем.',
  applicationName: 'DentHub',
  manifest: '/manifest.webmanifest',
  icons: { icon: '/denthub-icon.svg' },
  appleWebApp: { capable: true, title: 'DentHub', statusBarStyle: 'default' },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  viewportFit: 'cover',
};

const themeScript = `
try {
  const saved = localStorage.getItem('clinicos-theme');
  const theme = saved || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  document.documentElement.dataset.theme = theme;
  document.documentElement.dataset.largeText = localStorage.getItem('clinicos-large-text') === 'true' ? 'true' : 'false';
} catch (_) {}
`;

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="mn" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body className={arimo.className}><PwaRegister/>{children}</body>
    </html>
  );
}
