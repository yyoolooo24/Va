import type { MetadataRoute } from 'next';
export default function manifest():MetadataRoute.Manifest{
  return {
    name:'DentHub — Эмнэлгийн систем',short_name:'DentHub',description:'Цаг товлол, өвчтөн, эмчилгээ, касс болон эмнэлгийн дотоод удирдлагыг нэг дор.',
    start_url:'/',display:'standalone',background_color:'#f7faff',theme_color:'#1769e0',orientation:'any',lang:'mn',
    icons:[{src:'/denthub-icon.svg',sizes:'any',type:'image/svg+xml',purpose:'any'},{src:'/denthub-icon.svg',sizes:'any',type:'image/svg+xml',purpose:'maskable'}]
  };
}
