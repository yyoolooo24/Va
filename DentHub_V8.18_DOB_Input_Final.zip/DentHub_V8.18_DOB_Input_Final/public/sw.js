/* DentHub V8.8 service worker.
   Deliberately does NOT cache pages, API responses, Supabase requests, patient data or medical files. */
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',(event)=>event.waitUntil(self.clients.claim()));
