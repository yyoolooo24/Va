# DentHub V8.6.24 changelog

## Үзлэг, эмчилгээ
- Removed the doctor-side payment method/amount/payment-history controls.
- Added a clean visit-total card and **Дуусгаад Касс руу илгээх** action.
- Doctor completion writes the encounter total and hands the linked patient/encounter/remaining amount to Cashier.
- Orthodontic treatments are directly searchable within **Гажиг засал** and no longer require a tooth selection.
- All other treatment groups still require one or more selected teeth.

## Касс / Кассын журнал
- Added `denthub_record_encounter_payment_v2` for atomic cashbook + encounter payment writes.
- Cash/card/transfer/custom payment methods now reliably create `finance_transactions` rows.
- Receipt selection is stored on the cashbook transaction.

## Нийслэлийн ЭМГ
- Receipt/eBarimt list now reads receipt-marked cashbook transactions from all payment methods.
- Historical paid QPay invoices remain visible through fallback logic.
- Duplicate QPay/cashbook rows are removed when the QPay invoice has a linked finance transaction.

## QPay
- Successful QPay callbacks copy receipt metadata to the linked finance transaction so Cashbook and Health Department reports agree.
