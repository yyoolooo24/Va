# DentHub V8.19.1 — Exact official-document template

- Rebuilt the printable **Албан бичиг** layout from the supplied `Албан бичиг драфт Танан цагаан 1(1).docx` reference.
- Clinic logo is now a full logo banner at the upper-left, with organization name and contact block directly below.
- Top-right editable subject block follows the reference placement.
- Added the two blue reference lines: document date/number and `танай … -ны № … -т`.
- Added a separate incoming reference number field (`referenceNo`) without a SQL migration; documents remain JSON files in Supabase Storage.
- Print view uses the same A4 structure and hides all editor controls.
- Existing V8.19 saved documents remain readable; `referenceNo` defaults blank.
