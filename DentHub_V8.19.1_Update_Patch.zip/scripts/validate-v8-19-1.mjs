import fs from 'node:fs';
const checks=[
 ['components/OfficialDocumentsWorkspace.tsx',['official-paper-logo-banner','official-paper-reference-block','referenceNo','official-print-incoming-line']],
 ['app/api/official-documents/route.ts',['referenceNo:compact','official-documents']],
 ['app/globals.css',['DentHub V8.19.1','official-paper-logo-banner','official-print-reference-block']]
];
let failed=false;for(const [file,needles] of checks){if(!fs.existsSync(file)){console.error(`Missing ${file}`);failed=true;continue}const body=fs.readFileSync(file,'utf8');for(const n of needles){if(!body.includes(n)){console.error(`${file}: missing ${n}`);failed=true}}}if(failed)process.exit(1);console.log('DentHub V8.19.1 exact official-document template validation passed.');
