import { randomUUID } from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, requireApiUser } from '@/lib/auth';

const BUCKET = 'clinic-documents';
const FOLDER = 'official-documents';

type OfficialDocument = {
  id:string;
  organizationName:string;
  contactBlock:string;
  topRightTitle:string;
  documentNo:string;
  documentDate:string;
  recipient:string;
  referenceNo:string;
  heading:string;
  body:string;
  signerTitle:string;
  signerName:string;
  note?:string;
  status:'draft'|'ready';
  createdAt:string;
  updatedAt:string;
  createdBy?:string|null;
  updatedBy?:string|null;
};

function text(value:unknown,max=20000){return String(value??'').replace(/\r\n/g,'\n').slice(0,max)}
function compact(value:unknown,max=300){return text(value,max).trim()}
function dateValue(value:unknown){const v=compact(value,20);return /^\d{4}-\d{2}-\d{2}$/.test(v)?v:new Date().toISOString().slice(0,10)}
function statusFor(message:string){const secured=apiErrorStatus(message);return secured===500?400:secured}
function pathFor(clinicId:string,id:string){return `${clinicId}/${FOLDER}/${id}.json`}

async function authorize(request:NextRequest, ownerOnly=false){
  const auth=await requireApiUser(request,ownerOnly?['owner']:['owner','employee']);
  if(!auth.profile.clinic_id)throw new Error('CLINIC_NOT_FOUND');
  if(auth.profile.role==='employee'){
    const allowed=Array.isArray(auth.profile.allowed_modules)?auth.profile.allowed_modules:[];
    if(!allowed.includes('official_documents'))throw new Error('MODULE_NOT_ALLOWED');
  }
  return auth;
}

async function ensureBucket(admin:any){
  const {data,error}=await admin.storage.getBucket(BUCKET);
  if(data&&!error)return;
  const created=await admin.storage.createBucket(BUCKET,{public:false,fileSizeLimit:26214400});
  if(created.error&&!String(created.error.message||'').toLowerCase().includes('already'))throw created.error;
}

async function readJson(admin:any,path:string):Promise<OfficialDocument|null>{
  const {data,error}=await admin.storage.from(BUCKET).download(path);
  if(error||!data)return null;
  try{return JSON.parse(await data.text()) as OfficialDocument}catch{return null}
}

function normalize(body:any,base?:Partial<OfficialDocument>):OfficialDocument{
  const now=new Date().toISOString();
  return {
    id:compact(body.id||base?.id,80)||randomUUID(),
    organizationName:compact(body.organizationName??base?.organizationName,240),
    contactBlock:text(body.contactBlock??base?.contactBlock,1800).trim(),
    topRightTitle:text(body.topRightTitle??base?.topRightTitle,1400).trim(),
    documentNo:compact(body.documentNo??base?.documentNo,100),
    documentDate:dateValue(body.documentDate??base?.documentDate),
    recipient:compact(body.recipient??base?.recipient,500),
    referenceNo:compact(body.referenceNo??base?.referenceNo,160),
    heading:compact(body.heading??base?.heading,500),
    body:text(body.body??base?.body,30000).trim(),
    signerTitle:compact(body.signerTitle??base?.signerTitle,260),
    signerName:compact(body.signerName??base?.signerName,260),
    note:text(body.note??base?.note,2000).trim(),
    status:(body.status==='ready'?'ready':'draft'),
    createdAt:base?.createdAt||now,
    updatedAt:now,
    createdBy:base?.createdBy||null,
    updatedBy:base?.updatedBy||null,
  };
}

export async function GET(request:NextRequest){
  try{
    const {profile,admin}=await authorize(request);const clinicId=String(profile.clinic_id);
    await ensureBucket(admin);
    const id=compact(request.nextUrl.searchParams.get('id'),80);
    if(id){const item=await readJson(admin,pathFor(clinicId,id));return item?NextResponse.json({item}):NextResponse.json({error:'Албан бичиг олдсонгүй.'},{status:404})}
    const {data,error}=await admin.storage.from(BUCKET).list(`${clinicId}/${FOLDER}`,{limit:250,sortBy:{column:'updated_at',order:'desc'}});if(error)throw error;
    const files=(data||[]).filter((x:any)=>String(x.name||'').endsWith('.json'));
    const items=(await Promise.all(files.map((file:any)=>readJson(admin,`${clinicId}/${FOLDER}/${file.name}`)))).filter(Boolean) as OfficialDocument[];
    items.sort((a,b)=>String(b.updatedAt||'').localeCompare(String(a.updatedAt||'')));
    return NextResponse.json({items});
  }catch(e:any){const m=e?.message||'Албан бичиг ачаалж чадсангүй.';return NextResponse.json({error:m},{status:statusFor(m)})}
}

export async function POST(request:NextRequest){
  try{
    const {profile,admin}=await authorize(request);const clinicId=String(profile.clinic_id);await ensureBucket(admin);
    const body=await request.json();const item=normalize(body);item.createdBy=profile.id||null;item.updatedBy=profile.id||null;
    if(!item.organizationName)item.organizationName=profile.full_name||'';
    if(!item.heading&&!item.body&&!item.topRightTitle)return NextResponse.json({error:'Албан бичгийн агуулга оруулна уу.'},{status:400});
    const {error}=await admin.storage.from(BUCKET).upload(pathFor(clinicId,item.id),JSON.stringify(item,null,2),{contentType:'application/json; charset=utf-8',upsert:false});if(error)throw error;
    return NextResponse.json({item});
  }catch(e:any){const m=e?.message||'Албан бичиг хадгалж чадсангүй.';return NextResponse.json({error:m},{status:statusFor(m)})}
}

export async function PATCH(request:NextRequest){
  try{
    const {profile,admin}=await authorize(request);const clinicId=String(profile.clinic_id);await ensureBucket(admin);
    const body=await request.json();const id=compact(body.id,80);if(!id)return NextResponse.json({error:'ID дутуу байна.'},{status:400});
    const existing=await readJson(admin,pathFor(clinicId,id));if(!existing)return NextResponse.json({error:'Албан бичиг олдсонгүй.'},{status:404});
    const item=normalize({...body,id},existing);item.createdBy=existing.createdBy||null;item.updatedBy=profile.id||null;
    if(!item.heading&&!item.body&&!item.topRightTitle)return NextResponse.json({error:'Албан бичгийн агуулга оруулна уу.'},{status:400});
    const {error}=await admin.storage.from(BUCKET).upload(pathFor(clinicId,id),JSON.stringify(item,null,2),{contentType:'application/json; charset=utf-8',upsert:true});if(error)throw error;
    return NextResponse.json({item});
  }catch(e:any){const m=e?.message||'Албан бичиг шинэчилж чадсангүй.';return NextResponse.json({error:m},{status:statusFor(m)})}
}

export async function DELETE(request:NextRequest){
  try{
    const {profile,admin}=await authorize(request,true);const clinicId=String(profile.clinic_id);const body=await request.json();const id=compact(body.id,80);if(!id)return NextResponse.json({error:'ID дутуу байна.'},{status:400});
    const {error}=await admin.storage.from(BUCKET).remove([pathFor(clinicId,id)]);if(error)throw error;return NextResponse.json({ok:true});
  }catch(e:any){const m=e?.message||'Албан бичиг устгаж чадсангүй.';return NextResponse.json({error:m},{status:statusFor(m)})}
}
