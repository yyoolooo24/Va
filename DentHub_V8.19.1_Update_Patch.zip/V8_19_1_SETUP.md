# DentHub V8.19.1 setup

This release corrects the **Албан бичиг** editor/print layout to match the supplied Word reference.

No SQL migration is required.

```bash
npm install
npm run validate:v8.19.1
npm run build
npx vercel --prod
```

Saved official documents remain in the existing private `clinic-documents` Supabase Storage bucket. The new `referenceNo` field is stored inside the existing JSON document file and is backward-compatible.
