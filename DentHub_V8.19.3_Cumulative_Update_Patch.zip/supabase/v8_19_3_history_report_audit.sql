-- DentHub V8.19.3 — treatment-history archive/edit audit + editable NEMG report drafts
-- Safe additive migration. Run once in Supabase SQL Editor before using V8.19.3 features.

begin;

alter table public.encounters
  add column if not exists history_archived_at timestamptz,
  add column if not exists history_archived_by uuid references public.profiles(id) on delete set null,
  add column if not exists updated_at timestamptz,
  add column if not exists updated_by uuid references public.profiles(id) on delete set null;

alter table public.appointments
  add column if not exists history_archived_at timestamptz,
  add column if not exists history_archived_by uuid references public.profiles(id) on delete set null;

create index if not exists encounters_history_archive_idx
  on public.encounters(clinic_id, history_archived_at, created_at desc);
create index if not exists appointments_history_archive_idx
  on public.appointments(clinic_id, history_archived_at, starts_at desc);

create table if not exists public.treatment_history_revisions (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  source text not null check (source in ('encounter','appointment')),
  record_id uuid not null,
  patient_id uuid references public.patients(id) on delete set null,
  changed_by uuid references public.profiles(id) on delete set null,
  action text not null default 'edit' check (action in ('edit','archive','restore')),
  before_data jsonb not null default '{}'::jsonb,
  after_data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists treatment_history_revisions_idx
  on public.treatment_history_revisions(clinic_id, source, record_id, created_at desc);
alter table public.treatment_history_revisions enable row level security;
drop policy if exists "treatment_history_revisions_select" on public.treatment_history_revisions;
create policy "treatment_history_revisions_select" on public.treatment_history_revisions for select to authenticated
using (
  public.current_app_role()='platform_admin' or
  (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
);

alter table public.health_department_records
  add column if not exists updated_at timestamptz,
  add column if not exists updated_by uuid references public.profiles(id) on delete set null,
  add column if not exists archived_at timestamptz,
  add column if not exists archived_by uuid references public.profiles(id) on delete set null;
create index if not exists health_department_records_archive_idx
  on public.health_department_records(clinic_id, archived_at, created_at desc);

create table if not exists public.health_department_report_drafts (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  report_type text not null check (report_type in ('monthly','yearly')),
  period_key text not null,
  report_rows jsonb not null default '[]'::jsonb,
  ebarimt_rows jsonb not null default '[]'::jsonb,
  notes text,
  status text not null default 'draft' check (status in ('draft','ready')),
  created_by uuid references public.profiles(id) on delete set null,
  updated_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(clinic_id, report_type, period_key)
);
create index if not exists health_department_report_drafts_idx
  on public.health_department_report_drafts(clinic_id, report_type, period_key);
alter table public.health_department_report_drafts enable row level security;
drop policy if exists "health_department_report_drafts_select" on public.health_department_report_drafts;
create policy "health_department_report_drafts_select" on public.health_department_report_drafts for select to authenticated
using (
  public.current_app_role()='platform_admin' or
  (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
);
drop policy if exists "health_department_report_drafts_owner_write" on public.health_department_report_drafts;
create policy "health_department_report_drafts_owner_write" on public.health_department_report_drafts for all to authenticated
using (clinic_id=public.current_clinic_id() and public.current_app_role()='owner')
with check (clinic_id=public.current_clinic_id() and public.current_app_role()='owner');

create table if not exists public.health_department_report_revisions (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  draft_id uuid not null references public.health_department_report_drafts(id) on delete cascade,
  changed_by uuid references public.profiles(id) on delete set null,
  before_data jsonb not null default '{}'::jsonb,
  after_data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists health_department_report_revisions_idx
  on public.health_department_report_revisions(clinic_id, draft_id, created_at desc);
alter table public.health_department_report_revisions enable row level security;
drop policy if exists "health_department_report_revisions_select" on public.health_department_report_revisions;
create policy "health_department_report_revisions_select" on public.health_department_report_revisions for select to authenticated
using (
  public.current_app_role()='platform_admin' or
  (clinic_id=public.current_clinic_id() and public.current_app_role() in ('owner','employee'))
);

commit;
