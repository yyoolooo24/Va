import fs from 'node:fs';
const checks=[
 ['components/StaffTreatmentHistory.tsx',['Архив','Засварын түүх','action:\'edit\'','action:restore']],
 ['app/api/clinic/treatment-history/route.ts',['treatment_history_revisions','history_archived_at','export async function PATCH','export async function DELETE']],
 ['components/HealthDepartmentWorkspace.tsx',['health_department_report_drafts','saveReportDraft','Хадгалсан тайлан засах','archiveRecord']],
 ['supabase/v8_19_3_history_report_audit.sql',['treatment_history_revisions','health_department_report_drafts','health_department_report_revisions','history_archived_at']],
 ['app/globals.css',['DentHub V8.19.3','history-view-toggle','saved-report-status']]
];
let failed=false;
for(const [file,needles] of checks){const text=fs.readFileSync(file,'utf8');for(const needle of needles){if(!text.includes(needle)){console.error(`MISSING ${needle} in ${file}`);failed=true;}}}
if(failed)process.exit(1);
console.log('DentHub V8.19.3 validation passed.');
