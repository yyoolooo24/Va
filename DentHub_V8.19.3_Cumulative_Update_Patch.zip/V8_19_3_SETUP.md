# V8.19.3 setup

1. Run `supabase/v8_19_3_history_report_audit.sql` in Supabase SQL Editor once.
2. In the existing Codespace folder, apply the V8.19.3 patch.
3. Run:

```bash
npm run validate:v8.19.3
npm run build
npx vercel --prod
```

This migration is additive: it adds archive/audit/report-draft tables and columns; it does not delete existing clinical or report data.
