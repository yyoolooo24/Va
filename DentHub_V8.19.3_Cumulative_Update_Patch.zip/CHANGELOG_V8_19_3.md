# DentHub V8.19.3 — Treatment History + NEMG Report Audit

## Treatment history
- Permanent delete removed from the clinic treatment-history API/UI.
- Added **Archive / Restore** instead of destructive delete.
- Added **Edit** for clinical history text fields.
- Every edit/archive/restore writes a revision into `treatment_history_revisions` with before/after data and actor/time.
- Added revision-history viewer inside the Treatment History module.
- Archived rows are kept separately and can be restored.

## Нийслэлийн эрүүл мэндийн газар
- Monthly/yearly calculated reports can now be **saved as a draft snapshot**.
- Saved snapshots can be reopened and **edited cell-by-cell**.
- `Шинээр бодох` reloads fresh DentHub values without silently overwriting the saved report.
- Saving an edited report creates an audit revision.
- Existing НЭМГ document records can now be edited later, including title/period/notes and optional file replacement.
- Document records archive instead of hard delete.

## Database
Run `supabase/v8_19_3_history_report_audit.sql` once before using these features.
