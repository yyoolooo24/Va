'use client';

import { useEffect, useMemo, useState } from 'react';
import { Building2, Check, FilePenLine, Loader2, Pencil, Plus, Printer, Save, Search, Trash2 } from 'lucide-react';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import type { AppLang, AppProfile } from './DashboardApp';
import ConfirmDialog from './ui/ConfirmDialog';

export type OfficialDocument = {
  id:string;
  organizationName:string;
  contactBlock:string;
  topRightTitle:string;
  documentNo:string;
  documentDate:string;
  recipient:string;
  referenceNo:string;
  heading:string;
  body:string;
  signerTitle:string;
  signerName:string;
  note?:string;
  status:'draft'|'ready';
  createdAt?:string;
  updatedAt?:string;
  createdBy?:string|null;
  updatedBy?:string|null;
};

type Form = Omit<OfficialDocument,'id'|'createdAt'|'updatedAt'|'createdBy'|'updatedBy'>;

function today(){return new Date().toISOString().slice(0,10)}
function displayDate(value:string){if(!value)return '';const [y,m,d]=value.split('-');return y&&m&&d?`${y}.${m}.${d}`:value}
function printParagraphs(value:string){return value.split(/\n\s*\n/g).map(x=>x.replace(/\n+/g,' ').trim()).filter(Boolean)}
function freshForm(clinicName:string,signerName:string):Form{return {
  organizationName:clinicName,
  contactBlock:'',
  topRightTitle:'',
  documentNo:'',
  documentDate:today(),
  recipient:'',
  referenceNo:'',
  heading:'',
  body:'',
  signerTitle:'ГҮЙЦЭТГЭХ ЗАХИРАЛ',
  signerName,
  note:'',
  status:'draft',
}}

export default function OfficialDocumentsWorkspace({profile,clinicName,clinicLogoUrl,lang}:{profile:AppProfile;clinicName:string;clinicLogoUrl?:string|null;lang:AppLang}){
  const en=lang==='EN';
  const [items,setItems]=useState<OfficialDocument[]>([]);
  const [editingId,setEditingId]=useState<string|null>(null);
  const [form,setForm]=useState<Form>(()=>freshForm(clinicName,profile.full_name||''));
  const [query,setQuery]=useState('');
  const [loading,setLoading]=useState(true);
  const [saving,setSaving]=useState(false);
  const [error,setError]=useState('');
  const [notice,setNotice]=useState('');
  const [deleteItem,setDeleteItem]=useState<OfficialDocument|null>(null);
  const [printDoc,setPrintDoc]=useState<OfficialDocument|null>(null);

  const filtered=useMemo(()=>{const q=query.trim().toLowerCase();if(!q)return items;return items.filter(x=>`${x.topRightTitle} ${x.heading} ${x.recipient} ${x.referenceNo||''} ${x.documentNo} ${x.body}`.toLowerCase().includes(q))},[items,query]);

  async function token(){const s=getSupabaseBrowser();if(!s)return '';const {data}=await s.auth.getSession();return data.session?.access_token||''}
  async function api(path:string,init?:RequestInit){const t=await token();const res=await fetch(path,{...init,headers:{'Content-Type':'application/json',Authorization:`Bearer ${t}`,...(init?.headers||{})}});const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Алдаа гарлаа.');return body}

  async function load(){
    if(!isSupabaseConfigured()){setLoading(false);return}
    setLoading(true);setError('');
    try{const body=await api('/api/official-documents');setItems(body.items||[])}catch(e:any){setError(e?.message||'Албан бичиг ачаалж чадсангүй.')}finally{setLoading(false)}
  }
  useEffect(()=>{void load()},[profile.clinic_id]);
  useEffect(()=>{if(!notice)return;const t=window.setTimeout(()=>setNotice(''),2600);return()=>window.clearTimeout(t)},[notice]);

  function newDocument(){setEditingId(null);setForm(freshForm(clinicName,profile.full_name||''));setError('');window.scrollTo({top:0,behavior:'smooth'})}
  function edit(item:OfficialDocument){setEditingId(item.id);setForm({organizationName:item.organizationName||clinicName,contactBlock:item.contactBlock||'',topRightTitle:item.topRightTitle||'',documentNo:item.documentNo||'',documentDate:item.documentDate||today(),recipient:item.recipient||'',referenceNo:item.referenceNo||'',heading:item.heading||'',body:item.body||'',signerTitle:item.signerTitle||'',signerName:item.signerName||'',note:item.note||'',status:item.status==='ready'?'ready':'draft'});setError('');window.scrollTo({top:0,behavior:'smooth'})}
  function snapshot():OfficialDocument{return {id:editingId||'preview',...form}}
  function printCurrent(item?:OfficialDocument){
    const previousTitle=document.title;
    setPrintDoc(item||snapshot());
    // Browser print headers often use the page title. Blank it while printing, then restore.
    document.title='';
    const restore=()=>{document.title=previousTitle;window.removeEventListener('afterprint',restore)};
    window.addEventListener('afterprint',restore);
    window.setTimeout(()=>{window.print();window.setTimeout(()=>{if(document.title==='')restore()},1000)},120);
  }

  async function save(){
    if(!form.heading.trim()&&!form.body.trim()&&!form.topRightTitle.trim()){setError(en?'Enter the document title or body first.':'Албан бичгийн гарчиг эсвэл агуулгыг оруулна уу.');return}
    setSaving(true);setError('');
    try{
      const payload={id:editingId||undefined,...form,organizationName:form.organizationName.trim()||clinicName,signerName:form.signerName.trim()||profile.full_name};
      const body=await api('/api/official-documents',{method:editingId?'PATCH':'POST',body:JSON.stringify(payload)});
      const item=body.item as OfficialDocument;
      setItems(list=>[item,...list.filter(x=>x.id!==item.id)]);
      setEditingId(item.id);
      setForm({organizationName:item.organizationName,contactBlock:item.contactBlock,topRightTitle:item.topRightTitle,documentNo:item.documentNo,documentDate:item.documentDate,recipient:item.recipient,referenceNo:item.referenceNo||'',heading:item.heading,body:item.body,signerTitle:item.signerTitle,signerName:item.signerName,note:item.note||'',status:item.status});
      setNotice(en?'Official document saved.':'Албан бичиг хадгалагдлаа.');
    }catch(e:any){setError(e?.message||'Албан бичиг хадгалж чадсангүй.')}finally{setSaving(false)}
  }

  async function remove(){if(!deleteItem)return;setSaving(true);setError('');try{await api('/api/official-documents',{method:'DELETE',body:JSON.stringify({id:deleteItem.id})});setItems(list=>list.filter(x=>x.id!==deleteItem.id));if(editingId===deleteItem.id)newDocument();setDeleteItem(null);setNotice(en?'Document deleted.':'Албан бичиг устгагдлаа.')}catch(e:any){setError(e?.message||'Устгаж чадсангүй.')}finally{setSaving(false)}}

  return <div className="page-stack official-documents-page">
    <header className="page-head official-documents-head"><div><small>{clinicName}</small><h1>{en?'Official documents':'Албан бичиг'}</h1><p>{en?'Create, edit, save and print A4 official letters with your clinic logo.':'Эмнэлгийн логотой A4 албан бичиг үүсгэж, текстийг шууд засаж, хадгалаад хэвлэнэ.'}</p></div><button className="btn-primary" onClick={newDocument}><Plus size={17}/>{en?'New document':'Шинэ албан бичиг'}</button></header>
    {error&&<div className="inline-error">{error}</div>}{notice&&<div className="inline-success"><Check size={16}/>{notice}</div>}

    <section className="official-documents-layout">
      <aside className="panel-card official-documents-list-panel">
        <div className="official-documents-list-head"><div><b>{en?'Saved documents':'Хадгалсан бичиг'}</b><small>{items.length} {en?'documents':'бичиг'}</small></div><button className="icon-btn-soft" onClick={newDocument} title={en?'New':'Шинэ'}><Plus size={17}/></button></div>
        <label className="module-search official-document-search"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={en?'Search documents…':'Албан бичиг хайх…'}/></label>
        <div className="official-document-list">
          {loading?<div className="official-document-loading"><Loader2 className="spin"/></div>:filtered.length?filtered.map(item=><button key={item.id} className={editingId===item.id?'active':''} onClick={()=>edit(item)}><span className="official-document-list-icon"><FilePenLine size={17}/></span><span><b>{item.heading||item.topRightTitle||(en?'Untitled document':'Гарчиггүй бичиг')}</b><small>{displayDate(item.documentDate)}{item.documentNo?` · № ${item.documentNo}`:''}</small><em>{item.status==='ready'?(en?'READY':'БЭЛЭН'):(en?'DRAFT':'НООРОГ')}</em></span></button>):<div className="empty-state official-document-empty"><FilePenLine/><b>{en?'No saved documents yet':'Хадгалсан албан бичиг алга'}</b><small>{en?'Create your first official letter.':'Шинэ албан бичиг үүсгээд хадгална уу.'}</small></div>}
        </div>
      </aside>

      <main className="panel-card official-document-editor-shell">
        <div className="official-document-toolbar">
          <div><small>{editingId?(en?'Editing saved document':'Хадгалсан бичиг засаж байна'):(en?'New document':'Шинэ албан бичиг')}</small><b>{form.heading||form.topRightTitle||(en?'Untitled official document':'Гарчиггүй албан бичиг')}</b></div>
          <div className="official-document-toolbar-actions"><label className="official-document-date-meta"><span>{en?'Date':'Огноо'}</span><input type="date" value={form.documentDate} onChange={e=>setForm(v=>({...v,documentDate:e.target.value}))}/></label><label className="official-status-toggle"><input type="checkbox" checked={form.status==='ready'} onChange={e=>setForm(v=>({...v,status:e.target.checked?'ready':'draft'}))}/><span>{form.status==='ready'?(en?'Ready':'Бэлэн'):(en?'Draft':'Ноорог')}</span></label><button className="btn-light" onClick={()=>printCurrent()}><Printer size={16}/>{en?'Print':'Хэвлэх'}</button><button className="btn-primary" onClick={save} disabled={saving}>{saving?<Loader2 className="spin" size={16}/>:<Save size={16}/>} {en?'Save':'Хадгалах'}</button></div>
        </div>

        <div className="official-paper-stage">
          <article className="official-paper" aria-label={en?'Editable official document':'Засварлах албан бичиг'}>
            <section className="official-paper-letterhead">
              <div className="official-paper-brand-block">
                <div className="official-paper-logo-banner">{clinicLogoUrl?<img src={clinicLogoUrl} alt={`${clinicName} logo`}/>:<span className="official-paper-logo-placeholder"><Building2/></span>}</div>
                <input className="official-paper-org-input" value={form.organizationName} onChange={e=>setForm(v=>({...v,organizationName:e.target.value}))} placeholder={clinicName}/>
                <textarea className="official-paper-contact-input" value={form.contactBlock} onChange={e=>setForm(v=>({...v,contactBlock:e.target.value}))} placeholder={en?'District, khoroo, address\nPhone\nEmail':'Дүүрэг, хороо, хаяг\nУтас\nИ-мэйл'} rows={5}/>
              </div>
              <textarea className="official-paper-top-title" value={form.topRightTitle} onChange={e=>setForm(v=>({...v,topRightTitle:e.target.value}))} placeholder={en?'Top-right title':'Баруун дээд гарчиг'} rows={4}/>
            </section>

            <section className="official-paper-reference-block">
              <div className="official-paper-number-line">
                <span className="official-paper-number-rule"/>
                <span>№</span>
                <input value={form.documentNo} onChange={e=>setForm(v=>({...v,documentNo:e.target.value}))} aria-label={en?'Document number':'Албан бичгийн дугаар'} placeholder="________________"/>
              </div>
              <div className="official-paper-incoming-line">
                <span>{en?'your':'танай'}</span>
                <input value={form.recipient} onChange={e=>setForm(v=>({...v,recipient:e.target.value}))} aria-label={en?'Incoming date/reference':'Танай огноо / тайлбар'} placeholder="______________"/>
                <span>{en?'No.':'-ны №'}</span>
                <input value={form.referenceNo} onChange={e=>setForm(v=>({...v,referenceNo:e.target.value}))} aria-label={en?'Incoming reference number':'Танай бичгийн дугаар'} placeholder="__________"/>
                <span>{en?'ref.':'-т'}</span>
              </div>
            </section>
            <input className="official-paper-heading" value={form.heading} onChange={e=>setForm(v=>({...v,heading:e.target.value}))} placeholder={en?'Subject / heading':'Гарчиг (ж: Ажилд томилох тухай:)'}/>
            <textarea className="official-paper-body" value={form.body} onChange={e=>setForm(v=>({...v,body:e.target.value}))} placeholder={en?'Type the official document body here…':'Албан бичгийн үндсэн агуулгыг энд бичнэ…'} rows={18}/>
            <section className="official-paper-signature"><input value={form.signerTitle} onChange={e=>setForm(v=>({...v,signerTitle:e.target.value}))} placeholder={en?'Signer title':'Албан тушаал'}/><input value={form.signerName} onChange={e=>setForm(v=>({...v,signerName:e.target.value}))} placeholder={en?'Signer name':'Гарын үсэг зурах хүний нэр'}/></section>
          </article>
        </div>

        {editingId&&<div className="official-document-saved-actions"><button className="btn-light" onClick={()=>printCurrent()}><Printer size={15}/>{en?'Print current':'Хэвлэх'}</button><button className="btn-light" onClick={()=>{const item=items.find(x=>x.id===editingId);if(item)edit(item)}}><Pencil size={15}/>{en?'Reload saved':'Хадгалсныг сэргээх'}</button>{profile.role==='owner'&&<button className="btn-light danger" onClick={()=>{const item=items.find(x=>x.id===editingId);if(item)setDeleteItem(item)}}><Trash2 size={15}/>{en?'Delete':'Устгах'}</button>}</div>}
      </main>
    </section>

    {printDoc&&<article className="official-print-root" aria-hidden="true">
      <section className="official-print-letterhead"><div className="official-print-brand">{clinicLogoUrl&&<img src={clinicLogoUrl} alt=""/>}<b>{printDoc.organizationName||clinicName}</b>{printDoc.contactBlock&&<p>{printDoc.contactBlock}</p>}</div>{printDoc.topRightTitle&&<div className="official-print-top-title">{printDoc.topRightTitle}</div>}</section>
      <section className="official-print-reference-block">
        <div className="official-print-number-line"><span className="official-print-number-rule"/><span>№</span><b>{printDoc.documentNo||'________________'}</b></div>
        <div className="official-print-incoming-line"><span>{en?'your':'танай'}</span><b>{printDoc.recipient||'______________'}</b><span>{en?'No.':'-ны №'}</span><b>{printDoc.referenceNo||'__________'}</b><span>{en?'ref.':'-т'}</span></div>
      </section>
      {printDoc.heading&&<h1 className="official-print-heading">{printDoc.heading}</h1>}
      <section className="official-print-body">{printParagraphs(printDoc.body).map((paragraph,i)=><p key={i}>{paragraph}</p>)}</section>
      <section className="official-print-signature"><b>{printDoc.signerTitle}</b><span>/{printDoc.signerName}/</span></section>
    </article>}

    <ConfirmDialog open={Boolean(deleteItem)} title={en?'Delete this official document?':'Энэ албан бичгийг устгах уу?'} description={deleteItem?.heading||deleteItem?.topRightTitle||''} confirmLabel={en?'Delete':'Устгах'} cancelLabel={en?'Cancel':'Болих'} busy={saving} onCancel={()=>!saving&&setDeleteItem(null)} onConfirm={remove}/>
  </div>
}
