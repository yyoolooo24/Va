import { NextRequest, NextResponse } from 'next/server';
import { apiErrorStatus, requireApiUser, requireModule } from '@/lib/auth';

function isDoctorProfile(profile:any){return profile?.role==='employee'&&(profile?.staff_type==='doctor'||(!profile?.staff_type&&/(эмч|doctor|dentist|orthodont|surgeon)/i.test(String(profile?.specialty||''))))}
function rawId(value:string){return String(value||'').replace(/^(enc|apt)-/,'')}
function safeText(value:any){const x=String(value??'').trim();return x||null}

async function getRecord(admin:any,clinicId:string,source:string,id:string,doctorId?:string|null){
  if(source==='appointment'){
    let q=admin.from('appointments').select('id,patient_id,doctor_id,service_name,service_request,clinical_summary,notes,status,starts_at,history_archived_at').eq('id',id).eq('clinic_id',clinicId);
    if(doctorId)q=q.eq('doctor_id',doctorId);
    const {data,error}=await q.maybeSingle();if(error)throw error;return data;
  }
  let q=admin.from('encounters').select('id,patient_id,doctor_id,diagnosis,treatment_plan,notes,status,created_at,history_archived_at').eq('id',id).eq('clinic_id',clinicId);
  if(doctorId)q=q.eq('doctor_id',doctorId);
  const {data,error}=await q.maybeSingle();if(error)throw error;return data;
}

async function loadEncounters(admin:any,clinicId:string,archived:boolean,patientId?:string,doctorId?:string){
  let q=admin.from('encounters').select('id,appointment_id,patient_id,doctor_id,diagnosis,treatment_plan,notes,selected_teeth,dentition,status,deleted_at,created_at,updated_at,history_archived_at,patients(full_name,phone),doctor:profiles!encounters_doctor_id_fkey(full_name),treatment_lines:encounter_treatments(id,tooth_no,service_name,notes,unit_price,total_amount,created_at)').eq('clinic_id',clinicId);
  q=archived?q.not('history_archived_at','is',null):q.is('history_archived_at',null);
  if(patientId)q=q.eq('patient_id',patientId);if(doctorId)q=q.eq('doctor_id',doctorId);
  const {data,error}=await q.order('created_at',{ascending:false}).limit(1000);if(error)throw error;return data||[];
}
async function loadAppointments(admin:any,clinicId:string,archived:boolean,patientId?:string,doctorId?:string){
  let q=admin.from('appointments').select('id,patient_id,doctor_id,service_name,service_request,clinical_summary,notes,status,starts_at,history_archived_at,patients(full_name,phone),doctor:profiles!appointments_doctor_id_fkey(full_name)').eq('clinic_id',clinicId).in('status',['completed','done']);
  q=archived?q.not('history_archived_at','is',null):q.is('history_archived_at',null);
  if(patientId)q=q.eq('patient_id',patientId);if(doctorId)q=q.eq('doctor_id',doctorId);
  const {data,error}=await q.order('starts_at',{ascending:false}).limit(1000);if(error)throw error;return data||[];
}

export async function GET(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','employee']);requireModule(auth,'treatment_history');const {profile,admin}=auth;const clinicId=profile.clinic_id;if(!clinicId)return NextResponse.json({items:[]});
    const source=String(request.nextUrl.searchParams.get('source')||'');const revisionId=rawId(String(request.nextUrl.searchParams.get('revisionFor')||''));
    if(revisionId&&source){
      const doctorId=isDoctorProfile(profile)?String(profile.id):null;const record=await getRecord(admin,clinicId,source,revisionId,doctorId);if(!record)return NextResponse.json({revisions:[]});
      const {data,error}=await admin.from('treatment_history_revisions').select('id,action,before_data,after_data,created_at,changed_by').eq('clinic_id',clinicId).eq('source',source).eq('record_id',revisionId).order('created_at',{ascending:false}).limit(100);if(error)throw error;
      return NextResponse.json({revisions:data||[]});
    }
    const patientId=String(request.nextUrl.searchParams.get('patientId')||'').trim();const archived=request.nextUrl.searchParams.get('archived')==='1';const doctorId=isDoctorProfile(profile)?String(profile.id):undefined;
    const [encRaw,aptRaw,linkedRaw]=await Promise.all([loadEncounters(admin,clinicId,archived,patientId||undefined,doctorId),loadAppointments(admin,clinicId,archived,patientId||undefined,doctorId),(()=>{let q=admin.from('encounters').select('appointment_id').eq('clinic_id',clinicId).not('appointment_id','is',null);if(patientId)q=q.eq('patient_id',patientId);if(doctorId)q=q.eq('doctor_id',doctorId);return q.limit(2000)})()]);
    const encounters=(encRaw||[]).filter((x:any)=>!x.deleted_at&&x.status!=='history_deleted').map((x:any)=>({id:`enc-${x.id}`,source:'encounter',date:x.created_at,patient_id:x.patient_id,patient_name:x.patients?.full_name||'Өвчтөн',phone:x.patients?.phone||null,doctor_name:x.doctor?.full_name||null,title:x.diagnosis||x.treatment_plan||'Үзлэг, эмчилгээ',diagnosis:x.diagnosis||null,treatment_plan:x.treatment_plan||null,notes:x.notes||null,selected_teeth:x.selected_teeth||[],dentition:x.dentition||'adult',status:x.status,treatment_lines:x.treatment_lines||[],appointment_id:x.appointment_id||null,archived_at:x.history_archived_at||null,updated_at:x.updated_at||null}));
    const appointments=(aptRaw||[]).map((x:any)=>({id:`apt-${x.id}`,source:'appointment',date:x.starts_at,patient_id:x.patient_id,patient_name:x.patients?.full_name||'Өвчтөн',phone:x.patients?.phone||null,doctor_name:x.doctor?.full_name||null,title:x.service_name||'Эмчилгээ',diagnosis:x.clinical_summary||null,treatment_plan:x.service_name||null,notes:x.notes||null,patient_request:x.service_request||null,status:x.status,archived_at:x.history_archived_at||null}));
    const linked=new Set(((linkedRaw as any)?.data||[]).map((x:any)=>x.appointment_id).filter(Boolean).map(String));const fallback=appointments.filter((x:any)=>!linked.has(rawId(x.id)));const items=[...encounters,...fallback].sort((a,b)=>+new Date(b.date)-+new Date(a.date));return NextResponse.json({items});
  }catch(error:any){const message=error?.message||'Эмчилгээний түүх ачаалж чадсангүй.';return NextResponse.json({error:message},{status:(()=>{const x=apiErrorStatus(message);return x===500?400:x})()})}
}

export async function PATCH(request:NextRequest){
  try{
    const auth=await requireApiUser(request,['owner','employee']);requireModule(auth,'treatment_history');const {profile,admin}=auth;const clinicId=profile.clinic_id;if(!clinicId)throw new Error('FORBIDDEN');
    const body=await request.json();const source=String(body.source||'encounter');const id=rawId(String(body.id||''));if(!id)throw new Error('ID_MISSING');const doctorId=isDoctorProfile(profile)?String(profile.id):null;const current=await getRecord(admin,clinicId,source,id,doctorId);if(!current)throw new Error('HISTORY_NOT_FOUND');
    const action=String(body.action||'edit');let patch:any={};
    if(action==='archive')patch={history_archived_at:new Date().toISOString(),history_archived_by:profile.id};
    else if(action==='restore')patch={history_archived_at:null,history_archived_by:null};
    else if(source==='appointment')patch={service_name:safeText(body.title)||'Эмчилгээ',service_request:safeText(body.patient_request),clinical_summary:safeText(body.diagnosis),notes:safeText(body.notes)};
    else patch={diagnosis:safeText(body.diagnosis),treatment_plan:safeText(body.treatment_plan),notes:safeText(body.notes),updated_at:new Date().toISOString(),updated_by:profile.id};
    const table=source==='appointment'?'appointments':'encounters';let uq=admin.from(table).update(patch).eq('id',id).eq('clinic_id',clinicId);if(doctorId)uq=uq.eq('doctor_id',doctorId);const {error}=await uq;if(error)throw error;const after={...current,...patch};
    const {error:revErr}=await admin.from('treatment_history_revisions').insert({clinic_id:clinicId,source,record_id:id,patient_id:current.patient_id||null,changed_by:profile.id||null,action:action==='archive'?'archive':action==='restore'?'restore':'edit',before_data:current,after_data:after});if(revErr)throw revErr;
    return NextResponse.json({ok:true,id,source,action});
  }catch(error:any){const message=error?.message||'Эмчилгээний түүх шинэчилж чадсангүй.';return NextResponse.json({error:message},{status:(()=>{const x=apiErrorStatus(message);return x===500?400:x})()})}
}

export async function DELETE(){return NextResponse.json({error:'Эмчилгээний түүхийг бүр мөсөн устгахгүй. Архивлах үйлдлийг ашиглана уу.'},{status:405})}
