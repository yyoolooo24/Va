# V8.19.2 setup

No SQL migration is required.

```bash
npm install
npm run validate:v8.19.2
npm run build
npx vercel --prod
```
