# DentHub V8.19 — Official Documents

- Added **Албан бичиг / Official Documents** as a first-class clinic module.
- Matches the supplied Mongolian official-letter draft layout: clinic logo/identity on the upper-left, editable upper-right title, number/date line, subject/body and signature area.
- All visible document text is editable directly on an A4-style canvas.
- Documents can be saved, reopened, edited, marked Draft/Ready, printed and deleted by the clinic owner.
- Saved documents are stored privately as JSON inside the existing Supabase `clinic-documents` bucket under each clinic, so **no new SQL migration is required**.
- Employee access can be granted from Management → module permissions using the new `Албан бичиг` permission.
- Print view is A4-optimized and uses the clinic logo configured in DentHub branding.
