'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Bell, Boxes, CalendarDays, CircleDollarSign, ClipboardPlus, CreditCard, FileBarChart, FileText,
  Home, LogOut, Menu, MessageSquare, Moon, PanelLeftClose, PanelLeftOpen, Search, ShieldCheck,
  Stethoscope, Sun, UsersRound, X, Building2, CircleUserRound, CheckCircle2,
  MessageCircle, Heart, UserPlus, ArrowRight, LayoutGrid, Tags, UserCog, Clock3, Truck, ShoppingCart,
  ClipboardList, ArrowLeftRight, ReceiptText, HandCoins, TestTube2, ContactRound, ShieldPlus, Wrench, Warehouse,
  ShoppingBag, RotateCcw, Banknote, BadgePercent, BookOpenCheck, FileSignature, ListChecks, SlidersHorizontal, FilePenLine
} from 'lucide-react';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import DashboardHome from './DashboardHome';
import Notifications from './Notifications';
import AdminPanel from './AdminPanel';
import PaymentPanel from './PaymentPanel';
import ClientPurchaseHistory from './ClientPurchaseHistory';
import ClientTreatmentHistory from './ClientTreatmentHistory';
import StaffTreatmentHistory from './StaffTreatmentHistory';
import ModulePage from './ModulePage';
import ERPOverview from './ERPOverview';
import TreatmentWorkspace from './TreatmentWorkspace';
import PatientCardsWorkspace from './PatientCardsWorkspace';
import ClientPatientCard from './ClientPatientCard';
import InternalProceduresWorkspace from './InternalProceduresWorkspace';
import HealthDepartmentWorkspace from './HealthDepartmentWorkspace';
import FinanceWorkspace from './FinanceWorkspace';
import ContractsWorkspace from './ContractsWorkspace';
import HealthQuestionnaireWorkspace from './HealthQuestionnaireWorkspace';
import ConsentFormsWorkspace from './ConsentFormsWorkspace';
import PlatformSubscriptionPlans from './PlatformSubscriptionPlans';
import OfficialDocumentsWorkspace from './OfficialDocumentsWorkspace';

export type Role = 'platform_admin' | 'owner' | 'employee' | 'client' | 'supplier';
export type AppLang = 'MN' | 'EN';
export type ViewKey = 'home' | 'subscriptions' | 'appointments' | 'consent_forms' | 'official_documents' | 'treatment_history' | 'patients' | 'patient_cards' | 'treatments' | 'payments' | 'erp' | 'sales' | 'sales_returns' | 'cashbook' | 'price_lists' | 'services' | 'inventory' | 'stock_movements' | 'suppliers' | 'procurement' | 'purchase_orders' | 'lab_orders' | 'rooms' | 'crm' | 'insurance' | 'invoices' | 'receivables' | 'expenses' | 'finance' | 'staff' | 'shifts' | 'assets' | 'branches' | 'supplier_warehouse' | 'partner_clinics' | 'internal_procedures' | 'health_department' | 'questionnaire' | 'contracts' | 'reports' | 'chat' | 'notifications' | 'admin' | 'profile';
export type AppProfile = { id?: string; full_name: string; role: Role; clinic_id?: string | null; phone?: string | null; language?: 'mn'|'en'; active?: boolean; specialty?: string | null; staff_type?: string | null; allowed_modules?: string[] | null; clinic_modules?: string[] | null; clinic_status?: string | null; clinic_plan?: string | null };
export type NotificationItem = {
  id:string; type:'connection'|'follow'|'comment'|'like'|'message'|'system'; title:string; detail:string; time:string;
  target:ViewKey; targetId?:string; unread:boolean;
};

type NavMeta = { mn: string; en: string; icon: any };
const navMeta: Record<ViewKey, NavMeta> = {
  home: { mn: 'Нүүр', en: 'Home', icon: Home },
  subscriptions: { mn: 'Багцын тохиргоо', en: 'Subscription Plans', icon: SlidersHorizontal },
  appointments: { mn: 'Цаг товлол', en: 'Appointments', icon: CalendarDays },
  consent_forms: { mn: 'Зөвшөөрлийн хуудас', en: 'Consent Forms', icon: FileSignature },
  official_documents: { mn: 'Албан бичиг', en: 'Official Documents', icon: FilePenLine },
  treatment_history: { mn: 'Эмчилгээний түүх', en: 'Treatment History', icon: ClipboardPlus },
  patients: { mn: 'Өвчтөн', en: 'Patients', icon: UsersRound },
  patient_cards: { mn: 'Өвчтөний карт', en: 'Patient Cards', icon: FileText },
  treatments: { mn: 'Үзлэг, эмчилгээ', en: 'Treatments', icon: ClipboardPlus },
  payments: { mn: 'Касс', en: 'Cashier', icon: CreditCard },
  erp: { mn: 'ERP модулиуд', en: 'ERP Modules', icon: LayoutGrid },
  sales: { mn: 'Борлуулалт', en: 'Sales', icon: ShoppingBag },
  sales_returns: { mn: 'Буцаалт', en: 'Returns', icon: RotateCcw },
  cashbook: { mn: 'Кассын журнал', en: 'Cashbook', icon: Banknote },
  price_lists: { mn: 'Үнийн жагсаалт', en: 'Price Lists', icon: BadgePercent },
  services: { mn: 'Үйлчилгээ & үнэ', en: 'Services & Pricing', icon: Tags },
  inventory: { mn: 'Бараа материал', en: 'Inventory', icon: Boxes },
  stock_movements: { mn: 'Барааны хөдөлгөөн', en: 'Stock Movement', icon: ArrowLeftRight },
  suppliers: { mn: 'Ханган нийлүүлэгч', en: 'Suppliers', icon: Truck },
  procurement: { mn: 'Худалдан авалт', en: 'Procurement', icon: ShoppingCart },
  purchase_orders: { mn: 'Захиалга / PO', en: 'Purchase Orders', icon: ClipboardList },
  lab_orders: { mn: 'Лабораторийн захиалга', en: 'Lab Orders', icon: TestTube2 },
  rooms: { mn: 'Өрөө & кабинет', en: 'Rooms & Operatories', icon: Building2 },
  crm: { mn: 'CRM', en: 'CRM', icon: ContactRound },
  insurance: { mn: 'Даатгал', en: 'Insurance', icon: ShieldPlus },
  invoices: { mn: 'Нэхэмжлэх', en: 'Invoices', icon: ReceiptText },
  receivables: { mn: 'Авлага', en: 'Receivables', icon: HandCoins },
  expenses: { mn: 'Зардал', en: 'Expenses', icon: CircleDollarSign },
  finance: { mn: 'Санхүү', en: 'Finance', icon: CircleDollarSign },
  staff: { mn: 'Ажилтнууд', en: 'Staff', icon: UserCog },
  shifts: { mn: 'Ээлж & хуваарь', en: 'Shifts & Roster', icon: Clock3 },
  assets: { mn: 'Үндсэн хөрөнгө', en: 'Assets', icon: Wrench },
  branches: { mn: 'Салбарууд', en: 'Branches', icon: Warehouse },
  supplier_warehouse: { mn: 'Ханган нийлүүлэх', en: 'Supply', icon: Warehouse },
  partner_clinics: { mn: 'Хамтрагч эмнэлгүүд', en: 'Partner Clinics', icon: Building2 },
  internal_procedures: { mn: 'Дотоод журам', en: 'Internal Procedures', icon: BookOpenCheck },
  health_department: { mn: 'Нийслэлийн ЭМГ', en: 'Health Department', icon: Building2 },
  questionnaire: { mn: 'Бүртгэл & асуумж', en: 'Registration & Questionnaire', icon: ListChecks },
  contracts: { mn: 'Гэрээ', en: 'Contracts', icon: FileSignature },
  reports: { mn: 'Тайлан', en: 'Reports', icon: FileBarChart },
  chat: { mn: 'Чат', en: 'Chat', icon: MessageSquare },
  notifications: { mn: 'Мэдэгдэл', en: 'Notifications', icon: Bell },
  admin: { mn: 'Удирдлага', en: 'Management', icon: ShieldCheck },
  profile: { mn: 'Миний мэдээлэл', en: 'My Profile', icon: CircleUserRound },
};
const navLabel=(key:ViewKey,lang:AppLang)=>lang==='EN'?navMeta[key].en:navMeta[key].mn;
const roleLabel=(role:Role,lang:AppLang)=>lang==='EN'?({platform_admin:'Platform Admin',owner:'Clinic Owner',employee:'Doctor / Staff',client:'Patient',supplier:'Supplier'} as const)[role]:({platform_admin:'Системийн админ',owner:'Эмнэлгийн эзэмшигч',employee:'Эмч / Ажилтан',client:'Өвчтөн',supplier:'Ханган нийлүүлэгч'} as const)[role];


function employeeDefaultViews(specialty?: string | null): ViewKey[] {
  const s=(specialty||'').toLowerCase();
  if(s.includes('ресеп')||s.includes('reception')) return ['appointments','consent_forms','patients','payments','sales','internal_procedures','chat','notifications','profile'];
  if(s.includes('сувила')||s.includes('nurse')) return ['appointments','consent_forms','patients','patient_cards','treatments','treatment_history','inventory','lab_orders','internal_procedures','chat','notifications','profile'];
  if(s.includes('нягт')||s.includes('finance')||s.includes('санхүү')) return ['payments','sales','sales_returns','cashbook','invoices','receivables','expenses','finance','reports','internal_procedures','chat','notifications','profile'];
  if(s.includes('эмч')||s.includes('doctor')||s.includes('dentist')) return ['appointments','consent_forms','patients','patient_cards','treatments','treatment_history','services','staff','contracts','internal_procedures','chat','notifications','profile'];
  return ['appointments','consent_forms','patients','staff','contracts','internal_procedures','chat','notifications','profile'];
}

function viewsForProfile(profile: AppProfile): ViewKey[] {
  if (profile.role === 'platform_admin') return ['home', 'admin', 'subscriptions', 'reports', 'notifications', 'profile'];
  const clinicModules=new Set([...(profile.clinic_modules||[]),'official_documents']);
  const always:ViewKey[]=['home','notifications','profile'];
  if (profile.role === 'owner') {
    const all:ViewKey[]=['appointments','consent_forms','official_documents','patients','patient_cards','treatment_history','treatments','payments','erp','sales','sales_returns','cashbook','price_lists','services','inventory','stock_movements','suppliers','procurement','purchase_orders','lab_orders','crm','insurance','invoices','receivables','expenses','finance','staff','shifts','assets','branches','internal_procedures','health_department','questionnaire','contracts','reports','chat'];
    return [...always,...all.filter(v=>clinicModules.has(v)),'admin'];
  }
  if (profile.role === 'employee') {
    const requested=(profile.allowed_modules||[]).filter((x):x is ViewKey=>x in navMeta && !['admin','supplier_warehouse','partner_clinics','rooms'].includes(x));
    const roleViews=requested.length?requested:employeeDefaultViews(profile.specialty);
    return Array.from(new Set<ViewKey>([...always,...roleViews.filter(v=>clinicModules.has(v))]));
  }
  if (profile.role === 'supplier') return ['home', 'supplier_warehouse', 'partner_clinics', 'chat', 'notifications', 'profile'];
  return ['home', 'appointments', 'patient_cards', 'treatment_history', 'payments', 'chat', 'notifications', 'profile'];
}

function relativeTime(value:string|undefined,lang:AppLang){
  if(!value) return '';
  const en=lang==='EN';
  const ms=Date.now()-new Date(value).getTime();
  const min=Math.max(0,Math.floor(ms/60000));
  if(min<1) return en?'Just now':'Дөнгөж сая';
  if(min<60) return en?`${min} min`:`${min} минут`;
  const hr=Math.floor(min/60); if(hr<24) return en?`${hr} hr`:`${hr} цаг`;
  const day=Math.floor(hr/24); if(day<7) return en?`${day} day${day===1?'':'s'}`:`${day} өдөр`;
  return new Date(value).toLocaleDateString(en?'en-US':'mn-MN');
}

function notificationBody(kind:string,body:string|undefined,lang:AppLang){
  if(lang==='MN') return body||'';
  const exact:Record<string,string>={
    'Танд шинэ мессеж ирлээ':'Sent you a new message',
  };
  return exact[body||'']||body||({comment:'New comment',like:'New like',follow:'New follower',connection:'Connection update',message:'New message',system:'System notification'} as Record<string,string>)[kind]||'';
}

function mapDbNotification(row:any,lang:AppLang):NotificationItem{
  const kind=['connection','follow','comment','like','message','system'].includes(row.kind)?row.kind:'system';
  let target:ViewKey='notifications';
  if(row.target_type==='post'||kind==='comment'||kind==='like') target='notifications';
  else if(row.target_type==='chat'||kind==='message') target='chat';
  else if(row.target_type==='profile'||kind==='connection'||kind==='follow') target='notifications';
  return {id:String(row.id),type:kind,title:row.title||(lang==='EN'?'Notification':'Мэдэгдэл'),detail:notificationBody(kind,row.body,lang),time:relativeTime(row.created_at,lang),target,targetId:row.target_id||undefined,unread:!row.read_at};
}
function NotificationIcon({type}:{type:NotificationItem['type']}) {
  if(type==='comment') return <MessageCircle size={18}/>;
  if(type==='like') return <Heart size={18}/>;
  if(type==='connection'||type==='follow') return <UserPlus size={18}/>;
  return <Bell size={18}/>;
}

export default function DashboardApp() {
  const router = useRouter();
  const [profile, setProfile] = useState<AppProfile | null>(null);
  const [clinicName, setClinicName] = useState('Төв эмнэлэг');
  const [clinicLogoUrl, setClinicLogoUrl] = useState<string | null>(null);
  const [view, setView] = useState<ViewKey>('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCompact, setSidebarCompact] = useState(false);
  const [loading, setLoading] = useState(true);
  const [focusId, setFocusId] = useState<string | undefined>();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [theme, setTheme] = useState<'light'|'dark'>('light');
  const [largeText, setLargeText] = useState(false);
  const [lang, setLang] = useState<AppLang>('MN');
  const [search, setSearch] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const savedTheme = (localStorage.getItem('clinicos-theme') as 'light'|'dark' | null) || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    setTheme(savedTheme);
    document.documentElement.dataset.theme = savedTheme;
    const savedLarge = localStorage.getItem('clinicos-large-text') === 'true';
    const savedLang=(localStorage.getItem('clinicos-lang') as AppLang|null)||'MN'; setLang(savedLang); document.documentElement.lang=savedLang==='MN'?'mn':'en';
    setLargeText(savedLarge);
    document.documentElement.dataset.largeText = savedLarge ? 'true' : 'false';
  }, []);

  useEffect(() => {
    function onDown(e:MouseEvent){ if(notificationRef.current && !notificationRef.current.contains(e.target as Node)) setNotificationOpen(false); }
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, []);

  useEffect(() => {
    (async () => {
      if (!isSupabaseConfigured()) { router.replace('/'); setLoading(false); return; }
      const supabase = getSupabaseBrowser();
      const { data: sessionData } = await supabase!.auth.getSession();
      if (!sessionData.session) { router.replace('/'); return; }
      const { data, error } = await supabase!.from('profiles').select('id, full_name, role, clinic_id, phone, language, active, specialty, staff_type, allowed_modules').eq('id', sessionData.session.user.id).single();
      if (error || !data || (data as any).active === false) { if((data as any)?.active===false) await supabase!.auth.signOut(); router.replace('/'); return; }
      let nextProfile={...(data as AppProfile)};
      if((data as any).language){ const dbLang=(data as any).language==='en'?'EN':'MN'; setLang(dbLang); localStorage.setItem('clinicos-lang',dbLang); document.documentElement.lang=dbLang==='MN'?'mn':'en'; }
      if(data.clinic_id){
        const {data: clinic}=await supabase!.from('clinics').select('name,logo_url,status,plan,enabled_modules').eq('id',data.clinic_id).maybeSingle();
        if(!clinic){await supabase!.auth.signOut();router.replace('/?access=clinic-blocked');return;}
        if(clinic?.name) setClinicName(clinic.name);
        setClinicLogoUrl((clinic as any)?.logo_url||null);
        nextProfile={...nextProfile,clinic_modules:(clinic as any)?.enabled_modules||[],clinic_status:(clinic as any)?.status||null,clinic_plan:(clinic as any)?.plan||null};
      } else if ((data as any).role === 'supplier') {
        const {data: supplier}=await supabase!.from('supplier_profiles').select('company_name').eq('user_id',data.id).maybeSingle();
        setClinicName(supplier?.company_name || (data as any).full_name || 'Supplier');
      } else if ((data as any).role === 'client') {
        setClinicName('DentHub');
      }
      setProfile(nextProfile);
      setLoading(false);
    })();
  }, [router]);


  useEffect(()=>{
    if(!profile?.id || !isSupabaseConfigured()) return;
    const supabase=getSupabaseBrowser(); if(!supabase) return;
    let alive=true;
    (async()=>{
      const {data}=await supabase.from('notifications').select('id,kind,title,body,target_type,target_id,read_at,created_at').eq('user_id',profile.id).order('created_at',{ascending:false}).limit(40);
      if(alive&&data) setNotifications(data.map((row:any)=>mapDbNotification(row,lang)));
    })();
    const channel=supabase.channel(`clinicos-notifications-${profile.id}`)
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:`user_id=eq.${profile.id}`},(payload:any)=>{
        const next=mapDbNotification(payload.new,lang); setNotifications(list=>[next,...list.filter(n=>n.id!==next.id)]);
      }).subscribe();
    return()=>{alive=false;supabase.removeChannel(channel)};
  },[profile?.id,lang]);

  const nav = useMemo<ViewKey[]>(() => profile ? viewsForProfile(profile) : [], [profile]);
  const unread = notifications.filter(n=>n.unread).length;
  const mobileNav: ViewKey[] = useMemo<ViewKey[]>(() => {
    if (!profile) return [];
    if (profile.role === 'owner') return ['home','appointments','patients','chat','notifications'];
    if (profile.role === 'employee') { const allowed=viewsForProfile(profile); return (['home','appointments','patients','chat','notifications'] as ViewKey[]).filter(v=>allowed.includes(v)); }
    if (profile.role === 'platform_admin') return ['home','admin','subscriptions','notifications','profile'];
    if (profile.role === 'supplier') return ['home','supplier_warehouse','partner_clinics','chat','notifications'];
    return ['home','appointments','patient_cards','payments','chat'];
  }, [profile]);

  function navigate(next: ViewKey, id?: string) {
    if (profile && !viewsForProfile(profile).includes(next)) next = 'home';
    setView(next); setFocusId(id); setSidebarOpen(false); setNotificationOpen(false); setSearchOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function openNotification(item:NotificationItem){
    setNotifications(list=>list.map(n=>n.id===item.id?{...n,unread:false}:n));
    if(profile?.id&&isSupabaseConfigured()) getSupabaseBrowser()?.from('notifications').update({read_at:new Date().toISOString()}).eq('id',item.id).eq('user_id',profile.id).then(()=>{});
    navigate(item.target,item.targetId);
  }

  function markAllRead(){
    setNotifications(list=>list.map(n=>({...n,unread:false})));
    if(profile?.id&&isSupabaseConfigured()) getSupabaseBrowser()?.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',profile.id).is('read_at',null).then(()=>{});
  }

  function toggleTheme(){
    const next=theme==='light'?'dark':'light'; setTheme(next); document.documentElement.dataset.theme=next; localStorage.setItem('clinicos-theme',next);
  }
  function toggleLarge(){
    const next=!largeText; setLargeText(next); document.documentElement.dataset.largeText=String(next); localStorage.setItem('clinicos-large-text',String(next));
  }
  async function toggleLang(){
    const next:AppLang=lang==='MN'?'EN':'MN'; setLang(next); localStorage.setItem('clinicos-lang',next); document.documentElement.lang=next==='MN'?'mn':'en';
    if(profile?.id&&isSupabaseConfigured()) await getSupabaseBrowser()?.from('profiles').update({language:next==='MN'?'mn':'en'}).eq('id',profile.id);
  }

  async function logout() {
    const supabase = getSupabaseBrowser(); if (supabase) await supabase.auth.signOut();
    router.replace('/');
  }

  if (loading || !profile) return <div className="app-loading"><div className="brand-mark"><Stethoscope /></div><p>{lang==='EN'?'Loading DentHub…':'DentHub ачаалж байна…'}</p></div>;
  const en=lang==='EN';
  const userNavLabel=(key:ViewKey)=>key==='payments'&&profile.role==='client'?(lang==='EN'?'Purchase history':'Худалдан авалтын түүх'):key==='treatment_history'&&profile.role==='client'?(lang==='EN'?'Appointment & visit history':'Цаг & үзлэгийн түүх'):navLabel(key,lang);
  const pageLabel = userNavLabel(view);
  const initials = profile.full_name.replace('Др.','').trim().charAt(0) || 'C';

  const navGroups=(()=>{
    if(profile.role==='platform_admin'){
      const keys=['home','admin','subscriptions','reports','notifications','profile'] as ViewKey[];
      return [{id:'platform',label:en?'Platform':'Системийн удирдлага',items:keys.filter(k=>nav.includes(k))}];
    }
    if(!['owner','employee'].includes(profile.role)) return [{id:'main',label:'',items:nav}];
    const definitions=[
      {id:'daily',label:en?'Daily operations':'Өдөр тутмын үйл ажиллагаа',keys:['home','appointments','consent_forms','patients','patient_cards','treatment_history','treatments','payments','chat','notifications'] as ViewKey[]},
      {id:'internal',label:en?'Internal operations':'Дотоод үйл ажиллагаа',keys:['official_documents','erp','services','price_lists','sales','sales_returns','cashbook','inventory','stock_movements','procurement','expenses','finance','staff','shifts','assets','branches','questionnaire','internal_procedures','health_department','reports','admin','profile'] as ViewKey[]},
      {id:'collab',label:en?'Collaborative operations':'Хамтран үйл ажиллагаа',keys:['suppliers','purchase_orders','lab_orders','contracts','crm','insurance','invoices','receivables'] as ViewKey[]},
    ];
    const used=new Set<ViewKey>();const groups=definitions.map(g=>({...g,items:g.keys.filter(k=>{if(!nav.includes(k)||used.has(k))return false;used.add(k);return true})})).filter(g=>g.items.length);
    const rest=nav.filter(k=>!used.has(k));if(rest.length)groups.push({id:'other',label:en?'Other':'Бусад',keys:[] as ViewKey[],items:rest} as any);return groups;
  })();

  const searchItems = (profile.role==='platform_admin' ? [
    {label:en?'Clinic management':'Эмнэлгийн удирдлага',hint:en?'Clinics, access, users':'Эмнэлэг, эрх, хэрэглэгч',view:'admin' as ViewKey},
    {label:en?'Subscription plans':'Багцын тохиргоо',hint:en?'Plans, prices, modules':'Багц, үнэ, модулийн эрх',view:'subscriptions' as ViewKey},
    {label:en?'Reports':'Тайлан',hint:en?'Platform reports':'Системийн тайлан',view:'reports' as ViewKey},
    {label:en?'Notifications':'Мэдэгдэл',hint:en?'Requests and system activity':'Хүсэлт болон системийн үйлдэл',view:'notifications' as ViewKey},
  ] : [
    {label:en?'Find patient':'Өвчтөн хайх',hint:en?'Name, phone, register':'Нэр, утас, регистр',view:'patients' as ViewKey},
    {label:en?'Book appointment':'Цаг товлох',hint:en?'Today, doctor, room':'Өнөөдөр, эмч, өрөө',view:'appointments' as ViewKey},
    ...(profile.role==='client'?[{label:en?'Appointment & visit history':'Цаг & үзлэгийн түүх',hint:en?'Booked, visited, cancelled or missed appointments':'Цаг авсан, ирж үзүүлсэн, цуцалсан, ирээгүй түүх',view:'treatment_history' as ViewKey}]:[]),
    {label:profile.role==='client'?(en?'Purchase history':'Худалдан авалтын түүх'):(en?'Cashier':'Касс'),hint:profile.role==='client'?(en?'Payments and purchase records':'Төлбөр, худалдан авалтын бүртгэл'):(en?'Payment, eBarimt':'Төлбөр, eBarimt'),view:'payments' as ViewKey},
    ...(['owner','employee'].includes(profile.role)?[{label:en?'Official documents':'Албан бичиг',hint:en?'Create, edit, save and print letters':'Үүсгэх, засах, хадгалах, хэвлэх',view:'official_documents' as ViewKey},{label:en?'ERP modules':'ERP модулиуд',hint:en?'Supply, finance, staff, lab':'Хангамж, санхүү, ажилтан, лаборатори',view:'erp' as ViewKey}]:[]),
    {label:en?'Chat':'Чат',hint:en?'Message patients or clinic staff':'Өвчтөн эсвэл эмнэлгийн ажилтантай чатлах',view:'chat' as ViewKey},
  ]).filter(x=>!search || `${x.label} ${x.hint}`.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className={`app-shell ${sidebarCompact ? 'sidebar-compact' : ''}`}>
      <div className={`mobile-scrim ${sidebarOpen ? 'show' : ''}`} onClick={() => setSidebarOpen(false)} />
      <aside className={`app-sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-brand-row">
          <button className="brand-lockup sidebar-lockup" onClick={() => navigate('home')} aria-label="DentHub home">
            <div className="brand-mark"><Stethoscope size={23} /></div>
            <div className="brand-copy"><strong>DENTHUB</strong><span>{en?'clinic management':'эмнэлгийн удирдлага'}</span></div>
          </button>
          <button className="sidebar-close-mobile" onClick={() => setSidebarOpen(false)}><X size={20} /></button>
        </div>

        <div className="tenant-chip">
          <span className={`tenant-avatar ${clinicLogoUrl?'has-logo':''}`}>{clinicLogoUrl?<img src={clinicLogoUrl} alt={`${clinicName} logo`}/>:<Building2 size={21} />}</span>
          <span className="tenant-text"><b>{profile.role === 'platform_admin' ? (en?'Platform administration':'Системийн удирдлага') : clinicName}</b><small>{profile.role === 'platform_admin' ? (en?'All clinics & plans':'Эмнэлэг ба багцын хяналт') : `${en?'Plan':'Багц'} · ${profile.clinic_plan||'—'}`}</small></span>
        </div>

        <nav className="main-nav grouped-main-nav">
          {navGroups.map(group=><section className="nav-section" key={group.id}>{group.label&&<div className="nav-section-title">{group.label}</div>}{group.items.map((key:ViewKey)=>{const Icon=navMeta[key].icon;return <button key={key} className={view===key?'active':''} onClick={()=>navigate(key)} title={userNavLabel(key)}><span className="nav-icon"><Icon size={20}/></span><span className="nav-label">{userNavLabel(key)}</span>{key==='notifications'&&unread>0&&<span className="nav-badge">{unread}</span>}</button>})}</section>)}
        </nav>

        <div className="sidebar-footer">
          <button className="user-mini" onClick={() => navigate('profile')}><span>{initials}</span><div><b>{profile.full_name}</b><small>{roleLabel(profile.role,lang)}</small></div></button>
          <button className="logout-mini" onClick={logout} title={en?'Log out':'Гарах'}><LogOut size={19} /></button>
        </div>
      </aside>

      <div className="app-main">
        <header className="app-topbar">
          <div className="topbar-left">
            <button className="menu-btn" onClick={() => setSidebarOpen(true)}><Menu size={22} /></button>
            <button className="compact-btn" onClick={() => setSidebarCompact(!sidebarCompact)} title="Sidebar"><span className="desktop-only">{sidebarCompact ? <PanelLeftOpen size={20} /> : <PanelLeftClose size={20} />}</span></button>
            <div className="search-wrap">
              <div className="global-search"><Search size={19} /><input value={search} onFocus={()=>setSearchOpen(true)} onChange={e=>{setSearch(e.target.value);setSearchOpen(true)}} placeholder={en?'Search patient, phone, service…':'Өвчтөн, утас, үйлчилгээ хайх…'} /><kbd>Ctrl K</kbd></div>
              {searchOpen && <div className="search-popover">
                <div className="search-popover-title">{en?'Quick navigation':'Хурдан очих'}</div>
                {searchItems.map(x=><button key={x.view} onClick={()=>navigate(x.view)}><span>{x.label}</span><small>{x.hint}</small><ArrowRight size={16}/></button>)}
                {!searchItems.length&&<p>{en?'No results found.':'Илэрц олдсонгүй.'}</p>}
              </div>}
            </div>
          </div>
          <div className="topbar-right">
            <button className={`accessibility-btn ${largeText?'active':''}`} onClick={toggleLarge} title={largeText?(en?'Normal text size':'Энгийн хэмжээ'):(en?'Larger text':'Текст томруулах')}>A+</button>
            <button className="lang-btn" title={en?'Switch to Mongolian':'Англи хэл рүү солих'} onClick={toggleLang}>{en?'MN':'EN'}</button>
            <button className="theme-btn" onClick={toggleTheme} title={theme==='light'?'Dark theme':'Light theme'}>{theme==='light'?<Moon size={19}/>:<Sun size={19}/>}</button>
            <div className="notification-wrap" ref={notificationRef}>
              <button className={`notification-btn ${notificationOpen?'active':''}`} onClick={()=>setNotificationOpen(v=>!v)} aria-label={en?'Notifications':'Мэдэгдэл'}><Bell size={20} />{unread>0&&<span>{unread}</span>}</button>
              {notificationOpen&&<div className="notification-popover">
                <div className="notification-popover-head"><div><strong>{en?'Notifications':'Мэдэгдэл'}</strong><small>{unread} {en?'unread':'уншаагүй'}</small></div>{unread>0&&<button onClick={markAllRead}><CheckCircle2 size={16}/> {en?'Mark read':'Уншсан болгох'}</button>}</div>
                <div className="notification-popover-list">
                  {notifications.slice(0,8).map(item=><button key={item.id} className={item.unread?'unread':''} onClick={()=>openNotification(item)}>
                    <span className="notify-icon"><NotificationIcon type={item.type}/></span><span className="notify-copy"><b>{item.title}</b><span>{item.detail}</span><small>{item.time}</small></span>{item.unread&&<i/>}
                  </button>)}
                </div>
                <button className="notification-see-all" onClick={()=>navigate('notifications')}>{en?'See all notifications':'Бүх мэдэгдэл харах'} <ArrowRight size={16}/></button>
              </div>}
            </div>
            <button className="profile-pill" onClick={() => navigate('profile')}><span>{initials}</span><div><b>{profile.full_name}</b><small>{roleLabel(profile.role,lang)}</small></div></button>
          </div>
        </header>

        <main className="content-wrap">
          <div className="mobile-page-title"><small>DentHub</small><h1>{pageLabel}</h1></div>
          {view === 'home' && <DashboardHome profile={profile} clinicName={clinicName} onNavigate={navigate} lang={lang} />}
          {view === 'notifications' && <Notifications items={notifications} onOpen={openNotification} onMarkAll={markAllRead} lang={lang} />}
          {view === 'subscriptions' && profile.role==='platform_admin' && <PlatformSubscriptionPlans lang={lang} />}
          {view === 'admin' && <AdminPanel profile={profile} clinicName={clinicName} clinicLogoUrl={clinicLogoUrl} onClinicLogoChange={setClinicLogoUrl} onClinicNameChange={setClinicName} lang={lang} />}
          {view === 'payments' && (profile.role==='client'?<ClientPurchaseHistory profile={profile} lang={lang}/>:<PaymentPanel profile={profile} clinicName={clinicName} lang={lang} />)}
          {view === 'treatment_history' && profile.role==='client' && <ClientTreatmentHistory profile={profile} lang={lang}/>}
          {view === 'treatment_history' && (profile.role==='owner'||profile.role==='employee') && <StaffTreatmentHistory profile={profile} clinicName={clinicName} lang={lang}/>}
          {view === 'treatments' && (profile.role==='owner'||profile.role==='employee') && <TreatmentWorkspace profile={profile} clinicName={clinicName} lang={lang} onNavigate={next=>navigate(next)}/>} 
          {view === 'patient_cards' && profile.role==='client' && <ClientPatientCard profile={profile} lang={lang}/>}
          {view === 'patient_cards' && (profile.role==='owner'||profile.role==='employee') && <PatientCardsWorkspace profile={profile} clinicName={clinicName} clinicLogoUrl={clinicLogoUrl} lang={lang}/>}
          {view === 'consent_forms' && (profile.role==='owner'||profile.role==='employee') && <ConsentFormsWorkspace profile={profile} clinicName={clinicName} clinicLogoUrl={clinicLogoUrl} lang={lang}/>}
          {view === 'erp' && <ERPOverview profile={profile} clinicName={clinicName} lang={lang} onNavigate={navigate} />}
          {view === 'official_documents' && (profile.role==='owner'||profile.role==='employee') && <OfficialDocumentsWorkspace profile={profile} clinicName={clinicName} clinicLogoUrl={clinicLogoUrl} lang={lang} />}
          {view === 'internal_procedures' && <InternalProceduresWorkspace profile={profile} clinicName={clinicName} clinicLogoUrl={clinicLogoUrl} lang={lang} />}
          {view === 'health_department' && <HealthDepartmentWorkspace profile={profile} clinicName={clinicName} lang={lang} />}
          {view === 'questionnaire' && <HealthQuestionnaireWorkspace profile={profile} clinicName={clinicName} lang={lang} />}
          {view === 'contracts' && <ContractsWorkspace profile={profile} clinicName={clinicName} lang={lang} />}
          {view === 'finance' && <FinanceWorkspace profile={profile} clinicName={clinicName} lang={lang} />}
          {!['home','notifications','admin','subscriptions','payments','erp','treatment_history','treatments','patient_cards','consent_forms','official_documents','internal_procedures','health_department','questionnaire','contracts','finance'].includes(view) && <ModulePage view={view} profile={profile} clinicName={clinicName} theme={theme} onThemeChange={toggleTheme} lang={lang} onNavigate={navigate} />}
        </main>
      </div>

      <nav className="mobile-bottom-nav" style={{gridTemplateColumns:`repeat(${Math.max(mobileNav.length,1)},1fr)`}}>
        {mobileNav.map((k) => {
          const Icon = navMeta[k].icon;
          return <button key={k} className={view === k ? 'active' : ''} onClick={() => navigate(k)}><Icon size={21} /><span>{userNavLabel(k)}</span>{k==='notifications'&&unread>0&&<i>{unread}</i>}</button>;
        })}
      </nav>
    </div>
  );
}
