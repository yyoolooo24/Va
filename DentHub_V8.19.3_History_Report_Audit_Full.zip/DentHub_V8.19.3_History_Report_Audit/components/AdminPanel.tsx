'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { Ban, Building2, CheckCircle2, Download, FileSpreadsheet, ImageIcon, KeyRound, Loader2, Plus, RotateCcw, Search, ShieldCheck, Trash2, Upload, UserPlus, UsersRound, Settings2, X } from 'lucide-react';
import { getSupabaseBrowser, isSupabaseConfigured } from '@/lib/supabase-browser';
import type { AppLang } from './DashboardApp';
import DentSelect from './ui/DentSelect';
import NumericInput from './ui/NumericInput';
import ConfirmDialog from './ui/ConfirmDialog';
import PlatformClinicControl from './PlatformClinicControl';
import ClinicSubscriptionCard from './ClinicSubscriptionCard';
import ModuleAccessPicker from './ModuleAccessPicker';
import { BUILTIN_SUBSCRIPTION_PLANS, sanitizeClinicModules, type SubscriptionPlanDefinition } from '@/lib/subscription';

type Profile = { id?: string; full_name:string; role:string; clinic_id?:string|null; clinic_modules?:string[]|null; clinic_status?:string|null; clinic_plan?:string|null; allowed_modules?:string[]|null; specialty?:string|null; staff_type?:string|null };
type Clinic = { id:string; name:string; plan:string; users:number; status:string };
type ManagedUser = { id:string; full_name:string; role:string; phone:string|null; clinic_id:string|null; active:boolean; created_at?:string; specialty?:string|null; staff_type?:string|null; allowed_modules?:string[]|null };

const employeeModules=[
  ['appointments','Цаг товлол'],['consent_forms','Зөвшөөрлийн хуудас'],['official_documents','Албан бичиг'],['patients','Өвчтөн'],['patient_cards','Өвчтөний карт'],['treatment_history','Эмчилгээний түүх'],['treatments','Үзлэг, эмчилгээ'],['services','Үйлчилгээ'],['payments','Касс'],['sales','Борлуулалт'],['sales_returns','Буцаалт'],['cashbook','Кассын журнал'],['price_lists','Үнийн жагсаалт'],['inventory','Бараа материал'],['stock_movements','Барааны хөдөлгөөн'],['suppliers','Ханган нийлүүлэгч'],['procurement','Худалдан авалт'],['purchase_orders','Захиалга / PO'],['lab_orders','Лаборатори'],['crm','CRM'],['invoices','Нэхэмжлэх'],['receivables','Авлага'],['expenses','Зардал'],['finance','Санхүү'],['shifts','Ээлж & хуваарь'],['chat','Чат'],['reports','Тайлан']
] as const;


const employeePresets=[
  {key:'dentist',mn:'Шүдний эмч',en:'Dentist',staffType:'doctor',modules:['appointments','consent_forms','patients','patient_cards','treatment_history','treatments','services','chat']},
  {key:'nurse',mn:'Сувилагч',en:'Nurse',staffType:'nurse',modules:['appointments','consent_forms','patients','patient_cards','treatment_history','treatments','inventory','lab_orders','chat']},
  {key:'reception',mn:'Ресепшн',en:'Reception',staffType:'reception',modules:['appointments','consent_forms','patients','payments','sales','chat']},
  {key:'finance',mn:'Санхүү',en:'Finance',staffType:'finance',modules:['payments','sales','sales_returns','cashbook','invoices','receivables','expenses','finance','reports','chat']},
] as const;

const initialClinics: Clinic[] = [];
const demoUsers: ManagedUser[] = [];

export default function AdminPanel({profile,clinicName,clinicLogoUrl,onClinicLogoChange,onClinicNameChange,lang}:{profile:Profile;clinicName:string;clinicLogoUrl?:string|null;onClinicLogoChange?:(url:string|null)=>void;onClinicNameChange?:(name:string)=>void;lang:AppLang}) {
  const en=lang==='EN';
  const platform = profile.role==='platform_admin';
  const [tab,setTab]=useState<'clinics'|'users'|'branding'|'data'>(platform?'clinics':'users');
  const [clinics,setClinics]=useState<Clinic[]>(()=>process.env.NEXT_PUBLIC_DEMO_MODE==='true'||!isSupabaseConfigured()?initialClinics:[]);
  const [users,setUsers]=useState<ManagedUser[]>(()=>process.env.NEXT_PUBLIC_DEMO_MODE==='true'||!isSupabaseConfigured()?demoUsers:[]);
  const [message,setMessage]=useState('');
  const [busy,setBusy]=useState(false);
  const [accessBusy,setAccessBusy]=useState<string|null>(null);
  const [userSearch,setUserSearch]=useState('');
  const [showInactive,setShowInactive]=useState(true);
  const [platformPlans,setPlatformPlans]=useState<SubscriptionPlanDefinition[]>(BUILTIN_SUBSCRIPTION_PLANS);
  const [clinicForm,setClinicForm]=useState({name:'',plan:'START',ownerName:'',ownerPhone:'',ownerPassword:'',employeeLimit:'5',enabledModules:[...BUILTIN_SUBSCRIPTION_PLANS[0].enabled_modules] as string[]});
  const [clinicModulePickerOpen,setClinicModulePickerOpen]=useState(false);
  const [userForm,setUserForm]=useState({fullName:'',phone:'',password:'',role:'employee',clinicId:'c1',specialty:'',staffType:'doctor',allowedModules:['appointments','patients','treatment_history','treatments','chat'] as string[]});
  const [userModulePickerOpen,setUserModulePickerOpen]=useState(false);
  const [permissionUser,setPermissionUser]=useState<ManagedUser|null>(null);
  const [permissionSpecialty,setPermissionSpecialty]=useState('');
  const [permissionStaffType,setPermissionStaffType]=useState('other');
  const [permissionModules,setPermissionModules]=useState<string[]>([]);
  const [accessConfirmUser,setAccessConfirmUser]=useState<ManagedUser|null>(null);
  const [resetUser,setResetUser]=useState<ManagedUser|null>(null);
  const [resetPassword,setResetPassword]=useState('');
  const [resetBusy,setResetBusy]=useState(false);
  const configured=useMemo(()=>isSupabaseConfigured(),[]);
  const clinicExcelRef=useRef<HTMLInputElement|null>(null);
  const patientExcelRef=useRef<HTMLInputElement|null>(null);
  const staffExcelRef=useRef<HTMLInputElement|null>(null);
  const logoInputRef=useRef<HTMLInputElement|null>(null);
  const [logoBusy,setLogoBusy]=useState(false);
  const [logoPreview,setLogoPreview]=useState<string|null>(clinicLogoUrl||null);
  const [clinicNameDraft,setClinicNameDraft]=useState(clinicName);
  useEffect(()=>setLogoPreview(clinicLogoUrl||null),[clinicLogoUrl]);
  useEffect(()=>setClinicNameDraft(clinicName),[clinicName]);
  useEffect(()=>{if(!message)return;const id=window.setTimeout(()=>setMessage(''),6500);return()=>window.clearTimeout(id)},[message]);

  async function loadUsers(){
    if(!configured) return;
    const supabase=getSupabaseBrowser(); if(!supabase) return;
    const {data,error}=await supabase.from('profiles').select('id,full_name,role,phone,clinic_id,active,created_at,specialty,staff_type,allowed_modules').order('created_at',{ascending:false});
    if(error){
      if(String(error.message).toLowerCase().includes('active')) setMessage(en?'Run supabase/v7_1_access_upgrade.sql first.':'Эхлээд supabase/v7_1_access_upgrade.sql файлыг Supabase SQL Editor дээр ажиллуулна уу.');
      return;
    }
    setUsers((data||[]) as ManagedUser[]);
  }

  useEffect(()=>{
    if(!configured) return;
    let active=true;
    (async()=>{
      const supabase=getSupabaseBrowser(); if(!supabase) return;
      if(platform){
        const [{data},{data:planData,error:planError}]=await Promise.all([
          supabase.from('clinics').select('id,name,plan,status').order('created_at',{ascending:false}),
          supabase.from('platform_subscription_plans').select('code,name_mn,name_en,description_mn,description_en,enabled_modules,employee_limit,price,billing_cycle,duration_months,active,sort_order').eq('active',true).order('sort_order'),
        ]);
        if(active&&data){
          const rows=data.map((c:any)=>({id:c.id,name:c.name,plan:c.plan,users:0,status:String(c.status||'active').toUpperCase()}));
          setClinics(rows); if(rows[0]) setUserForm(v=>({...v,clinicId:rows[0].id}));
        }
        if(active&&!planError&&planData?.length)setPlatformPlans(planData.map((p:any)=>({...p,enabled_modules:sanitizeClinicModules(p.enabled_modules),employee_limit:Number(p.employee_limit||1),price:Number(p.price||0),duration_months:Number(p.duration_months||1),active:p.active!==false,sort_order:Number(p.sort_order||0)})) as SubscriptionPlanDefinition[]);
      }
      await loadUsers();
    })();
    return()=>{active=false};
  },[configured,platform,lang]);


  async function resetStaffPassword(){
    if(!resetUser)return;
    if(resetPassword.length<8){setMessage(en?'Temporary password must be at least 8 characters.':'Түр нууц үг хамгийн багадаа 8 тэмдэгт байна.');return}
    setResetBusy(true);setMessage('');
    try{
      const token=await accessToken();if(!token)throw new Error('Нэвтрэх эрх дууссан байна.');
      const res=await fetch('/api/admin/reset-password',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({userId:resetUser.id,password:resetPassword})});
      const body=await res.json().catch(()=>({}));if(!res.ok)throw new Error(body.error||'Password reset failed.');
      setMessage(en?`Temporary password set for ${resetUser.full_name}.`:`${resetUser.full_name}-д түр нууц үг тохирууллаа.`);
      setResetUser(null);setResetPassword('');
    }catch(e:any){setMessage(e?.message||'Нууц үг сэргээж чадсангүй.')}finally{setResetBusy(false)}
  }

  async function brandingRequest(method:'POST'|'PATCH'|'DELETE',body?:FormData|Record<string,unknown>){
    const token=await accessToken();if(!token)throw new Error(en?'Your session expired. Please sign in again.':'Нэвтрэх эрхийн хугацаа дууссан байна. Дахин нэвтэрнэ үү.');
    const init:RequestInit={method,headers:{Authorization:`Bearer ${token}`}};
    if(body instanceof FormData)init.body=body;else if(body){(init.headers as Record<string,string>)['Content-Type']='application/json';init.body=JSON.stringify(body)}
    const res=await fetch('/api/clinic/branding',init);const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data.error||'Үйлдэл амжилтгүй боллоо.');return data;
  }

  async function uploadClinicLogo(file:File){
    if(platform||!profile.clinic_id)return;
    if(file.size>2*1024*1024){setMessage(en?'Logo must be 2 MB or smaller.':'Лого 2 MB-аас бага хэмжээтэй байна.');return}
    if(!['image/png','image/jpeg','image/webp'].includes(file.type)){setMessage(en?'Use PNG, JPG or WEBP.':'PNG, JPG эсвэл WEBP зураг сонгоно уу.');return}
    setLogoBusy(true);setMessage('');
    try{const formData=new FormData();formData.append('file',file);const data=await brandingRequest('POST',formData);const url=String(data.logoUrl||'');setLogoPreview(url);onClinicLogoChange?.(url);setMessage(en?'Clinic logo updated.':'Эмнэлгийн лого амжилттай шинэчлэгдлээ.');}
    catch(e:any){setMessage(e?.message||'Лого хадгалж чадсангүй.')}finally{setLogoBusy(false);if(logoInputRef.current)logoInputRef.current.value=''}
  }

  async function saveClinicName(){
    if(platform||!profile.clinic_id)return;const name=clinicNameDraft.trim();if(!name){setMessage(en?'Enter a clinic name.':'Эмнэлгийн нэр оруулна уу.');return}
    setLogoBusy(true);setMessage('');
    try{const data=await brandingRequest('PATCH',{name});onClinicNameChange?.(String(data.name||name));setMessage(en?'Clinic name updated.':'Эмнэлгийн нэр амжилттай шинэчлэгдлээ.')}catch(e:any){setMessage(e?.message||'Эмнэлгийн нэр хадгалж чадсангүй.')}finally{setLogoBusy(false)}
  }

  async function removeClinicLogo(){
    if(platform||!profile.clinic_id)return;setLogoBusy(true);setMessage('');
    try{await brandingRequest('DELETE');setLogoPreview(null);onClinicLogoChange?.(null);setMessage(en?'Clinic logo removed.':'Эмнэлгийн лого ариллаа.')}catch(e:any){setMessage(e?.message||'Лого арилгаж чадсангүй.')}finally{setLogoBusy(false)}
  }

  async function accessToken() {
    const supabase=getSupabaseBrowser(); if(!supabase) return null;
    const {data}=await supabase.auth.getSession(); return data.session?.access_token||null;
  }

  function applyClinicPlan(plan:string){
    const selected=platformPlans.find(p=>p.code===plan)||BUILTIN_SUBSCRIPTION_PLANS.find(p=>p.code===plan)||BUILTIN_SUBSCRIPTION_PLANS[0];
    setClinicForm(v=>({...v,plan,employeeLimit:String(selected.employee_limit),enabledModules:[...selected.enabled_modules]}));
  }

  async function createClinic() {
    if(!clinicForm.name.trim()) return setMessage(en?'Enter a clinic name.':'Эмнэлгийн нэр оруулна уу.');
    setBusy(true); setMessage('');
    try {
      if(configured) {
        const token=await accessToken();
        const res=await fetch('/api/admin/create-clinic',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify(clinicForm)});
        const body=await res.json(); if(!res.ok) throw new Error(body.error||(en?'Could not create clinic.':'Эмнэлэг үүсгэж чадсангүй.'));
        setClinics(list=>[{id:body.clinic.id,name:body.clinic.name,plan:body.clinic.plan,users:body.owner?1:0,status:'ACTIVE'},...list]);
      } else setClinics(list=>[{id:`local-${Date.now()}`,name:clinicForm.name,plan:clinicForm.plan,users:clinicForm.ownerName?1:0,status:'ACTIVE'},...list]);
      setClinicForm({name:'',plan:'START',ownerName:'',ownerPhone:'',ownerPassword:'',employeeLimit:String((platformPlans.find(p=>p.code==='START')||BUILTIN_SUBSCRIPTION_PLANS[0]).employee_limit),enabledModules:[...(platformPlans.find(p=>p.code==='START')||BUILTIN_SUBSCRIPTION_PLANS[0]).enabled_modules]});
      setMessage(en?'Clinic created successfully.':'Эмнэлэг амжилттай үүслээ.');
      await loadUsers();
    } catch(e:any){setMessage(e.message||'Алдаа гарлаа.');} finally {setBusy(false);}
  }

  async function createUser() {
    if(!userForm.fullName||!userForm.phone||!userForm.password) return setMessage(en?'Enter name, phone and password.':'Нэр, утас, нууц үг оруулна уу.');
    setBusy(true); setMessage('');
    try {
      if(configured) {
        const token=await accessToken();
        const payload={...userForm,clinicId:platform?userForm.clinicId:profile.clinic_id};
        const res=await fetch('/api/admin/create-user',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify(payload)});
        const body=await res.json(); if(!res.ok) throw new Error(body.error||'User create failed.');
      } else {
        setUsers(list=>[{id:`local-${Date.now()}`,full_name:userForm.fullName,role:userForm.role,phone:userForm.phone,clinic_id:platform?userForm.clinicId:profile.clinic_id||null,active:true},...list]);
      }
      setUserForm({...userForm,fullName:'',phone:'',password:'',specialty:'',staffType:'doctor',allowedModules:['appointments','patients','treatment_history','treatments','chat']});
      setMessage(en?'User added successfully.':'Хэрэглэгч амжилттай нэмэгдлээ.');
      await loadUsers();
    } catch(e:any){setMessage(e.message||'Алдаа гарлаа.');} finally {setBusy(false);}
  }

  async function confirmChangeAccess(){
    const user=accessConfirmUser;if(!user)return;
    const nextActive=!user.active;
    setAccessBusy(user.id); setMessage('');
    try{
      if(configured){
        const token=await accessToken();
        const res=await fetch('/api/admin/user-access',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({userId:user.id,action:nextActive?'reactivate':'deactivate'})});
        const body=await res.json(); if(!res.ok) throw new Error(body.error||'Access update failed.');
      }
      setUsers(list=>list.map(x=>x.id===user.id?{...x,active:nextActive}:x));
      setMessage(nextActive?(en?'Access restored.':'Эрх сэргээгдлээ.'):(en?'Access removed. History was kept.':'Эрх цуцлагдлаа. Өмнөх түүх хадгалагдана.'));
      setAccessConfirmUser(null);
    }catch(e:any){setMessage(e.message||'Алдаа гарлаа.');}finally{setAccessBusy(null)}
  }


  async function exportManagementExcel(entity:'clinics'|'patients'|'staff'){
    setBusy(true);setMessage('');
    try{
      const token=await accessToken();
      if(!token)throw new Error(en?'Please sign in again.':'Нэвтрэх эрхээ дахин сэргээнэ үү.');
      const res=await fetch(`/api/admin/excel-sync?entity=${entity}`,{headers:{Authorization:`Bearer ${token}`}});
      const body=await res.json();if(!res.ok)throw new Error(body.error||'Excel data export failed.');
      const rows=Array.isArray(body.rows)?body.rows:[];
      const XLSX=await import('xlsx');
      const wb=XLSX.utils.book_new();
      const sheet=XLSX.utils.json_to_sheet(rows);
      const widths:Record<string,number>={clinics:22,patients:22,staff:22};
      sheet['!cols']=Object.keys(rows[0]||{id:''}).map(k=>({wch:Math.min(42,Math.max(14,k.length+4,widths[entity]))}));
      if(rows.length)sheet['!autofilter']={ref:sheet['!ref']||'A1:A1'};
      XLSX.utils.book_append_sheet(wb,sheet,entity==='clinics'?'Clinics':entity==='patients'?'Patients':'Staff');
      const guide=XLSX.utils.aoa_to_sheet([
        ['DentHub Excel sync'],
        [en?'Edit the exported rows, then import the SAME file in Management.':'Экспортолсон мөрүүдээ засаад Удирдлага хэсэгт ЯГ ЭНЭ файлаа буцааж импортлоно.'],
        [en?'Never change the ID column (clinic_id / patient_id / user_id). It identifies the exact Supabase record.':'ID багануудыг (clinic_id / patient_id / user_id) өөрчлөхгүй байна уу. Эдгээр нь Supabase дахь тухайн бүртгэлийг алдаагүй шинэчлэх үндсэн түлхүүр юм.'],
        [en?'Patients: name, phone, register, birth date, address, emergency phone, gender and notes can be updated.':'Өвчтөн: нэр, утас, регистр, төрсөн огноо, хаяг, яаралтай үед холбоо барих утас, хүйс, тэмдэглэл шинэчилж болно.'],
        [en?'Staff: name, phone, position, allowed_modules and active can be updated.':'Эмч/ажилтан: нэр, утас, албан тушаал, allowed_modules, active шинэчилж болно.'],
        [en?'Clinic owner: clinic name can be updated. Platform Admin can also change plan/status.':'Эмнэлгийн эзэмшигч эмнэлгийн нэрээ шинэчилж болно. Системийн админ багц болон төлөвийг мөн өөрчилж болно.'],
      ]);
      guide['!cols']=[{wch:105}];XLSX.utils.book_append_sheet(wb,guide,'README');
      XLSX.writeFile(wb,`denthub-${entity}-${new Date().toISOString().slice(0,10)}.xlsx`);
      setMessage(en?'Excel downloaded. Edit it and import it back to apply changes.':'Excel татагдлаа. Засварлаад буцааж импортлоход website дээр өөрчлөлт орно.');
    }catch(e:any){setMessage(e?.message||'Excel экспорт хийж чадсангүй.');}finally{setBusy(false);}
  }

  async function importManagementExcel(entity:'clinics'|'patients'|'staff',file:File){
    setBusy(true);setMessage('');
    try{
      const XLSX=await import('xlsx');
      const buf=await file.arrayBuffer();
      const wb=XLSX.read(buf,{type:'array',cellDates:false});
      const first=wb.Sheets[wb.SheetNames[0]];if(!first)throw new Error(en?'Workbook is empty.':'Excel sheet хоосон байна.');
      const rows=XLSX.utils.sheet_to_json(first,{defval:''});if(!rows.length)throw new Error(en?'No data rows found.':'Өгөгдлийн мөр олдсонгүй.');
      const token=await accessToken();if(!token)throw new Error(en?'Please sign in again.':'Нэвтрэх эрхээ дахин сэргээнэ үү.');
      const res=await fetch('/api/admin/excel-sync',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({entity,rows})});
      const body=await res.json();if(!res.ok)throw new Error(body.error||'Excel import failed.');
      await loadUsers();
      if(platform){const s=getSupabaseBrowser();if(s){const {data}=await s.from('clinics').select('id,name,plan,status').order('created_at',{ascending:false});if(data)setClinics(data.map((c:any)=>({id:c.id,name:c.name,plan:c.plan,users:0,status:String(c.status||'active').toUpperCase()})));}}
      const errorCount=Array.isArray(body.errors)?body.errors.length:0;
      setMessage(en?`Excel applied: ${body.updated||0} updated${errorCount?`, ${errorCount} row(s) need attention`:''}.`:`Excel өөрчлөлт орлоо: ${body.updated||0} мөр шинэчлэгдлээ${errorCount?`, ${errorCount} мөр алдаатай`:''}.${errorCount?` ${body.errors.slice(0,3).join(' | ')}`:''}`);
    }catch(e:any){setMessage(e?.message||'Excel импорт хийж чадсангүй.');}finally{setBusy(false);}
  }

  const visibleUsers=users.filter(u=>{
    const q=userSearch.toLowerCase();
    const matches=!q||`${u.full_name} ${u.phone||''} ${u.role}`.toLowerCase().includes(q);
    const allowed=platform?true:['owner','employee'].includes(u.role);
    return matches&&allowed&&(showInactive||u.active);
  });
  const roleText=(r:string)=>en?({owner:'Owner',employee:'Doctor / Staff',client:'Patient',supplier:'Supplier',platform_admin:'Системийн админ'} as any)[r]||r:({owner:'Эзэмшигч',employee:'Эмч / Ажилтан',client:'Өвчтөн',supplier:'Ханган нийлүүлэгч',platform_admin:'Системийн админ'} as any)[r]||r;
  const messageIsError=/алдаа|чадсангүй|failed|error|invalid|шаардлагатай|буруу|violat|security policy|row-level/i.test(message);

  return <div className="page-stack admin-page">
    <header className="page-head"><div><small>{platform?'DentHub Platform':clinicName}</small><h1>{platform?(en?'Platform management':'Системийн удирдлага'):(en?'Clinic management':'Эмнэлгийн удирдлага')}</h1><p>{platform?(en?'Manage clinics, subscriptions, modules and access from one place.':'Эмнэлэг, багц, модуль болон нэвтрэх эрхийг нэг дор удирдана.'):(en?'Create staff accounts and manage access.':'Эмч, ажилтны бүртгэл болон эрхийг эндээс удирдана.')}</p></div></header>
    <div className="admin-tabs">{platform&&<button className={tab==='clinics'?'active':''} onClick={()=>setTab('clinics')}><Building2 size={17}/> {en?'Clinics':'Эмнэлгүүд'}</button>}<button className={tab==='users'?'active':''} onClick={()=>setTab('users')}><UsersRound size={17}/> {en?'Users & access':'Хэрэглэгчид'}</button>{!platform&&<button className={tab==='branding'?'active':''} onClick={()=>setTab('branding')}><ImageIcon size={17}/> {en?'Clinic branding':'Нэр & лого'}</button>}<button className={tab==='data'?'active':''} onClick={()=>setTab('data')}><FileSpreadsheet size={17}/> {en?'Excel management':'Excel өгөгдөл'}</button></div>
    {message&&<div className={`platform-action-toast ${messageIsError?'error':'success'}`} role="status"><div>{messageIsError?<X size={17}/>:<CheckCircle2 size={17}/>}<span>{message}</span></div><button onClick={()=>setMessage('')} aria-label={en?'Close':'Хаах'}><X size={15}/></button></div>}
    {logoBusy&&<div className="workspace-busy-notice" role="status" aria-live="polite"><Loader2 className="spin" size={17}/><span>{en?'Saving clinic branding… Please wait.':'Эмнэлгийн тохиргоог хадгалж байна… Түр хүлээнэ үү.'}</span></div>}

    {tab==='clinics'&&platform&&<div className="admin-grid">
      <article className="panel-card form-card"><div className="panel-head"><div><h2>{en?'New clinic':'Шинэ эмнэлэг'}</h2><p>{en?'Create the clinic workspace and owner account together.':'Эмнэлгийн орчин болон эзэмшигчийн бүртгэлийг нэг дор үүсгэнэ.'}</p></div><span className="icon-cube"><Plus/></span></div>
        <label>{en?'Clinic name':'Эмнэлгийн нэр'}<input value={clinicForm.name} onChange={e=>setClinicForm({...clinicForm,name:e.target.value})} placeholder="City Clinic"/></label>
        <label>{en?'Plan':'Багц'}<DentSelect value={clinicForm.plan} onChange={applyClinicPlan} options={platformPlans.map(p=>({value:p.code,label:`${en?p.name_en:p.name_mn} · ${p.enabled_modules.length} ${en?'modules':'модуль'}`}))}/></label><button type="button" className="clinic-access-editor" onClick={()=>setClinicModulePickerOpen(true)}><span><b>{en?'Module access':'Модулийн эрх'}</b><small>{en?'Starts from the selected plan; customize only if needed.':'Сонгосон багцын эрх автоматаар орно. Шаардлагатай үед л өөрчилнө.'}</small></span><strong>{clinicForm.enabledModules.length} {en?'modules':'модуль'}</strong></button>
        <div className="form-section-title">{en?'Owner account':'Эзэмшигчийн мэдээлэл'} <small>{en?'optional':'заавал биш'}</small></div>
        <label>{en?'Owner name':'Эзэмшигчийн нэр'}<input value={clinicForm.ownerName} onChange={e=>setClinicForm({...clinicForm,ownerName:e.target.value})}/></label>
        <label>{en?'Owner phone':'Утас'}<NumericInput value={clinicForm.ownerPhone} onValueChange={ownerPhone=>setClinicForm({...clinicForm,ownerPhone})} maxDigits={8} placeholder="99xx xxxx"/></label>
        <label>{en?'Initial password':'Түр нууц үг'}<input type="password" value={clinicForm.ownerPassword} onChange={e=>setClinicForm({...clinicForm,ownerPassword:e.target.value})}/></label>
        <button className="btn-primary full" disabled={busy} onClick={createClinic}><Building2 size={17}/>{busy?(en?'Creating…':'Үүсгэж байна…'):(en?'Create clinic':'Эмнэлэг үүсгэх')}</button>
      </article>
      <PlatformClinicControl lang={lang}/>
    </div>}


    {tab==='users'&&!platform&&<ClinicSubscriptionCard profile={profile as any} lang={lang}/>}

    {tab==='branding'&&!platform&&<article className="panel-card clinic-branding-card clinic-branding-focus"><div className="panel-head"><div><h2>{en?'Clinic name, logo & branding':'Эмнэлгийн нэр, лого ба брэндинг'}</h2><p>{en?'The saved clinic name and logo appear in the program, patient cards, consent forms and internal procedure printouts.':'Хадгалсан эмнэлгийн нэр, лого нь программ дотор, өвчтөний карт, зөвшөөрлийн хуудас болон журмын хэвлэл дээр харагдана.'}</p></div><span className="icon-cube"><ImageIcon/></span></div><div className="clinic-branding-body"><div className={`clinic-logo-preview ${logoPreview?'has-image':''}`}>{logoPreview?<img src={logoPreview} alt={`${clinicName} logo`}/>:<Building2 size={34}/>}</div><div className="clinic-branding-copy"><label className="clinic-name-edit"><span>{en?'Clinic name':'Эмнэлгийн нэр'}</span><div><input value={clinicNameDraft} onChange={e=>setClinicNameDraft(e.target.value)} maxLength={120}/><button type="button" className="btn-secondary" disabled={logoBusy||clinicNameDraft.trim()===clinicName.trim()} onClick={saveClinicName}><CheckCircle2 size={16}/>{en?'Save name':'Нэр хадгалах'}</button></div></label><small>{en?'PNG / JPG / WEBP · max 2 MB':'PNG / JPG / WEBP · дээд тал нь 2 MB'}</small><div className="clinic-branding-actions"><button type="button" className="btn-primary" disabled={logoBusy} onClick={()=>logoInputRef.current?.click()}><Upload size={16}/>{logoBusy?(en?'Saving…':'Хадгалж байна…'):(en?'Upload / change logo':'Лого оруулах / солих')}</button>{logoPreview&&<button type="button" className="btn-secondary" disabled={logoBusy} onClick={removeClinicLogo}><Trash2 size={16}/>{en?'Remove':'Арилгах'}</button>}<input ref={logoInputRef} type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>{const f=e.target.files?.[0];if(f)uploadClinicLogo(f)}}/></div></div></div></article>}

    {tab==='users'&&<div className="admin-users-layout">
      <article className="panel-card form-card"><div className="panel-head"><div><h2>{platform?(en?'Add account':'Хэрэглэгч нэмэх'):(en?'Add doctor / staff':'Эмч / ажилтан нэмэх')}</h2><p>{platform?(en?'Owner / Doctor / Staff':'Эзэмшигч / Эмч / Ажилтан'):(en?'Clinic-created staff account':'Эмнэлгийн дотоод хэрэглэгч')}</p></div><span className="icon-cube"><UserPlus/></span></div>
        <label>{en?'Name':'Нэр'}<input value={userForm.fullName} onChange={e=>setUserForm({...userForm,fullName:e.target.value})} placeholder={en?'Full name':'Овог нэр'}/></label>
        <label>{en?'Phone':'Утас'}<NumericInput value={userForm.phone} onValueChange={phone=>setUserForm({...userForm,phone})} maxDigits={8} placeholder="99xx xxxx"/></label>
        <label>{en?'Role':'Эрх'}<DentSelect value={userForm.role} onChange={role=>setUserForm({...userForm,role})} options={[...(platform?[{value:'owner',label:en?'Clinic owner':'Эмнэлгийн эзэмшигч'}]:[]),{value:'employee',label:en?'Doctor / Staff':'Эмч / Ажилтан'}]}/></label>
        {platform&&<label>{en?'Clinic':'Эмнэлэг'}<DentSelect searchable value={userForm.clinicId} onChange={clinicId=>setUserForm({...userForm,clinicId})} options={clinics.map(c=>({value:c.id,label:c.name}))}/></label>}
        {userForm.role==='employee'&&<><label>{en?'Specialty / position':'Мэргэжил / албан тушаал'}<input value={userForm.specialty} onChange={e=>setUserForm({...userForm,specialty:e.target.value})} placeholder={en?'Dentist / nurse / reception':'Шүдний эмч / сувилагч / бүртгэлийн ажилтан'}/></label><label>{en?'Staff type':'Ажилтны төрөл'}<DentSelect value={userForm.staffType} onChange={staffType=>setUserForm({...userForm,staffType})} options={[{value:'doctor',label:en?'Doctor':'Эмч'},{value:'nurse',label:en?'Nurse':'Сувилагч'},{value:'reception',label:en?'Reception':'Ресепшн'},{value:'cashier',label:en?'Cashier':'Касс'},{value:'finance',label:en?'Finance':'Санхүү'},{value:'inventory',label:en?'Inventory':'Агуулах'},{value:'manager',label:en?'Manager':'Менежер'},{value:'other',label:en?'Other':'Бусад'}]}/></label><button type="button" className="clinic-access-editor staff-module-editor" onClick={()=>setUserModulePickerOpen(true)}><span><b>{en?'Staff module access':'Ажилтны модулийн эрх'}</b><small>{en?'Choose the work areas this employee can see.':'Энэ ажилтан яг ямар ажлын хэсгүүдийг харахыг эндээс сонгоно.'}</small></span><strong>{userForm.allowedModules.length} {en?'modules':'модуль'}</strong></button></>}
        <label>{en?'Initial password':'Түр нууц үг'}<input type="password" value={userForm.password} onChange={e=>setUserForm({...userForm,password:e.target.value})}/></label>
        <button className="btn-primary full" onClick={createUser} disabled={busy}><UserPlus size={17}/>{busy?(en?'Adding…':'Нэмж байна…'):(platform?(en?'Add account':'Хэрэглэгч нэмэх'):(en?'Add doctor / staff':'Эмч / ажилтан нэмэх'))}</button>
      </article>

      <article className="panel-card access-card"><div className="panel-head"><div><h2>{en?'Access management':'Ажилтны эрх'}</h2><p>{en?'Remove login access when someone leaves. Their history is not deleted.':'Ажлаас гарсан хүний нэвтрэх эрхийг цуцална. Өмнөх түүх устахгүй.'}</p></div><span className="icon-cube"><ShieldCheck/></span></div>
        <div className="access-toolbar"><div className="module-search"><Search size={18}/><input value={userSearch} onChange={e=>setUserSearch(e.target.value)} placeholder={en?'Search staff by name or phone…':'Эмч, ажилтны нэр эсвэл утсаар хайх…'}/></div><label className="tiny-check"><input type="checkbox" checked={showInactive} onChange={e=>setShowInactive(e.target.checked)}/><span>{en?'Show inactive':'Идэвхгүйг харах'}</span></label></div>
        <div className="access-list">{visibleUsers.length===0?<div className="rail-empty">{en?'No users found.':'Хэрэглэгч олдсонгүй.'}</div>:visibleUsers.map(u=>{
          const protectedUser=u.id===profile.id||u.role==='platform_admin'||(!platform&&u.role==='owner');
          return <div className={`access-row ${!u.active?'inactive':''}`} key={u.id}><span className="user-access-avatar">{u.full_name.charAt(0)}</span><div className="access-copy"><b>{u.full_name}</b><span>{u.phone||'—'} · {roleText(u.role)}{u.specialty?` · ${u.specialty}`:''}</span></div><span className={`status-pill ${u.active?'active':'suspended'}`}>{u.active?(en?'ACTIVE':'ИДЭВХТЭЙ'):(en?'INACTIVE':'ИДЭВХГҮЙ')}</span>{u.role==='employee'&&<button className="permission-edit-btn" onClick={()=>{setPermissionUser(u);setPermissionSpecialty(u.specialty||'');setPermissionStaffType(u.staff_type||'other');setPermissionModules(u.allowed_modules||[]);}}><Settings2 size={15}/>{en?'Modules':'Модуль'}</button>}{((platform&&u.role!=='platform_admin')||(!platform&&u.role==='employee'))&&<button className="permission-edit-btn" onClick={()=>{setResetUser(u);setResetPassword('');setMessage('')}}><KeyRound size={15}/>{en?'Reset password':'Нууц үг сэргээх'}</button>}{protectedUser?<span className="protected-access"><ShieldCheck size={15}/>{en?'Protected':'Хамгаалалттай'}</span>:<button className={u.active?'danger-soft':'restore-soft'} disabled={accessBusy===u.id} onClick={()=>setAccessConfirmUser(u)}>{u.active?<><Ban size={16}/>{en?'Remove access':'Эрх цуцлах'}</>:<><RotateCcw size={16}/>{en?'Restore':'Сэргээх'}</>}</button>}</div>
        })}</div>
        <div className="access-explainer"><CheckCircle2 size={18}/><div><b>{en?'Why not delete staff?':'Яагаад ажилтныг шууд устгахгүй вэ?'}</b><p>{en?'Appointments, treatments, payments and audit history stay attached to the correct person. Deactivation blocks login without breaking old records.':'Үзлэг, цаг, төлбөр, audit түүх тухайн хүний нэр дээр хэвээр үлдэнэ. Идэвхгүй болгох нь нэвтрэх эрхийг хаахаас түүхийг устгахгүй.'}</p></div></div>
      </article>
    </div>}

    {tab==='data'&&<section className="admin-excel-panel panel-card">
      <div className="panel-head"><div><h2>{en?'Excel data management':'Excel өгөгдлийн удирдлага'}</h2><p>{en?'Export the live Supabase rows, edit them in Excel, then import the same file to update DentHub.':'Supabase дахь бодит мэдээллийг Excel-ээр татаж, засварлаад буцааж импортлоход DentHub дээр шууд шинэчлэгдэнэ.'}</p></div><span className="icon-cube"><FileSpreadsheet/></span></div>
      <div className="admin-excel-note"><ShieldCheck size={17}/><div><b>{en?'Stable IDs prevent duplicate records':'Тогтвортой ID нь бүртгэлийг зөв тааруулж, давхардлаас хамгаална'}</b><span>{en?'Do not edit clinic_id, patient_id or user_id. Those IDs tell DentHub exactly which record to update.':'clinic_id, patient_id, user_id баганыг өөрчлөхгүй. DentHub яг аль бүртгэлийг засахаа эдгээр ID-аар танина.'}</span></div></div>
      <div className="admin-excel-grid">
        <article className="admin-excel-card"><span className="icon-cube"><Building2/></span><div><b>{en?'Clinic account':'Эмнэлгийн бүртгэл'}</b><p>{platform?(en?'Clinic name, plan and status.':'Эмнэлгийн нэр, багц болон төлөв.'):(en?'Update your clinic name safely.':'Өөрийн эмнэлгийн нэрийг аюулгүй шинэчилнэ.')}</p></div><div className="admin-excel-actions"><button className="btn-light" disabled={busy} onClick={()=>exportManagementExcel('clinics')}><Download size={16}/>{en?'Export':'Татах'}</button><button className="btn-secondary" disabled={busy} onClick={()=>clinicExcelRef.current?.click()}><Upload size={16}/>{en?'Import':'Импорт'}</button><input ref={clinicExcelRef} type="file" accept=".xlsx,.xls" onChange={e=>{const f=e.target.files?.[0];if(f)importManagementExcel('clinics',f);e.currentTarget.value='';}}/></div></article>
        <article className="admin-excel-card"><span className="icon-cube"><UsersRound/></span><div><b>{en?'Patients / clients':'Өвчтөн'}</b><p>{en?'Name, phone, register, birth date, address, emergency phone, gender and notes. Linked patient accounts are kept in sync.':'Нэр, утас, регистр, төрсөн огноо, хаяг, яаралтай үед холбоо барих утас, хүйс, тэмдэглэл. Холбогдсон өвчтөний бүртгэл мөн дагаж шинэчлэгдэнэ.'}</p></div><div className="admin-excel-actions"><button className="btn-light" disabled={busy} onClick={()=>exportManagementExcel('patients')}><Download size={16}/>{en?'Export':'Татах'}</button><button className="btn-secondary" disabled={busy} onClick={()=>patientExcelRef.current?.click()}><Upload size={16}/>{en?'Import':'Импорт'}</button><input ref={patientExcelRef} type="file" accept=".xlsx,.xls" onChange={e=>{const f=e.target.files?.[0];if(f)importManagementExcel('patients',f);e.currentTarget.value='';}}/></div></article>
        <article className="admin-excel-card"><span className="icon-cube"><UserPlus/></span><div><b>{en?'Doctors / employees':'Эмч / ажилтан'}</b><p>{en?'Name, login phone, position, module permissions and active status.':'Нэр, нэвтрэх утас, албан тушаал, модулийн эрх болон идэвхтэй эсэх төлөв.'}</p></div><div className="admin-excel-actions"><button className="btn-light" disabled={busy} onClick={()=>exportManagementExcel('staff')}><Download size={16}/>{en?'Export':'Татах'}</button><button className="btn-secondary" disabled={busy} onClick={()=>staffExcelRef.current?.click()}><Upload size={16}/>{en?'Import':'Импорт'}</button><input ref={staffExcelRef} type="file" accept=".xlsx,.xls" onChange={e=>{const f=e.target.files?.[0];if(f)importManagementExcel('staff',f);e.currentTarget.value='';}}/></div></article>
      </div>
    </section>}

    {clinicModulePickerOpen&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&setClinicModulePickerOpen(false)}><div className="modal-card clinic-module-setup-modal"><header><div><small>{clinicForm.plan}</small><h2>{en?'New clinic module access':'Шинэ эмнэлгийн модулийн эрх'}</h2></div><button onClick={()=>setClinicModulePickerOpen(false)}><X/></button></header><div className="clinic-module-setup-scroll"><ModuleAccessPicker value={clinicForm.enabledModules} onChange={enabledModules=>setClinicForm(v=>({...v,enabledModules}))} lang={lang}/></div><footer><button className="btn-primary" onClick={()=>setClinicModulePickerOpen(false)}><CheckCircle2 size={16}/>{en?'Done':'Боллоо'}</button></footer></div></div>}
    {userModulePickerOpen&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&setUserModulePickerOpen(false)}><div className="modal-card clinic-module-setup-modal staff-module-modal"><header><div><small>{userForm.fullName||userForm.specialty||clinicName}</small><h2>{en?'Staff module access':'Ажилтны модулийн эрх'}</h2></div><button onClick={()=>setUserModulePickerOpen(false)}><X/></button></header><div className="clinic-module-setup-scroll"><ModuleAccessPicker value={userForm.allowedModules} onChange={allowedModules=>setUserForm(v=>({...v,allowedModules}))} lang={lang} availableModules={employeeModules.filter(([key])=>platform||key==='official_documents'||(profile.clinic_modules||[]).includes(key)).map(([key])=>key)} showPlanPresets={false} presets={employeePresets.map(p=>({key:p.key,mn:p.mn,en:p.en,modules:p.modules}))} title={en?'Visible work areas':'Харах ажлын хэсгүүд'} description={en?'Start with a role preset, then switch only the modules this employee actually needs.':'Албан тушаалын бэлэн тохиргоогоос эхлээд тухайн ажилтанд хэрэгтэй модуль дээр л өөрчлөлт хийнэ.'}/></div><footer><button className="btn-secondary" onClick={()=>setUserModulePickerOpen(false)}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={()=>setUserModulePickerOpen(false)}><CheckCircle2 size={16}/>{en?'Done':'Боллоо'}</button></footer></div></div>}
    <ConfirmDialog open={Boolean(accessConfirmUser)} busy={Boolean(accessBusy)} danger={Boolean(accessConfirmUser?.active)} title={accessConfirmUser?(accessConfirmUser.active?(en?'Remove this user’s access?':'Энэ хэрэглэгчийн эрхийг цуцлах уу?'):(en?'Restore this user’s access?':'Энэ хэрэглэгчийн эрхийг сэргээх үү?')):''} description={accessConfirmUser?(accessConfirmUser.active?(en?`${accessConfirmUser.full_name} will no longer be able to sign in. Existing history will be kept.`:`${accessConfirmUser.full_name} системд нэвтрэх боломжгүй болно. Өмнөх үзлэг, төлбөр, түүх устахгүй.`):(en?`${accessConfirmUser.full_name} will be able to sign in again.`:`${accessConfirmUser.full_name} системд дахин нэвтрэх эрхтэй болно.`)):''} confirmLabel={accessConfirmUser?.active?(en?'Remove access':'Эрх цуцлах'):(en?'Restore access':'Эрх сэргээх')} cancelLabel={en?'Cancel':'Болих'} onCancel={()=>!accessBusy&&setAccessConfirmUser(null)} onConfirm={confirmChangeAccess}/>
    {resetUser&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&!resetBusy&&setResetUser(null)}><div className="modal-card permission-modal"><header><div><small>{resetUser.full_name}</small><h2>{en?'Reset password':'Нууц үг сэргээх'}</h2></div><button onClick={()=>!resetBusy&&setResetUser(null)}><X/></button></header><div className="modal-fields"><label>{en?'Temporary password':'Түр нууц үг'}<input autoFocus type="password" value={resetPassword} onChange={e=>setResetPassword(e.target.value)} onKeyDown={e=>e.key==='Enter'&&void resetStaffPassword()} placeholder={en?'At least 8 characters':'8-аас дээш тэмдэгт'}/></label><div className="admin-excel-note"><ShieldCheck size={17}/><div><b>{en?'Use when this user forgot their password.':'Хэрэглэгч нууц үгээ мартсан үед ашиглана.'}</b><span>{en?'Give the temporary password to the user. After signing in they can change it from My Profile.':'Түр нууц үгийг хэрэглэгчид өгнө. Нэвтэрсний дараа Миний мэдээлэл хэсгээс өөрөө шинэ нууц үг сольж болно.'}</span></div></div></div><footer><button className="btn-secondary" onClick={()=>setResetUser(null)} disabled={resetBusy}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={resetStaffPassword} disabled={resetBusy||resetPassword.length<8}>{resetBusy?(en?'Resetting…':'Сэргээж байна…'):(en?'Set temporary password':'Түр нууц үг тохируулах')}</button></footer></div></div>}
    {permissionUser&&<div className="modal-backdrop" onMouseDown={e=>e.currentTarget===e.target&&setPermissionUser(null)}><div className="modal-card permission-modal"><header><div><small>{permissionUser.full_name}</small><h2>{en?'Position & module access':'Албан тушаал ба модулийн эрх'}</h2></div><button onClick={()=>setPermissionUser(null)}><X/></button></header><div className="modal-fields"><label>{en?'Position':'Албан тушаал'}<input value={permissionSpecialty} onChange={e=>setPermissionSpecialty(e.target.value)} placeholder="Шүдний эмч / сувилагч / ресепшн"/></label><label>{en?'Staff type':'Ажилтны төрөл'}<DentSelect value={permissionStaffType} onChange={setPermissionStaffType} options={[{value:'doctor',label:en?'Doctor':'Эмч'},{value:'nurse',label:en?'Nurse':'Сувилагч'},{value:'reception',label:en?'Reception':'Ресепшн'},{value:'cashier',label:en?'Cashier':'Касс'},{value:'finance',label:en?'Finance':'Санхүү'},{value:'inventory',label:en?'Inventory':'Агуулах'},{value:'manager',label:en?'Manager':'Менежер'},{value:'other',label:en?'Other':'Бусад'}]}/></label><div className="wide"><ModuleAccessPicker value={permissionModules} onChange={setPermissionModules} lang={lang} availableModules={employeeModules.filter(([key])=>platform||key==='official_documents'||(profile.clinic_modules||[]).includes(key)).map(([key])=>key)} showPlanPresets={false} presets={employeePresets.map(p=>({key:p.key,mn:p.mn,en:p.en,modules:p.modules}))} title={en?'Visible work areas':'Харах ажлын хэсгүүд'} description={en?'Choose a preset and fine-tune only what this employee needs.':'Бэлэн тохиргоо сонгоод тухайн ажилтанд хэрэгтэй хэсгийг л нэмж, хасна.'}/></div></div><footer><button className="btn-secondary" onClick={()=>setPermissionUser(null)}>{en?'Cancel':'Болих'}</button><button className="btn-primary" onClick={async()=>{if(!configured){setPermissionUser(null);return}const s=getSupabaseBrowser();if(!s)return;setBusy(true);const {error}=await s.from('profiles').update({specialty:permissionSpecialty.trim()||null,staff_type:permissionStaffType,allowed_modules:permissionModules.filter(m=>platform||m==='official_documents'||(profile.clinic_modules||[]).includes(m))}).eq('id',permissionUser.id);setBusy(false);if(error){setMessage(error.message);return}setUsers(list=>list.map(x=>x.id===permissionUser.id?{...x,specialty:permissionSpecialty.trim()||null,staff_type:permissionStaffType,allowed_modules:permissionModules.filter(m=>platform||m==='official_documents'||(profile.clinic_modules||[]).includes(m))}:x));setPermissionUser(null);setMessage(en?'Permissions saved.':'Модулийн эрх хадгалагдлаа.')}} disabled={busy}>{en?'Save':'Хадгалах'}</button></footer></div></div>}
  </div>
}
