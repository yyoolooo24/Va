# DentHub V8.19.2 — Official print clean / exact Word layout

- Removed DentHub/page-title text from the printed official letter.
- Added zero-margin A4 print mode to suppress browser date, URL and page counter headers/footers.
- Moved page margins inside the official A4 sheet so printed output stays clean.
- Matched the supplied Word reference more closely: large upper-left logo, blue organization/contact block, upper-right title, exact № / incoming reference lines, paragraph spacing and signature row.
- Document date remains editable metadata in the toolbar but is not printed because it is not present in the supplied Word layout.
- Body print formatting now treats blank-line separated blocks as paragraphs for a Word-like official layout.
- No SQL migration required.
