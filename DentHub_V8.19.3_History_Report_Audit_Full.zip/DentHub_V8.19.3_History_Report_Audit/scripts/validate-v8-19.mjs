import fs from 'node:fs';

const checks = [
  ['components/OfficialDocumentsWorkspace.tsx', ['Албан бичиг','official-paper','/api/official-documents','Printer','Save']],
  ['app/api/official-documents/route.ts', ['clinic-documents','official-documents','export async function GET','export async function POST','export async function PATCH']],
  ['components/DashboardApp.tsx', ["'official_documents'",'OfficialDocumentsWorkspace']],
  ['lib/subscription.ts', ["'official_documents'", "mn:'Албан бичиг'"]],
  ['app/globals.css', ['DentHub V8.19','official-paper','official-print-root']],
];
let failed=false;
for(const [file,needles] of checks){
  if(!fs.existsSync(file)){console.error(`Missing ${file}`);failed=true;continue}
  const body=fs.readFileSync(file,'utf8');
  for(const needle of needles){if(!body.includes(needle)){console.error(`${file}: missing ${needle}`);failed=true}}
}
if(failed)process.exit(1);
console.log('DentHub V8.19 validation passed.');
