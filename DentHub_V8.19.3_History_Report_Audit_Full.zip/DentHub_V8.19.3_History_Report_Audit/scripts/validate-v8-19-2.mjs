import fs from 'node:fs';
const component=fs.readFileSync('components/OfficialDocumentsWorkspace.tsx','utf8');
const css=fs.readFileSync('app/globals.css','utf8');
const checks=[
 ['official module',component.includes('OfficialDocumentsWorkspace')],
 ['blank print title',component.includes("document.title=''" )],
 ['number line no printed date',component.includes('official-print-number-rule') && !component.includes('official-print-number-line"><span>{displayDate')],
 ['A4 zero print margin',css.includes('@page{size:A4 portrait;margin:0}')],
 ['A4 owned padding',css.includes('padding:38mm 28mm 24mm')],
 ['clean print root',css.includes('width:210mm;min-height:297mm')],
];
let failed=false;for(const [name,ok] of checks){console.log(`${ok?'✓':'✗'} ${name}`);if(!ok)failed=true}if(failed)process.exit(1);console.log('DentHub V8.19.2 validation passed.');
