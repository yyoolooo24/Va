# V8.19 setup

No new Supabase SQL migration is required.

Deploy normally:

```bash
npm install
npm run validate:v8.19
npm run build
npx vercel --prod
```

The module uses the existing `clinic-documents` Supabase Storage bucket and `SUPABASE_SERVICE_ROLE_KEY` already used by DentHub server APIs.
